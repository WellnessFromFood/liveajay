

<?php
class Billy extends CI_Controller {
    
    
    public $data = array();
    public $msg = array();

 	public function __construct()
	{
        parent::__construct();
        $this->load->helper('helper');
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
			
		}
		
		
		$this->data['page'] = 9;
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->load->library('talentlmsapi');
    }
    
    
    public function fixUser()
    {
        //The goal here is to add additional row or rows back to the diets_plan_mapping table
        //If we are given a startDay of 2, then we will add rows to diets_plan_mapping_table for 3, 4, 5, 6, and 7 of the given week
        //We determine how to populate the table with information in the customer_diets_plan - previously entered data from the user
        
        echo 'We are in fixUser <br>'; 
        $custid = 977;
        $week = 32;
        $startDay = 3;
        $this->fixThisUser($custid, $week, $startDay);
        
    }
    
    public function fixThisUser($custid, $week, $startDay)
    {
        /*
        $sql = "SELECT * FROM customer_diets_plan WHERE customer_id=" . $custid . ' and weeks=' . $week . ' and week_wise_days=' . $startDay;
        
        $usersData = $this->common_model->solveCustomQuery($sql);
        
        $detailsId = $usersData[0]->id;
        
        $dataDetailSql = "SELECT * FROM customer_diets_plan_desc WHERE customer_diets_plan_id = ". $detailsId;
        
        $dataDetails = $this->common_model->solveCustomQuery($dataDetailSql);
        
        echo '$dataDetails is <pre>'; print_r($dataDetails);
    */    
    
    
        $endDay = 7;
        $messageId = 79;
        $netgram_id = 142;
        $carb=1;
        $hunger=0;
        $pressure=1;
        $sugar=1;
        $updatedBy = 'Repair';
        $updateDate = date("m/d/Y");
        
        
        
        
        for ($ith=$startDay; $ith<8; $ith++)
        
        {
            echo 'This is the ' . $ith . ' time thru the loop <br>';
             $newUserData = array(
                                    'mapping_id' => 1,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 2,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
           // echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 3,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 5,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 6,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 7,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 9,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 10,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
            $newUserData = array(
                                    'mapping_id' => 12,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 13,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 14,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 15,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
                                    
           
            $newUserData = array(
                                    'mapping_id' => 16,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 17,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 18,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 19,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 20,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
            $this->common_model->save('diets_plan_mapping', $newUserData);
           
            $newUserData = array(
                                    'mapping_id' => 21,
                                    'customer_id' => $custid,
                                    'message_id' => $messageId,
                                    'netgram_id' => $netgram_id,
                                    'allowmeet_id' => 0,
                                    'questionnaire_id' => 0,
                                    'week_id' => $week,
                                    'day_id' => $ith,
                                    'diet_net_carb_val' => $carb,
                                    'diet_hunger_val' => $hunger,
                                    'diet_blood_pressure' => $pressure,
                                    'diet_blood_sugar_level' => $sugar,
                                    'updated_by' => $updatedBy,
                                    'updated_date' => $updateDate);
                        
            //echo '$newUserData is <pre>'; print_r($newUserData); 
                       
           $this->common_model->save('diets_plan_mapping', $newUserData);  
            
        }
        
    }
    
    
    
    
    
    
    
    public function fix()
    {
        
        echo "here we are in fix";
        
        $userSql = 'SELECT * from user WHERE status=1 and role_type=3';
        $users = $this->common_model->solveCustomQuery($userSql);
        
        echo "We found " . count($users);
        
        //for each user - check to see if they have any records in the mapping table - keep count
        
        
        foreach ($users as $thisUser)
        {
            
            $sql = 'SELECT * FROM diets_plan_mapping where week_id=40 and day_id=1 and customer_id=' . $thisUser->id;
            
            $thisData = $this->common_model->solveCustomQuery($sql);
            if (count($thisData) > 0 )
            {
                foreach ($thisData as $eachRow)
                {
                    echo $eachRow->mapping_id . '<br>';
                    
                    //create a new row in the grad_diets_plan_mapping
                    
                    $newUserData = array(
                                            'mapping_id' => $eachRow->mapping_id,
                                            'customer_id' => $eachRow->customer_id,
                                            'message_id' => $eachRow->message_id,
                                            'netgram_id' => $eachRow->netgram_id,
                                            'allowmeet_id' => $eachRow->allowmeet_id,
                                            'extraMeeting' => $eachRow->extra_metting,
                                            'questionnaire_id' => $eachRow->questionnaire_id,
                                            'admin_msg_id' => $eachRow->admin_msg_id,
                                            'week_id' => -1,
                                            'day_id' => -1,
                                            'dietNetCarb_val' => $eachRow->diet_net_carb_val,
                                            'dietHunger_val' => $eachRow->diet_hunger_val,
                                            'dietBloodPressure_val' => $eachRow->diet_blood_pressure,
                                            'dietBloodSugar_val' => $eachRow->diet_blood_sugar_level);
                    
                   //echo '$newUserData is <pre>'; print_r($newUserData); 
                   
                   $this->common_model->save('grad_diets_plan_mapping', $newUserData);
                   
                    
                }  
            }
            else
            {
                echo 'Do this one by hand ' . $thisUser->id . '<br>';
            }
            //echo 'Found '. count($userData) . ' records for ' . $thisUser->id .'<br>';
        }
        
        
        
        $sql = "SELECT * FROM diets_plan_mapping where customer_id =" . "780 and week_id =40" . " and day_id =1";
        $thisData = $this->common_model->solveCustomQuery($sql);
        
        
        
        
        
        
        
        //echo '<br> Found $thisData is <pre>'; print_r($thisData);
            
            
            
                            
        
        
        
        
        
        
        
    /*    
        
        
        $user_data = array(
						'first_name' => $firstName,
						'last_name'  => $lastname,
						'emailid' => $emailid,
						'contact_no' => $phoneNo,
						'number_week' =>$week,
						'created_date' => $currentDate,
						'status' => '1',
						'role_type' => 3,
						'hash' => $hash = $thisHash,
						'active' => 1,
						'nag_email' => 1,
						'cheerleader_email' => 1,
						'is_special' => $special,
						'updated_date' => $time);
						*/
					                                    //echo 'about to save the user for the first time <pre>'; print_r($user_data);
					
					
					/*********** Create a user *************/
					//Save the user data in the user table
				//	$this->common_model->save('user',$user_data);
        
        
        
        
        
        
        
        
        
    }
    
    
    
    
    public function testDate()
    {
        $custid=787;
        $aDate = $this->common_model->getRow('user', 'created_date', array('id'=>$custid));
        
        echo '$aDate is <pre>'; echo $aDate->created_date;
        $strDate = $aDate->created_date;
        
        $newDate = $this->common_model->getDateForWeekDayStart($strDate, 2, 5);
        
        echo '$newDate is <pre>'; print_r($newDate);
        echo '<br>' . date('m/d/Y H:i:s', $newDate); 
        
        
    }
    
    public function testBlog()
    {
        $none='';
        $test = $this->common_model->getNSeasonalBlogsOtherThan(2, $none);
        echo 'We found in $test <pre>'; print_r($test); 
        
        
    }
    
    
    
    public function testDBcall()
    {
        $custid = 787;
        $ans = $this->common_model->customer_diets_info2($custid);
		//echo '<br> Just called customer_diets_info2 <br>';
		//	                        echo '<pre>'; print_r($ans); 
		
				
		 $realWeek = $ans['realWeek'];
		 $gradStatus = $ans['gradStatus'];
		        
		                            //echo '<br> realWeek is '. $realWeek;
		        
		        
		 $customer_diets_info = $ans['editPattern'];
		 
		 //echo '$customer_diets_info is <pre>'; print_r($customer_diets_info); die;
        
        //Net carb information
        
        
  		$gramcond=array('gm.customer_id'=>$customer_diets_info[0]->customer_id);
  		
  		echo '$gramcond is <pre>'; print_r($gramcond); 
  		
		$gramfield='(m.Message) AS Message';
		
		echo '<br> $gramfield is ' . $gramfield . '<br>';
		
		$gramjoin=array(
    					array(
    						'join_table'=>'grad_diets_plan_mapping as gm',
    						'on_first_table'=>'m.MessageID',
    						'on_second_table'=>'gm.netgram_id'));
    						
    						
    	echo '$gramjoin is <pre>'; print_r($gramjoin);
                						
                //Get the gram message
 	 			$data['net_gram']=  $this->common_model->getJoinDataTest("messagecenterposttable as m", 
 	 			                                                            $gramcond, 
 	 			                                                            $gramfield, 
 	 			                                                            $gramjoin,
 	 			                                                            '',
 	 			                                                            '',
 	 			                                                            '',
 	 			                                                            '',
 	 			                                                            'gm.netgram_id'); 
 	 		echo '$data[net_gram] is <pre>'; print_r($data['net_gram']);
    }
    
    
    public function testNotification()
    {
       // echo 'Yes - got here'; die;
        
        $userData = Array(
                'first_name' =>"Billy",
                'last_name' =>"Pruchno",
                'emailid' =>"billypruchno@outlook.com",
                'contact_no' =>"313 357 1412");
                
                
        $this->sendNotificationOfSpecialSignup($userData);
        
    }
    
    public function checkThis()
    {
        $arr1='';
        $array1= implode(',',$arr1);
        echo '$array1 is <pre>'; print_r($array1);
        
    }
    
    public function arrayToObj()
    {
        $custid = 2;
        $weeksToUse = 41;
        $days_info['day'] = 5;
        
        
        $days_info_qry = array(
                'status' => 1,
                'labelid' => 1,
                'input_type' => 1,
                'diet_name' => "Breakfast (in grams)",
                'comments' => "",
                'staff_comments' => "", 
                'week_id' => $weeksToUse,
                'day_id' => $days_info['day'],
                'diet_plan_value' => 30,
                'customer_diets_plan_id' =>'' ,
                'diet_plan_id' => 1,
                'customer_id' => $custid,
                'message_id' => 1,
                'netgram_id' => 140,
                'allowmeet_id' => 0,
                'questionnaire_id' => 0,
                'admin_msg_id' =>0);
                
        $obj = (object) $days_info_qry;
        
        echo 'object is ' . print_r($obj);
        
        
        
        
    }
    
    
    
    
    //copied here for testing
    public function sendNotificationOfSpecialSignup($userData)
		{
		    //echo 'You just called sendNotificationOfSpecialSignup with <br>'; 
		    //echo '<pre>'; print_r($userData); die;
		    
		    //sample idea for now....
		    $startTemplate ="<p>Dear,</p>
				<p>" . $userData['first_name'] ." has just signed up.  From their intake form, they specified that they have recently taken one of the medicines on the Medical Exclusion list. 
				                    Please Contact them as soon as possible to get their local provider. phone no ". $userData['contact_no'] ."</p>";

						$subData = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>34));
						$startTemplate .= $subData->email_description;
					   
						$sub= $subData->subject_txt;
						$staff = $this->common_model->getRows('user','first_name,emailid',array('role_type'=>2, 'status'=>1));
						$staff_data=array();
						if(!empty($staff))
						{
							foreach ($staff as $svalue) 
							{
								$staff_data[] = array('email'=>$svalue->emailid,'name'=>$svalue->first_name);
							}
						}
						
						//
						//echo 'About to send email to <br>';
						//echo '<pre>'; print_r($staff_data); 
						//echo '<br>'; echo $startTemplate; die;
						$this->common_model->sendMultipleMail($staff_data,$sub,$startTemplate);
		    
		}
		
    
    
    public function show(){
        $testArray = Array('2020/09/04', '19:50:34');
        
        echo '<pre>'; print_r($testArray);
        $firstVal = date('Y-m-d H:i:s');
        echo '$firstVal = '. $firstVal . '<br>';
       
        $timeValStr = $testArray[0]." ".$testArray[1];
        echo '$timeValStr = ' . $timeValStr . '<br>';
        $test = strtotime($timeValStr);
        echo '$test = ' . $test;
        
        $tester = 1228;
        $userdata = $this->common_model->getRow('user','emailid',array('id'=>$tester));
        echo '<pre>'; print_r($userdata);
        //$newTime = date('Y-m-d H:i:s',strtotime(date('Y-m-d H:i:s'),$testArray[0]." ".$testArray[1]));
        
    }
    
    public function test_form(){
        
        //$this->load->view('backoffice/customer/customer_view', $this->data);
        $this->load->view('backoffice/billy_first_view', $this->data);
        //return view('backoffice/billy_first_view');
    }
    public function acceptData(){
        
        //echo "Now get data from the 'form'" ; 
        //echo '<pre>'; print_r($this);
        echo '<br>';
        $email = $this->input->post('email');
        echo "Email is " .$email;
        echo '<br>';
        $name =$this->input->post('name');
        echo "Name is " . $name;
        echo '<br>';
        
        if(set_value('name'))
        {
            echo 'It is true';
        }
        else
        {
            echo 'It is false';
        }
        
        
        if(isset($name))
        {
            echo 'Isset is true';
        }
        else
        {
            echo 'Isset is false';
        }
        
        
        /*
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-1');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-2');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-3');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-4');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-5');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-6');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-7');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-8');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-9');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-10');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-11');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
        $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-12');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
         $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-13');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
         $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-14');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
         $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-15');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
         $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-16');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
         $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-17');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
         $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-18');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
         $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-19');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
        
         $mydaysInfo = $this->calculate_date('2020-08-1', '2020-08-20');
        echo 'Week is: '; print_r($mydaysInfo); echo '<br>';
    */
        
        
    }
    
   public function calculate_date($get_created_date, $startDate='')
  
   //expected format or $get_created_date = "2020-07-12"
   //base function from common
   //Added a 2nd optional parameter for testing
   //Given the time that the user was created ($get_created_date) - determine the week / day 
   //   of the user based on current time (or the date passed in).
   
	{
		$nodays='';
		$noweek='';
		$days_info=array();

        if (isset($startDate) && !empty($startDate)){
            $date1 = $startDate;
            echo "Using the given date of " . $date1; echo '<br>';
        }
        else
        {
            
            $date1 = date('Y-m-d H:i:s'); 
            echo "Using the current date of " . $date1; echo '<br>';    
        }
		
		$date2 =  $get_created_date;
		$diff = strtotime($date1) - strtotime($date2);
		$days = ceil(($diff)/ (60*60*24));

		if($days >7){
			$noweek =  number_format($days/7,1);
			$totaldays= $days%7;
			$val = explode(".",$noweek);
			if($totaldays==0){
				$days_info['day']=7;
				$days_info['week'] = $val[0];
			}else{
				$days_info['day'] = $totaldays;
				$days_info['week'] = $val[0]+1;
			}
			//$days_info['week'] = $val[0]+1;
		}else{
			$days_info['day'] = $days;
			$days_info['week']= 1;
		}
		
		echo 'User Created date = '. $get_created_date; echo '<br>';
		echo 'date to test = '. $date1; echo '<br>';
		
		echo '<pre>'; print_r($days_info);
		return $days_info;


	}
    
    
    public function test_date()
    {
        
        $thisDate = "9/22/2020";
        echo 'Input: $thisDate is '. $thisDate . '<br>';
        
        $ans = calculate_TheWeek($thisDate);
        echo '<pre>' . 'ans = '; print_r($ans); echo '<br>';
        
        
        $thisDate = "9/21/2020";
        echo 'Input: $thisDate is '. $thisDate . '<br>';
        
        $ans = calculate_TheWeek($thisDate);
        echo '<pre>' . 'ans = '; print_r($ans); echo '<br>';
        
        
        $thisDate = "9/19/2020";
        echo 'Input: $thisDate is '. $thisDate . '<br>';
        
        $ans = calculate_TheWeek($thisDate);
        echo '<pre>' . 'ans = '; print_r($ans); echo '<br>';
        
        
        
        $thisDate = "9/14/2020";
        echo 'Input: $thisDate is '. $thisDate . '<br>';
        
        $ans = calculate_TheWeek($thisDate);
        echo '<pre>' . 'ans = '; print_r($ans); echo '<br>';
        
        $thisDate = "9/13/2020";
        echo 'Input: $thisDate is '. $thisDate . '<br>';
        
        $ans = calculate_TheWeek($thisDate);
        echo '<pre>' . 'ans = '; print_r($ans); echo '<br>';
        
        
        
        
        
        
    }
    
    
    
    
    
    public function test_email(){

	$user_data= $this->common_model->getRows('user','type,hash',array('emailid'=>"billypruchno@outlook.com"));
	$mail = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>21,'status'=>1));

	$data['password'] ="Your_Password";//$this->input->post('password');
	$data['email'] ="billypruchno@outlook.com";//$this->input->post('email');
	$data['dynamic_content'] = $mail->email_description;
	$data['full_name']=$name=ucwords(strtolower("Billy"));
	$massege = $this->load->view('frontend/email/backoffice_user_mail',$data,true);
	echo $massege;exit;
	$subject ="Welcome to Wellness - does this work?";

	$email_dat = array(
	'to'=>$this->input->post('email'),
	'subject'=>$subject,
	'msg'=>$massege);
	$res = $this->common_model->Send_GetStarted_Mail($email_dat);
    }
    
    public function testThis(){
        
        echo "Hello there - Billy" ; 
        $chkcarb_hunger = $this->common_model->check_hunger_level(6,1,1156);
        echo "<br>";
        echo  $chkcarb_hunger;
        
        
    }
    
    public function what(){
        echo "Hello What" ; 
       // $customer_diets_info = $this->common_model->customer_diets_info(1156);
      //  echo '<pre>'; print_r($customer_diets_info);die;
      
      
      echo '<pre>'; print_r($this->session->userdata('customers'));
      
       
    }
    
    
    
    	public function testEmail()
	{
	    $userId = 1344;
	    
	    //$user = $this->common_model->getRow('user','',array('id'=>$userId));
	    //$templateId = 309;
	    $this->sendThisEmail($userId, 24);
	    
        echo 'Now check to see if the email is sent and arrives';	    

	    
	}
    
    
    public function sendThisEmail($user="",$templateId=""){
		$CI = & get_instance();
		echo '$user is ' . '<pre>'; print_r($user);
		
		$userdata = $CI->common_model->getRow('user','emailid',array('id'=>$user));
		$content = $CI->common_model->getRow('send_email','subject_txt,email_description',array('id'=>$templateId,'status'=>1));
		if(!empty($userdata) && !empty($content)){
			$email_dat = array(
				'to'=>$userdata->emailid,
				'subject'=>$content->subject_txt,
				'msg'=>$content->email_description
			);
			$CI->common_model->Send_GetStarted_Mail($email_dat);
		}	
	}
    
    
    
    
    
    public function testHere(){
        
        $customer_diets_info = $this->common_model->customer_diets_info(1156);
        
             $label1=array();
			$label2=array();
			$label3=array();
			$label4=array();
			if(!empty($customer_diets_info))
			{
				foreach($customer_diets_info as $val){
					if($val->input_type==1){
						if($val->status == 1)
						{
							$label1[$val->labelid]=$val;
						}
						
					} 
					else if($val->input_type==2)
					{
						if($val->status == 1)
						{
							$label2[$val->labelid]=$val;
						}

					}
					else if($val->input_type==3)
					{
						if($val->status == 1)
						{
							$label3[$val->labelid]=$val;
						}

					}
					else{
						if($val->status == 1)
						{
							$label4[$val->labelid]=$val;
						}
						
					}
				}

				$data['label1'] = $label1;
				$data['label2'] = $label2;
				$data['label3'] = $label3;
				$data['label4'] = $label4;
			 	$data['weekid']= $customer_diets_info[0]->week_id;
				$data['dayid'] = $customer_diets_info[0]->day_id;
				$data['message_id'] = $customer_diets_info[0]->message_id;
				$data['netgram_id'] = $customer_diets_info[0]->netgram_id;
				$data['allowmeet_id'] = $customer_diets_info[0]->allowmeet_id;
				$data['questionnaire_id'] = $customer_diets_info[0]->questionnaire_id;
			    $data['lession_id'] = $customer_diets_info[0]->admin_msg_id;
    }
    
    
    echo '<pre>'; print_r($data);die;
    
    
    }
    public function testMe(){
        echo "Hello there - Billy" ; 
        //echo <br>;
        $total_get_sql = 'SELECT count(id) as total FROM blog where status=1';
        $total_get = $this->common_model->solveCustomQuery($total_get_sql);
        echo "Looks like we have " .$total_get[0]->total ." Blogs";
        
        
        $testimonial_sql = "SELECT * FROM blog t  order by blog_type asc " ;
        $this->data['recs'] = $this->common_model->solveCustomQuery($testimonial_sql);
        $records_count = $total_get[0]->total;
        echo $records_count;
        
        $first = mt_rand(0,$records_count);
        $second = mt_rand(0,$records_count);
        if ($second == $first)
        {
           $second = mt_rand(0,$records_count);
        }
        $third = mt_rand(0,$records_count);
        
        if ($third == $first or $third == $second){
            $third = mt_rand(0,$records_count);
        }
        
        $blog_results = $this->data['recs'];
        
        echo "<br> We found that the type is " .gettype($blog_results);
        
        echo "<br>First is " .$first;
        echo "<br>&nbsp ".$blog_results[$first]->title;
        echo "<br>Second is " .$second;
        echo "<br>&nbsp ".$blog_results[$second]->title;
        echo "<br>Third is " .$third;
        echo "<br>&nbsp ".$blog_results[$third]->title;
        
        
        $ans = $this->common_model->get2RandomBlogs();
        
        
        echo '<pre>'; print_r($ans);die;
    }   
}
