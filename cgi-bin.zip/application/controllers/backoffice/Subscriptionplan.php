<?php

class Subscriptionplan extends CI_Controller {
	public $data = array();

    public $msg = array();

	

 	public function __construct()

	{

        parent::__construct();

		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)

		{

			redirect('backoffice/login');

			exit();

		}

		$this->data['page'] = 9;

		$this->data['page_form_id']=42;

		$this->data['page_module_id']=4;

		$this->data['live_user_id'] = $this->session->userdata('admin')->id;

        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');

        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');

        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);

        $this->output->set_header('Pragma: no-cache');

    }

	public function show($start=0)

	{

		$this->data['page_form_id']=42;

		$this->data['page_module_id']=4;

		($start)?($limit_from=$start):($limit_from=0); $limit=100;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage Subscription Plan</li></ol>';

		$cond='';

		$url_cond='';$con='';		

		$conds=array();			

		$customer="SELECT * FROM subscriptionplan ".$cond." order by id desc LIMIT ".$limit_from.",".$limit;

		$this->data['recs'] = $this->common_model->solveCustomQuery($customer);		

		$this->data['action_customer_search_submit']=base_url('backoffice/customer/show');		

		$this->load->view('backoffice/subscriptionplan/scriptionplan_view', $this->data);

	}

	public function update($user_id=0){			

			   $user_id=base64_decode($user_id);			

				if($this->_validData($user_id)){				

					$this->data = array(

						'name' => $this->input->post('add_subscription_plan'),

						'price' => $this->input->post('add_subscription_price'),

						'coupon_code' => $this->input->post('coupon_code'),

						'first_month' => $this->input->post('first_month'),
						'second_month_charge' => $this->input->post('second_month'),
						'disconut_charge' => $this->input->post('disconut_charge'),

						'description' => $this->input->post('description'),
						'term_and_policy' => $this->input->post('term_description'),


						'status' => $this->input->post('status'),

						'created_date' => date('Y-m-d,H:i:s'),

						'created_by' => $this->data['live_user_id']

					);

					

			if((bool)$this->common_model->update('subscriptionplan',$this->data, array('id'=>$user_id)) === TRUE){

							

				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');

				$this->session->set_flashdata($this->msg);

				redirect('backoffice/subscriptionplan/show');

			}else{

				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

				$this->session->set_flashdata($this->msg);

				return $this->edit($user_id);

			}

		}else{

			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

			$this->session->set_flashdata($this->msg);

			return $this->edit(base64_encode($user_id));

		}

	}	

	public function add()

	{

		$this->data['page'] = 1922;

		$this->data['page_form_id']=42;

		$this->data['page_module_id']=4;

		$campus_ids=array();

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Subscription Plan</li></ol>';			

		$this->data['act'] = site_url('backoffice/subscriptionplan/save');

        $this->data['submit'] = lang('SAVE_BTN');





        $maxdisplay = "SELECT max(display_order) as maxdisplay FROM createform where form_type=1"; 

		$maxdisplay = $this->common_model->solveCustomQuery($maxdisplay);

		$this->data['maxdis'] = $maxdisplay[0]->maxdisplay+1;

        $this->load->view('backoffice/subscriptionplan/add_scriptionplan_view', $this->data, FALSE);

	}

	

	public function save(){

			if($this->_validData()){

				$this->data = array(

					'name' => $this->input->post('add_subscription_plan'),

					'price' => $this->input->post('add_subscription_price'),
					'coupon_code' => $this->input->post('coupon_code'),

					'description' => $this->input->post('description'),
					'term_and_policy' => $this->input->post('term_description'),


					'status' => $this->input->post('status'),

					'first_month' => $this->input->post('first_month'),
					'second_month_charge' => $this->input->post('second_month'),
					'disconut_charge' => $this->input->post('disconut_charge'),


					'created_date' => date('Y-m-d,H:i:s'),

					'created_by' => $this->data['live_user_id']

				);

			$user_id = $this->common_model->save('subscriptionplan',$this->data);

			if($user_id!=''){				

				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');

				$this->session->set_flashdata($this->msg);

				redirect('backoffice/subscriptionplan/show');

			}else{

				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

				$this->session->set_flashdata($this->msg);

				return $this->add();

			}

		}

		else

		{

			return $this->add();

		}

	}

	public function edit($user_id=0){

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/subscriptionplan/show').'">Manage Subscription Plan</a></li><li class="active">Edit customer</li></ol>';

		$user_id=base64_decode($user_id);

		

		$user_sql="SELECT * FROM subscriptionplan WHERE id=".$user_id;

		$this->data['rec'] = $this->common_model->solveCustomQuery($user_sql);

		

		$this->data['act'] = site_url('backoffice/subscriptionplan/update/'.base64_encode($user_id));

		$this->data['submit'] = lang('UPDATE_BTN');

		$this->load->view('backoffice/subscriptionplan/add_scriptionplan_view', $this->data, FALSE);

	}

	private function _validData($id=0)

	{

		$this->form_validation->set_rules('add_subscription_plan', 'Add subscription', 'trim|required|strip_tags');

		$this->form_validation->set_rules('add_subscription_price', 'Add subscription price', 'trim|required|strip_tags');

		return $this->form_validation->run();

    }

	private function hash_password($password) 

	{

		return password_hash($password, PASSWORD_BCRYPT);	

	}

	private function attributes_validdata($id=0)

	{

		$this->form_validation->set_rules('attributelist', 'Add Attribute', 'trim|required|strip_tags');		

		return $this->form_validation->run();

    }

	private function attributes_validdata12($id=0)

	{

		$this->form_validation->set_rules('add_attribute_name', 'Add Attribute', 'trim|required|strip_tags');		

		return $this->form_validation->run();

    }

	public function attributes_show($start=0)

	{

		$this->data['page_form_id']=47;

		$this->data['page_module_id']=19;

		($start)?($limit_from=$start):($limit_from=0); $limit=100;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage Subscription Plan</li></ol>';

		$cond='';

		$url_cond='';$con='';		

		$conds=array();			

		$customer="SELECT * FROM attribute ".$cond." order by id desc LIMIT ".$limit_from.",".$limit;

		$this->data['recs'] = $this->common_model->solveCustomQuery($customer);		

		$this->data['action_customer_search_submit']=base_url('backoffice/customer/show');		

		$this->load->view('backoffice/subscriptionplan/attributes_show', $this->data);

	}

	public function show_mapping_attributes($start=0)

	{

		$this->data['page_form_id']=45;

		$this->data['page_module_id']=4;

		($start)?($limit_from=$start):($limit_from=0); $limit=100;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage Subscription Plan</li></ol>';

		$cond='';

		$url_cond='';$con='';		

		$conds=array();			

		$customer="SELECT * FROM attribute ".$cond." order by id desc LIMIT ".$limit_from.",".$limit;

		$this->data['recs'] = $this->common_model->solveCustomQuery($customer);		

		$this->data['action_customer_search_submit']=base_url('backoffice/customer/show');		

		$this->load->view('backoffice/subscriptionplan/show_mapping_attributes', $this->data);

	}

	public function add_mapping_attributes()

	{

		

		//echo $this->session->userdata('formid');

		//echo '<pre>'; print_r($this->input->post());die;

		/*

		Array

		(

			[0] => stdClass Object

				(

				[id] => 2

				[form_id] => 2

				[attribute_id] => 1

				[attribute_values] => Fullname

				[status] => 1

				[created_date] => 2018-12-28

				[created_by] => 1

			)



		)

		*/

		

		$uriid = $this->uri->segment(4);

		$this->data['page'] = 1922;

		$this->data['page_form_id']=25;

		$this->data['page_module_id']=3;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Subscription Plan</li></ol>';			

		$this->data['act'] = site_url('backoffice/subscriptionplan/save_mapping_attribute/'.$this->uri->segment(4));

        $this->data['submit'] = lang('SAVE_BTN');

		//$this->data['generateformname'] = $this->generateform($this->session->userdata('formid'));

		if(!empty($this->uri->segment(4)))

		{

			 $this->data['formid'] = $this->session->unset_userdata('formid');

			 $this->data['formid'] =$this->uri->segment(4);

		}else{

			$this->data['formid'] = $this->session->userdata('formid');

		}

		$mapping_attributes="SELECT * FROM attribute  where status=1 order by id asc";

		$this->data['attributelist'] = $this->common_model->solveCustomQuery($mapping_attributes);

        $this->load->view('backoffice/subscriptionplan/add_mapping_attribute_view', $this->data, FALSE);

	}

	/* public function createnewform($array){

		

		foreach($array as $k=>$val){ 

		

			if($val->attribute_id==1){				

				$html ='<table id="menu_name_datatable1" class="table table-bordered table-striped">';

						$html .='<thead>';

							$html .='<tr><th width="22">S. No</th></tr>';

						$html .='</thead>';

						$html .='<tbody>';									

							$html .='<tr><td></td></tr>';					

						$html .='</tbody>';

				$html .='</table>';

			}

			//echo '<pre>'; print_r($val);die;

		}

		

	} */



	public function add_attributes()

	{

		$this->data['page'] = 1922;

		$this->data['page_form_id']=47;

		$this->data['page_module_id']=19;

		$campus_ids=array();

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Subscription Plan</li></ol>';			

		$this->data['act'] = site_url('backoffice/subscriptionplan/save_attributes');

        $this->data['submit'] = lang('SAVE_BTN');

        $this->load->view('backoffice/subscriptionplan/add_attribute_view', $this->data, FALSE);

	}	

	public function save_mapping_attribute($id=''){		

		//echo '<pre>'; print_r($this->input->post());die;		

		if($this->attributes_validdata()){ 

		$allfieldname = $this->input->post('field_name');

		$alllabelname = $this->input->post('label_name');

		if(!empty($allfieldname))

		{

			foreach($allfieldname as $key=>$fname)

			{

				$attrlist = $this->input->post('attributelist');

				if($key>0)

				{

					$attrlist = 2;

				}

				if($attrlist ==7)

				{

					$fname =  $fname."_q";

				}

				$this->data = array(

					'attribute_id' => $attrlist,

					//'form_heading' => $this->input->post('form_heading'),

					'label_name' =>trim($alllabelname[$key]),

					'form_id' => $this->input->post('formid'),

					'field_name' =>trim($fname),

					'attribute_values' =>implode(',',$this->input->post('field_option')),

					'status' => $this->input->post('status'),

					'created_date' => date('Y-m-d,H:i:s'),

					'created_by' => $this->data['live_user_id']

				);

			$user_id = $this->common_model->save('mapping_attribute',$this->data);

			

			}

			if($user_id!=''){				

				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');

				$this->session->set_flashdata($this->msg);

				redirect('backoffice/subscriptionplan/add_mapping_attributes/'.$id);

			}else{

				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

				$this->session->set_flashdata($this->msg);

				return $this->add_mapping_attributes();

			}

		}

				

		}

		else

		{

			return $this->add_mapping_attributes();

		}

	}		

	public function updatemedicalform()

	{

				$formid = $this->input->post('formid');

				



				$data = array(

					'allow_medical_frm' =>0

				);

				

				if($formid =='cancel')

				{

					$update1= $this->common_model->update("createform",$data);

				}

				else

				{

					$update1= $this->common_model->update("createform",$data);

				}

				

			

				if($update1)

				{

					$updatedata1 = array(

					'id' => $this->input->post('formid')

					);



					$data1 = array(

					'allow_medical_frm' =>$this->input->post('formid')

				);

			

				$update1= $this->common_model->update("createform",$data1,$updatedata1);

				}



			if(!empty($update1)){

				echo 1;exit;

			}else{

				echo 0;exit;

			}

		

	}

	public function save_attributes(){

			if($this->attributes_validdata12()){

				$this->data = array(

					'attribute_name' => $this->input->post('add_attribute_name'),

					'status' => $this->input->post('status'),

					'created_date' => date('Y-m-d,H:i:s'),

					'created_by' => $this->data['live_user_id']

				);

			$user_id = $this->common_model->save('attribute',$this->data);

			if($user_id!=''){				

				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');

				$this->session->set_flashdata($this->msg);

				redirect('backoffice/subscriptionplan/attributes_show');

			}else{

				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

				$this->session->set_flashdata($this->msg);

				return $this->add_attributes();

			}

		}

		else

		{

			return $this->add_attributes();

		}

	}

	public function edit_attributes($user_id=0){

		$this->data['page_form_id']=47;

		$this->data['page_module_id']=19;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/subscriptionplan/show').'">Manage Subscription Plan</a></li><li class="active">Edit customer</li></ol>';

		$user_id=base64_decode($user_id);

		

		$user_sql="SELECT * FROM attribute WHERE id=".$user_id;

		$this->data['rec'] = $this->common_model->solveCustomQuery($user_sql);

		

		$this->data['act'] = site_url('backoffice/subscriptionplan/update_attribute/'.base64_encode($user_id));

		$this->data['submit'] = lang('UPDATE_BTN');

		$this->load->view('backoffice/subscriptionplan/add_attribute_view', $this->data, FALSE);

	}



		public function update_attribute($user_id=0){			

				$user_id=base64_decode($user_id);			

				if($this->attributes_validdata($user_id)){				

					$this->data = array(

					'attribute_name' => $this->input->post('add_attribute_name'),

					'status' => $this->input->post('status'),

					'created_date' => date('Y-m-d,H:i:s'),

					'created_by' => $this->data['live_user_id']

				);					

			if((bool)$this->common_model->update('attribute',$this->data, array('id'=>$user_id)) === TRUE){

							

				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');

				$this->session->set_flashdata($this->msg);

				redirect('backoffice/subscriptionplan/attributes_show');

			}else{

				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

				$this->session->set_flashdata($this->msg);

				return $this->edit_attributes($user_id);

			}

		}else{

			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

			$this->session->set_flashdata($this->msg);

			return $this->edit_attributes(base64_encode($user_id));

		}

	}

	public function delete_attributes($cust_id=0)

	{

		if((bool)$this->common_model->delete('attribute',array('id'=>base64_decode($cust_id)))==true){

			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');

		}else{

			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

		}

		$this->session->set_flashdata($this->msg);

		redirect('backoffice/subscriptionplan/attributes_show');

	}

	public function subscriptiondelete($cust_id=0)

	{

		if((bool)$this->common_model->delete('createform',array('id'=>base64_decode($cust_id)))==true){

			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');

		}else{

			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

		}

		$this->session->set_flashdata($this->msg);

		$form_name="SELECT id,form_name,form_description FROM createform";

		$this->data['create_formname'] = $this->common_model->solveCustomQuery($form_name);		

		$this->data['formid'] =$this->uri->segment(4);

		$mapping_attributes="SELECT * FROM attribute  where status=1 order by id asc";

		$this->data['attributelist'] = $this->common_model->solveCustomQuery($mapping_attributes);

        $this->load->view('backoffice/subscriptionplan/createformview', $this->data, FALSE);

	}	

	public function createform($start=0)

	{

		$this->data['page_form_id']=48;

		$this->data['page_module_id']=19;

		($start)?($limit_from=$start):($limit_from=0); $limit=100;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage Subscription Plan</li></ol>';

		$cond='';

		$url_cond='';$con='';		

		$conds=array();			

		$customer="SELECT * FROM attribute ".$cond." order by id desc LIMIT ".$limit_from.",".$limit;

		$this->data['recs'] = $this->common_model->solveCustomQuery($customer);	

		$this->data['act'] = site_url('backoffice/subscriptionplan/save_createform_data');		

		$this->data['action_customer_search_submit']=base_url('backoffice/customer/show');

		$this->data['submit'] = lang('UPDATE_BTN');	



        $maxdisplay = "SELECT max(display_order) as maxdisplay FROM createform where form_type =1"; 

		$maxdisplay = $this->common_model->solveCustomQuery($maxdisplay);

		$this->data['maxdis'] = $maxdisplay[0]->maxdisplay + 1;	

		$this->load->view('backoffice/subscriptionplan/add_createform_view', $this->data);

	}

	public function check_medical_type($fid)

	{		

		$this->db->where('form_type',$fid);

		$this->db->where('form_type !=',1);

		$this->db->where('form_type !=',0);

		$query = $this->db->get('createform');

		if ($query->num_rows() > 0){

			return 1;

		}

		else{

		return 0;

		}

	}

	public function save_createform_data($start=0)

	{

		$formtype= $this->input->post('formtype');

		$dformtype = $this->check_medical_type($formtype);

		if($this->validate_createform_data()){

				$this->data = array(

					'form_type' => $this->input->post('formtype'),

					'form_name' => $this->input->post('add_create_form'),

					'form_description' =>$this->input->post('add_form_description'),

					'status' => $this->input->post('status'),

					'display_order' => $this->input->post('display_order'),

					'created_date' => date('Y-m-d,H:i:s'),

					'created_by' => $this->data['live_user_id']

				);







				if($dformtype==1){

					$this->msg = array('msg'=>'Medical form should be unique', 'msg_type'=>'error');

					$this->session->set_flashdata($this->msg);

					return $this->createform();

				}

			 $user_id = $this->common_model->save('createform',$this->data);

			 $id = $this->db->insert_id();

			

			$this->session->set_userdata('formid',$id);

			$this->session->set_userdata('formname',$this->input->post('add_create_form'));

			

			if($user_id!=''){				

				$this->msg = array('msg'=>lang('CREATE_FORM'), 'msg_type'=>'success');

				$this->session->set_flashdata($this->msg);				

				redirect('backoffice/subscriptionplan/add_mapping_attributes');				

			}else{

				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

				$this->session->set_flashdata($this->msg);

				return $this->createform();

			}

		}

		else

		{

			return $this->createform();

		}

	

	

		

	}

	/*public function check_medical_type($fid)

	{

		

		$this->db->where('form_type',2);

		$query = $this->db->get('createform');

		if ($query->num_rows() > 0){

		return true;

		}

		else{

		return false;

		}

	}*/

	private function validate_createform_data($id=0)

	{

		

		//$this->form_validation->set_rules('formtype', 'Medical', 'trim|callback_check_medical_type');

		$this->form_validation->set_rules('add_create_form', 'Add create form', 'trim|required|strip_tags');

		return $this->form_validation->run();

    }	

	public function formattributelist(){

			echo '<pre>'; print_r($this->input->post()); die;

			$formids = $this->input->post('formattributelist');			

			$get_all_mapp_attribute="SELECT * FROM mapping_attribute where form_id =".$formids."";			

			$get_all_data = $this->common_model->solveCustomQuery($get_all_mapp_attribute);

			

			

			$html ='<table class="table"><thead>

				 <tr>

					<th>Firstname</th>

					<th>Form Description</th>

					<th>Email</th>

				  </tr>

		    </thead>';

			$html .='<tbody>';

				foreach($get_all_data as  $vl){

					 $html .='<tr>';

					 $html .='<td>"'.$vl->form_id.'"</td>';

					 $html .='<td>"'.$this->common_model->getCustomFielddata('attribute','attribute_name',array('id'=>$vl->attribute_id)).'"</td>';

					 $html .='<td>"'.$this->common_model->getCustomFielddata('attribute_values','attribute_name',array('id'=>$vl->attribute_id)).'"</td>';

					 $html .='</tr>';

				}   

			$html .='</tbody>';

			$html .='</table>';

			echo $html;exit;

	}

	public function createformview(){

		$uriid = $this->uri->segment(4);

		$this->data['page'] = 1922;

		$this->data['page_form_id']=48;

		$this->data['page_module_id']=19;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Subscription Plan</li></ol>';			

		$this->data['act'] = site_url('backoffice/subscriptionplan/save_mapping_attribute');

        $this->data['submit'] = lang('SAVE_BTN');

		$form_name="SELECT id,form_name,form_description,allow_medical_frm,form_type FROM createform where mapped_status=0";

		$this->data['create_formname'] = $this->common_model->solveCustomQuery($form_name);	

		//echo '<pre>'; print_r($this->data['formname']);die;

		$this->data['formid'] =$this->uri->segment(4);

		$mapping_attributes="SELECT * FROM attribute  where status=1 order by id asc";

		$this->data['attributelist'] = $this->common_model->solveCustomQuery($mapping_attributes);

        $this->load->view('backoffice/subscriptionplan/createformview', $this->data, FALSE);



	}

	public function customerallform(){

		$uriid = $this->uri->segment(4);

		$this->data['page'] = 1922;

		$this->data['page_form_id']=48;

		$this->data['page_module_id']=19;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Subscription Plan</li></ol>';			

		$this->data['act'] = site_url('backoffice/subscriptionplan/save_mapping_attribute');

        $this->data['submit'] = lang('SAVE_BTN');

		$form_name="SELECT id,form_name,form_description,allow_medical_frm FROM createform where mapped_status=0";

		$this->data['create_formname'] = $this->common_model->solveCustomQuery($form_name);	

		//echo '<pre>'; print_r($this->data['formname']);die;

		$this->data['formid'] =$this->uri->segment(4);

		$mapping_attributes="SELECT * FROM attribute  where status=1 order by id asc";

		$this->data['attributelist'] = $this->common_model->solveCustomQuery($mapping_attributes);

        $this->load->view('backoffice/subscriptionplan/createformview', $this->data, FALSE);



	}

	public function mappedform(){

		$uriid = $this->uri->segment(4);

		$this->data['page'] = 1922;

		$this->data['page_form_id']=48;

		$this->data['page_module_id']=19;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Subscription Plan</li></ol>';			

		$this->data['act'] = site_url('backoffice/subscriptionplan/save_mapping_attribute');

        $this->data['submit'] = lang('SAVE_BTN');

		$form_name="SELECT id,form_name,form_description FROM createform  where mapped_status=1";

		$this->data['create_formname'] = $this->common_model->solveCustomQuery($form_name);	

		//echo '<pre>'; print_r($this->data['formname']);die;

		$this->data['formid'] =$this->uri->segment(4);

		$mapping_attributes="SELECT * FROM attribute  order by id asc";

		$this->data['attributelist'] = $this->common_model->solveCustomQuery($mapping_attributes);

        $this->load->view('backoffice/subscriptionplan/mappedformview', $this->data, FALSE);



	}

	public function deleteattribute(){

		//echo '<pre>'; print_r($this->input->post());die;

		$id = $this->input->post('id');

		$delrecord="delete FROM mapping_attribute where id='".$id."'";

		$deleterecord = $this->db->query($delrecord);

		if(!empty($deleterecord))

		{			

			echo 1 ;exit;

		}else

		{

			echo 0 ;exit;

		}

	}

	public function showexercise($start=0)

	{

		$this->data['page_form_id']=43;

		$this->data['page_module_id']=4;

		($start)?($limit_from=$start):($limit_from=0); $limit=100;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage Subscription Plan</li></ol>';

		$cond='';

		$url_cond='';$con='';		

		$conds=array();			

		$customer="SELECT * FROM exercise ".$cond." order by id desc LIMIT ".$limit_from.",".$limit;

		$this->data['recs'] = $this->common_model->solveCustomQuery($customer);		

		$this->data['action_customer_search_submit']=base_url('backoffice/customer/show');		

		$this->load->view('backoffice/subscriptionplan/exercise_view', $this->data);

	}

	private function validate_exercise($id=0)

	{

		$this->form_validation->set_rules('add_exercise_plan', 'Add Exercise', 'trim|required|strip_tags');

		return $this->form_validation->run();

    }

	public function addexercise($user_id=0){

		$this->data['page_form_id']=43;

		$this->data['page_module_id']=4;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/subscriptionplan/show').'">Manage Subscription Plan</a></li><li class="active">Add Exercise</li></ol>';

		$user_id=base64_decode($user_id);		

		$user_sql="SELECT * FROM exercise";

		$this->data['rec'] = $this->common_model->solveCustomQuery($user_sql);

		

		$this->data['act'] = site_url('backoffice/subscriptionplan/saveexercise');

		$this->data['submit'] = lang('UPDATE_BTN');

		$this->load->view('backoffice/subscriptionplan/add_exercise_view', $this->data, FALSE);

	}

	public function edit_exercise($user_id=0){

		$this->data['page_form_id']=43;

		$this->data['page_module_id']=4;

		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/subscriptionplan/show').'">Manage Subscription Plan</a></li><li class="active">Edit customer</li></ol>';

		$user_id=base64_decode($user_id);

		

		$user_sql="SELECT * FROM exercise WHERE id=".$user_id;

		$this->data['rec'] = $this->common_model->solveCustomQuery($user_sql);

		//echo '<pre>';print_r($this->data['rec']);die;

		$this->data['act'] = site_url('backoffice/subscriptionplan/updateexercise/'.base64_encode($user_id));

		$this->data['submit'] = lang('UPDATE_BTN');

		$this->load->view('backoffice/subscriptionplan/add_exercise_view', $this->data, FALSE);

	}



	public function saveexercise(){

			if($this->validate_exercise()){

				$this->data = array(

					'exercise_name' => $this->input->post('add_exercise_plan'),

					'status' => $this->input->post('status'),

					'created_date' => date('Y-m-d,H:i:s')

				);

			$user_id = $this->common_model->save('exercise',$this->data);

			if($user_id!=''){				

				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');

				$this->session->set_flashdata($this->msg);

				redirect('backoffice/subscriptionplan/showexercise');

			}else{

				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

				$this->session->set_flashdata($this->msg);

				return $this->addexercise();

			}

		}

		else

		{

			return $this->addexercise();

		}

	}

	public function updateexercise($user_id=0){			

			   $user_id=base64_decode($user_id);

			

				if($this->validate_exercise($user_id)){				

					$this->data = array(

						'exercise_name' => $this->input->post('add_exercise_plan'),

						'status' => $this->input->post('status'),

						'created_date' => date('Y-m-d,H:i:s')

				);				

			if((bool)$this->common_model->update('exercise',$this->data, array('id'=>$user_id)) === TRUE){

							

				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');

				$this->session->set_flashdata($this->msg);

				redirect('backoffice/subscriptionplan/showexercise');

			}else{

				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

				$this->session->set_flashdata($this->msg);

				return $this->edit_exercise($user_id);

			}

		}else{

			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');

			$this->session->set_flashdata($this->msg);

			return $this->edit_exercise(base64_encode($user_id));

		}

	}	

 }

?>