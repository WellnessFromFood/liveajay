<?php
class Lmsdata extends CI_Controller {

	public $data = array();
    public $msg = array();

 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 19;
		$this->data['page_form_id']=2;
		$this->data['page_module_id']=2;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
		$this->load->library('talentlmsapi');
    }

	public function show(){
		$this->data['page_form_id']=40;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">View LMS User Data</li></ol>';
		$user_sql="SELECT id,lms_id,first_name,last_name,emailid from user where status = 1 and role_type = 3 and lms_id !=0 order by id desc";
		$this->data['recs'] = $this->common_model->solveCustomQuery($user_sql);
		$this->load->view('backoffice/user/lmsData', $this->data);
	}

	public function lms_details($lmsId=""){

		$this->data['page_form_id']=40;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">View LMS User Data</li></ol>';
		$user_sql="SELECT id,lms_id,first_name,last_name,emailid from user where lms_id = ".base64_decode($lmsId);
		$this->data['recs'] = $this->common_model->solveCustomQuery($user_sql);
		$lmsData = $this->talentlmsapi->forAll(base64_decode($lmsId));
		$this->data['course'] = $lmsData['courses'];
		
		$this->load->view('backoffice/user/lmsDetails', $this->data);
	}
}
?>
