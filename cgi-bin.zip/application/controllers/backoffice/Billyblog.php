<?php
    class Billyblog extends CI_Controller{
        public $data = array();   
        public $msg = array();
        public function __construct()
        {
    	    parent::__construct();
    	    $this->load->helper('helper');
    		if ((bool) $this->session->userdata('IsAdminLoggedIn') == FALSE) {
    			redirect('backoffice/login');
    			exit();
		}
		
        $this->data['page'] = 10;
        $this->data['page_form_id'] = 39;        
        $this->data['page_module_id'] = 17;        
        $this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:' . gmdate('D, d M Y H:i:s') . 'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0', false);
        $this->output->set_header('Pragma: no-cache'); 
    }
    
    public function me()
    {
        echo 'This is the BillyBlog controller - watch out' . '<br>';
        
        $customerId = 1305;
        //Given the customer id - get the created_date
        $created_date = $this->common_model->getCustomFielddata('user', 'created_date', array('id'=>$customerId));
        
        $weekDay = calculate_TheWeek($created_date);
        echo 'The created_date is ' . $created_date . '<br>';
        //echo '$weekDay is ' . '<pre>'; print_r($weekDay); die;
        $theBlogs = $this->common_model->getBlogsForThisUser($customerId, $weekDay['week'], $weekDay['day']);
        
        echo 'The blogs are: ' . '<pre>'; print_r($theBlogs);
        
    }
    
    public function show($start = 0)
    {
        //User requested a list of the blogs - this will generate it, display them via the list view
    	($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit = 100;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Blog</li></ol>';
        $cond = '';
        $url_cond = '';
        $testimonial = '';
        
        
        $testimonial_sql = "SELECT * FROM blog  order by blog_type asc";
        $this->data['recs'] = $this->common_model->solveCustomQuery($testimonial_sql);
        $records_count = count($this->data['recs']);
        
        $this->data['pagigShow'] = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        $this->data['act_testimonial_search_submit'] = base_url('backoffice/billyblog/show');
        $this->load->view('backoffice/blog/billyblog_view', $this->data); 
    }
    
    public function add()
    {
        $campus_ids = array();
        $course_ids = array();
        $faculty_ids = array();
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add blog</li></ol>';
        $this->data['act'] = site_url('backoffice/blog/save');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/blog/add_blog_view', $this->data, FALSE);
    }
    public function save()
    {
        if ($this->validate_blog()) {
            $time = time();
            $this->data = array(
                'title' => $this->input->post('title'),
                'short_description' => $this->input->post('short_description'),
                'description' => $this->input->post('description'),
                'blog_type' => $this->input->post('blog_type'),
                'status' => $this->input->post('status'),
                'created_date' => date('Y-d-m'),
                'video_url' => $this->input->post('url'),
                'button_name' => $this->input->post('button'),
                'display_order' => $this->input->post('display_order'),
                'created_by' => $this->data['live_user_id']
            );
            if ($_FILES['image']['name']) {
                $this->updata = $this->functions->do_upload('uploads/social/', 'image');
                if (@$this->updata['res'] === TRUE) {
                    if ($this->input->post('OldBannerImage')) {
                        unlink('uploads/social/' . $this->input->post('OldBannerImage'));
                    }
                    $this->data['image'] = $this->updata['upload_data']['file_name'];
                } else {
                    $this->msg = array(
                        'file_msg' => substr($this->updata['msg'], 3, -4)
                    );
                    $this->session->set_userdata($this->msg);
                    return $this->add();
                }
            }
            $id = $this->common_model->saveAndGetLastId('blog', $this->data);
            if ($id != '') {
                $this->msg = array(
                    'msg' => lang('RECORD_SAVED'),
                    'msg_type' => 'success'
                );
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/blog/show');
            } else {
                $this->msg = array(
                    'msg' => lang('RECORD_ERROR'),
                    'msg_type' => 'error'
                );
                $this->session->set_flashdata($this->msg);
                return $this->add();
            }
        }
        else {
            return $this->add();
        }
    }
    public function edit($id = 0)
    {
    	$this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit blog</li></ol>';
        $id = base64_decode($id);
        $testimonial_sql = "SELECT * FROM blog WHERE id=" . $id;
        $this->data['rec'] = $this->common_model->solveCustomQuery($testimonial_sql);
        $this->data['act'] = site_url('backoffice/billyblog/update/' . base64_encode($id));
        $this->data['submit'] = lang('UPDATE_BTN');
        
        
        //echo 'about to load the view'; die;
        $this->load->view('backoffice/blog/add_billyblog_view', $this->data, FALSE);
    }
    public function delete_image()
    {
    	$id = $this->input->post('id');
        
        if ((bool) $this->common_model->update('blog', array(
            'image' => ''
        ), array(
            'id' => $id
        )) === true) {
            
            if (file_exists('uploads/social/' . $this->input->post('image_path'))) {
                
                unlink('uploads/social/' . $this->input->post('image_path'));
                
            }
            
            echo 'true';
            
        } else {
            
            echo 'false';
            
        }
        
    }
    
    
    
    public function update($id = 0)
    {
        
        $id = base64_decode($id);
        if ($this->validate_blog($id)) {
            
            $time = time();
            $weekToDisplay = $this->input->post('week_to_display');
            
           
			//echo '$weekToDisplay is '. $weekToDisplay; die;
            
            $this->data = array(
                'title' => $this->input->post('title'),
                'sub_type' => $this->input->post('sub_type'),
                'week_to_display' => $this->input->post('week_to_display'),
                'months_to_display' => $this->input->post('months_to_display'),
                'short_description' => $this->input->post('short_description'),
                'description' => $this->input->post('description'),
                'blog_type' => $this->input->post('blog_type'),
                'status' => $this->input->post('status'),
                
                'created_date' => date('Y-d-m'),
                
                'video_url' => $this->input->post('url'),
                
                'button_name' => $this->input->post('button'),
                
                'display_order' => $this->input->post('display_order'),
                
                'created_by' => $this->data['live_user_id']
            );
            
            if ($_FILES['image']['name']) {
                
                $this->updata = $this->functions->do_upload('uploads/social/', 'image');
                
                if (@$this->updata['res'] === TRUE) {
                    
                    if ($this->input->post('OldBannerImage')) {
                        
                        unlink('uploads/social/' . $this->input->post('OldBannerImage'));
                        
                    }
                    $this->data['image'] = $this->updata['upload_data']['file_name'];
                    
                } else {
                    
                    $this->msg = array(
                        'file_msg' => substr($this->updata['msg'], 3, -4)
                    );
                    
                    $this->session->set_userdata($this->msg);
                    
                    return $this->edit($id);
                    
                }
                
            }
            
            
            //echo "about to commit and ... "; echo '<pre>'; print_r($this->data); die;
            if ((bool) $this->common_model->update('blog', $this->data, array(
                'id' => $id
            )) === TRUE) {
                
            }
        }
        
        $this->msg = array(
            'msg' => lang('RECORD_UPDATED'),
            'msg_type' => 'success'
        );
        
        $this->session->set_flashdata($this->msg);
        
        redirect('backoffice/billyblog/show');
        
    }
    
    
    
    public function delete($id = 0)
    {
        
        $id = base64_decode($id);
        
        $testimonial_result = $this->common_model->getRow('blog', '', array(
            'id' => $id
        ));
        
        if ((bool) $this->common_model->delete('blog', array(
            'id' => $id
        )) == true) {
            
            
            
            if ($testimonial_result->image != '') {
                
                unlink('uploads/social/' . $testimonial_result->image);
                
            }
            
            $this->msg = array(
                'msg' => lang('RECORD_DELETED'),
                'msg_type' => 'success'
            );
            
        } else {
            
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
            
        }
        
        $this->session->set_flashdata($this->msg);
        
        redirect('backoffice/blog/show');
        
    }
    
    
    
    private function validate_blog($id = 0)
    {
        
        //$this->form_validation->set_rules('testimonial_type_id', 'social Type ', 'trim|required|strip_tags');
        
        //$this->form_validation->set_rules('course_ids[]', 'Course ', 'trim|required|strip_tags');
        
        $this->form_validation->set_rules('title', 'Title', 'trim|required|strip_tags');
        
        return $this->form_validation->run();
        
    }
    
    
    
    public function ch_status($id = 0, $Status = 0)
    {
        
        if ($id) {
            
            $time = time();
            
            $this->data = array(
                'status' => $Status,
                'modified_date' => $time
            );
            
            if ($this->common_model->update('blog', $this->data, array(
                'id' => $id
            ))) {
                
                $this->data['msg'] = lang('RECORD_UPDATED');
                
                $this->data['msg_type'] = true;
                
            } else {
                
                $this->data['msg'] = lang('RECORD_ERROR');
                
                $this->data['msg_type'] = false;
                
            }
            
        } else {
            
            $this->data['msg'] = lang('RECORD_ERROR');
            
            $this->data['msg_type'] = false;
            
        }
        
        header('Content-Type: application/json');
        
        echo json_encode($this->data['msg_type']);
        
    }
    
    
    
    public function checkImage()
    {
        
        if (empty($_FILES['BannerImage']['name'])) {
            
            $this->form_validation->set_message('checkImage', 'Banner image is required');
            
            return FALSE;
            
        }
        
        return TRUE;
        
    }

    public function view_recipes()
    {
        $this->data['page_form_id'] = 63;        
        $this->data['page_module_id'] = 17;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Recipes</li></ol>';
        $sql = "SELECT r.*,w.number_of_week FROM recipes r join week w on r.week_id = w.id  order by id desc";
        $this->data['recs'] = $this->common_model->solveCustomQuery($sql);
        $this->load->view('backoffice/blog/recipe_view', $this->data); 
    }

    private function validate_recipe($id = 0)
    {
        
        
        $this->form_validation->set_rules('title', 'Title', 'trim|required|strip_tags');
        
        return $this->form_validation->run();
        
    }

    public function add_recipe()
    {
        $this->data['page_form_id'] = 63;        
        $this->data['page_module_id'] = 17;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Add Recipes</a></li><li class="active">Add blog</li></ol>';
        $this->data['weeks'] = $this->common_model->getRows('week','id,number_of_week',array('status'=>1));
        $this->data['act'] = site_url('backoffice/blog/save_recipe');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/blog/add_recipe_view', $this->data, FALSE);
    }
    public function save_recipe()
    {
        if ($this->validate_recipe()) {
            $time = time();
            $this->data = array(
                'title' => $this->input->post('title'),
                'week_id'=> $this->input->post('weekid'),
                'short_description' => $this->input->post('short_description'),
                'description' => $this->input->post('description'),
                'type' => $this->input->post('type'),
                'status' => $this->input->post('status'),
                'created_date' => date('Y-m-d H:i:s'),
                'display_order' => $this->input->post('display_order')
            );
            if ($_FILES['image']['name']) {
                $this->updata = $this->functions->do_upload('uploads/social/', 'image');
                if (@$this->updata['res'] === TRUE) {
                    if ($this->input->post('oldimage')) {
                        unlink('uploads/social/' . $this->input->post('oldimage'));
                    }
                    $this->data['image'] = $this->updata['upload_data']['file_name'];
                } else {
                    $this->msg = array(
                        'file_msg' => substr($this->updata['msg'], 3, -4)
                    );
                    $this->session->set_userdata($this->msg);
                    return $this->add_recipe();
                }
            }
            $id = $this->common_model->saveAndGetLastId('recipes', $this->data);
            if ($id != '') {
                $this->msg = array(
                    'msg' => lang('RECORD_SAVED'),
                    'msg_type' => 'success'
                );
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/blog/view_recipes');
            } else {
                $this->msg = array(
                    'msg' => lang('RECORD_ERROR'),
                    'msg_type' => 'error'
                );
                $this->session->set_flashdata($this->msg);
                return $this->add_recipe();
            }
        }
        else {
            return $this->add_recipe();
        }
    }

    public function edit_recipe($id = 0)
    {

        $this->data['page_form_id'] = 63;        
        $this->data['page_module_id'] = 17;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit Recipes</li></ol>';
        $id = base64_decode($id);
        $sql = "SELECT * FROM recipes WHERE id=" . $id;
        $this->data['rec'] = $this->common_model->solveCustomQuery($sql);
        $this->data['act'] = site_url('backoffice/blog/update_recipe/' . base64_encode($id));
        $this->data['weeks'] = $this->common_model->getRows('week','id,number_of_week',array('status'=>1));
        $this->data['submit'] = lang('UPDATE_BTN');
        $this->load->view('backoffice/blog/add_recipe_view', $this->data, FALSE);
    }
    
    public function update_recipe($id = 0)
    {
        
        $id = base64_decode($id);
        
        if ($this->validate_recipe($id)) {
            
            $this->data = array(
                'title' => $this->input->post('title'),
                'week_id'=> $this->input->post('weekid'),
                'short_description' => $this->input->post('short_description'),
                'description' => $this->input->post('description'),
                'type' => $this->input->post('type'),
                'status' => $this->input->post('status'),
                'display_order' => $this->input->post('display_order')
            );
            
            if ($_FILES['image']['name']) {
                $this->updata = $this->functions->do_upload('uploads/social/', 'image');
                if (@$this->updata['res'] === TRUE) {
                    if ($this->input->post('oldimage')) {
                        unlink('uploads/social/' . $this->input->post('oldimage'));
                    }
                    $this->data['image'] = $this->updata['upload_data']['file_name'];
                } else {
                    $this->msg = array(
                        'file_msg' => substr($this->updata['msg'], 3, -4)
                    );
                    $this->session->set_userdata($this->msg);
                    return $this->add_recipe();
                }
            }
            
            if ((bool) $this->common_model->update('recipes', $this->data, array(
                'id' => $id
            )) === TRUE) {
                
            }
        }
        $this->msg = array(
            'msg' => lang('RECORD_UPDATED'),
            'msg_type' => 'success'
        );
        $this->session->set_flashdata($this->msg);
        redirect('backoffice/blog/view_recipes'); 
    }

    public function delete_recipe($id = 0)
    {
        
        $id = base64_decode($id);
        $result = $this->common_model->getRow('recipes', '', array(
            'id' => $id
        ));
        
        if ((bool) $this->common_model->delete('recipes', array(
            'id' => $id
        )) == true) {
                
        if ($result->image != '') {
            unlink('uploads/social/' . $result->image);
        }
            
            $this->msg = array(
                'msg' => lang('RECORD_DELETED'),
                'msg_type' => 'success'
            );
            
        } else {
            
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
            
        }
        
        $this->session->set_flashdata($this->msg);
        
        redirect('backoffice/blog/view_recipes');
        
    }
    
    
    
    
}

?>