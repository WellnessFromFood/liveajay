<?php
class Customer extends CI_Controller {

	public $data = array();
    public $msg = array();

 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
			
		}
		$this->data['page'] = 9;
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->load->library('talentlmsapi');
    }
	public function checkEmailAvailable()
	{
		$user_id = ($this->input->post('user_id'));
		$cond=array('emailid'=>$this->input->post('email'),'id !='=>$user_id);
		$result=$this->common_model->getRows('user','id',$cond);
		if(!empty($result)){
			echo(json_encode(false));
		}else{
			echo(json_encode(true));
		}
	}
	public function verifieduser()
	{
		$custid = $this->input->post('custid');
		$data=array('active'=>1,'verified_date'=>date('Y-m-d H:i:s'));

		$result=$this->common_model->update('user',$data,array('id'=>$custid));
		if(!empty($result)){
			echo(json_encode(true));
		}else{
			echo(json_encode(false));
		}
	}

	public function messagefordiy()
	{
		$this->data['page_form_id']=54;
		$this->data['page_module_id']=3;
		/*$alldiy_message="SELECT DISTINCT allow_all_diy_user_msg FROM user ";
		$alldiymessages= $this->common_model->solveCustomQuery($alldiy_message);*/
		$this->data['messagelst'] = $this->common_model->getRows('messagecenterposttable','Message,MessageID,onoff_status',array('message_type_id'=>3,
		'status '=>1));
		$this->data['act']=base_url('backoffice/customer/addmessagefordiy');
		$this->data['submit'] = 'Apply Message';
		$this->data['alldiymessage'] =$this->data['messagelst'][0]->onoff_status;

		//echo '<pre>'; print_r($this->data['messagelst'][0]->onoff_status);die;
		$this->load->view('backoffice/customer/messagefordiy_view', $this->data);
	}
	private function validdiymessage($id=0)
	{
		$this->form_validation->set_rules('active', 'Please select ', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
	public function addmessagefordiy(){
			
			$allow_all_diy_user_msg='';	$msg='';
			$allow_all_diy_user_msg=$this->input->post('allow_all_diy_user_msg');
			$all_diy_user_msg_id=$this->input->post('all_diy_user_msg_id');
			$msg="Message has been disallow successfully";
			if($allow_all_diy_user_msg==1)
			{
				$msg="Allow message has been successfully";
			}

			$sql = "SELECT DISTINCT custid FROM orders where subscription_type=1";

			$totalsql = $this->common_model->solveCustomQuery($sql);
			$this->data=array(
				'allow_all_diy_user_msg'=>$allow_all_diy_user_msg,
				'all_diy_user_msg_id'=>$all_diy_user_msg_id,

			);

			foreach($totalsql as $vk)
			{
				$finalupdate=$this->common_model->update('user',$this->data, array('id'=>$vk->custid));
				//echo  $str = $this->db->last_query();
			}

			if($finalupdate !='')
			{
				$this->common_model->update('messagecenterposttable',array('onoff_status'=>$allow_all_diy_user_msg), array('MessageID'=>$all_diy_user_msg_id));

				$this->msg =$msg;
				$this->data['submit'] = 'Apply Message';
				$this->data['alldiymessage'] =$allow_all_diy_user_msg;
				$this->data['messagelst'] = 
				$this->common_model->getRows('messagecenterposttable','Message,MessageID',array('message_type_id'=>'3','status '=>'1'));
				//echo '<pre>'; print_r($this->input->post());die;
				
			}
			//echo '<pre>'; print_r($this->data['alldiymessage']);die;
			$this->data['act']=base_url('backoffice/customer/addmessagefordiy');
			$this->load->view('backoffice/customer/messagefordiy_view', $this->data);

	}
	public function show($start=0)
	{
	    //Display the Manage Customer form - populate the controls with data. This presents a list of Customers and waits for user to select a customer/function
	    //view url = backoffice/customer/show (form_name = View Users)
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage customer</li></ol>';
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		
		//Using the on-page search function
		if($this->input->post('form_submit_customer')=='Search'){
		    
			$customer_name = $this->input->post('customer_name');
			if($customer_name!=''){
				$conds[] = "emailid like '%".trim($customer_name)."%'";
			}
			$url_cond.='?customer_name='.$customer_name.'&form_submit_customer=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "and ".$con;
		}
		
		//Get the values from the form, and temporarily store them
		$this->data['customer_name'] =$this->input->post('customer_name');
		
		//SQL to get the count of all customers - (all types)
		$total_get_sql = "SELECT count(id) as total FROM user where role_type=3 ".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		
		//role_type of 3 is a Customer (all types - includes DIY, Premium, Premium plus, Not registered )
		$customer="SELECT * FROM user where role_type=3  ".$cond." order by id desc LIMIT ".$limit_from.",".$limit;
		
        //Run the query
		$this->data['recs'] = $this->common_model->solveCustomQuery($customer);
		
		$records_count=$total_get[0]->total;
		
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['action_customer_search_submit']=base_url('backoffice/customer/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		//echo '<pre>'; print_r($this->data['recs']);die;
		$this->load->view('backoffice/customer/customer_view', $this->data);
	}
	public function customerdetail($start=0)
	{
	    //User clicks on a Full Name in the Customer Management view.  This will present the user's answers to the questionnaire in another view 
		//print_r($this->input->get());die;
		error_reporting(0);
		$myorders='';
		
		$cust_id = $this->input->get('cust_id');
		$frm_id = $this->input->post('frm_id');
		//When does $frm_id not equal to blank?

		if($cust_id !='')
		{
			$conds[]="  d.user in(".base64_decode($cust_id).")";
		}
		if($frm_id !='')
		{
		    echo '<pre>'; print_r("Found it - Cust_id = " .$cust_id. " and frm_id = ". $frm_id);die;
			$conds[]="  d.form_id in(".$frm_id.")";
		}
		$cond=implode(" and ",$conds);
		if(!empty($cond)){
				$cond='WHERE '.$cond;
		}	
	
		$customer2="SELECT ANY_VALUE(c.form_name) as form_name,ANY_VALUE(c.id) as id,ANY_VALUE(field_name) as field_name,ANY_VALUE(field_value) as field_value,ANY_VALUE(form_id) as form_id FROM `savequestionnnairfrmval` as d join createform as c on c.id=d.form_id
		where d.user=".base64_decode($cust_id)." group by d.form_id ";
		$this->data['recs2'] = $this->common_model->solveCustomQuery($customer2);


		$customer="SELECT c.form_name,c.id,field_name,field_value,form_id  FROM `savequestionnnairfrmval`
		as d join createform as c on c.id=d.form_id ".$cond." ";
		//die;
		$this->data['frm_id']=$frm_id;
		$this->data['recs'] = $this->common_model->solveCustomQuery($customer);
		$this->load->view('backoffice/customer/questionnairedetail_view', $this->data);

	}
	public function delete($cust_id=0)
	{
		try{
		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
									TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
				TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');

		$lms_id = $this->common_model->getRow('user','lms_id',array('id'=>base64_decode($cust_id)));

		if(!empty($lms_id) && ($lms_id->lms_id !=0))
		{
			$deleteuser =TalentLMS_User::delete(array('user_id' =>$lms_id->lms_id,'permanent'=>'yes'));
		}
		}catch(Exception $e) {
			echo $e->getMessage();

		}
		/* //print_r($deleteuser);die;
		if(!empty($deleteuser['message']) && $deleteuser['message']=='Operation completed successfully')
		{ */
			if((bool)$this->common_model->delete('user',array('id'=>base64_decode($cust_id)))==true){
				$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
			}

		//}

		$this->session->set_flashdata($this->msg);
		redirect('backoffice/customer/show');
	}
	public function edit2($cust_id=0)
	{
	    echo '<pre>'; echo "Someone called edit 2!"; die;
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/customer/show').'">Customer</A></li><li class="active">Edit customer</li></ol>';

	    $cust_id=base64_decode($cust_id);
		$this->data['rec'] = $this->common_model->getRow('user','*',array('id'=>$cust_id));
		$this->data['act'] = site_url('backoffice/customer/update/'.base64_encode($cust_id));
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->load->view('backoffice/customer/edit_customer_view', $this->data, FALSE);
	}
	private function customer_valid_data($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('customer', 'Customer', 'trim|required|strip_tags');
		}
		else
		{
		$this->form_validation->set_rules('customer', 'Customer Name', 'trim|required|strip_tags');

		}
		return $this->form_validation->run();
    }
	public function update2($cust_id)
	{
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		if($this->customer_valid_data($cust_id)){ //echo '<pre>'; print_r($this->input->post());die;
			$this->data = array(
			'first_name' => $this->input->post('customer'),
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'updated_by' => $this->data['live_user_id']);
			if((bool)$this->common_model->update('user',$this->data, array('id'=>base64_decode($cust_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/customer/show');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($cust_id);
			}
			}
			else
			{
				return $this->edit($cust_id);
			}
	}


		public function update($user_id=0){
			//echo '<pre>'; print_r($this->input->post());die;


		$diastolic_morning=$this->input->post('diastolic_morning');
		$diastolic_evening=$this->input->post('diastolic_evening');
		$pulse_morning=$this->input->post('pulse_morning');
		$pulse_evening=$this->input->post('pulse_evening');

		$wakeup=$this->input->post('wakeup');
		$beforelunch=$this->input->post('beforelunch');
		$beforedinner=$this->input->post('beforedinner');
		$beforebed=$this->input->post('beforebed');
		$array1='';
        $array2='';
        $arr1='';
        $arr2='';

        $arr = get_defined_vars();
        //echo '<pre>'; print_r($arr);
        //echo '<pre>'; print_r($this->input->post());

   if($diastolic_morning !=''|| $diastolic_evening='' || $pulse_morning='' || $pulse_evening='')
   {
   // echo '<pre>'; print_r("inside"); die;
   	$arr1=	array($diastolic_morning,$diastolic_evening,$pulse_morning,$pulse_evening);
   }

		 if($wakeup !=''|| $beforelunch='' || $beforedinner='' || $beforebed='')
   {
       //echo '<pre>'; print_r("inside 2nd"); die;
    $arr2=	array($wakeup,$beforelunch,$beforedinner,$beforebed);
   }
   
   //echo '<pre>'; print_r("got this far"); print_r($arr1);print_r($arr2);   die;
		
if(!empty($arr2) || !empty($arr1))
   		{
    $array1= implode(',',$arr1);
    $array2= implode(',',$arr2);
   		}
		 
	$user_id=base64_decode($user_id);
			if($this->_validData($user_id)){
			
			//	$role_id_name=$this->input->post('role_id');
			//	$rslt=explode('#',$role_id_name);

				$activeall = $this->input->post('active');
				$ad_hocall = $this->input->post('ad_hoc_meeting');
				$ad_act_message = $this->input->post('active_message');

				if($activeall=='on')
				{
					$active =1;
				}
				else
				{
					$active =0;
				}
				if($ad_hocall=='on')
				{
					$ad_hoc_meeting =1;
				}
				else
				{
					$ad_hoc_meeting =0;
				}
				if($ad_act_message=='on')
				{
					$ad_act_message =1;
				}
				else
				{
					$ad_act_message =0;
				}

				//echo '<pre>'; print_r($ad_hoc_meeting);die;
			
			
	
			$role_name ='';

			if(!empty($this->session->userdata('admin')->role_name)){
				$role_name = $this->session->userdata('admin')->role_name;
			}
			$implodeval ='';
			$role_id_name = $this->input->post('role_id');
			$all_medications = $this->input->post('medications');
			if(!empty($all_medications))
			{
			$implodeval = implode(',',$all_medications);
			}

				$activeall = $this->input->post('active');
				$ad_hocall = $this->input->post('ad_hoc_meeting');
				$ad_act_message = $this->input->post('active_message');
				
				$plan_id = $this->input->post('planid');
				if($plan_id==3 || $plan_id==2)
				{
					$subscriptionPlanId=2;
				}
				else
				{
					$subscriptionPlanId=1;
				}
				//echo '$plan_id is ' .$plan_id;die;   
				$starting_week = $this->input->post('starting_week');
				if($starting_week > 0){
					$starting_days = ($starting_week*7)-1;
					$created_date = date('Y-m-d', strtotime("-".$starting_days." days"));
				}else{
					$created_date = date('Y-m-d');
				}	
			
			
			
			
			
			
			
			
			
			
			
				$role_id_name=$this->input->post('role_id');
				$rslt=explode('#',$role_id_name);
				$this->data = array(
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'address' => $this->input->post('address'),
					'role_type' => $rslt[0],
					'role_name' => "Staff",
					'emailid' => $this->input->post('email'),
					'active'=>$active,
					'ad_hoc_meeting'=>$ad_hoc_meeting,
					'active_message'=>$ad_act_message,
					//'medications' =>$implodeval,
					//'password' => md5($this->input->post('password')),
					'country_id' => $this->input->post('country_id'),
					'state_id' => $this->input->post('state_id'),
					'city_id' => $this->input->post('city_id'),
					'status' => $this->input->post('status'),
					'number_week' => $this->input->post('number_week'),
					'created_by' => $this->data['live_user_id'],
					 'contact_no' => $this->input->post('contact_no'),
					 'subscription_plan_id' => $this->input->post('planid'),
					'dateofbirth' =>date('Y-m-d',strtotime($this->input->post('dateofbirth'))),
					'medications' =>'',//$implodeval,
					'weight' => $this->input->post('weight'),
					'height' => $this->input->post('height'),
					'gender' => $this->input->post('gender'),
					//'allow_subscription' => $this->input->post('allow_subscription'),
					'inches' => $this->input->post('inches'),
					'age' => $this->input->post('age')
				);
				//echo '<pre>'; print_r($this->data);die;
			if($_FILES['profile_image']['name']){
				$this->updata = $this->functions->do_upload('uploads/profile_images/', 'profile_image');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/profile_images/'.$this->input->post('OldBannerImage'));
						}
						$this->data['profile_image'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($user_id);
					}
			}
			if((bool)$this->common_model->update('user',$this->data, array('id'=>$user_id)) === TRUE){
                //echo '<pre>'; print_r($this->data);die;
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/customer/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($user_id);
			}
		}
		else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($user_id);
			}
}

	public function postdata($start=0)
	{
		$this->data['page_form_id']=16;
		$this->data['page_module_id']=3;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">View post data</li></ol>';
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		if($this->input->post('form_submit_customer')=='Search'){
			$customer_name = $this->input->post('customer_name');
			if($customer_name!=''){
				$conds[] = "customer like '%".$customer_name."%'";
			}
			$url_cond.='?customer_name='.$customer_name.'&form_submit_customer=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "and ".$con;
		}
		$this->data['customer_name'] =$this->input->post('customer_name');
		$total_get_sql = "SELECT count(id) as total FROM user where role_type=3 ".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		$course_stream_sql="SELECT * FROM user where role_type=3  ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		//$this->data['act_customer_search_submit']=base_url('backoffice/customer/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/customer/customer_past_data_view', $this->data);
	}
	public function schedule_meeting($start=0)
	{
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Schedule meeting</li></ol>';
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		if($this->input->post('form_submit_customer')=='Search'){
			$customer_name = $this->input->post('customer_name');
			if($customer_name!=''){
				$conds[] = "customer like '%".$customer_name."%'";
			}
			$url_cond.='?customer_name='.$customer_name.'&form_submit_customer=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['customer_name'] =$this->input->post('customer_name');
		$total_get_sql = "SELECT count(id) as total FROM user ".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		$course_stream_sql="SELECT * FROM user ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_customer_search_submit']=base_url('backoffice/customer/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		//$this->load->view('backoffice/customer/schedule_meeting_view', $this->data);
		$this->load->view('backoffice/customer/customer_view', $this->data);
	}
	public function cancel_meeting($start=0)
	{
		$this->data['page_form_id']=20;
		$this->data['page_module_id']=3;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">User</li></ol>';
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		if($this->input->post('form_submit_customer')=='Search'){
			$customer_name = $this->input->post('customer_name');
			if($customer_name!=''){
				$conds[] = "customer like '%".$customer_name."%'";
			}
			$url_cond.='?customer_name='.$customer_name.'&form_submit_customer=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['customer_name'] =$this->input->post('customer_name');
		$total_get_sql = "SELECT count(id) as total FROM user ".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		$course_stream_sql="SELECT * FROM user ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_customer_search_submit']=base_url('backoffice/customer/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		//$this->load->view('backoffice/customer/cancel_meeting_view', $this->data);
		$this->load->view('backoffice/customer/customer_view', $this->data);
	}
	public function acknowledge($start=0)
	{
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">User</li></ol>';
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		if($this->input->post('form_submit_customer')=='Search'){
			$customer_name = $this->input->post('customer_name');
			if($customer_name!=''){
				$conds[] = "customer like '%".$customer_name."%'";
			}
			$url_cond.='?customer_name='.$customer_name.'&form_submit_customer=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['customer_name'] =$this->input->post('customer_name');
		$total_get_sql = "SELECT count(id) as total FROM user ".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		$course_stream_sql="SELECT * FROM user ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_customer_search_submit']=base_url('backoffice/customer/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		//$this->load->view('backoffice/customer/acknowledge_schedule_view', $this->data);
		$this->load->view('backoffice/customer/customer_view', $this->data);
	}
	public function next_schedule_meeting($start=0)
	{
		$this->data['page_form_id']=20;
		$this->data['page_module_id']=3;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Next Schedule meeting</li></ol>';
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		if($this->input->post('form_submit_customer')=='Search'){
			$customer_name = $this->input->post('customer_name');
			if($customer_name!=''){
				$conds[] = "customer like '%".$customer_name."%'";
			}
			$url_cond.='?customer_name='.$customer_name.'&form_submit_customer=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['customer_name'] =$this->input->post('customer_name');
		$total_get_sql = "SELECT count(id) as total FROM user ".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		$course_stream_sql="SELECT * FROM user ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['action_next_customer_search_submit']=base_url('backoffice/customer/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		//$this->load->view('backoffice/customer/next_schedule_view', $this->data);
		$this->load->view('backoffice/customer/next_schedule_meeting_view', $this->data);
	}
	public function add()
	{
	//Staff or Admin clicked menu item to Add Customer - (url = backoffice/customer/add)
	//Displays the Add New Customer page 
		$this->data['page'] = 1922;
		$this->data['page_form_id']=25;
		$this->data['page_module_id']=3;
		
		//$array1 = get_defined_vars();
        //print_r($array1);
		//echo '<pre>'; print_r($this->data); print_r(" Add was fired, and " .gettype($this));print_r(" and " .get_class($this));die;
		
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Customer</li></ol>';
		
		//Get the possible values for each field from the database
		$this->data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
		$this->data['week'] = $this->common_model->getRows('week','id,number_of_week',array('status'=>'1'));
		
		$this->data['role'] = $this->common_model->getRows('user_role','role_id,role_name',array('role_status'=>'1',
		'role_id '=>'3'));
		$this->data['subscriptionplan']= $this->common_model->getRows('subscriptionplan','id,name',array('special_status'=>'1'));
		
		$this->data['act'] = site_url('backoffice/customer/save');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/customer/add_customer_view', $this->data, FALSE);
	}
	private function hash_password($password)
	{
		return password_hash($password, PASSWORD_BCRYPT);
	}

    public function save()
    {
//This is run when the Admin or Staff clicks Save on the Add New Customer Page
	    //echo '<pre>'; print_r($this->input->post());die;
    
		//check to make sure the appropriate data was entered, and legal
		if($this->_validData())
		{
		    //Get data from the form
		    $plan_id = $this->input->post('planid');
		    //$plan_id = 1 means DIY (not used)
		    //$plan_id = 2 means Premium (main program - without Drugs)
		    //$plan_id = 3 means Special (add Blood Pressure, Blood Sugars) - main program with Drugs
			                //echo '$plan_id is ' . $plan_id . '<br>'; die;
			
                        //echo 'about to get planid <br>'; 
			/*================Insert Data In Order Table==================*/
			
			if($plan_id == 1){
				$plan= "Do It Yourself (DIY)";
				$up_status = "Normal";
				$subscriptionPlanId=1;
			}
			elseif($plan_id == 2)
			{
				$plan= "PREMIUM";
				$up_status = "Upgraded With Premium";
				$subscriptionPlanId=2;
			}
			else
			{
				$plan= "Special PREMIUM from BackEnd";
				$up_status = "Special Premium Customer from Backend";
				$subscriptionPlanId=2;
			}
		    
			$role_name ='';
			$role_id_name = $this->input->post('role_id');
            $newRoleName = $this->common_model->getRow('user_role', 'role_name', array('role_id'=>$role_id_name));
			$role_name = $newRoleName->role_name;
			
			            //echo 'Lets take a look at userdata = <pre>'; print_r($this->session->userdata); die;
			
			$firstName = $this->input->post('first_name');
			$lastName = $this->input->post('last_name');
			$address = $this->input->post('address');
			
			$hash = md5(rand(0,1000));
			$emailId = $this->input->post('email');
			
			$phoneNum = $this->input->post('contact_no');
			$hashedPassword = $this->hash_password(trim($this->input->post('password')));
			$countryId = $this->input->post('country_id');
			$stateId = $this->input->post('state_id');
			$cityId = $this->input->post('city_id');
			$weight = $this->input->post('weight');
			$height = $this->input->post('height');
			$gender = $this->input->post('gender');
			$inches = $this->input->post('inches');
			$age = $this->input->post('age');
			$dateOfBirth = date('Y-m-d',strtotime($this->input->post('dateofbirth')));
			$status = $this->input->post('status');
			$totalWeekNumber = $this->input->post('number_week');
			$startingWeekNumber = $this->input->post('starting_week')+1;
			$createdBy = $this->data['live_user_id'];
			
			//did the user provide an image?  
			if($_FILES['profile_image']['name'])
			{
				$this->updata = $this->functions->do_upload('uploads/profile_images/', 'profile_image');
					if(@$this->updata['res'] === TRUE)
					{
						if($this->input->post('OldBannerImage'))
						{
							unlink('uploads/profile_images/'.$this->input->post('OldBannerImage'));
						}
						$this->data['profile_image'] = $this->updata['upload_data']['file_name'];
					}
					else
					{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit();
					}
			}
			
			//Some of the flags set by the user
			$activeall = $this->input->post('active');
			$ad_hocall = $this->input->post('ad_hoc_meeting');
			$ad_act_message = $this->input->post('active_message');

			if($activeall=='on')
			{
				$active =1;
			}
			else
			{
				$active =0;
			}
			
			if($ad_hocall=='on')
			{
				$ad_hoc_meeting =1;
			}
			else
			{
				$ad_hoc_meeting =0;
			}
			
			if($ad_act_message=='on')
			{
				$add_active_message =1;
			}
			else
			{
				$add_active_message =0;
			}
				
			        //echo '<pre>'; print_r($this->input->post());die;   
			$starting_week = $this->input->post('starting_week');
			        //echo '$starting_week is ' . $starting_week; die;   
			if($starting_week > 0)
			{
				$starting_days = ($starting_week * 7)-1;
				$created_date = date('Y-m-d', strtotime("-".$starting_days." days"));
			}
			else
			{
				$created_date = date('Y-m-d');
			}
			
			$this->data = array(
				'first_name' => $firstName,
				'last_name' => $lastName,
				'address' => $address,
				'role_type' =>$role_id_name,
				'hash' => $hash,
				'role_name' => $role_name,                                         //$this->session->userdata('admin')->role_name,
				'emailid' => $emailId,
				'active'=>$active,
				'ad_hoc_meeting'=>$ad_hoc_meeting,
				'active_message'=>$add_active_message,
				'contact_no' => $phoneNum,
				'subscription_plan_id' => $subscriptionPlanId,
				'password' => $hashedPassword,
				'payment_status'=>1,
				'country_id' => $countryId,
				'state_id' => $stateId,
				'city_id' => $cityId,
				'weight' => $weight,
				'height' => $height,
				'gender' => $gender,
				'inches' => $inches,
				'age' => $age,
				'dateofbirth' => $dateOfBirth,
				'status' => $status,
				'number_week' => $totalWeekNumber,
				'created_date' => $created_date,
				'starting_week'=> $startingWeekNumber,
				'created_by' => $createdBy,
				'cheerleader_email' =>1,
				'nag_email' =>1);
				
			                //echo '<pre>'; print_r($this->data);
			
			/********************************/
            //Here is where we save the user information to the user table - can this be carved out as its own function?
			$user_id = $this->common_model->saveAndGetLastId('user',$this->data);
				
			$this->data = array(
				'name' => $this->input->post('first_name')." ".$this->input->post('last_name'),
				'subscription_name' =>$plan,
				'subscription_price' =>0,
				'subscription_type'=>$subscriptionPlanId,
				'upgrade_status'=>$up_status,
				'custid' => $user_id,
				'email' => $emailId,
				'card_num' =>" ",
				'card_cvc' =>" ",
				'card_exp_month' =>" ",
				'card_exp_year' => " ",
				'item_name' => "",
				'item_number' => "",
				'item_price' =>0,
				'item_price_currency' => "INR",
				'paid_amount_currency' =>0,
				'paid_amount_currency' => "INR",
				'txn_id' => "Not Available",
				'payment_status' => "succeeded",
				'created' => date('Y-m-d'),
				'modified' => "0000-00-00",
				'added_type'=>2
				);
                				//echo 'About to save the order';
                				//echo '<pre>'; print_r($this->data); die;
				
				/********************************/
				//Here is where we save the order in the orders table
				$this->common_model->save('orders',$this->data);
				
				
				
				/*================End Insert Data=============================*/
				$planid= $this->input->post('planid');
				$weekNumber = $this->input->post('number_week');

                //Get some user information from the user table for this specific user
				$getuserdata = $this->common_model->getRow('user','id, emailid, first_name, last_name' ,array('status'=>'1', 'id'=>$user_id));
				                    
				                    //echo '$user_id is ' . $user_id . '<br>';
				                    //echo '<pre>'; print_r($getuserdata); die;
				                    
				                    
				/********************************/
				//Create a new talentLMS user
				$this->talentlmsapi->lmssignup($getuserdata,$up_status,$remove=false);
				                //echo 'called talent'; die;
                
                /********************************/
                //Send email to user
				$maildata=array(
								'full_name'=>$firstName." ".$lastName,
								'emailid'=>$emailId,
								'price'=>0,
								'contact_no'=>$phoneNum,
								'subject'=>$plan,
								'startWeek'=>$starting_week
							);
				        //echo 'About to sendMail and maildata is '; echo'<pre>'; print_r($maildata); die;
				
				//Sendemail to user
				$this->common_model->sendMail($maildata);
				
				/*---------Start Mapping-------------*/
			
			    $startWeek = $this->input->post('starting_week');
			    //echo 'starting Week is '. $this->input->post('starting_week') ;
			    //echo 'bullshit =  ' . ($startWeek + 1) . 'and weekNumber is ' . $weekNumber . '<br>';
			    
				$all_day_week = $this->common_model->calculate_day_custom_start_week(intval($this->input->post('starting_week'))+1, $weekNumber);
                           // echo 'All_Day_Week is <pre>'; print_r($all_day_week); die;
                
                //Build the backend tables that define the diet and its features - based on the master template
                $this->common_model->buildBackendTablesForUser($all_day_week, $user_id, $plan_id, $created_date );
                redirect('backoffice/customer/show');
				/*---------End Mapping-------------*/
			}       
			//user_id is not set
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				//echo 'about to run add'; die;
				return $this->add();
			}
	}

		
		
	public function SendMailCust()
		{
			//Send Mail

					$user_data= $this->common_model->getRows('user','type,hash',array('emailid'=>$this->input->post('email')));
					$data['hash']=$user_data[0]->hash;
					$password=$this->common_model->randomPassword();
					$md = 	$this->hash_password($password);
					$udata=array("password" =>trim($md));
					$data['sendpass'] =$password;
					$data['email'] =$this->input->post('email');
					$data['full_name']=$name=ucwords(strtolower($this->input->post('first_name')));
					$massege = $this->load->view('frontend/email/backoffice_user_mail',$data,true);
					$subject ="Wellness Backoffice Mail";
					$updatepass = $this->common_model->update('user', $udata, $cond=array("emailid"=>$emailid));
					$email_dat = array(
					'to'=>$this->input->post('email'),
					'subject'=>$subject,
					'msg'=>$massege);
					$res = $this->common_model->Send_GetStarted_Mail($email_dat);
					//Send Email Mail
		}
	public function edit($user_id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/customer/show').'">Manage customer</a></li><li class="active">Edit customer</li></ol>';
		$user_id=base64_decode($user_id);
		
		$user_sql="SELECT * FROM user WHERE id=".$user_id;
		$this->data['rec'] = $this->common_model->solveCustomQuery($user_sql);
		//echo '<pre>';print_r($this->data['rec']);die;
		$db_country_id =$this->data['rec'][0]->country_id;
		$db_state_id =$this->data['rec'][0]->state_id;
		

		
		$this->data['role'] = $this->common_model->getRows('user_role','role_id,role_name',array('role_status'=>'1','role_id !='=>'1'));
		$this->data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
		$this->data['state'] = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1','country_id'=>$db_country_id));
		$this->data['city'] = $this->common_model->getRows('cities','id,city_name,state_id',array('status'=>'1','state_id'=>$db_state_id));
		$this->data['week'] = $this->common_model->getRows('week','id,number_of_week',array('status'=>'1'));
		$this->data['act'] = site_url('backoffice/customer/update/'.base64_encode($user_id));
		$this->data['subscriptionplan']= $this->common_model->getRows('subscriptionplan','id,name',array('special_status'=>'1'));
		//echo '';print_r($this->data['subscriptionplan']);die;
		$this->data['submit'] = lang('UPDATE_BTN');
		$this->load->view('backoffice/customer/edit_customer_view', $this->data, FALSE);
	}
	private function _validData($id=0)
	{
		$this->form_validation->set_rules('first_name', 'First Name ', 'trim|required|strip_tags');
		$this->form_validation->set_rules('last_name', 'Last Name ', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('address', 'Address ', 'trim|required|strip_tags');
		$this->form_validation->set_rules('email', 'Email ', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('password', 'Password ', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
	public function find_state_by_country_id($country_id=0)
	{
		//$state_id=@$this->input->post('state_id');
		if(!empty($country_id)){
			$state = $this->common_model->getRows('state','state_id,country_id,state_name',array('status'=>'1','country_id'=>$country_id));
			$html="<option value=''>Please Select</option>";
			if(!empty($state)){ foreach($state as $state_val){
			if($country_id==$state_val->country_id){ $selected='selected'; }else{ $selected=''; }
			$html.="<option value='".$state_val->state_id."' ".$selected.">".$state_val->state_name."</option>";
			}}
		}
		echo $html;
	}
	public function find_state_id($state_id=0)
	{
		//$state_id=@$this->input->post('state_id');
		$cities = $this->common_model->getRows('cities','id,state_id,city_name',array('status'=>'1','state_id'=>$state_id));
		$html="<option value=''>Please Select</option>";
		if(!empty($cities)){ foreach($cities as $cities_val){
		if($state_id==$cities_val->state_id){ $selected='selected'; }else{ $selected=''; }
		$html.="<option value='".$cities_val->id."' ".$selected.">".$cities_val->city_name."</option>";
		}}
		echo $html;
	}
	public function reset_password()
	{
		$id = base64_decode($this->uri->segment(4));
		$user_name = $this->common_model->getRows('user','emailid',array('id'=>$id));
		//print_r($user_name);die;
		$data['getusername']=$user_name[0]->emailid;
		$data['submit'] = $this->lang->line('SAVE_BTN');
		$data['action'] = site_url('backoffice/customer/update_reset_password/'.base64_encode($id));
		$data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/customer/reset_password_view', $data);
	}
	public function update_reset_password($id=0)
	{
		$getalllinfo =  $this->session->userdata('admin');
		//echo '<pre>'; print_r($getalllinfo);die;
		$id = base64_decode($id);
		$getusername = $this->input->post('email');
		$getpassword = $this->input->post('password');
		if(($getusername !='') && ($getpassword !='')){
			$data=array(
			'password'=>$this->hash_password($getpassword)
			);
		$cond=array('id'=>$id,'emailid'=>$getusername,'status'=>1);
/*		echo "<pre>";
		print_r($data);
		print_r($cond);*/
		//die();
		if(($getalllinfo->role_type ==1) or $getalllinfo->role_type ==2)
		{

			if($this->common_model->update('user',$data, $cond))
			{
				$this->msg = array('msg'=>$this->lang->line('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/customer/show');
			}

		}else{
			$this->msg = array('msg'=>$this->lang->line('NOT_PERMISSION'), 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			redirect('backoffice/customer/reset_password/'.base64_encode($id));

		}

		}else{
			$this->msg = array('msg'=>$this->lang->line('NOT_BLANK'), 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			redirect('backoffice/customer/reset_password/'.base64_encode($id));
		}
		//echo '<pre>';print_r($this->input->post());die;
	}
	public function deletecustomer(){


				require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
				TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
				TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');
				//TalentLMS::setApiKey('gfKQd266a5BG6DauIIezMMMMmjpnGj');
				//TalentLMS::setDomain('anil123.talentlms.com');
				// echo '<pre>'; print_r($this->input->post('ids'));die;
				$ids = $this->input->post('ids');
				$comma_ids = implode(',', $ids);
				 //echo($comma_ids); die;
				if(!empty($ids))
				{
				    $lms_id = $this->common_model->solveCustomQuery("SELECT lms_id FROM user WHERE id IN(".$comma_ids.")");
				}


				if(isset($lms_id) && (!empty($lms_id)))
				{
					foreach($lms_id as $k => $vkk)
					{  // echo '<pre>'; print_R();die;
						if($vkk->lms_id != 0){
							$deleteuser = TalentLMS_User::delete(array('user_id' =>$vkk->lms_id,'permanent'=>'yes'));
						}
						
					}
				}

				if((bool)$this->db->query("DELETE FROM user WHERE id IN(".$comma_ids.")")==true){
						$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
						echo 1;
						exit;
					}else{
						$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
						echo 0;
						exit;
				}

				
	}

	public function contactus(){
				$this->data['page_form_id']=57;
		$this->data['page_module_id']=4;
			$this->data['contactus'] = $this->common_model->getRows('contactus','*');
		$this->load->view('backoffice/customer/contactus_view', $this->data);
	}

	public function sync_lms($id=0){
		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');

		$getDate = $this->common_model->solveCustomQuery("SELECT id,created_date,first_name,last_name,emailid,lms_id,subscription_plan_id FROM `user` where status=1  and created_date <>'0000-00-00' and id = ".$id." order by created_date desc");
		if(!empty($getDate)){
			foreach($getDate as $val)
			{
				$lmsid = $val->lms_id;
			    $plan_id = $val->subscription_plan_id;
			    $user_id= $val->id;
			    if($plan_id==1)
			    {
			        TalentLMS::setDomain('diy-healthtransitionsuniversity.talentlms.com');
			    }else
			    {
			     	TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
			    }
			    $getDateval = $val->created_date;	
			    $noofweek = $this->calculate_date($getDateval);
			    if(!empty($noofweek))
				{
					if($noofweek['week'] >=3 && $noofweek['week'] < 10)
					{
						try{
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
				        }catch(Exception $e){
                            $e->getMessage();
                        }
					
					}
					elseif($noofweek['week'] >=10 && $noofweek['week'] < 15)
					{
						try{
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }	
					}
					elseif($noofweek['week'] >=15 && $noofweek['week'] < 20)
					{
						try{
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '144'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >=20 && $noofweek['week'] < 25)
					{
						try{
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '146'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >=25 && $noofweek['week'] < 30)
					{
						try{
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '146'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '148'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >= 30 && $noofweek['week'] < 35)
					{
						//$WFF='WFF 8: Therapeutic Fasting';
						try{
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '146'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '148'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '150'));
						}catch(Exception $e){
	                    	$e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >=35 && $noofweek['week'] < 40)
					{
						try{
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '146'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '148'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '150'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '152'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >=40)
					{
						try{
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '146'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '148'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '150'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '152'));
							TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '154'));
						}catch(Exception $e){
	                         $e->getMessage();
	                    }
					}	
				}
			}
		}
	}
	public function calculate_date($get_created_date)
	{
		$nodays='';
		$noweek='';
		$days_info=array();

		$date1 = date('Y-m-d H:i:s');
		$date2 =  $get_created_date;
		$diff = strtotime($date1) - strtotime($date2);
		$days = ceil(($diff)/ (60*60*24));

		if($days >14){
			$noweek =  number_format($days/7,1);
			$totaldays= $days%7;
			$val = explode(".",$noweek);
			if($totaldays==0){
				$days_info['day']=7;
				$days_info['week'] = $val[0];
			}else{
				$days_info['day'] = $totaldays;
				$days_info['week'] = $val[0]+1;
			}
		}else{
				$days_info['day'] ='';
				$days_info['week']= '';
		}
		return $days_info;
	}

	public function removeAdd($id=873){

		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
		
		$getDate = $this->common_model->solveCustomQuery("SELECT id,created_date,first_name,last_name,emailid,lms_id,subscription_plan_id FROM `user` where status=1  and created_date <>'0000-00-00' and id = ".$id." order by created_date desc");
		if($getDate[0]->subscription_plan_id==1)
	    {
	        TalentLMS::setDomain('diy-healthtransitionsuniversity.talentlms.com');
	    }else
	    {
	     	TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
	    }
		TalentLMS_Course::removeUser(array('user_id' => $getDate[0]->lms_id, 'course_id' => '142'));
	}

	public function free_sample_lessons(){

		$this->data['page_form_id']=62;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">View Free Sample Lessons</li></ol>';
		$user_sql="SELECT * FROM free_sample_lessons  order by id desc";
		$this->data['recs'] = $this->common_model->solveCustomQuery($user_sql);
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/customer/lession_view', $this->data);
	}
}

?>
