<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Meeting extends CI_Controller
{
    public $data = array();
    public $msg = array();

    public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 25;
		$this->data['page_form_id']=13;
		$this->data['page_module_id']=7;
		//$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
    public function medical($start=0)
	{
		//print_r($this->input->post());die;
		$this->data['page_form_id']=50;
		$this->data['page_module_id']=4;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Diet label</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_diets')=='Search'){
			$diets_name = $this->input->post('diets_name');	
			if($diets_name!=''){
				$conds[] = "Message like '%".$diets_name."%'";
			}
			$url_cond.='?diets_name='.$diets_name.'&form_submit_diets=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['diets_name'] =$this->input->post('diets_name');
		$total_get_sql = "SELECT count(id) as total FROM net_gram ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM medical ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_diets_search_submit']=base_url('backoffice/meeting/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/meeting/show_medical_view', $this->data);
    }
    public function meeting_edit($id=0)
	{$this->data['page_form_id']=24;
		$this->data['page_module_id']=7;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
		$id=base64_decode($id);
		$this->data['rec'] = $this->common_model->getRows('medical','*',array('id'=>$id));
		//print_r($this->data['rec']);die;
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->data['act'] = base_url('backoffice/meeting/update_medical/'.base64_encode($id));	
		$this->load->view('backoffice/meeting/add_medical_view', $this->data, FALSE);

	}
    public function add_medical($start=0)
	{
		$this->data['page_form_id']=24;
		$this->data['page_module_id']=7;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->data['act'] = base_url('backoffice/meeting/medical_save');
		$this->load->view('backoffice/meeting/add_medical_view', $this->data, FALSE);
		
	}
	public function show_netgram($start=0)
	{
		//print_r($this->input->post());die;
		$this->data['page_form_id']=46;
		$this->data['page_module_id']=4;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Diet label</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_diets')=='Search'){
			$diets_name = $this->input->post('diets_name');	
			if($diets_name!=''){
				$conds[] = "Message like '%".$diets_name."%'";
			}
			$url_cond.='?diets_name='.$diets_name.'&form_submit_diets=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['diets_name'] =$this->input->post('diets_name');
		$total_get_sql = "SELECT count(id) as total FROM net_gram ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM net_gram ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_diets_search_submit']=base_url('backoffice/meeting/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/meeting/netgram_view', $this->data);
    }
	public function show_questionnaire($start=0)
	{
		//print_r($this->input->post());die;
		$this->data['page_form_id']=45;
		$this->data['page_module_id']=4;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Diet label</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_diets')=='Search'){
			$diets_name = $this->input->post('diets_name');	
			if($diets_name!=''){
				$conds[] = "Message like '%".$diets_name."%'";
			}
			$url_cond.='?diets_name='.$diets_name.'&form_submit_diets=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['diets_name'] =$this->input->post('diets_name');
		$total_get_sql = "SELECT count(id) as total FROM questionnairetable ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM questionnairetable ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_diets_search_submit']=base_url('backoffice/meeting/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/meeting/questionnaire_view', $this->data);
    }
	public function show($start=0)
	{
		//print_r($this->input->post());die;
		$this->data['page_form_id']=45;
		$this->data['page_module_id']=4;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Diet label</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_diets')=='Search'){
			$diets_name = $this->input->post('diets_name');	
			if($diets_name!=''){
				$conds[] = "Message like '%".$diets_name."%'";
			}
			$url_cond.='?diets_name='.$diets_name.'&form_submit_diets=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['diets_name'] =$this->input->post('diets_name');
		$total_get_sql = "SELECT count(id) as total FROM allow_meeting ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM allow_meeting ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_diets_search_submit']=base_url('backoffice/meeting/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/meeting/meeting_view', $this->data);
    }
	public function delete_meeting($diets_id=0){
		if((bool)$this->common_model->delete('allow_meeting',array('id'=>base64_decode($diets_id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/meeting/show');
	}
	public function delete_netgram($diets_id=0){
		if((bool)$this->common_model->delete('net_gram',array('id'=>base64_decode($diets_id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/meeting/show_netgram');
	}
	public function delete_questionnaire($diets_id=0){
		if((bool)$this->common_model->delete('questionnairetable',array('id'=>base64_decode($diets_id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/meeting/show_questionnaire');
	}
	public function add_meeting($start=0)
	{
		$this->data['page_form_id']=24;
		$this->data['page_module_id']=7;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->data['act'] = base_url('backoffice/meeting/meeting_save');
		$this->load->view('backoffice/meeting/add_meeting_view', $this->data, FALSE);
		
	}
	public function add_netgram($start=0)
	{
		$this->data['page_form_id']=46;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->data['act'] = base_url('backoffice/meeting/netgram_save');
		$this->load->view('backoffice/meeting/add_netgram_view', $this->data, FALSE);
		
	}
	public function add_questionnaire($start=0)
	{
		$this->data['page_form_id']=45;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->data['act'] = base_url('backoffice/meeting/questionnaire_save');
		$this->load->view('backoffice/meeting/add_questionnaire_view', $this->data, FALSE);
	}
	public function validate_meeting()
	{

		$this->form_validation->set_rules('add_meeting', 'Add meeting', 'trim|required|strip_tags');
		return $this->form_validation->run();

	}
	public function validate_medical()
	{

		$this->form_validation->set_rules('agree_title', 'Add agree', 'trim|required|strip_tags');
		return $this->form_validation->run();

	}
	public function validate_netgram()
	{

		$this->form_validation->set_rules('add_netgram', 'Add netgram', 'trim|required|strip_tags');
		return $this->form_validation->run();

	}
	public function validate_questionnaire()
	{

		$this->form_validation->set_rules('add_questionnaire', 'Add questionnaire', 'trim|required|strip_tags');
		return $this->form_validation->run();

	}
	public function questionnaire_save()
	{
		if($this->validate_questionnaire()){	
			$time=time();
			$this->data = array(
				'questionnaire_name' => $this->input->post('add_questionnaire'),
				'status' => $this->input->post('status'),
			);
			if((bool)$this->common_model->save('questionnairetable',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/meeting/show_questionnaire');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_questionnaire();
			}
		}
		else
		{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
			$this->session->set_flashdata($this->msg);
			return $this->add_questionnaire();
		}
		
	}
	public function medical_save()
	{
		if($this->validate_medical()){	
			$time=time();
			$this->data = array(
				'agree_title' => $this->input->post('agree_title'),
				'description' => $this->input->post('description'),
				'status' => $this->input->post('status'),
				'created_date' => date('Y-d-m'),
			);
			if((bool)$this->common_model->save('medical',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/meeting/medical');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_medical();
			}
		}
		else
		{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
			$this->session->set_flashdata($this->msg);
			return $this->add_medical();
		}
		
	}
	public function update_medical($id){
		//echo $id;
		//print_r($this->input->post());die;
		
		if($this->validate_medical($id)){ //echo $id;die;
			$this->data = array(
				'agree_title' => $this->input->post('agree_title'),
				'description' => $this->input->post('description'),
				'status' => $this->input->post('status'),
				'created_date' => date('Y-d-m'),
			);				
			if((bool)$this->common_model->update('medical',$this->data, array('id'=>base64_decode($id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/meeting/medical');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->meeting_edit($id);
			}
			}
			else
			{
				return $this->meeting_edit($id);
			}
	}			
	public function netgram_save()
	{
		if($this->validate_netgram()){	
			$time=time();
			$this->data = array(
				'net_gram_name' => $this->input->post('add_netgram'),
				'status' => $this->input->post('status'),
			);
			if((bool)$this->common_model->save('net_gram',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/meeting/show_netgram');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_netgram();
			}
		}
		else
		{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
			$this->session->set_flashdata($this->msg);
			return $this->add_netgram();
		}
		
	}
	public function meeting_save()
	{
		//echo '<pre>'; print_r($this->input->post());die;
		//echo '<pre>'; print_r($this->input->post());die;
		if($this->validate_meeting()){	
			$time=time();
			$this->data = array(
				'meeting_name' => $this->input->post('add_meeting'),
				'status' => $this->input->post('status'),
			);
			if((bool)$this->common_model->save('allow_meeting',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/meeting/show');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_meeting();
			}
		}
		else
		{
			//echo "A4"; die;
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
			$this->session->set_flashdata($this->msg);
			return $this->add_meeting();
		}
		
	}
	
	
	
	public function week_edit($id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';
			
	    $id=base64_decode($id);		
		$this->data['rec'] = $this->common_model->getRow('week','*',array('id'=>$id));
		$this->data['act'] = site_url('backoffice/meeting/update_week/'.base64_encode($id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->data['msglist'] = $this->common_model->getRows('messagecenterposttable','MessageID,Message',array('status'=>'1'));
		$this->data['questionnairetable'] = $this->common_model->getRows('questionnairetable','id,questionnaire_name',array('status'=>'1'));
		$this->data['net_gram'] = $this->common_model->getRows('net_gram','id,net_gram_name',array('status'=>'1'));
		$this->data['allow_meeting'] = $this->common_model->getRows('allow_meeting','id,meeting_name',array('status'=>'1'));
		 $this->load->view('backoffice/meeting/add_week_view', $this->data, FALSE);
	}
	public function update_week($id){
		if($this->validate_week($id)){ 
			$this->data = array(
				'week_message_id'=>$this->input->post('week_message_id'),
				'number_of_week' => $this->input->post('number_of_week'),
				'default_val' => $this->input->post('default_val'),
				'status' => $this->input->post('status'),
			);				
			if((bool)$this->common_model->update('week',$this->data, array('id'=>base64_decode($id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/meeting/week');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->week_edit($id);
			}
			}
			else
			{
				return $this->week_edit($id);
			}
	}			
}
?>
