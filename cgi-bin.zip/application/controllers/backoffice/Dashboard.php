<?php 
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public $data = array();
    public $msg = array();

    public function __construct(){
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE){
			redirect('backoffice/login');
			exit();
		}
		$this->data['page']=1;
		$this->data['page_form_id']=1;
		$this->data['page_module_id']=1;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }	
	public function index()
	{   $total_cust='';
		
		$customer_diets_plan_sql="SELECT ANY_VALUE(customer_diets_plan.id) as id ,ANY_VALUE(customer_id) AS customer_id ,ANY_VALUE(meeting_date) as meeting_date,ANY_VALUE(comments) as comments,ANY_VALUE(user.first_name) as first_name, ANY_VALUE(user.last_name) as last_name, ANY_VALUE(weeks) as weeks,ANY_VALUE(week_wise_days) as week_wise_days, ANY_VALUE(customer_diets_plan.created_date) as created_date, ANY_VALUE(user.status) as status, ANY_VALUE(user.subscription_plan_id) as subscription_plan_id
		FROM  `customer_diets_plan` 
		JOIN customer_diets_plan_desc ON customer_diets_plan.id = customer_diets_plan_desc.customer_diets_plan_id
		JOIN user ON customer_diets_plan.customer_id = user.id   group by customer_id";
			
		$this->data['recs'] = $this->common_model->solveCustomQuery($customer_diets_plan_sql);		
		
		$this->data['records_count']=count($this->data['recs']);
		
		$total_cust=$this->common_model->solveCustomQuery("SELECT count(id) as custname from user where role_type=3 AND status=1");
		if(!empty($total_cust))
		{
			$this->data['customer_name'] = $total_cust[0]->custname;
		}
		$this->load->view('backoffice/dashboard',$this->data);
	}
	
}
