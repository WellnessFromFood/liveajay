<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class userProgress
{
    public $id;
    public $first_name;
    public $last_name;
    public $email;
    public $userCreatedDate;
    public $lastTimeLoggedIntoWFF;
    public $lastTimeLoggedDataToWFF;
    public $startingWeek=0;
    public $currentWeek=0;
    public $talentId;
    public $lastLogToTalent;
    public $coursesAssigned=0;
    public $coursesStarted=0;
    public $coursesCompleted=0;
    public $studyTimeSpent;
    public $nagEmailFlag;
    public $cheerleaderEmailFlag;
}

class apiLimit
{
    public $numberOfCallsLeft;
    public $timeOfNextReset;
    
}   



class Progress extends CI_Controller
//This class will gather information about the user's progress
{	
    public function __construct()
	{
	    parent::__construct();
	    $this->load->helper('helper');
	    $this->load->helper('sendinblue');
	    $this->output->cache(5);
	    if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		
		//$this->data['live_user_id'] = $this->session->userdata('admin')->id;
		
        
        require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
    }
    
   public function test()
   {
       TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
       //Now make a call to the api to decrement the counter by 1 - getting the latest remaining number
       
       //Not sure if that user exists
       $user_data = TalentLMS_User::retrieve(1);
       
       $sendInBlueApiLimit = TalentLMS_Siteinfo::getRateLimit();
       $date = date('d-m-y G:i:s');
       echo '$date is ' . $date . '<br>';
       $nextUpdateIn = strtotime($sendInBlueApiLimit['formatted_reset']) - strtotime($date);
      
       echo 'It is now ' . $date . '<br> Updates in about ' . date("i:s", $nextUpdateIn);
       echo '<pre>'; print_r($sendInBlueApiLimit);
   }
   
   
   
   /*
   --Moved to a helper class
   public function getNumberOfApiCallsLeftThisHour()
   {
       //This will return an apiLimit object - that will contain two pieces of data:
       //   the number of api calls left in this hour
       //   the number of minutes when the hour is up - and the apis will refresh
       
        TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
        //make a call to the api to force the cache to get reset
        $user_data = TalentLMS_User::retrieve(1);
        $sendInBlueApiLimit = TalentLMS_Siteinfo::getRateLimit();
        $date = date('d-m-y G:i:s');
        $nextUpdateIn = strtotime($sendInBlueApiLimit['formatted_reset']) - strtotime($date); 
       
       $thisApiLimit = new apiLimit();
       $thisApiLimit->numberOfCallsLeft = $sendInBlueApiLimit['remaining'];
       $thisApiLimit->timeOfNextReset = date("i:s", $nextUpdateIn);
       
       return $thisApiLimit;
   }
   */
   
   
   public function export_progress()
   {
       echo "Still working on this one ..."; 
       die;
       
       $user_sql="SELECT logged_in,emailid,id,first_name,last_name,nag_email FROM user WHERE  online in(1,0) ORDER BY UNIX_TIMESTAMP(logged_in) DESC";
		$this->data['recs'] = $this->common_model->solveCustomQuery($user_sql);

		$datatbl='';
        $datatbl = '<table cellspacing="2" cellpadding="5" style="border:2px;text-align:center;" border="1" width="60%">';
        $datatbl .= '<tr>
					<th  class="center">Entry No</th>
					<th class="center">First Name</th>
					<th  class="center">Last Name</th>
					<th  class="center">Email</th>
					<th  class="center">Automation Log Date</th>
					<th class="center">Last Diet Log</th>
					<th  class="center">Last Logged In Time</th>
					<th  class="center">Automation Mail Send Date</th>
					</tr>'; 
        			$i = 1;
        			$j=0;
        foreach ($this->data['recs'] as $val) {
        $datee = $this->common_model->getCustomFielddata('automation_detail','created_date',array('userid'=>$val->id));
        if(!empty($datee)) $logDate = date('M d Y h:i:s',strtotime($datee)); else $logDate="";
        
        $getDate = $this->common_model->solveCustomQuery("SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(created_date) as created_date,updated_date FROM `customer_diets_plan` where customer_id=".$val->id." order by id desc limit 1");
        $lastDiet ="";
        if(!empty($getDate[0]->created_date))
        {
          $lastDiet = date('M d Y h:i:s',strtotime($getDate[0]->created_date));
        }
        else if(!empty($getDate[0]->updated_date)){
          $lastDiet = date('M d Y',strtotime($getDate[0]->updated_date));
        }
        if($val->logged_in == '0000-00-00 00:00:00' || empty($val->logged_in))
        {

          $logged = '';

        }
        else
        {

          $logged = date('M d Y h:i:s',strtotime($val->logged_in));

        }
        $getDays = $this->common_model->solveCustomQuery("SELECT days from automation where status=1 order by id desc limit 1");

	    if(isset($getDays) && !empty($getDays))
	    {
	      $GetDays = $getDays[0]->days;
	    }

				$datatbl .= '<tr> 
				<td style="text-align:center;">'. $i++ . '</td>	
				<td style="text-align:center;">'. $val->first_name . '</td>						
				<td style="text-align:center;">'. $val->last_name . '</td>
				<td style="text-align:center;">'. $val->emailid . '</td>
				<td style="text-align:center;">'. $logDate . '</td>
				<td style="text-align:center;">'. $lastDiet . '</td>
				<td style="text-align:center;">'. $logged . '</td>
				<td style="text-align:center;">'. date ("M d Y", strtotime("+$GetDays day", strtotime($val->logged_in))). '</td>';

			}	       
			$datatbl .= "</tr></table>";
			//echo  $datatbl;die;       
			header('Content-Type: application/force-download');        
			header('Content-disposition: attachment; filename=loggedIn_data_'.date('d-m-Y').'.xls');         
			header("Pragma: ");        
			header("Cache-Control: ");        
			echo $datatbl;
			die; 
       
       
   }
    
	public function calculate_date($get_created_date)
	{
				$nodays='';
				$noweek='';
				$days_info=array();

				$date1 = date('Y-m-d H:i:s');
				$date2 =  $get_created_date;
				$diff = strtotime($date1) - strtotime($date2);
				$days = ceil(($diff)/ (60*60*24));
				
				//echo '$days is ' . $days; die;
                $totaldays= $days%7;

				if($days > 7){
					$noweek =  number_format($days/7,1);
					
					$val = explode(".",$noweek);
					//echo '$totaldays is ' . $totaldays; die;
					if($totaldays==0){
						$days_info['day']=7;
						$days_info['week'] = $val[0];
					}else{
						$days_info['day'] = $totaldays;
						$days_info['week'] = $val[0]+1;
					}
					
					
				//	if($totaldays==0){
					//	$days_info['day']=$val[1];
						//$days_info['week'] = $val[0];
				//	}else{
					//	$days_info['day'] = $val[1];
					//	$days_info['week'] = $val[0];
				//	}
					//$days_info['week'] = $val[0]+1;
				}else{
						$days_info['day'] = $totaldays;
						$days_info['week']= '1';
				}
				//echo '<pre>'; print_r($days_info);die;
				return $days_info;


	}


    public function index()
    {
        //0 for not started
        //1 for in progress
        //2 for graduating the first 10 month class
        
        //This is a somewhat expensive function in terms of API calls.  so, this is a simple throttling mechanism that will not allow the 
        // API count to get less than 500 in the next hour.
        //
        // We are only allowed 2000api calls/hour to the TalentLMS server until it throttles us.
        
        $currentApiHourLimit = getNumberOfApiCallsLeftThisHour();
        
        //echo '<pre'; print_r($currentApiHourLimit);
        
        if ($currentApiHourLimit->numberOfCallsLeft < 300)
        {
            $this->session->set_flashdata('msg', 'Low API limit of '.  $currentApiHourLimit->numberOfCallsLeft   . ' till the end of the hour. Please wait :' . $currentApiHourLimit->timeOfNextReset);
            redirect('backoffice/user/logged_user');
            
        }
        
        //Status is active, user has a TalentLMSId, and they are a "Customer"
        //SELECT * FROM `user` where status='1' and lms_id <> '0' and role_type='3' ORDER BY `last_name` ASC
        $users = $this->common_model->solveCustomQuery("SELECT * FROM `user` where status='1' and lms_id <> '0' and role_type='3' and grad_status=0 ORDER BY `last_name` ASC");
        //$user_sql="SELECT * FROM user where role_type=3 and grad_status=0, and status=1 ORDER BY UNIX_TIMESTAMP(logged_in) DESC";
        
        
        //echo '<pre>'; print_r($users); die;
        foreach($users as $userId=>$thisUser)
        {
            $thisUserProgress = new userProgress;
            $thisUserProgress->id = $thisUser->id;
            $thisUserProgress->first_name = $thisUser->first_name;
            $thisUserProgress->last_name = $thisUser->last_name;
            $thisUserProgress->email = $thisUser->emailid;
            $thisUserProgress->userCreatedDate = $this->common_model->getCustomFielddata('user','created_date',array('id'=>$thisUser->id));
            
            /* Last time user logged in */
            if($thisUser->logged_in == '0000-00-00 00:00:00' || empty($thisUser->logged_in))
            {
              $thisUserProgress->lastTimeLoggedIntoWFF = "Never Logged On";
            }
            else
            {
              $thisUserProgress->lastTimeLoggedIntoWFF = date('M d Y h:i:s',strtotime($thisUser->logged_in));
            }          
            
            /* last time the user logged data $to WFF */
            if($thisUser->logged_in == '0000-00-00 00:00:00' || empty($thisUser->logged_in))
            {
              $thisUserProgress->lastTimeLoggedDataToWFF = 'Never Logged Data';
            }
            else
            {
              $thisUserProgress->lastTimeLoggedDataToWFF =  date('M d Y h:i:s',strtotime($thisUser->logged_in));
            }  
            
            /* get the starting week */
            $thisUserProgress->startingWeek = $thisUser->starting_week;
            
            /* get the current Week */
            $programProgress = calculate_TheWeek($thisUserProgress->userCreatedDate);
            $thisUserProgress->currentWeek = $programProgress['week'];
            $thisUserProgress->currentDay = $programProgress['day'];
            
            /* store the talentLMSId for the user */
            $thisUserProgress->talentId = $this->common_model->getCustomFielddata('user','lms_id',array('id'=>$thisUser->id));
            
            /* make the call to the TalentLMS API to get info for the user */
            TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
            $userTalentData = TalentLMS_User::retrieve($thisUserProgress->talentId);
            
            //echo 'About to get timeline data for ' . $thisUserProgress->talentId  . '<br>';
            $userTimelineData = TalentLMS_Siteinfo::getTimeline(array('event_type'=>'user_login_user', 'user_id' => $thisUserProgress->talentId));
            
            //If there is nothing in the timeline for this user's login, they did not login yet
            if (empty($userTimelineData))
            {
                $thisUserProgress->lastLogToTalent = 'Did not log in yet';
            }
            else
            {
                //echo 'output from timeline: <br>';
                //echo '<pre>'; print_r($userTimelineData);
                $thisUserProgress->lastLogToTalent = $userTimelineData[0]['timestamp'];
            }
            
            $thisUserProgress->nagEmailFlag = $thisUser->nag_email;
            $thisUserProgress->cheerleaderEmailFlag = $thisUser->cheerleader_email;
            
            
            if ($userTalentData["created_on"] == ($userTalentData["last_updated"]))
            {
                $thisUserProgress->lastLogToTalent = "Never Logged On";
                $thisUserProgress->coursesAssigned = count($userTalentData["courses"]);
                $thisUserProgress->studyTimeSpent =  "No time";
                
            }
            else
            {
                //Get the count of courses
                $thisUserProgress->coursesAssigned = count($userTalentData["courses"]);
                
                $totalTime='';
                //loop thru the courses that are assigned to the user and gather any progress
                foreach($userTalentData["courses"] as $key => $eachCourse)
                {
                    if (!empty($eachCourse["total_time"]))
                    {
                        $totalTime = addDurationToTotal($eachCourse["total_time"], $totalTime);
                    }
                    if (!empty($eachCourse["completed_on"]))
                    {
                        $thisUserProgress->coursesCompleted = $thisUserProgress->coursesCompleted + 1;
                    }
                    
                    if ($eachCourse["completion_percentage"] <> 0)
                    {
                        $thisUserProgress->coursesStarted = $thisUserProgress->coursesStarted + 1;
                    }
                    
                }
                if (empty($totalTime)){
                    $thisUserProgress->studyTimeSpent =  "No time";
                }
                else
                {
                    $thisUserProgress->studyTimeSpent = $totalTime;
                }
                                    
                                    
            }
           $this->data[$userId]= $thisUserProgress; 
        }
       
		
		$this->data['page_form_id']=63;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">View Users Progress</li></ol>';
		$this->data['apiHourLimitInfo'] = $currentApiHourLimit;
	
        $this->load->view('backoffice/user/progress_view', $this->data);
    }
    


	public function enrolleddata($user_id,$course="",$history_id,$week="")
	{ 
		$user_data = $this->common_model->getRow('user','lms_id,first_name,last_name',array('id'=>$user_id));
		enrollCustomer($user_id,$week);
		$data = array(
			'user_id'=>$user_id,
			'name'=>$user_data->first_name." ".$user_data->last_name,
			'enrolled_on'=>$course,
			'created_date'=>date('Y-m-d h:i:s'),
			'lms_id'=>$user_data->lms_id,
			'automation_history_id'=>$history_id
		);
		$this->common_model->save('automation_nextlession',$data);
	}

	public function index_old()
	{
		$GetDays='';
		$getDateval='';
		$WFF='';
		//and id=764
		$check_auto = $this->common_model->getRow('automation_logs','*',array('id'=>2));
		if($check_auto->automation_status == 1){

		$his = array(
			'name'=>$check_auto->name,
			'start_runTime'=>date('Y-m-d h:i:s'),
			'action_taken'=>0,
			'automation_type'=>$check_auto->id);
		$history_id = $this->common_model->saveAndGetLastId('automation_history',$his);
		$this->common_model->update('automation_logs',array('started_on'=>date('Y-m-d'),'automation_status'=>3),array('id'=>2));
		$getDate = $this->common_model->solveCustomQuery("SELECT id,created_date,first_name,last_name,emailid,lms_id,subscription_plan_id FROM `user` where status=1  and created_date <>'0000-00-00' order by created_date desc");
		$action = 0;
	
		if(!empty($getDate))
		{
				
			foreach($getDate as $k=>$val)
			{
			    $emailid = $val->emailid;
		    	$lmsid = $val->lms_id;
			    $plan_id = $val->subscription_plan_id;
			    $user_id= $val->id;
			    if($plan_id==1)
			    {
			        TalentLMS::setDomain('diy-healthtransitionsuniversity.talentlms.com');
			    }else
			    {
			     	TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
			    }
				$getDateval = $val->created_date;	
				$noofweek = $this->calculate_date($getDateval);
				if(!empty($noofweek))
				{
					if($noofweek['week']==3 && $noofweek['day'] ==1)
					{
						
						try{
						    	TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						        $this->enrolleddata($user_id,'WFF 3: Getting Started',$history_id,22);
						        $action++;
					        }catch(Exception $e){
	                            $e->getMessage();
	                        }
					
					}
					elseif($noofweek['week']==6 && $noofweek['day']==1)
					{
						//$WFF='WFF 4: A Quick Fix vs. A Way of Life';
						try{
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
						$this->enrolleddata($user_id,'WFF 6: A Quick Fix vs. A Way of Life',$history_id,23);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }	
					}
					elseif($noofweek['week']==10 && $noofweek['day']==1)
					{
						//$WFF='WFF 5: Transition to Everyday Foods';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '144'));
						$this->enrolleddata($user_id,'WFF 5: Transition to Everyday Foods',$history_id,26);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==15 && $noofweek['day']==1)
					{
						//$WFF='WFF 6: Exercise?';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '146'));
						$this->enrolleddata($user_id,'WFF 6: Exercise?',$history_id,27);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==25 && $noofweek['day']==1)
					{
						//$WFF='WFF 7: "Cheating" and Experiencing Setbacks';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '148'));
						$this->enrolleddata($user_id,'WFF 7: "Cheating" and Experiencing Setbacks',$history_id,28);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==30 && $noofweek['day']==1)
					{
						//$WFF='WFF 8: Therapeutic Fasting';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '150'));
						$this->enrolleddata($user_id,'WFF 8: Therapeutic Fasting',$history_id,29);
						
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==35 && $noofweek['day']==1)
					{
						//$WFF='WFF 9: Managing Temptations';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '152'));
						$this->enrolleddata($user_id,'WFF 9: Managing Temptations',$history_id,30);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==40 && $noofweek['day']==1)
					{
					    
						//$WFF='WFF 10: Graduation!';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '154'));
						$this->enrolleddata($user_id,'WFF 10: Graduation!',$history_id,31);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}	
					elseif($noofweek['week']==45 && $noofweek['day']==1)
					{
					    //This is where we want to change the status to Graduation!
						//$WFF='WFF 10: Graduation!';
						try{
					//	TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '154'));
					//	$this->enrolleddata($user_id,'WFF 10: Graduation!',$history_id,31);
					//	$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}	
				}
			}

		
		}
		$this->common_model->update('automation_logs',array('date_time_last_run'=>date('Y-m-d h:i:s'),'action_taken'=>$action,'automation_status'=>1),array('id'=>2));  
	    $this->common_model->update('automation_history',array('end_runTime'=>date('Y-m-d h:i:s'),'action_taken'=>$action),array('run_id'=>$history_id));

	}  
	       
}

public function cron_test(){
	$this->index();
}
}

