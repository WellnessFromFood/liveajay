<?php
class User extends CI_Controller {

	public $data = array();
    public $msg = array();

 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 19;
		$this->data['page_form_id']=2;
		$this->data['page_module_id']=2;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }

	public function show()
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">View users</li></ol>';
		$user_sql="SELECT * FROM user WHERE  role_type in(SELECT role_id FROM user_role where role_id !=3) order by id desc";
		$this->data['recs'] = $this->common_model->solveCustomQuery($user_sql);
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/user/user_view', $this->data);
	}

	public function add()
	{
		$this->data['page'] = 1922;
		$this->data['page_form_id']=7;
		$this->data['page_module_id']=2;
		$campus_ids=array();
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add user</li></ol>';
		$this->data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
		$this->data['week'] = $this->common_model->getRows('week','id,number_of_week',array('status'=>'1'));
		$this->data['role'] = $this->common_model->getRows('user_role','role_id,role_name',array('role_id !='=>3,'role_status'=>1));
		//$this->data['campus_ids']=$campus_ids;
		$this->data['act'] = site_url('backoffice/user/save');
        $this->data['submit'] = lang('SAVE_BTN');
		//echo '<pre>'; print_r($this->data['role']);die;
        $this->load->view('backoffice/user/add_user_view', $this->data, FALSE);
	}
	private function hash_password($password)
	{
		return password_hash($password, PASSWORD_BCRYPT);
	}
	public function save(){
		if($this->_validData()){
			$role_name='';
			 //echo '<pre>'; print_r($this->input->post());die;
			if(!empty($this->session->userdata('admin')->role_name)){
				$role_name = $this->session->userdata('admin')->role_name;
			}
			$role_id_name=$this->input->post('role_id');
			$this->data = array(
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'address' => $this->input->post('address'),
				'role_type' =>$role_id_name,
				'role_name' => $role_name,
				'emailid' => $this->input->post('email'),
				'password' => $this->hash_password($this->input->post('password')),
				'country_id' => $this->input->post('country_id'),
				'state_id' => $this->input->post('state_id'),
				'city_id' => $this->input->post('city_id'),
				'status' => $this->input->post('status'),
				'contact_no'=>$this->input->post('contact_no'),
				'number_week' => $this->input->post('number_week'),
				'created_date' => date('Y-m-d,H:i:s'),
				'created_by' => $this->data['live_user_id']);
			if($_FILES['profile_image']['name']){
				$this->updata = $this->functions->do_upload('uploads/profile_images/', 'profile_image');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/profile_images/'.$this->input->post('OldBannerImage'));
						}
						$this->data['profile_image'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit();
					}
			}
			$user_id = $this->common_model->saveAndGetLastId('user',$this->data);

			$this->data1 = array(
					'provider_name' => $this->input->post('providername'),
					'pcustid' => $user_id
			);

			$this->common_model->saveAndGetLastId('provider',$this->data1);

			if($user_id!=''){

				//Send Mail
				$hashCode = md5(rand(0,1000));
		    	$mailEmail = $this->input->post('email');
		    	$name = ucwords($this->input->post('first_name'));
				$this->common_model->update('user',array('hash'=>trim($hashCode)),array('emailid'=>$mailEmail));
				$mail = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>21,'status'=>1));
				$data['hash']=$hashCode;
				$data['email'] =$mailEmail;
				$data['dynamic_content'] = $mail->email_description;
				$data['full_name']=$name;
				$massege = $this->load->view('frontend/email/backoffice_user_mail',$data,true);
				$subject = $mail->subject_txt;

				$email_dat = array(
				'to'=>$mailEmail,
				'subject'=>$subject,
				'msg'=>$massege);
				$res = $this->common_model->Send_GetStarted_Mail($email_dat);
				//echo $massege;
				//Send Email Mail*/

				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/user/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			return $this->add();
		}
	}

	public function edit($user_id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/user/show').'">Manage user</a></li><li class="active">Edit user</li></ol>';
		$user_id=base64_decode($user_id);
		$user_sql="SELECT * FROM user WHERE id=".$user_id;
		$this->data['rec'] = $this->common_model->solveCustomQuery($user_sql);
		$db_country_id =$this->data['rec'][0]->country_id;
		$db_state_id =$this->data['rec'][0]->state_id;
		$this->data['role'] = $this->common_model->getRows('user_role','role_id,role_name',array('role_id !='=>3,'role_status'=>1));
		$this->data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
		$this->data['state'] = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1','country_id'=>$db_country_id));
		$this->data['city'] = $this->common_model->getRows('cities','id,city_name,state_id',array('status'=>'1','state_id'=>$db_state_id));
		$this->data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
		$this->data['act'] = site_url('backoffice/user/update/'.base64_encode($user_id));
		$this->data['submit'] = lang('UPDATE_BTN');
		$this->load->view('backoffice/user/add_user_view', $this->data, FALSE);
	}

	public function delete_image(){
		$user_id = $this->input->post('user_id');
		if((bool)$this->common_model->update('user',array('profile_image'=>''),array('id'=>$user_id)) === true){
			if(file_exists('uploads/profile_images/'.$this->input->post('image_path'))){
                unlink('uploads/profile_images/'.$this->input->post('image_path'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}

	public function update($user_id=0){
	    $user_id=base64_decode($user_id);
		if($this->_validData($user_id)){
			$time = time();
			$campus_ids=$this->input->post('campus_ids');
			$role_id_name=$this->input->post('role_id');
			
			//echo '<pre>'; print_r($this->input->post());die;
			
			$rslt=explode('#',$role_id_name);
			$this->data = array(
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'address' => $this->input->post('address'),
				'role_type' => $rslt[0],
				'role_name' => "Staff",
				'emailid' => $this->input->post('email'),
				'contact_no'=>$this->input->post('contact_no'),
				//'password' => md5($this->input->post('password')),
				'country_id' => $this->input->post('country_id'),
				'state_id' => $this->input->post('state_id'),
				'city_id' => $this->input->post('city_id'),
				'status' => $this->input->post('status'),
				'number_week' => $this->input->post('number_week'),
				'created_date' => $time,
				'created_by' => $this->data['live_user_id']);
				
			
			
				
			if($_FILES['profile_image']['name']){
			    
			    
				$this->updata = $this->functions->do_upload('uploads/profile_images/', 'profile_image');
				
				
					if(@$this->updata['res'] === TRUE){
					    
					    
						if($this->input->post('OldBannerImage')){
							unlink('uploads/profile_images/'.$this->input->post('OldBannerImage'));
						}
						$this->data['profile_image'] = $this->updata['upload_data']['file_name'];
					}else{
					    
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						
						$this->session->set_userdata($this->msg);
						//echo '<pre>'; print_r($this->msg);die;
						return $this->edit($user_id);
					}
			}
			
			
			
			
			if((bool)$this->common_model->update('user',$this->data, array('id'=>$user_id)) === TRUE){

				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/user/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($user_id);
			}
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
			$this->session->set_flashdata($this->msg);
			return $this->edit(base64_encode($user_id));
		}
	}

	public function delete($id=0){
	    $id=base64_decode($id);
		if((bool)$this->common_model->delete('user',array('id'=>$id))){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		 $this->session->set_flashdata($this->msg);
		redirect('backoffice/user/show');
	}

	private function _validData($id=0)
	{
		$this->form_validation->set_rules('first_name', 'First Name ', 'trim|required|strip_tags');
	
		$this->form_validation->set_rules('email', 'Email ', 'trim|required|strip_tags');
		
		return $this->form_validation->run();
    }

	public function ch_status($id=0,$Status=0){
		if($id){
			$time = time();
			$this->data = array('status'=>$Status,'modified_date'=>$time);
			if($this->common_model->update('user',$this->data,array('id'=>$id))){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode($this->data['msg_type']);
	}
	public function checkImage()
	{
		if(empty($_FILES['BannerImage']['name'])){
			$this->form_validation->set_message('checkImage', 'Banner image is required');
			return FALSE;
		}
		return TRUE;
	}
	public function find_state_by_country_id($country_id=0)
	{
		//$state_id=@$this->input->post('state_id');
		if(!empty($country_id)){
			$state = $this->common_model->getRows('state','state_id,country_id,state_name',array('status'=>'1','country_id'=>$country_id));
			$html="<option value=''>Please Select</option>";
			if(!empty($state)){ foreach($state as $state_val){
			if($country_id==$state_val->country_id){ $selected='selected'; }else{ $selected=''; }
			$html.="<option value='".$state_val->state_id."' ".$selected.">".$state_val->state_name."</option>";
			}}
		}
		echo $html;
	}
	public function find_state_id($state_id=0)
	{
		//$state_id=@$this->input->post('state_id');
		$cities = $this->common_model->getRows('cities','id,state_id,city_name',array('status'=>'1','state_id'=>$state_id));
		$html="<option value=''>Please Select</option>";
		if(!empty($cities)){ foreach($cities as $cities_val){
		if($state_id==$cities_val->state_id){ $selected='selected'; }else{ $selected=''; }
		$html.="<option value='".$cities_val->id."' ".$selected.">".$cities_val->city_name."</option>";
		}}
		echo $html;
	}
		public function reset_password(){
		$id = base64_decode($this->uri->segment(4));
		$user_name = $this->common_model->getRows('user','emailid',array('id'=>$id));
		//print_r($user_name);die;
		$data['getusername']=$user_name[0]->emailid;
		$data['submit'] = $this->lang->line('SAVE_BTN');
		$data['action'] = site_url('backoffice/user/update_reset_password/'.base64_encode($id));
		$data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/user/reset_password_view', $data);
	}
	public function update_reset_password($id=0)
	{
		$getalllinfo =  $this->session->userdata('admin');
		//echo '<pre>'; print_r($getalllinfo);die;
		$id = base64_decode($id);
		$getusername = $this->input->post('email');
		$getpassword = $this->input->post('password');
		if(($getusername !='') && ($getpassword !='')){
			$data=array(
			'password'=>$this->hash_password($getpassword)
			);
		$cond=array('id'=>$id,'emailid'=>$getusername,'status'=>1);
/*		echo "<pre>";
		print_r($data);
		print_r($cond);*/
		//die();
		if($getalllinfo->role_type ==1){

			if($this->common_model->update('user',$data, $cond))
			{
				$this->msg = array('msg'=>$this->lang->line('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/user/show');
			}

		}else{
			$this->msg = array('msg'=>$this->lang->line('NOT_PERMISSION'), 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			redirect('backoffice/user/reset_password/'.base64_encode($id));

		}

		}else{
			$this->msg = array('msg'=>$this->lang->line('NOT_BLANK'), 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			redirect('backoffice/user/reset_password/'.base64_encode($id));
		}
		//echo '<pre>';print_r($this->input->post());die;
	}
	public function deleteuser(){

			$id= $this->db->query("delete from user where id in(".$this->input->post('ids').")");
			echo $id;die;
	}
	public function logged_user(){
		$this->data['page_form_id']=40;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">View users</li></ol>';
		//$user_sql="SELECT logged_in,emailid,id,first_name,last_name,nag_email,role_type FROM user where role_type=3 and grad_status=0, and status=1 ORDER BY UNIX_TIMESTAMP(logged_in) DESC";
		$user_sql="SELECT * FROM user where role_type=3 and grad_status=0 and status=1 ORDER BY UNIX_TIMESTAMP(logged_in) DESC";
		$this->data['recs'] = $this->common_model->solveCustomQuery($user_sql);
		
		$this->load->view('backoffice/user/logged_user', $this->data);
	}

	public function export_logged_user()
	{
		$user_sql="SELECT logged_in,emailid,id,first_name,last_name,nag_email FROM user WHERE  online in(1,0) ORDER BY UNIX_TIMESTAMP(logged_in) DESC";
		$this->data['recs'] = $this->common_model->solveCustomQuery($user_sql);

		$datatbl='';
        $datatbl = '<table cellspacing="2" cellpadding="5" style="border:2px;text-align:center;" border="1" width="60%">';
        $datatbl .= '<tr>
					<th  class="center">Entry No</th>
					<th class="center">First Name</th>
					<th  class="center">Last Name</th>
					<th  class="center">Email</th>
					<th  class="center">Automation Log Date</th>
					<th class="center">Last Diet Log</th>
					<th  class="center">Last Logged In Time</th>
					<th  class="center">Automation Mail Send Date</th>
					</tr>'; 
        			$i = 1;
        			$j=0;
        foreach ($this->data['recs'] as $val) {
        $datee = $this->common_model->getCustomFielddata('automation_detail','created_date',array('userid'=>$val->id));
        if(!empty($datee)) $logDate = date('M d Y h:i:s',strtotime($datee)); else $logDate="";
        
        $getDate = $this->common_model->solveCustomQuery("SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(created_date) as created_date,updated_date FROM `customer_diets_plan` where customer_id=".$val->id." order by id desc limit 1");
        $lastDiet ="";
        if(!empty($getDate[0]->created_date))
        {
          $lastDiet = date('M d Y h:i:s',strtotime($getDate[0]->created_date));
        }
        else if(!empty($getDate[0]->updated_date)){
          $lastDiet = date('M d Y',strtotime($getDate[0]->updated_date));
        }
        if($val->logged_in == '0000-00-00 00:00:00' || empty($val->logged_in))
        {

          $logged = '';

        }
        else
        {

          $logged = date('M d Y h:i:s',strtotime($val->logged_in));

        }
        $getDays = $this->common_model->solveCustomQuery("SELECT days from automation where status=1 order by id desc limit 1");

	    if(isset($getDays) && !empty($getDays))
	    {
	      $GetDays = $getDays[0]->days;
	    }

				$datatbl .= '<tr> 
				<td style="text-align:center;">'. $i++ . '</td>	
				<td style="text-align:center;">'. $val->first_name . '</td>						
				<td style="text-align:center;">'. $val->last_name . '</td>
				<td style="text-align:center;">'. $val->emailid . '</td>
				<td style="text-align:center;">'. $logDate . '</td>
				<td style="text-align:center;">'. $lastDiet . '</td>
				<td style="text-align:center;">'. $logged . '</td>
				<td style="text-align:center;">'. date ("M d Y", strtotime("+$GetDays day", strtotime($val->logged_in))). '</td>';

			}	       
			$datatbl .= "</tr></table>";
			//echo  $datatbl;die;       
			header('Content-Type: application/force-download');        
			header('Content-disposition: attachment; filename=loggedIn_data_'.date('d-m-Y').'.xls');         
			header("Pragma: ");        
			header("Cache-Control: ");        
			echo $datatbl;
			die;     

	}

	public function test()
	{
		$sub33= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>3,'status'=>1));
		$emailid = "gla.anilgupta88@gmail.com";
		$stime="time";
		$sdate="Date";
		$proname= "Proname";
		$customername="Anil Gagan";
		$this->common_model->commonMail(3,$sub33,$emailid,'',
					@$stime,@$sdate,$customername,$proname,'jh@gmail.com');
	}

	public function test1()
	{
		$sub122= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>12,'status'=>1));
		$emailid = 'p9006614336@gmail.com';
		$stime="time";
		$sdate="Date";
		$proname= "Proname";
		$customername="Anil Gagan";
		$this->common_model->commonMail(3,$sub122,$emailid,'',
					@$stime,@$sdate,$customername,$proname,"gla.anilgupta88@gmail.com");
	}
	
	public function changeCheerleaderStatus()
	{
	    //This will update the underlying model (and database)
		$val = $this->input->post('val');
		$user_id = $this->input->post('user_id');
		if($val == 1) {
			$data = array('cheerleader_email'=>0);
		}else{
			$data = array('cheerleader_email'=>1);
		}
		$res = $this->common_model->update('user',$data,array('id'=>$user_id));
		if($res) echo 1;
		else echo 0;
	}

	public function changeNagStatus()
	{
	//This will update the underlying model (and database)
	//echo "chageNag is called";
		$val = $this->input->post('val');
		$user_id = $this->input->post('user_id');
		$id = $this->input->post('id');
		
		if($val == 1) {
			$data = array('nag_email'=>0);
		}else{
			$data = array('nag_email'=>1,'no_of_sentMail'=>0);
		}
		$res = $this->common_model->update('user',$data,array('id'=>$user_id));
		if($res) echo 1;
		else echo 0;
	}
}
?>
