<?php
class Automation extends CI_Controller {

	public $data = array();
    public $msg = array();

 	public function __construct()
	{
		//echo date('Y-m-d h:i:s');exit;
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
			
		}

		$this->data['page'] = 9;
		$this->data['page_form_id']=61;
		$this->data['page_module_id']=20;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->load->library('talentlmsapi');
    }
	public function show($start=0)
	{
		$this->data['page_form_id']=61;
		$this->data['page_module_id']=20;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage automation</li></ol>';
		$automation="SELECT * FROM automation_logs limit ".$limit." offset ".$limit_from;
		$this->data['recs'] = $this->common_model->solveCustomQuery($automation);
		$total_c = $this->common_model->solveCustomQuery('select count(id) as total from automation_logs');

		
		$records_count=$total_c[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit);

		$this->load->view('backoffice/automation/automation_view', $this->data);
	}
	
	public function add()
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/automation/show').'">Manage automation</a></li><li class="active">Add automation</li></ol>';
				
		$this->data['submit'] = lang('SAVE_BTN');
		$this->data['act']= site_url('backoffice/automation/save');
		//echo '<pre>';print_r($this->data['rec']);die;
		$this->load->view('backoffice/automation/add_automation_view', $this->data, FALSE);
	}
	
	public function save()
	{
	//echo '<pre>'; print_r($this->input->post());die;		
		if($this->_validData())
		{
			$name = $this->input->post('name');
			$description = $this->input->post('description');
			$schedule_run_time = $this->input->post('schedule_run_time');
			$reoccurrence_type = $this->input->post('reoccurrence_type');
			$automation_status = $this->input->post('status');

			$data=array(
			    'name'=>$name,			
				'description'=>$description,
				'started_on'=>date('Y-m-d'),
				'schedule_run_time'=>$schedule_run_time,
				'reoccurrence_type'=>$reoccurrence_type,
				'automation_status'=>$automation_status
			);
		

			 $user_id = $this->common_model->saveAndGetLastId('automation_logs',$data);
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/automation/show');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
		}
	}
		
	

	public function edit($user_id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active"><a href="'.base_url('backoffice/automation/show').'">Manage automation</a></li><li class="active">Edit automation</li></ol>';
		$user_id=base64_decode($user_id);
		$user_sql="SELECT * FROM automation_logs WHERE id=".$user_id;
		$this->data['rec'] = $this->common_model->solveCustomQuery($user_sql);		
		$this->data['submit'] = lang('UPDATE_BTN');
		$this->data['act']= site_url('backoffice/automation/update');
		//echo '<pre>';print_r($this->data['rec']);die;
		$this->load->view('backoffice/automation/add_automation_view', $this->data, FALSE);
	}
	public function update($user_id='')
	{
		
		
		//echo '<pre>';print_r($this->input->post());die;

		$id = $this->input->post('id');
		$name = $this->input->post('name');
		$description = $this->input->post('description');
		$schedule_run_time = $this->input->post('schedule_run_time');
		$reoccurrence_type = $this->input->post('reoccurrence_type');
		$automation_status = $this->input->post('status');

		$data=array(
		    'name'=>$name,			
			'description'=>$description,
			'started_on'=>date('Y-m-d'),
			'schedule_run_time'=>$schedule_run_time,
			'reoccurrence_type'=>$reoccurrence_type,
			'automation_status'=>$automation_status
		);
		$cond=array('id'=>$id);
		

		if($this->common_model->update('automation_logs',$data, $cond))
			{
				$this->msg = array('msg'=>$this->lang->line('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/automation/show');
			}

	}

	public function history($id=0,$start=0){
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$id= base64_decode($id);
		$this->data['recs']= $this->common_model->getRows('automation_history','*',array('automation_type'=>$id),'run_id','desc',$limit_from,$limit);
		$count = $this->common_model->getRows('automation_history','count(run_id) as total',array('automation_type'=>$id));
		$records_count=$count[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit);

		$this->load->view('backoffice/automation/automation_history',$this->data);

	}
	public function history_details($run_id=0,$start=0){
		$id = base64_decode($run_id);
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['recs']= $this->common_model->getRows('automation_nextlession','*',array('automation_history_id'=>$id),'id','desc',$limit_from,$limit);
		$count = $this->common_model->getRows('automation_nextlession','count(id) as total',array('automation_history_id'=>$id));
		$this->data['run_id']=$id;
		$this->data['back_id']='';
		if(!empty($this->data['recs'])){
			$back_id = $this->common_model->getRow('automation_history','automation_type',array('run_id'=>$this->data['recs'][0]->automation_history_id));
			$this->data['back_id']=$back_id->automation_type;
		}
		$records_count=$count[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit);
		$this->load->view('backoffice/automation/history_details',$this->data);
	}
	private function _validData($id=0)
	{
		$this->form_validation->set_rules('name', 'First Name ', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
}	
