<?php
class Social extends CI_Controller {

	public $data = array();
    public $msg = array();
	
 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 10;
		$this->data['page_form_id']=38;
		$this->data['page_module_id']=16;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function show($start=0)
	{
		$this->data['page_form_id']=38;
		$this->data['page_module_id']=16;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">social</li></ol>';
		$cond='';
		$url_cond='';
		$testimonial='';
		$total_get_sql = "SELECT count(id) as total FROM social"; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		$testimonial_sql="SELECT * FROM social t  order by id  LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($testimonial_sql);
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);		
			
		$this->data['act_testimonial_search_submit']=base_url('backoffice/social/show');		
		$this->load->view('backoffice/social/social_view', $this->data);
	}	
	public function add()
	{
		$this->data['page'] = 1022;
		$this->data['page_form_id']=38;
		$this->data['page_module_id']=16;
		$campus_ids=array();
		$course_ids=array();
		$faculty_ids=array();
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add social</li></ol>';
		$this->data['act'] = site_url('backoffice/social/save');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/social/add_social_view', $this->data, FALSE);
	}
	
	public function save(){
		if($this->validate_testimonial()){
		    $time = time();
			$this->data = array(				
				'title' => $this->input->post('title'),
				'social_link' => $this->input->post('social_link'),	
				'status' => $this->input->post('status'),
				'created_date' => date('Y-d-m'),
				'created_by' => $this->data['live_user_id']);
			if($_FILES['image']['name']){
				$this->updata = $this->functions->do_upload('uploads/social/', 'image');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/social/'.$this->input->post('OldBannerImage'));
						}
						$this->data['image'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($id);
					}
			}	
			$id = $this->common_model->saveAndGetLastId('social',$this->data);
			if($id!=''){				
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/social/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			return $this->add();
		}
	}
	
	public function edit($id=0)
	{
		$this->data['page_form_id']=38;
		$this->data['page_module_id']=16;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit social</li></ol>';
		$id=base64_decode($id);
		
		$testimonial_sql="SELECT * FROM social WHERE id=".$id;
		$this->data['rec'] = $this->common_model->solveCustomQuery($testimonial_sql);		
		$this->data['act'] = site_url('backoffice/social/update/'.base64_encode($id));
		$this->data['submit'] = lang('UPDATE_BTN');
		$this->load->view('backoffice/social/add_social_view', $this->data, FALSE);
	}
	
	public function delete_image(){
		$id = $this->input->post('id');		
		if((bool)$this->common_model->update('social',array('image'=>''),array('id'=>$id)) === true){
			if(file_exists('uploads/testimonial/'.$this->input->post('image_path'))){
                unlink('uploads/testimonial/'.$this->input->post('image_path'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
	
	public function update($id=0){
	    $id=base64_decode($id);
		if($this->validate_testimonial($id)){
			$time = time();			
			$this->data = array(				
				'title' => $this->input->post('title'),
				'social_link' => $this->input->post('social_link'),	
				'status' => $this->input->post('status'),
				'created_date' => date('Y-d-m'),
				'created_by' => $this->data['live_user_id']);
			if($_FILES['image']['name']){
				$this->updata = $this->functions->do_upload('uploads/social/', 'image');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/social/'.$this->input->post('OldBannerImage'));
						}
						$this->data['image'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($id);
					}
			}	
			if((bool)$this->common_model->update('social',$this->data, array('id'=>$id)) === TRUE){
				}}
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/social/show');
			}
		
	public function delete($id=0){
	    $id=base64_decode($id);
		$testimonial_result=$this->common_model->getRow('social','',array('id'=>$id));
		if((bool)$this->common_model->delete('social',array('id'=>$id))==true){
			
			if($testimonial_result->image!=''){
				unlink('uploads/testimonial/'.$testimonial_result->image);
			}
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		 $this->session->set_flashdata($this->msg);
		redirect('backoffice/social/show');
	}
	
	private function validate_testimonial($id=0)
	{
		//$this->form_validation->set_rules('testimonial_type_id', 'social Type ', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('course_ids[]', 'Course ', 'trim|required|strip_tags');
		$this->form_validation->set_rules('title', 'social Name', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
	
	public function ch_status($id=0,$Status=0){
		if($id){
			$time = time();
			$this->data = array('status'=>$Status,'modified_date'=>$time);	
			if($this->common_model->update('social',$this->data,array('id'=>$id))){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode($this->data['msg_type']);
	}

	public function checkImage()
	{
		if(empty($_FILES['BannerImage']['name'])){
			$this->form_validation->set_message('checkImage', 'Banner image is required');
			return FALSE;
		}
		return TRUE;
	}
}
?>