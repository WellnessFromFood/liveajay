<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Country extends CI_Controller
{
    public $data = array();
    public $msg = array();

    public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 2;
		$this->data['page_form_id']=5;
		$this->data['page_module_id']=3;
        $this->load->model("backoffice/country_model","country_model");
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }

    public function show($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Country</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		if($this->input->get('form_submit_country')=='Search'){
			$country = $this->input->get('country');	
			if($country!=''){
				$cond.= "country_name like '%".$country."%'";
				$con_use++;	
			}
			$url_cond.='?country='.$country.'&form_submit_country=Search';
		}
		if($con_use){ $cond_created_where=' WHERE '; }else{ $cond_created_where=''; }
		/* get count */
		$total_get_sql = "SELECT count(country_id) as total FROM country ".$cond_created_where." ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$country_sql="SELECT * FROM country ".$cond_created_where." ".$cond." order by country_name LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($country_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->data['act_country_search_submit']=base_url('backoffice/country/show');
		$this->load->view('backoffice/masters/country_view', $this->data);
    }
	
    public function add()
	{
		$this->data['page'] = 222;
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Country</li><li class="active">Add Country</li></ol>';
		
		$this->data['act'] = base_url('backoffice/country/save');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/masters/add_country_view', $this->data, FALSE);
    }
	
	public function save()
	{
		if($this->_validData())
		{
			$this->data = array(
			'country_name' => ucwords($this->input->post('country_name')),
			'status' => $this->input->post('status'),
			'country_date_available' => time(),
			'country_last_modified' => time());
			if((bool)$this->common_model->save('country',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/country');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			return $this->add();
		}
	}
	
	private function _validData($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('country_name', 'Country Name', 'trim|required|strip_tags|callback_check_country_name['.$id.']');
		}
		else
		{
			$this->form_validation->set_rules('country_name', 'Country Name', 'trim|required|strip_tags|is_unique[country.country_name]');
		}
		$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	
	public function delete($id=0){
	    $id=base64_decode($id);
	    $Cond=array('country_id'=>$id);
		if((bool)$this->common_model->delete('country',$Cond)){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/country');
	}
	
	public function check_country_name($country_name, $id)
	{
		$cond=array('country_name'=>$country_name, 'country_id !='=>$id);
		if((bool)$this->common_model->getRows('country', '', $cond)===true){
			$this->form_validation->set_message('check_country_name', 'This %s is already used.');
			return false;
		}
		return true;
	}
	
	public function edit($id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Country</li><li class="active">Edit State</li></ol>';
			
	    $id=base64_decode($id);
		
		$this->data['rec'] = $this->common_model->getRow('country','*',array('country_id'=>$id));
		$this->data['act'] = site_url('backoffice/country/update/'.base64_encode($id));
		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/masters/add_country_view', $this->data, FALSE);
	}
	
	public function update($id)
	{
		if($this->_validData($id)){ 
			$this->data = array('country_name' => ucwords($this->input->post('country_name')),
			'status' => $this->input->post('status'),
			'country_date_available' => time(),
			'country_last_modified' => time());	 
			
			$Cond=array('country_id'=>base64_decode($id));
			if((bool)$this->common_model->update('country',$this->data, $Cond) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/country');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($id);
			}
			}
			else
			{
				return $this->edit($id);
			}
	}
	
	public function ch_status($id=0,$Status=0)
	{		
		if($id)
		{
			$this->data = array('status'=>$Status);
			$Cond=array('country_id'=>base64_decode($id));	
			if($this->common_model->update('country',$this->data, $Cond))
			{
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}
			else
			{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}
		else
		{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode( $this->data['msg_type']);
	}
}
?>
