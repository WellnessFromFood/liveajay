<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class State extends CI_Controller 
{
    public $data = array();
    public $msg = array();

    public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['FormId'] = 3;
		$this->data['page_form_id']=7;
		$this->data['page_module_id']=3;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function citylist($id=0)
	{
		$this->data['page_form_id']=28;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">City</li></ol>';
		
		//$this->data['recs'] = $this->common_model->getRows('cities','*','');
		$table = 'cities';
		$join = array('state' => 'state.state_id = cities.state_id');
		
		$fields = 'cities.id,cities.city_name as CityName,cities.state_id as StateId,state.state_name,cities.Status';
		
		$this->data['recs'] = $this->common_model->getJoinRows('cities',$join,'',$fields,array('cities.state_id'=>base64_decode($id)));
		$this->data['permission'] = $this->common_model->checkPermission();
        $this->load->view('backoffice/masters/city_view', $this->data);
		
	}
    public function show($start=0)
	{
		$this->data['page_form_id']=28;
		$this->data['page_module_id']=4;
		
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">State</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		if($this->input->get('form_submit_state')=='Search'){
			$country = $this->input->get('country');	
			$state = $this->input->get('state');	
			if($country!=''){
				$cond.= "s.country_id=".trim($country);
				$con_use++;	
			}
			if($state!=''){
				$state= "s.state_name like '%".trim($state)."%'";
				if($cond!=''){
					$cond.=' AND '.$state;
				}else{
					$cond.=$state;
				}
				$con_use++;	
			}
			$url_cond.='?country='.$country.'&state='.$state.'&form_submit_state=Search';
		}
		if($con_use){ $cond_created_where=' WHERE '; }else{ $cond_created_where=''; }
		/* get count */
		$total_get_sql = "SELECT count(s.state_id) as total FROM state s JOIN country c ON s.country_id=c.country_id ".$cond_created_where." ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$country_sql="SELECT s.*,c.country_name FROM state s JOIN country c ON s.country_id=c.country_id ".$cond_created_where." ".$cond." order by s.state_name LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($country_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		
		//$country_name= $this->common_model->getCustomFielddata('country','country_name',array('country_id'=>$country));
		$this->data['countryid']=$this->input->get('country');
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['country']=$this->common_model->getRows('country','country_id,country_name',array('status'=>1));
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->data['act_state_search_submit']=base_url('backoffice/state/show');		
		$this->load->view('backoffice/masters/state_view', $this->data);
    }
	
    public function add()
	{
		$this->data['page'] = 322;
		$this->data['page_form_id']=28;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">State</li><li class="active">Add State</li></ol>';		
		$this->data['country'] = $this->common_model->getRows('country','*','');
		$this->data['act'] = base_url('backoffice/state/save');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/masters/add_state_view', $this->data, FALSE);
    }
	
	public function save()
	{
		if($this->_validData())
		{
			$time = time();
			$this->data = array('country_id' => $this->input->post('country_name'),
			'state_name' => ucwords($this->input->post('state_name')),
			'status' => $this->input->post('status')
			);
			if((bool)$this->common_model->save('state',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/state/show');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			return $this->add();
		}
	}
	
	public function edit($id=0)
	{
		$this->data['page_form_id']=28;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">State</li><li class="active">Edit State</li></ol>';
			
	    $id=base64_decode($id);
		
		$this->data['country'] = $this->common_model->getRows('country','*','');
		$this->data['rec'] = $this->common_model->getRow('state','*',array('state_id'=>$id));
		$this->data['act'] = site_url('backoffice/state/update/'.base64_encode($id));
		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->load->view('backoffice/masters/add_state_view', $this->data, FALSE);
	}
	
	public function update($id)
	{
		if($this->_validData($id)){ 
		    $time = time();
			$this->data = array('country_id' => $this->input->post('country_name'),
					'state_name' => ucwords($this->input->post('state_name')),
					'status' => $this->input->post('status')
					);
			$Cond=array('state_id'=>base64_decode($id));
			
			if((bool)$this->common_model->update('state',$this->data, $Cond) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/state/show');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($id);
			}
			}
			else
			{
				return $this->edit($id);
			}
	}
	
	public function delete($id=0){
	    $id=base64_decode($id);
	    $Cond=array('state_id'=>$id);
		if((bool)$this->common_model->delete('state',$Cond)){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/state/show');
	}
	
	private function _validData($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('state_name', 'State Name', 'trim|required|strip_tags|callback_check_state_name['.$id.']');
		}
		else
		{
			$this->form_validation->set_rules('state_name', 'State Name', 'trim|required|strip_tags|is_unique[state.state_name]');
			$this->form_validation->set_rules('country_name', 'Country Name', 'trim|required|strip_tags');
		}
		$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	
	public function ch_status($id=0,$status=0){
		if($id){
			$this->data = array('status'=>$status);
			$Cond=array('state_id'=>$id);		
			if($this->common_model->update('state',$this->data,$Cond)){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode( $this->data['msg_type']);
	}
	public function check_state_name($state_name, $id)
	{
		$cond=array('state_name'=>$state_name, 'state_id !='=>$id);
		if((bool)$this->common_model->getRows('state', '', $cond)===true){
			$this->form_validation->set_message('check_state_name', 'This %s is already used.');
			return false;
		}
		return true;
	}
}
?>
