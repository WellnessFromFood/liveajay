<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends CI_Controller {

    public $data = array();
    public $msg = array();

    public function __construct(){
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE){
			redirect('backoffice/login');
			exit();
		}
		$this->load->library('upload');
        $this->load->library('image_lib');
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
		$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
    public function index(){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Profile</li></ol>';
		
	    $id = $this->session->userdata['admin']->id;
		$Cond = array('user.id'=>$id);
		//echo '<pre>';
		$join=	array('user'=>'user.state_id = state.state_id','country'=>'user.country_id = country.country_id');
		$fields = array('user.id','user.first_name','user.last_name','user.address','user.emailid','user.profile_image','user.contact_no','user.status','state.state_name','country.country_name');
		
		$this->data['result'] = $this->common_model->getJoinRows('state',$join,'',$fields,$Cond);
					  
					  
		$this->load->view('backoffice/profile_view', $this->data);
    }
	
    public function edit()
	{
		$id = $this->session->userdata['admin']->id;
	    $this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li><a href="'.base_url('backoffice/users').'"><i class="fa fa-dashboard"></i>Profile</a></li><li class="active">Edit Profile</li></ol>';
		$this->data['rec'] = $this->common_model->getRow('user','',array('id'=>$id));
		
		$cond=array('status'=>'1');
		$this->data['country_list'] = $this->common_model->getSelectOptionList('country','country_id','country_name',$this->data['rec']->country_id,$cond);
		
		$this->data['state_list'] = $this->common_model->getSelectOptionList('state','state_id','state_name',$this->data['rec']->state_id,$cond);
		
		$id = base64_encode($id);
		$this->data['act'] = site_url('backoffice/profile/update/'.$id);
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->load->view('backoffice/edit_profile_view', $this->data, FALSE);
	}
		
	public function deleteImage(){
		$id = $this->input->post('Id');
		 $this->data = array(
			'profile_image' => NULL
		);
		$Cond=array('id'=>$id);	
		if((bool)$this->common_model->update('user',$this->data, $Cond) === true){
			if(file_exists('uploads/backoffice_profile_image/'.$this->input->post('ImagePath'))){
                unlink('uploads/backoffice_profile_image/'.$this->input->post('ImagePath'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
	
	public function isUsernameAvailable()
	{
		$cond=array('username'=>$this->input->post('username'),'id !='=>$this->input->post('user_id'));
		$result=$this->common_model->getRows('user','id',$cond);
		if(!empty($result)){
			echo(json_encode(false));
		}else{
			echo(json_encode(true));
		}
	}	
	
	public function isEmailAvailable()
	{
		$cond=array('emailid'=>$this->input->post('emailid'),'id !='=>$this->input->post('user_id'));
		$result=$this->common_model->getRows('user','id',$cond);
		if(!empty($result)){
			echo(json_encode(false));
		}else{
			echo(json_encode(true));
		}
	}	
	
    public function update($id)
	{
		$id = base64_decode($id);
		$time=time();
		if($this->_validData()){
			  $this->data = array('first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'address' => $this->input->post('address'),
				'emailid' => $this->input->post('emailid'),
				'contact_no' => $this->input->post('contact_no'),
				'country_id' => $this->input->post('country'),
				'state_id' => $this->input->post('state'),
				'city_id' => $this->input->post('city'),
				'status' => $this->input->post('status'),
				'updated_date' => $time,
				'updated_by' => $this->data['live_user_id']);
				
				if(isset($_FILES['profile_image']['name']) && $_FILES['profile_image']['name'] != ''){
					$this->updata = $this->functions->do_upload('uploads/profile_images/', 'profile_image');
					$this->data['profile_image'] = $this->updata['upload_data']['file_name'];
					$unlink_profile_image_hidden = $this->input->post('profile_image_hidden');
					unlink('uploads/backoffice_profile_image/'.$unlink_profile_image_hidden);
				}
		    
			$user_id = $this->input->post('user_id');
			$this->common_model->update('user',$this->data,array('id'=>$user_id));	
			$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			redirect('backoffice/profile');	
		}else{
			$this->edit(base64_encode($id));
		}
	}
	
	private function _validData()
	{
		$this->form_validation->set_rules('first_name','First Name','required');
		$this->form_validation->set_rules('last_name','Last Name','required');
		$this->form_validation->set_rules('contact_no','Contact Number','required');
		$this->form_validation->set_rules('address','Address','required');
		$this->form_validation->set_rules('emailid','Emailid','required');
		return $this->form_validation->run();
    }
	
    public function change_password()
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Change Password</li></ol>';
		$this->data['act'] = site_url('backoffice/profile/update_password/');
		$this->data['Submit'] = lang('UPDATE_BTN');
		$this->load->view('backoffice/change_password_view', $this->data, FALSE);
	}
	
	public function update_password()
	{
	    $id = $this->session->userdata['admin']->id;
		
		if($this->_validPassword($id))
		{ 
			$this->data = array('password'=>$this->hash_password($this->input->post('password')),'updated_date'=>time());
			if((bool)$this->common_model->update('user',$this->data,array('id'=>$id)) === TRUE){
				$this->msg = array('msg'=>lang('PASSWORD_CHANGED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/profile/change_password');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->change_password();
			}
		}else{
			return $this->change_password();
		}
	}
	
    private function _validPassword()
	{
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		$this->form_validation->set_rules('old_password', 'Old Password', 'trim|required');
		$this->form_validation->set_rules('password', 'New Passsword', 'trim|required|min_length[5]|max_length[20]|matches[confirm_password]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Passsword', 'trim|required');
		return $this->form_validation->run();
    }
	
	 public function checkPassword(){
		$id = $this->input->post('userId');
		$password = $this->hash_password($this->input->post('password'));
		$whereArr = array(
			'id' => $id,
			'Password' => $password
		);
		$this->data = $this->profile_model->checkAdminPasssword($whereArr);
		if($this->data[0]->NumRows > 0){
			echo 'true';
		}else{
			echo 'false';
		}
	}
	
	public function checkPrevPassword(){
		$id = $this->session->userdata['admin']->id;
		$password = $this->hash_password($this->input->post('old_password'));
		$cond = array('id'=>$id,'password'=>$password);
		$this->data['userinfo'] = $this->common_model->getRow('user','*',$cond);
		if($this->data['userinfo'])
		{ 
	    return TRUE;
		}
		else
		{ 
		$this->form_validation->set_message('checkPrevPassword', lang('VALIDATE_PASSWORD')); 
		return FALSE;
		}
	}
	private function hash_password($password) 
	{
		return password_hash($password, PASSWORD_BCRYPT);	
	}	
}
?>
