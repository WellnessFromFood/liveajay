<?php
class Banner extends CI_Controller {

	public $data = array();
    public $msg = array();
	
 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE){
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 8;
		$this->data['page_form_id']=31;
		$this->data['page_module_id']=10;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function show($start=0)
	{
		//echo '<pre>'; print_r($t);die;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Banner</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		$join='';
		$conds=array();
		$banner='';
		if($this->input->post('form_submit_banner')=='Search'){
			$banner = $this->input->post('banner');
			if($banner!=''){
				$conds[]= "b.banner_title like '%".trim($banner)."%'";			
			}
			$url_cond.='?banner='.trim($banner).'&form_submit_banner=Search';
		}
		if(!empty($conds)){
			$cond1= implode(' and',$conds);
			$cond="where ". $cond1;
		}			
		/* get count */
		$total_get_sql = "SELECT count(b.banner_id) as total FROM banner b ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$banner_sql="SELECT b.* FROM banner b ".$cond." order by banner_id desc LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($banner_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['banner'] =$banner;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['permission'] = $this->common_model->checkPermission();
		
		$this->data['act_banner_search_submit']=base_url('backoffice/banner/show');
		$this->load->view('backoffice/banner/banner_view', $this->data);
	}
	
	public function add()
	{
		$this->data['page'] = 822;
		$this->data['page_form_id']=31;
		$this->data['page_module_id']=10;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Banner</li></ol>';
		//$this->data['rec'] = $this->common_model->getRows('banner','*',array('banner_status' =>1));
		$this->data['act'] = site_url('backoffice/banner/save');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/banner/add_banner_view', $this->data, FALSE);
	}
		
	public function delete_image(){
		$banner_id = $this->input->post('banner_id');		
		if((bool)$this->common_model->update('banner',array('upload_banner'=>''),array('banner_id'=>$banner_id)) === true){
			if(file_exists('uploads/banner_image/'.$this->input->post('image_path'))){
                unlink('uploads/banner_image/'.$this->input->post('image_path'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
	
	public function save(){
		
		if($this->_validData()){
		    $time = time();		   
			$this->data = array(
				'banner_title' => $this->input->post('banner_title'),	
				'banner_youtube_url' => $this->input->post('banner_youtube_url'),
				'display_order' => $this->input->post('display_order'),
				'banner_url' => $this->input->post('banner_url'),
				'banner_tag_line' => $this->input->post('banner_tag_line',false),
				'banner_status' => $this->input->post('banner_status'),
				'created_date' => $time,
				'created_by' => $this->data['live_user_id']
				);
			
			if($_FILES['upload_banner']['name']){
				$this->updata = $this->functions->do_upload('uploads/banner_image/', 'upload_banner');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/banner_image/'.$this->input->post('OldBannerImage'));
						}
						$this->data['upload_banner'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($id);
					}
			}
			if($_FILES['thumbnail_video']['name']){
				$this->updata = $this->functions->do_upload('uploads/banner_video/', 'thumbnail_video');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('ThumbnailVideo')){
							unlink('uploads/banner_video/'.$this->input->post('ThumbnailVideo'));
						}
						$this->data['upload_banner_video'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->add();
					}
			}
			$banner_id = $this->common_model->save('banner',$this->data);
			if($banner_id!=''){
				
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/banner/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}else{
			return $this->add();
		}
	}	
	public function edit($banner_id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit Banner</li></ol>';
		$banner_id=base64_decode($banner_id);		
		$this->data['rec'] = $this->common_model->getRows('banner','',array('banner_id' => $banner_id));		
		$this->data['act'] = site_url('backoffice/banner/update/'.base64_encode($banner_id));
		$this->data['submit'] = lang('UPDATE_BTN');
		$this->load->view('backoffice/banner/add_banner_view', $this->data, FALSE);
	}	
	public function update($banner_id=0){
	    $banner_id=base64_decode($banner_id);
		if($this->_validData($banner_id)){
			$time = time();			
		  	$this->data = array(
				'banner_title' => $this->input->post('banner_title'),
				'banner_youtube_url' => $this->input->post('banner_youtube_url'),
				'display_order' => $this->input->post('display_order'),
				'banner_url' => $this->input->post('banner_url'),
				'banner_tag_line' => $this->input->post('banner_tag_line',false),
				'banner_status' => $this->input->post('banner_status'),
				'updated_date' => $time,
				'updated_by' => $this->data['live_user_id']);
							
				if($_FILES['upload_banner']['name']){
				  $this->updata = $this->functions->do_upload('uploads/banner_image/', 'upload_banner');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/banner_image/'.$this->input->post('OldBannerImage'));
						}
						$this->data['upload_banner'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($page_id);
					}
				}
				if($_FILES['thumbnail_video']['name']){
				$this->updata = $this->functions->do_upload('uploads/banner_video/', 'thumbnail_video');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('ThumbnailVideo')){
							unlink('uploads/banner_video/'.$this->input->post('ThumbnailVideo'));
						}
						$this->data['upload_banner_video'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($page_id);
					}
			} 
				if((bool)$this->common_model->update('banner',$this->data, array('banner_id'=>$banner_id)) === TRUE){
					
					$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
					$this->session->set_flashdata($this->msg);
					redirect('backoffice/banner/show');
				}else{
					$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
					$this->session->set_flashdata($this->msg);
					return $this->edit($banner_id);
				}
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit(base64_encode($banner_id));
			}
	}
		
	public function delete($banner_id=0){
	    $banner_id=base64_decode($banner_id);
		$banner_result=$this->common_model->getRow('banner','',array('banner_id'=>$banner_id));
		if((bool)$this->common_model->delete('banner',array('banner_id'=>$banner_id))==true){
			
			if($banner_result->upload_banner!=''){
				unlink('uploads/banner_image/'.$banner_result->upload_banner);
			}
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/banner/show');
	}
	
	private function _validData($id=0)
	{	
		$this->form_validation->set_rules('banner_title', 'Banner Title', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('display_order', 'Banner Order', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
	
	public function ch_status($id=0,$Status=0){
		if($id){
			$time = time();
			$this->data = array('status'=>$Status,'modified_date'=>$time);	
			if($this->common_model->update('home_banner',$this->data,array('id'=>$id))){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode($this->data['msg_type']);
	}

	public function checkImage()
	{
		if(empty($_FILES['banner_image']['name'])){
			$this->form_validation->set_message('checkImage', 'Banner image is required');
			return FALSE;
		}
		die;
		return TRUE;
	}
	public function deleteThumnailVideo(){
		$id = $this->input->post('id');	
		$this->data = array(
			'upload_banner_video' => ''
		);
		$Cond=array('banner_id'=>$id);	
		if((bool)$this->common_model->update('banner',$this->data, $Cond) === true){	
		
			if(file_exists('uploads/banner_video/'.$this->input->post('videoPath'))){
                unlink('uploads/banner_video/'.$this->input->post('videoPath'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
}
?>