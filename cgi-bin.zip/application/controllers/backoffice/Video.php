<?php
class Video extends CI_Controller {

	public $data = array();
    public $msg = array();
	
 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE){
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 16;
		$this->data['page_form_id']=32;
		$this->data['page_module_id']=11;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function show($start=0)
	{
		$this->data['page_form_id']=32;
		$this->data['page_module_id']=11;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">video</li></ol>';
				
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$cond='';
		$url_cond='';		
		$con_use=0;
		$conds=array();
		$album_type_id='';
		if($this->input->post('form_submit_video')=='Search'){		
			$album_type_id = $this->input->post('video_search');
			
			if($album_type_id!=''){
				$conds[] = "v.video_title like '%".trim($album_type_id)."%'";
			}				
			$url_cond.='?form_submit_video=album_id='.trim($album_type_id).'&form_submit_video=Search';
		}
		if(!empty($conds)){
			$cond1= implode(' and ',$conds);
			$cond=" where ". $cond1;
		}
		$total_get_sql = "SELECT count(*) as total FROM video as v".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		//echo "<pre>"; print_r($total_get); die;
		$video_sql="SELECT * FROM video v ".$cond."  order by v.video_id desc LIMIT ".$limit_from.",".$limit;
		
		$this->data['videoId']=$album_type_id;
		$this->data['recs'] = $this->common_model->solveCustomQuery($video_sql);
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_video_search_submit']=base_url('backoffice/video/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/video/video_view', $this->data);
	}
	
	public function add()
	{
		$this->data['page'] = 1622;
		$this->data['page_form_id']=32;
		$this->data['page_module_id']=11;
		$this->data['gallery_type'] = $this->common_model->getRows('gallery_type','id,input_name',array('status'=>'1'));				
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add video</li></ol>';
		$this->data['act'] = site_url('backoffice/video/save');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->data['cancel'] = lang('CANCEL_BTN');
		//echo '<pre>'; print_r($this->data['gallery_type']);die;
        $this->load->view('backoffice/video/add_video_view', $this->data, FALSE);
	}
		
	
	public function deleteThumnailImage(){
		$id = $this->input->post('id');	
		$this->data = array(
			'thumbnail_image' => ''
		);
		$Cond=array('video_id'=>$id);	
		if((bool)$this->common_model->update('video',$this->data, $Cond) === true){	
		
			if(file_exists('uploads/video_image/'.$this->input->post('ImagePath'))){
                unlink('uploads/video_image/'.$this->input->post('ImagePath'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
	
	public function save(){
		
		if($this->validate_video()){
		    $time = time();		    
			$this->data = array(
				'health_tips' => $this->input->post('health_tips'),
				'type' => $this->input->post('type'),
				'main_heading' => $this->input->post('main_heading'),
				'video_title' => $this->input->post('video_title'),
				'description' => $this->input->post('description'),
				'main_description' => $this->input->post('main_description'),
				're_writeurl' => $this->input->post('re_writeurl'),
				'display_order' => $this->input->post('display_order'),
				'video_status' => $this->input->post('video_status'),
				'main_blog' => $this->input->post('main_blog'),
				'created_date' => $time,
				'created_by' => $this->data['live_user_id']);
			
			if($_FILES['thumbnail_image']['name']){
				$this->updata = $this->functions->do_upload('uploads/video_image/', 'thumbnail_image');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldThumbnailImage')){
							unlink('uploads/video_image/'.$this->input->post('OldThumbnailImage'));
						}
						$this->data['thumbnail_image'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->add();
					}
			}
			if($_FILES['thumbnail_video']['name']){
				$this->updata = $this->functions->do_upload('uploads/banner_video/', 'thumbnail_video');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('ThumbnailVideo')){
							unlink('uploads/banner_video/'.$this->input->post('ThumbnailVideo'));
						}
						$this->data['thumbnail_video'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->add();
					}
			}
			$video_id = $this->common_model->saveAndGetLastId('video',$this->data);

			if($video_id!=''){
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/video/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}else{
			return $this->add();
		}
	}
	
	public function edit($video_id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit video</li></ol>';
		$video_id=base64_decode($video_id);
		$this->data['rec'] = $this->common_model->getRows('video','*',array('video_id' => $video_id));
		$this->data['act'] = site_url('backoffice/video/update/'.base64_encode($video_id));
		$this->data['gallery_type'] = $this->common_model->getRows('gallery_type','id,input_name',array('status'=>'1'));				
	
		$this->data['submit'] = lang('UPDATE_BTN');
		$this->data['cancel'] = lang('CANCEL_BTN');
		//echo '<pre>'; print_r($this->data['rec']);die;
		$this->load->view('backoffice/video/add_video_view', $this->data, FALSE);
	}
	
	public function update($video_id=0){
		//echo '<pre>'; print_r($this->input->post());die;
	    $video_id=base64_decode($video_id);
		if($this->validate_video($video_id)){
			$time = time();
		  	$this->data = array(
				'health_tips' => $this->input->post('health_tips'),
				'type' => $this->input->post('type'),
				'main_heading' => $this->input->post('main_heading'),
				'video_title' => $this->input->post('video_title'),
				'description' => $this->input->post('description'),
				'main_description' => $this->input->post('main_description'),
				're_writeurl' => $this->input->post('re_writeurl'),
				'display_order' => $this->input->post('display_order'),
				'video_status' => $this->input->post('video_status'),
				'main_blog' => $this->input->post('main_blog'),
				'updated_date' => $time,
				'updated_by' => $this->data['live_user_id']);
							
							
				if($_FILES['thumbnail_video']['name']){
				$this->updata = $this->functions->do_upload('uploads/banner_video/', 'thumbnail_video');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('ThumbnailVideo')){
							unlink('uploads/banner_video/'.$this->input->post('ThumbnailVideo'));
						}
						$this->data['thumbnail_video'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($video_id);
					}
			}
			
				if($_FILES['thumbnail_image']['name']){
				$this->updata = $this->functions->do_upload('uploads/video_image/', 'thumbnail_image');
				if(@$this->updata['res'] === TRUE){
					if($this->input->post('OldThumbnailImage')){
						unlink('uploads/video_image/'.$this->input->post('OldThumbnailImage'));
					}
					$this->data['thumbnail_image'] = $this->updata['upload_data']['file_name'];
				}else{
					$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
					$this->session->set_userdata($this->msg);
					return $this->edit($video_id);
				}
			}	

			if((bool)$this->common_model->update('video',$this->data, array('video_id'=>$video_id)) === TRUE){
					$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
					$this->session->set_flashdata($this->msg);
					redirect('backoffice/video/show');
				}else{
					$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
					$this->session->set_flashdata($this->msg);
					return $this->edit($video_id);
				}
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit(base64_encode($video_id));
			}
	}
		
	public function delete($video_id=0){
	    $video_id=base64_decode($video_id);
		$video_result=$this->common_model->getRow('video','',array('video_id'=>$video_id));
		if((bool)$this->common_model->delete('video',array('video_id'=>$video_id))){			
			if($video_result->thumbnail_image!=''){
				unlink('uploads/video/'.$video_result->thumbnail_image);
				$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
			}
			
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/video/show');
	}
	
	private function validate_video($id=0)
	{	
		//$this->form_validation->set_rules('album_id', 'Album Type', 'trim|required|strip_tags');
		$this->form_validation->set_rules('video_title', 'Video Title', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('display_order', 'Display Order', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
	
	public function do_upload($upload_path='', $FileName=''){
        $md = explode('/',$this->functions->rootPath($upload_path));
        $mkd = '';
        foreach($md as $val){
            $mkd .= $val.'/';
            if(!is_dir($mkd)){
                mkdir($mkd);
            }
        }
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['file_name'] = rand(1000000, 10000000000000);
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload($FileName)){
            $this->updata = array('msg' => $this->upload->display_errors(), 'res' => FALSE);
        }else{
            $this->updata = array('upload_data' => $this->upload->data(), 'res' => TRUE);
            if(file_exists($this->input->post('ThumbnailImage'))){
                unlink($this->input->post('ThumbnailImage'));
            }
        }
        return $this->updata;
    }


	public function ch_status($id=0,$Status=0){
		if($id){
			$time = time();
			$this->data = array('video_status'=>$Status,'modified_date'=>$time);	
			if($this->common_model->update('video',$this->data,array('video_id'=>$id))){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode($this->data['msg_type']);
	}

	public function checkImage()
	{
		if(empty($_FILES['ThumbnailImage']['name'])){
			$this->form_validation->set_message('checkImage', 'video image is required');
			return FALSE;
		}
		die;
		return TRUE;
	}
	public function deleteThumnailVideo(){
		$id = $this->input->post('id');	
		$this->data = array(
			'thumbnail_video' => ''
		);
		$Cond=array('video_id'=>$id);	
		if((bool)$this->common_model->update('video',$this->data, $Cond) === true){	
		
			if(file_exists('uploads/banner_video/'.$this->input->post('videoPath'))){
                unlink('uploads/banner_video/'.$this->input->post('videoPath'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
}
?>