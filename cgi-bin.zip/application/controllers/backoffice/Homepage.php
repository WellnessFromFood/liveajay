<?php
class Homepage extends CI_Controller {

	public $data = array();
    public $msg = array();
	
 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 6;
		$this->data['page_form_id']=35;
		$this->data['page_module_id']=13;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function show($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Page</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		$conds=array();
		if($this->input->post('form_submit_page')=='Search'){			
			$home_page_name = $this->input->post('home_page_name');			
			if($home_page_name!=''){
				$conds[]= "p.home_page_name like '%".trim($home_page_name)."%'";
			}
			
			$url_cond.='?home_page_name='.$home_page_name.'&form_submit_page=Search';
		}
		if(!empty($conds)){
			$cond1= implode(' and',$conds);
			$cond="where ". $cond1;
		}
		$total_get_sql = "SELECT count(distinct p.home_page_id) as total FROM homepage p  ".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$page_sql="SELECT home_page_id,home_page_name,home_page_status FROM homepage p ".$cond." order by p.home_display_order asc";
		//echo $page_sql;die;
		$this->data['recs'] = $this->common_model->solveCustomQuery($page_sql);
		//echo '<pre>'; print_r($this->data['recs']);die;
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		
		$this->data['act_page_search_submit']=base_url('backoffice/homepage/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/homepage/home_page_view', $this->data);
	}
	
	public function add()
	{
		$this->data['page'] = 622;
		$this->data['page_form_id']=32;
		$this->data['page_module_id']=10;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add CMS</li></ol>';
		//$this->data['page_list'] = $this->buildTree($this->common_model->getRows('homepage','',array('home_page_status'=>'1')));		
		$this->data['act'] = site_url('backoffice/homepage/save');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/homepage/add_home_page_view', $this->data, FALSE);
	}
		
	public function delete_image(){
		$home_page_id = $this->input->post('home_page_id');
		if((bool)$this->common_model->update('page',array('home_upload_banner'=>''),array('home_page_id'=>$home_page_id)) === true){
			if(file_exists('uploads/page_image/'.$this->input->post('home_image_path'))){
                unlink('uploads/page_image/'.$this->input->post('home_image_path'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
	
	public function save(){
		if($this->validate_cms()){		   
			//$url_slug='';$url='';$find_slugurl='';
			//$url=$this->input->post('home_url_slug');
		//	if(!empty($url)){
			//	$url_slug =  str_replace(' ', '-',strtolower($url));
			//}else{
			//	$url_slug =  str_replace(' ', '-',strtolower($this->input->post('home_page_name')));
			//}
			
			//$urlslugdata = $this->checkurlslug($url_slug,$home_page_id);
			
			$this->data = array(				
				//'home_parent_id' => $this->input->post('home_parent_id'),
				'home_page_name' => ucwords(strtolower($this->input->post('home_page_name'))),
				//'home_url_slug' => $urlslugdata,
				//'home_link_name' => $this->input->post('home_link_name'),
				//'home_video_url' => $this->input->post('home_video_url'),
				//'home_page_short_description' => $this->input->post('home_page_short_description'),
				'home_page_description' => htmlspecialchars_decode($this->input->post('home_page_description'),ENT_QUOTES),
				//'home_top_description' => $this->input->post('home_top_description'),
				//'home_display_order' => $this->input->post('home_display_order'),
				//'re_writeurl' => $this->input->post('home_re_writeurl'),
				'home_page_title' => $this->input->post('home_page_title'),
				'home_meta_keywords' => $this->input->post('home_meta_keywords'),
				'home_meta_description' => $this->input->post('home_meta_description'),
				'home_page_status' => $this->input->post('home_page_status'),
				//'home_page_type' => $this->input->post('home_page_type'),
				//'home_created_date' => date('Y-m-d'),
				//'home_created_by' => $this->data['live_user_id']
				);
			
			
			
			if((bool)$this->common_model->save('homepage',$this->data) === TRUE){
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/homepage/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			return $this->add();
		}
	}
	
	public function edit($home_page_id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit CMS</li></ol>';
		$home_page_id=base64_decode($home_page_id);
		if(is_numeric($home_page_id)){
			//$this->data['page_list'] = //$this->buildTree($this->common_model->getRows('homepage','',array('page_status'=>'1')));
			
			$this->data['rec'] = $this->common_model->getRows('homepage','',array('home_page_id'=>$home_page_id));
			$this->data['act'] = site_url('backoffice/homepage/update/'.base64_encode($home_page_id));
			$this->data['submit'] = lang('UPDATE_BTN');
			$this->load->view('backoffice/homepage/add_home_page_view', $this->data, FALSE);
		}else{
			redirect('backoffice/homepage/show');
		}	
	}
	function checkurlslug($slug,$home_page_id=0){
		
		if($home_page_id==0){
			$find_slug_url=$this->common_model->getRows('homepage','home_url_slug',array('home_url_slug'=>$slug));
		}else{
			$find_slug_url=$this->common_model->getRows('homepage','home_url_slug',array('home_url_slug'=>$slug,'home_page_id !='=>$home_page_id));
		}
			if(count($find_slug_url)==0){				
				return $slug;
			}else{
				return $this->checkurlslug($slug."".rand(),$home_page_id);
			}
	}	
	public function update($home_page_id=0){
	
	$home_page_id=base64_decode($home_page_id);
		if($this->validate_cms($home_page_id)){
			//$url_slug='';$url='';
			//$url=$this->input->post('home_url_slug');
			//if(!empty($url)){
			//	$url_slug =  str_replace(' ', '-',strtolower($url));
			//}else{
			//	$url_slug =  str_replace(' ', '-',strtolower($this->input->post('home_page_name')));
			//}
			
			//$urlslugdata = $this->checkurlslug($url_slug,$home_page_id);
			
		  	$this->data = array(
				//'campus_id' => $this->input->post('home_campus_id'),
				//'home_parent_id' => $this->input->post('home_parent_id'),				
				'home_page_name' => ucwords(strtolower($this->input->post('home_page_name'))),
				//'menu_link' => $menu_link,
				//'home_url_slug' => $urlslugdata,
				//'home_link_name' => $this->input->post('home_link_name'),
				//'home_video_url' => $this->input->post('home_video_url'),
				//'home_page_short_description' => $this->input->post('home_page_short_description'),
				'home_page_description' => htmlspecialchars_decode($this->input->post('home_page_description'),ENT_QUOTES),
/* 				'top_description' => $this->input->post('home_top_description'),
				'home_display_order' => $this->input->post('home_display_order'),
				//'re_writeurl' => $this->input->post('home_re_writeurl'),
				'home_page_title' => $this->input->post('home_page_title'),
				'home_meta_keywords' => $this->input->post('home_meta_keywords'),
				'home_meta_description' => $this->input->post('home_meta_description'),
				'home_page_status' => $this->input->post('home_page_status'),
				'home_page_type' => $this->input->post('home_page_type'),
				'home_updated_date' => date('Y-m-d'),
				'home_updated_by' => $this->data['live_user_id'] */);							
				/* if($_FILES['upload_banner']['name']){
				  $this->updata = $this->functions->do_upload('uploads/page_image/', 'upload_banner');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/page_image/'.$this->input->post('OldBannerImage'));
						}
						$this->data['home_upload_banner'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($home_page_id);
					}
				} */
				 
			  if((bool)$this->common_model->update('homepage',$this->data, array('home_page_id'=>$home_page_id)) === TRUE){
					$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
					$this->session->set_flashdata($this->msg);
					redirect('backoffice/homepage/show');
				}else{
					$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
					$this->session->set_flashdata($this->msg);
					return $this->edit($home_page_id);
				}
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit(base64_encode($home_page_id));
			}
	}
	
	public function delete($home_page_id=0){
	    $home_page_id=base64_decode($home_page_id);
		$page_result=$this->common_model->getRow('home_page','',array('home_page_id'=>$home_page_id));
		if((bool)$this->common_model->delete('home_page',array('home_page_id'=>$home_page_id))){
			if($page_result->upload_banner!=''){
				unlink('uploads/page_image/'.$page_result->upload_banner);
			}
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/homepage/show');
	}
	
	private function validate_cms($id=0)
	{
		$this->form_validation->set_rules('home_page_name', 'Page Name', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('page_title', 'PageTitle', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('display_order', 'Display Order', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
	
	public function ch_status($id=0,$Status=0){
		if($id){
			$time = time();
			$this->data = array('home_status'=>$Status,'home_modified_date'=>$time);	
			if($this->common_model->update('page',$this->data,array('id'=>$id))){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode($this->data['msg_type']);
	}
	
	public function buildTree($data, $parent = 0) {
		//print_r($data);die;
		$tree = array();
		foreach ($data as $d) {//echo $d->ParentId.'ajit'.$d->id.'<br>';
			if ($d->home_parent_id == $parent) {
				$children = $this->buildTree($data, $d->home_page_id);
				if (!empty($children)) {
					$d->children = $children;
				}
				$tree[] = $d;
			}
		}//die;
		return $tree;
	}
	public function do_upload($upload_path='', $FileName='')
	{
	    echo 'Yes - we are using this function to upload the blog - or are we? ';
        $md = explode('/',$this->functions->rootPath($upload_path));
        $mkd = '';
        foreach($md as $val){
            $mkd .= $val.'/';
            if(!is_dir($mkd)){
                mkdir($mkd);
            }
        }
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['file_name'] = rand(1000000, 10000000000000);
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload($FileName)){
            $this->updata = array('msg' => $this->upload->display_errors(), 'res' => FALSE);
        }else{
            $this->updata = array('upload_data' => $this->upload->data(), 'res' => TRUE);
            if(file_exists($this->input->post('BannerImage'))){
                unlink($this->input->post('BannerImage'));
            }
        }
        return $this->updata;
    }
	
	public function checkImage()
	{
		if(empty($_FILES['BannerImage']['name'])){
			$this->form_validation->set_message('checkImage', 'Banner image is required');
			return FALSE;
		}
		return TRUE;
	}
}
?>