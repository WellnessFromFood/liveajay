<?php
class Page extends CI_Controller {

	public $data = array();
    public $msg = array();
	
 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 6;
		$this->data['page_form_id']=33;
		$this->data['page_module_id']=12;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function show($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Page</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		$conds=array();
		if($this->input->post('form_submit_page')=='Search'){			
			$page_name = $this->input->post('page_name');			
			if($page_name!=''){
				$conds[]= "p.page_name like '%".trim($page_name)."%'";
			}
			
			$url_cond.='?page_name='.$page_name.'&form_submit_page=Search';
		}
		if(!empty($conds)){
			$cond1= implode(' and',$conds);
			$cond="where ". $cond1;
		}
		$total_get_sql = "SELECT count(distinct p.page_id) as total FROM page p  ".$cond;
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$page_sql="SELECT distinct p.* FROM page p ".$cond." order by p.page_type asc LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->buildTree($this->common_model->solveCustomQuery($page_sql));
		//echo '<pre>'; print_r($this->data['recs']);die;
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		
		$this->data['act_page_search_submit']=base_url('backoffice/page/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/page/page_view', $this->data);
	}
	
	public function add()
	{
		$this->data['page'] = 622;
		$this->data['page_form_id']=32;
		$this->data['page_module_id']=10;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add CMS</li></ol>';
		$this->data['page_list'] = $this->buildTree($this->common_model->getRows('page','',array('page_status'=>'1')));		
		$this->data['act'] = site_url('backoffice/page/save');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/page/add_page_view', $this->data, FALSE);
	}
		
	public function delete_image(){
		$page_id = $this->input->post('page_id');
		if((bool)$this->common_model->update('page',array('upload_banner'=>''),array('page_id'=>$page_id)) === true){
			if(file_exists('uploads/page_image/'.$this->input->post('image_path'))){
                unlink('uploads/page_image/'.$this->input->post('image_path'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
	
	public function save(){
		if($this->validate_cms()){		   
			$url_slug='';$url='';$find_slugurl='';
			$url=$this->input->post('url_slug');
			if(!empty($url)){
				$url_slug =  str_replace(' ', '-',strtolower($url));
			}else{
				$url_slug =  str_replace(' ', '-',strtolower($this->input->post('page_name')));
			}
			
			$urlslugdata = $this->checkurlslug($url_slug,$page_id);
			
			$this->data = array(				
				'parent_id' => $this->input->post('parent_id'),
				'page_type' => $this->input->post('page_type'),
				'page_name' => ucwords(strtolower($this->input->post('page_name'))),
				'url_slug' => $urlslugdata,
				'link_name' => $this->input->post('link_name'),
				'video_url' => $this->input->post('video_url'),
				'page_short_description' => $this->input->post('page_short_description',false),
				'page_description' => $this->input->post('page_description',false),
				'top_description' => $this->input->post('top_description',false),
				'display_order' => $this->input->post('display_order'),
				//'re_writeurl' => $this->input->post('re_writeurl'),
				'page_title' => $this->input->post('page_title'),
				'meta_keywords' => $this->input->post('meta_keywords'),
				'meta_description' => $this->input->post('meta_description'),
				'page_status' => $this->input->post('page_status'),
				'page_type' => $this->input->post('page_type'),
				'created_date' => date('Y-m-d'),
				'created_by' => $this->data['live_user_id']);
			
			if($_FILES['upload_banner']['name']){
				$this->updata = $this->functions->do_upload('uploads/page_image/', 'upload_banner');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/page_image/'.$this->input->post('OldBannerImage'));
						}
						$this->data['upload_banner'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($id);
					}
			}
			
			if((bool)$this->common_model->save('page',$this->data) === TRUE){
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/page/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			return $this->add();
		}
	}
	
	public function edit($page_id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit CMS</li></ol>';
		$page_id=base64_decode($page_id);
		if(is_numeric($page_id)){
			$this->data['page_list'] = $this->buildTree($this->common_model->getRows('page','',array('page_status'=>'1')));
			
			$this->data['rec'] = $this->common_model->getRows('page','*',array('page_id'=>$page_id));
			$this->data['act'] = site_url('backoffice/page/update/'.base64_encode($page_id));
			$this->data['submit'] = lang('UPDATE_BTN');
			$this->load->view('backoffice/page/add_page_view', $this->data, FALSE);
		}else{
			redirect('backoffice/page/show');
		}	
	}
	function checkurlslug($slug,$page_id=0){
		
		if($page_id==0){
			$find_slug_url=$this->common_model->getRows('page','url_slug',array('url_slug'=>$slug));
		}else{
			$find_slug_url=$this->common_model->getRows('page','url_slug',array('url_slug'=>$slug,'page_id !='=>$page_id));
		}
			if(count($find_slug_url)==0){				
				return $slug;
			}else{
				return $this->checkurlslug($slug."".rand(),$page_id);
			}
	}	
	public function update($page_id=0){
		//echo '<pre>'; print_r($this->input->post());die;
	$page_id=base64_decode($page_id);
		if($this->validate_cms($page_id)){
			$url_slug='';$url='';
			$url=$this->input->post('url_slug');
			if(!empty($url)){
				$url_slug =  str_replace(' ', '-',strtolower($url));
			}else{
				$url_slug =  str_replace(' ', '-',strtolower($this->input->post('page_name')));
			}
			
			$urlslugdata = $this->checkurlslug($url_slug,$page_id);
			
		  	$this->data = array(
				//'campus_id' => $this->input->post('campus_id'),
				'parent_id' => $this->input->post('parent_id'),
				'page_type' => $this->input->post('page_type'),				
				'page_name' => ucwords(strtolower($this->input->post('page_name'))),
				//'menu_link' => $menu_link,
				'url_slug' => $urlslugdata,
				'link_name' => $this->input->post('link_name'),
				'video_url' => $this->input->post('video_url'),
				'page_short_description' => $this->input->post('page_short_description',false),
				'page_description' => $this->input->post('page_description',false),
				'top_description' => $this->input->post('top_description',false),
				'display_order' => $this->input->post('display_order'),
				//'re_writeurl' => $this->input->post('re_writeurl'),
				'page_title' => $this->input->post('page_title'),
				'meta_keywords' => $this->input->post('meta_keywords'),
				'meta_description' => $this->input->post('meta_description'),
				'page_status' => $this->input->post('page_status'),
				'page_type' => $this->input->post('page_type'),
				'updated_date' => $time,
				'updated_by' => $this->data['live_user_id']);							
				if($_FILES['upload_banner']['name']){
				  $this->updata = $this->functions->do_upload('uploads/page_image/', 'upload_banner');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/page_image/'.$this->input->post('OldBannerImage'));
						}
						$this->data['upload_banner'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($page_id);
					}
				}
				 
			  if((bool)$this->common_model->update('page',$this->data, array('page_id'=>$page_id)) === TRUE){
					$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
					$this->session->set_flashdata($this->msg);
					redirect('backoffice/page/show');
				}else{
					$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
					$this->session->set_flashdata($this->msg);
					return $this->edit($page_id);
				}
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit(base64_encode($page_id));
			}
	}
	
	public function delete($page_id=0){
	    $page_id=base64_decode($page_id);
		$page_result=$this->common_model->getRow('page','',array('page_id'=>$page_id));
		if((bool)$this->common_model->delete('page',array('page_id'=>$page_id))){
			if($page_result->upload_banner!=''){
				unlink('uploads/page_image/'.$page_result->upload_banner);
			}
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/page/show');
	}
	
	private function validate_cms($id=0)
	{
		$this->form_validation->set_rules('page_name', 'Page Name', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('page_title', 'PageTitle', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('display_order', 'Display Order', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
	
	public function ch_status($id=0,$Status=0){
		if($id){
			$time = time();
			$this->data = array('status'=>$Status,'modified_date'=>$time);	
			if($this->common_model->update('page',$this->data,array('id'=>$id))){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode($this->data['msg_type']);
	}
	
	public function buildTree($data, $parent = 0) {
		$tree = array();
		foreach ($data as $d) {//echo $d->ParentId.'ajit'.$d->id.'<br>';
			if ($d->parent_id == $parent) {
				$children = $this->buildTree($data, $d->page_id);
				if (!empty($children)) {
					$d->children = $children;
				}
				$tree[] = $d;
			}
		}//die;
		return $tree;
	}
	public function do_upload($upload_path='', $FileName=''){
        $md = explode('/',$this->functions->rootPath($upload_path));
        $mkd = '';
        foreach($md as $val){
            $mkd .= $val.'/';
            if(!is_dir($mkd)){
                mkdir($mkd);
            }
        }
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['file_name'] = rand(1000000, 10000000000000);
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload($FileName)){
            $this->updata = array('msg' => $this->upload->display_errors(), 'res' => FALSE);
        }else{
            $this->updata = array('upload_data' => $this->upload->data(), 'res' => TRUE);
            if(file_exists($this->input->post('BannerImage'))){
                unlink($this->input->post('BannerImage'));
            }
        }
        return $this->updata;
    }
	
	public function checkImage()
	{
		if(empty($_FILES['BannerImage']['name'])){
			$this->form_validation->set_message('checkImage', 'Banner image is required');
			return FALSE;
		}
		return TRUE;
	}
}
?>