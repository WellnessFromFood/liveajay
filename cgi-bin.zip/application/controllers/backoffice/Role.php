<?php
class Role extends CI_Controller {

	public $data = array();
    public $msg = array();
	
 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 17;
		$this->data['page_form_id']=1;
		$this->data['page_module_id']=2;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function show()
	{
		$this->data['page_form_id']=1;
		$this->data['page_module_id']=2;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">View role</li></ol>';
		$this->data['recs'] = $this->common_model->getRows('user_role','',array('role_id !='=>'14'),'role_name');
		$this->data['permission'] = $this->common_model->checkPermission();
		// echo $this->db->last_query();
		// print_r($this->data['permission']); exit;
		$this->load->view('backoffice/role/role_view', $this->data);
	}
	
	public function add()
	{
		$this->data['page'] = 1722;
		$this->data['page_form_id']=1;
		$this->data['page_module_id']=2;
		$this->data['role_id'] = 0;
		$album_ids=array();
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Album</li></ol>';
		$this->data['act_role'] = site_url('backoffice/role/save');
		
		$form_information_sql="SELECT fi.module_id,menu.menu_name FROM menu join form_information fi on menu.id=fi .module_id group by fi.module_id,menu.menu_name"; 
		
		$this->data['form_information_recs'] = $this->common_model->solveCustomQuery($form_information_sql);
        $this->data['submit'] = lang('SAVE_BTN');
        $this->data['cancel'] = lang('CANCEL_BTN');
        $this->load->view('backoffice/role/add_role_view', $this->data, FALSE);
	}
	
	public function save(){
		if($this->_validData()){
			$form_ids = $this->input->post('form_ids');
		    $time = time();
			$this->data = array(
			'role_name' => $this->input->post('role_name'),
			'role_status' => 1,
			'created_date' => $time,
			'created_by' => $this->data['live_user_id']);
			$role_id = $this->common_model->saveAndGetLastId('user_role',$this->data);
			if($role_id!=''){
				if(!empty($form_ids)){ foreach($form_ids as $form_ids_val){ 
					$this->common_model->save('form_permission',array('role_id'=>$role_id,'form_id'=>$form_ids_val));
				}}
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/role/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			return $this->add();
		}
	}
	
	public function edit($role_id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit Role</li></ol>';
		$this->data['rec'] = $this->common_model->getRows('user_role','',array('role_id'=>base64_decode($role_id)));
		$form_information_sql="SELECT fi.module_id,menu.menu_name FROM menu join form_information fi on menu.id=fi .module_id group by fi.module_id,menu.menu_name"; 
		$this->data['form_information_recs'] = $this->common_model->solveCustomQuery($form_information_sql);
		//echo '<pre>'; print_r($this->data['form_information_recs']);die;

		$this->data['act_role'] = base_url('backoffice/role/update/'.$role_id);
		$this->data['role_id'] = base64_decode($role_id);
		$this->data['submit'] = lang('UPDATE_BTN');
		$this->data['cancel'] = lang('CANCEL_BTN');
		$this->load->view('backoffice/role/add_role_view', $this->data, FALSE);
	}
	public function update($role_id=0){
	    $role_id = base64_decode($role_id); 
		if($this->_validData($role_id)){

			$form_add=$this->input->post('form_add');
			$form_view=$this->input->post('form_view');
			$form_edit=$this->input->post('form_edit');
			$form_delete=$this->input->post('form_delete');
			// print_r(count($form_view)); exit;
			$time = time();
			$this->data = array(
				'role_name' => $this->input->post('role_name'),
				'role_status' => $this->input->post('role_status'),
				'updated_date' => $time,
				'updated_by' => $this->data['live_user_id']);
			if((bool)$this->common_model->update('user_role',$this->data, array('role_id'=>$role_id)) === TRUE){ 
				$this->common_model->delete('form_permission',array('role_id'=>$role_id));
				//echo '<pre>'; print_r($this->input->post());die;
				if(!empty($form_view)){
					
				foreach($form_view as $key=>$form_view_val){ 
				
				    $access_edit='0';
					$access_delete='0';
					$access_add='0';
					if($form_add[$form_view_val]!="")
					{
						$access_add='1';
					}
					if($form_edit[$form_view_val]!="")
					{
						$access_edit='1';
					}
					if($form_delete[$form_view_val]!="")
					{
						$access_delete='1';
					}
					$get_view_result=$this->common_model->getRow('form_permission',array('role_id'=>$role_id,'form_id'=>$form_view_val));					
					$get_view_result1 = (array) $get_view_result;
					if(!empty($get_view_result1)){
					$this->common_model->update('form_permission',array('form_view'=>'1','form_edit'=>$access_edit,'form_delete'=>$access_delete,'form_add'=>$access_add),array('role_id'=>$role_id,'form_id'=>$form_view_val));
					
					}else{
					$this->common_model->save('form_permission',array('form_view'=>'1','role_id'=>$role_id,'form_id'=>$form_view_val,'form_edit'=>$access_edit,'form_delete'=>$access_delete,'form_add'=>$access_add));
					}
										
				}}				
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/role/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit(base64_encode($role_id));
			}
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
			$this->session->set_flashdata($this->msg);
			return $this->edit(base64_encode($role_id));
		} 

	}
	private function _validData($id=0)
	{
		$this->form_validation->set_rules('role_name', 'Role Name ', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }	
	public function ch_status($id=0,$Status=0){
		if($id){
			$time = time();
			$this->data = array('album_status'=>$Status,'modified_date'=>$time);	
			if($this->common_model->update('album',$this->data,array('album_id'=>$id))){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode($this->data['msg_type']);
	}
	public function delete($roleid=0){
		if((bool)$this->common_model->delete('user_role',array('role_id'=>base64_decode($roleid)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/role/show');
	}
}
?>