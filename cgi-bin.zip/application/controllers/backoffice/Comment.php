<?php
class Comment extends CI_Controller {

	public $data = array();
    public $msg = array();
	
 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 9;
		$this->data['page_form_id']=10;
		$this->data['page_module_id']=6;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function show($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM customer ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM customer ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		
		$this->load->view('backoffice/comment/comment_view', $this->data);
	}
	public function postdata($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM customer ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM customer ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/comment/postdata_view', $this->data);
	}
	public function schedule_meeting($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM comment ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM customer ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/comment/schedule_meeting_view', $this->data);
	}
	public function cancel_meeting($start=0)
	{($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM customer ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM customer ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/comment/cancel_meeting_view', $this->data);
	}
	public function acknowledge($start=0)
	{($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM customer ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM customer ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/comment/acknowledge_schedule_view', $this->data);
	}
	public function next_schedule_meeting($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM customer ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM customer ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/comment/next_schedule_view', $this->data);
	}
	
}

?>