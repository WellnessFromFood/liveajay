<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Message extends CI_Controller
{
    public $data = array();
    public $msg = array();

    public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 9;
		$this->data['page_form_id']=8;
		$this->data['page_module_id']=5;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
    
    public function deletemessage() {
	    $ids = $this->input->post('ids');
	    $comma_ids = implode(',', $ids);

	    if ((bool) $this->db->query("DELETE FROM time_slot WHERE id IN(".$comma_ids.
	            ")") == true) {
	        $this->msg = array('msg' => lang('RECORD_DELETED'), 'msg_type' => 'success');
	        echo 1;
	        exit;
	    } else {
	        $this->msg = array('msg' => lang('RECORD_ERROR'), 'msg_type' => 'error');
	        echo 0;
	        exit;
	    }
	}
    public function taxview($start=0)
	{
		//print_r($this->input->post());die;
		$this->data['page_form_id']=55;
		$this->data['page_module_id']=4;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message tracking</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM subscriptionmsg ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM tax ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/tax_view', $this->data);
    }
    public function automationview($start=0)
	{

		//print_r($this->input->post());die;
		$this->data['page_form_id']=58;
		$this->data['page_module_id']=4;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message tracking</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		
		$total_get_sql = "SELECT count(id) as total FROM automation ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM automation ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
	
		$this->load->view('backoffice/message/automation_view', $this->data);
    }
    public function phoneno($start=0)
	{

		//print_r($this->input->post());die;
		$this->data['page_form_id']=59;
		$this->data['page_module_id']=4;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message tracking</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		
		$total_get_sql = "SELECT count(id) as total FROM email_phoneno ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM email_phoneno ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
	
		$this->load->view('backoffice/message/phoneno_view', $this->data);
    }
     public function edit_automation_view($menu_id=0)
	{
		$this->data['page_form_id']=58;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec'] = $this->common_model->getRow('automation','*',array('id'=>$menu_id));
		$this->data['act'] = site_url('backoffice/message/update_automation_view/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		
		 $this->load->view('backoffice/message/edit_automation_view', $this->data, FALSE);
	} 
	  public function edit_phoneno_view($menu_id=0)
	{
		$this->data['page_form_id']=59;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec'] = $this->common_model->getRow('email_phoneno','*',array('id'=>$menu_id));
		$this->data['act'] = site_url('backoffice/message/update_email_phoneno_view/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/message/edit_email_phoneno_view', $this->data, FALSE);
	} 
    public function edit_tax_view($menu_id=0)
	{
		$this->data['page_form_id']=55;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec'] = $this->common_model->getRow('tax','*',array('id'=>$menu_id));
		$this->data['act'] = site_url('backoffice/message/update_tax_view/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/message/edit_tax_view', $this->data, FALSE);
	}
	public function update_email_phoneno_view($menu_id)
	{

		if($this->track_msg_validData($menu_id)){
			$this->data = array(
			'emailphoneno' => $this->input->post('message'),			
			'status' => $this->input->post('status'));		
			if((bool)$this->common_model->update('email_phoneno',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/phoneno');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit_automation_view($menu_id);
			}
			}
			else
			{
				return $this->edit_automation_view($menu_id);
			}
	}	
	public function update_automation_view($menu_id)
	{

		if($this->track_msg_validData($menu_id)){
			$this->data = array(
			'days' => $this->input->post('message'),			
			'status' => $this->input->post('status'));		
			if((bool)$this->common_model->update('automation',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/automationview');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit_automation_view($menu_id);
			}
			}
			else
			{
				return $this->edit_automation_view($menu_id);
			}
	}	
	public function update_tax_view($menu_id)
	{

		if($this->track_msg_validData($menu_id)){
			$this->data = array(
			'tax' => $this->input->post('message'),			
			'status' => $this->input->post('status'));		
			if((bool)$this->common_model->update('tax',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/taxview');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit_tax_view($menu_id);
			}
			}
			else
			{
				return $this->edit_tax_view($menu_id);
			}
	}	
	public function schedule_table($start=0)
	{
		$this->data['page_form_id']=35;
		$this->data['page_module_id']=4;
		
	/*	$course_stream_sql="SELECT * FROM time_slot_new where created_by=".$this->session->userdata('admin')->id." order by id ";
		$this->data['slotdata'] = $this->common_model->solveCustomQuery($course_stream_sql);
		//echo '<pre>'; print_r($this->data['slotdata']);die;
*/


		$this->data['gallery'] = $this->common_model->getRows('time_slot','*',array('created_by'=>$this->session->userdata('admin')->id));
		//$this->data['idd'] =$id;
		$this->data['slotdata']=array();
		if(!empty($this->data['gallery']))
		{
			foreach($this->data['gallery'] as $key=>$val)
			{
				$setgalary1[]=$val;
				if(($key+1)%5==0)
				{
					$this->data['slotdata'][]=$setgalary1;
					$setgalary1=array();
				}
			}
			$this->data['slotdata'][]=$setgalary1;

		}
		$this->data['act']=base_url('backoffice/message/save_schedule_table_alldata');	
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';		
		$this->load->view('backoffice/message/schedule_table_view', $this->data);
    }
	public function schedule_date($start=0)
	{
		$this->data['page_form_id']=35;
		$this->data['page_module_id']=4;
		//print_r($this->input->post());die;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message post</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM time_slot ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM time_slot where created_by=".$this->session->userdata('admin')->id." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/schedule_date_view', $this->data);
    }
    public function customer_schedule_date($start=0)
	{
		$this->data['page_form_id']=53;
		$this->data['page_module_id']=4;
		//print_r($this->session->userdata('admin')->role_type);die;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message post</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM time_slot ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		if($this->session->userdata('admin')->role_type==1)
		{
		$course_stream_sql="SELECT u.first_name,p.provider_name,s.weekid,s.dayid,s.slottime,s.schedule_date,s.id,u.id as userid,s.providerid
		FROM user as u join time_schedule as s on s.customerid=u.id join provider as p on s.providerid=p.id  
		 order by u.id  LIMIT ".$limit_from.",".$limit;
		}
		else
		{
		$course_stream_sql="SELECT first_name,provider_name,weekid,dayid,slottime,schedule_date,s.id,u.id as userid,s.providerid
		FROM `user` as u join time_schedule as s on s.customerid=u.id join provider as p on s.providerid=p.id  
		where  p.pcustid=".$this->session->userdata('admin')->id."  order by u.id  LIMIT ".$limit_from.",".$limit;
		}
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/save_schedule_table_alldata');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/customer_schedule_date_view', $this->data);
    }
    
    public function save_schedule_table_alldata()
	{		
		$multi = $this->input->post('multi');
		foreach($multi as $k=>$multidata)
		{
			foreach($multidata as $k1=>$multidataval)
			{
			$providerid= $this->input->post('providerid');
			$fromdate= date('Y-m-d',strtotime($this->input->post('calendardate')));
			$todate= date('Y-m-d',strtotime($this->input->post('todate')));

			$checkdata = $this->common_model->getRows('time_slot',
				'id',
				array(
					'providerid'=>$this->input->post('providerid'),					
					'calendardate' => date('Y-m-d',strtotime($this->input->post('calendardate'))),
				'todate' => date('Y-m-d',strtotime($this->input->post('todate')))
				));

			if(!empty($checkdata))
			{
				$chkempty = $this->common_model->solveCustomQuery('select slot_day from time_slot where id='.$k1.'');
				if(!empty($chkempty[0]->slot_day))
				{
					//echo '<pre>'; print_r($chkempty);die;
					$chkempty_arr = explode(",",$chkempty[0]->slot_day);
					if(!in_array($k,$chkempty_arr))
					{
						$this->common_model->update(
							'time_slot',
							array(
								'slot_day'=>$chkempty[0]->slot_day.",".$k
								), 
								array('id'=>$k1));
					}
				}
				else
				{
					$this->common_model->update(
							'time_slot',
							array(
								'slot_day'=>$k
								), 
								array('id'=>$k1));
				}
				
			}
		 }
		   
		}
		$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/message/schedule_table');
	}
    public function save_schedule_table()
	{

		if($this->schedule_validDataTable())
		{
			//echo '<pre>'; print_r($this->input->post());die;
			$starttime = $this->input->post('starttime');
			$endtime = $this->input->post('endtime');
			$range = range(strtotime($starttime),strtotime($endtime),30*60);
			
			foreach($range as $time){
        		
			$this->data = array(
			'providerid' =>  $this->input->post('providerid'),
			'calendardate' => date('Y-m-d',strtotime($this->input->post('calendardate'))),
			'todate' => date('Y-m-d',strtotime($this->input->post('todate'))),
			'timeslot' =>date("H:i",$time),			
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'created_by'=>$this->session->userdata('admin')->id);
			$this->common_model->save('time_slot_new',$this->data);
			}

			$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			redirect('backoffice/message/schedule_table');
			
		}
		else
		{
			return $this->add_schedule_table();
		}
	}
	public function save_schedule_date()
	{


		if($this->schedule_validData())
		{
			$starttime = $this->input->post('starttime');
			$endtime = $this->input->post('endtime');
			/*$explodetime= explode('-',$timeslot);
			$from =$explodetime[0];
			$to =$explodetime[1];*/
			$range = range(strtotime($starttime),strtotime($endtime),30*60);
			
			foreach($range as $time){
        		// echo date("H:i",$time)."\n";
			
			// $leftfrm = 12 - $starttime;
			// $leftto = 12 - $endtime;
			// $totaltime= $leftfrm + $leftto;

			// for($i=1;$i<=$totaltime+1;$i++)
			// {
				// $time=time();
				$this->data = array(
				'providerid' =>  $this->input->post('providerid'),
				'calendardate' => date('Y-m-d',strtotime($this->input->post('calendardate'))),
				'todate' => date('Y-m-d',strtotime($this->input->post('todate'))),
				'timeslot' =>date("H:i",$time),			
				'status' => $this->input->post('status'),
				'created_date' => date('Y-m-d'),
				'created_by'=>$this->session->userdata('admin')->id);
				$this->common_model->save('time_slot',$this->data);
			}


		// 	$starttime++;
		// }
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/schedule_date');
			/*if((bool)$this->common_model->save('time_slot',$this->data) === TRUE)
			{
				
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_schedule_date();
			}*/
		}
		else
		{
			return $this->add_schedule_date();
		}
	}
	public function show_nav($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		if($this->input->get('form_submit_nav')=='Search'){
			$nav_type = $this->input->get('nav_type');	
			if($nav_type!=''){
				$cond.= "nav_type like '%".$nav_type."%'";
				$con_use++;	
			}
			$url_cond.='?nav_type='.$nav_type.'&form_submit_nav=Search';
		}
		if($con_use){ $cond_created_where=' WHERE '; }else{ $cond_created_where=''; }
		/* get count */
		$total_get_sql = "SELECT count(id) as total FROM navigation_type ".$cond_created_where." ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$course_stream_sql="SELECT * FROM navigation_type ".$cond_created_where." ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_nav_type_search_submit']=base_url('backoffice/menu/show_nav');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/masters/nav_view', $this->data);
	}
	public function add_nav()
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Menu</li></ol>';
		$this->data['act'] = base_url('backoffice/menu/save_nav');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM navigation_type"; 
		$maxdisplay = $this->common_model->solveCustomQuery($maxdisplay);
		$this->data['maxdis'] = $maxdisplay[0]->maxdisplay+1;

        $this->load->view('backoffice/masters/add_nav_view', $this->data, FALSE);
    }
	public function save_nav()
	{
		if($this->nav_validData())
		{
			$time=time();
			$this->data = array(
			'title' => $this->input->post('title'),
			'nav_type' => $this->input->post('nav_type'),
			'display_order' => $this->input->post('display_order'),
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'created_by' => $this->data['live_user_id']);
			if((bool)$this->common_model->save('navigation_type',$this->data) === TRUE)
			{
				//echo "rr";die;
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/show_nav');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_nav();
			}
		}
		else
		{
			return $this->add_nav();
		}
	}
	
	private function nav_validData($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('nav_type', 'Nav Type', 'trim|required|strip_tags|callback_check_nav_type['.$id.']');
		}
		else
		{
			$this->form_validation->set_rules('title', 'Title', 'trim|required|strip_tags');
	$this->form_validation->set_rules('nav_type', 'Navigation Type', 'trim|required|strip_tags|is_unique[navigation_type.nav_type]');		
		}
		$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	public function nav_edit($id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Edit Menu</li></ol>';
			
	    $id=base64_decode($id);
		
		$this->data['rec'] = $this->common_model->getRow('navigation_type','*',array('id'=>$id));
		$this->data['act'] = site_url('backoffice/menu/nav_update/'.base64_encode($id));
		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/masters/add_nav_view', $this->data, FALSE);
	}
	public function nav_update($id)
	{
		if($this->nav_validData($id)){ 
			$this->data = array(
			'title' => $this->input->post('title'),
			'nav_type' => $this->input->post('nav_type'),
			'display_order' => $this->input->post('display_order'),
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'updated_by' => $this->data['live_user_id']);				
			if((bool)$this->common_model->update('navigation_type',$this->data, array('id'=>base64_decode($id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/show_nav');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->nav_edit($id);
			}
			}
			else
			{
				return $this->nav_edit($id);
			}
	}
	public function nav_delete($id=0){
		if((bool)$this->common_model->delete('navigation_type',array('id'=>base64_decode($id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/menu/show_nav');
	}
	public function schedule_time_delete($id=0,$pid=0,$schedultedate=0,$uid=0){

		$getcustid= $this->common_model->getRows('provider','pcustid',array('id'=>base64_decode($pid)));
		if($getcustid)
		{
		$staff_email= $this->common_model->getRows('user','first_name,emailid',array('id'=>($getcustid[0]->pcustid)));
		}
		$user_email= $this->common_model->getRows('user','first_name,emailid',array('id'=>base64_decode($uid)));
		$meeting_data = $this->common_model->getRows('time_schedule','*',array('id'=>base64_decode($id)));
		$slote_time = $meeting_data[0]->slottime;
		$sc_date    = date('M d Y',strtotime($meeting_data[0]->schedule_date));		
			if($this->session->userdata('admin')->role_type==1){
				if(!empty($user_email))
				{
					$emailid= $user_email[0]->emailid;
					$full_name=$user_email[0]->first_name;
					$sub1= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>16,'status'=>1));
					$this->common_model->commonMail(18,$sub1,$emailid,'',@$slote_time,$sc_date,$full_name);
				}
				if(!empty($staff_email))
				{
					$staffmail = $staff_email[0]->emailid;
					$staffName =$staff_email[0]->first_name;
					$sub11= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>17,'status'=>1));
					$this->common_model->commonMail(19,$sub11,$staffmail,'',@$slote_time,$sc_date,$staffName);
				}

			}else{
				if(!empty($user_email))
				{
					$emailid= $user_email[0]->emailid;
					$full_name=$user_email[0]->first_name;
					$sub1= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>14,'status'=>1));
					$this->common_model->commonMail(16,$sub1,$emailid,'',@$slote_time,$sc_date,$full_name);
				}
				//Mail Send to Staff
				if(!empty($staff_email))
				{
					$staffmail = $staff_email[0]->emailid;
					$staffName =$staff_email[0]->first_name;
					$sub11= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>15,'status'=>1));
					$this->common_model->commonMail(17,$sub11,$staffmail,'',@$slote_time,$sc_date,$staffName);
				}
			}
		if((bool)$this->common_model->delete('time_schedule',array('id'=>base64_decode($id)))==true){
		//if(1==1){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/message/customer_schedule_date');
	}
	public function show_nav_mapping($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		if($this->input->get('form_submit_nav')=='Search'){
			$nav_type = $this->input->get('nav_type');	
			if($nav_type!=''){
				$cond.= "nav_type like '%".$nav_type."%'";
				$con_use++;	
			}
			$url_cond.='?nav_type='.$nav_type.'&form_submit_nav=Search';
		}
		if($con_use){ $cond_created_where=' WHERE '; }else{ $cond_created_where=''; }
		/* get count */
		$total_get_sql = "SELECT count(id) as total FROM navigation_mapping ".$cond_created_where." ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$course_stream_sql="SELECT * FROM navigation_mapping ".$cond_created_where." ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_nav_type_search_submit']=base_url('backoffice/menu/show_nav_mapping');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/masters/nav_view_mapping', $this->data);
	}
	public function add_nav_mapping()
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Menu</li></ol>';
		$this->data['act'] = base_url('backoffice/menu/save_nav_mapping');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM navigation_type"; 
		$maxdisplay = $this->common_model->solveCustomQuery($maxdisplay);
		$this->data['maxdis'] = $maxdisplay[0]->maxdisplay+1;
		$this->data['nav_type_list']=$this->common_model->getRows('navigation_type','id,nav_type',array('status'=>1));
		$this->data['menu_list']=$this->common_model->getRows('menu','id,menu_name',array('status'=>1));
		$this->data['page_list']=$this->common_model->getRows('page','page_id,page_name',array('page_status'=>1));
        $this->load->view('backoffice/masters/add_nav_view_mapping', $this->data, FALSE);
    }
	public function save_nav_mapping()
	{
		if($this->nav_mapping_validData())
		{ 
	        $user_id=$this->data['live_user_id']; 
			$time=time();
			$all_page_id=$this->input->post('page_id');
			if(!empty($all_page_id))
			{
				foreach($all_page_id as $page_id)
				{
					$this->data = array(
					'nav_type' => $this->input->post('nav_type'),
					'label' => $this->input->post('label'),
					'page_type' => $this->input->post('page_type'),
					'page_id' => $page_id,			
					'created_date' => date('Y-m-d'),
					'created_by' => $user_id,
					'updated_date' => date('Y-m-d'),
					'updated_by' => $user_id);
					if((bool)$this->common_model->save('navigation_mapping',$this->data) === TRUE)
					{
						//echo "rr";die;
						$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
					}
					else
					{
						//echo "A4"; die;
						$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
						$this->session->set_flashdata($this->msg);
						return $this->add_nav_mapping();
					}
				}
				redirect('backoffice/menu/show_nav_mapping');
			}
		}
		else
		{
			return $this->add_nav_mapping();
		}
	}
	
	private function nav_mapping_validData($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('nav_type', 'Nav Type', 'trim|required|strip_tags|callback_check_nav_type['.$id.']');
		}
		else
		{
			$this->form_validation->set_rules('nav_type', 'Navigation Type', 'trim|required|strip_tags');
			$this->form_validation->set_rules('page_type', 'Category', 'trim|required|strip_tags');
			//$this->form_validation->set_rules('nav_type', 'Navigation Type', 'trim|required|strip_tags|is_unique[navigation_type.nav_type]');		
		}
		//$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	public function nav_mapping_edit($id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Edit Menu</li></ol>';
			
	    $id=base64_decode($id);
		
		$this->data['rec'] = $this->common_model->getRow('navigation_mapping','*',array('id'=>$id));
		$this->data['act'] = site_url('backoffice/menu/nav_mapping_update/'.base64_encode($id));
		$this->data['nav_type_list']=$this->common_model->getRows('navigation_type','id,nav_type',array('status'=>1));
		$this->data['menu_list']=$this->common_model->getRows('menu','id,menu_name',array('status'=>1));
		$this->data['page_list']=$this->common_model->getRows('page','page_id,page_name',array('page_status'=>1));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/masters/add_nav_view_mapping', $this->data, FALSE);
	}
	public function nav_mapping_update($id)
	{
		if($this->nav_mapping_validData($id)){ 
			$this->data = array(
			'title' => $this->input->post('title'),
			'nav_type' => $this->input->post('nav_type'),
			'display_order' => $this->input->post('display_order'),
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'updated_by' => $this->data['live_user_id']);				
			if((bool)$this->common_model->update('navigation_type',$this->data, array('id'=>base64_decode($id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/show_nav');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->nav_edit($id);
			}
			}
			else
			{
				return $this->nav_edit($id);
			}
	}
	public function nav_mapping_delete($id=0){
		if((bool)$this->common_model->delete('navigation_mapping',array('id'=>base64_decode($id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/menu/show_nav_mapping');
	}	
    public function show($start=0)
	{

		//print_r($this->input->post());die;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message post</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(MessageID) as total FROM messagecenterposttable ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM messagecenterposttable ".$cond." order by MessageID LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/message_view', $this->data);
    }
    
    public function email_template_name($start=0)
	{
		$this->data['page_form_id']=51;
		$this->data['page_module_id']=14;
		//print_r($this->input->post());die;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message post</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(MessageID) as total FROM messagecenterposttable ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM master_email_temp ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/email_template_name', $this->data);
    }
    public function add_email_template()
	{
		$this->data['page'] = 2522;
		$this->data['page_form_id']=51;
		$this->data['page_module_id']=14;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Message</li></ol>';
		$this->data['act'] = base_url('backoffice/message/save_email_template');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM messagecenterposttable"; 
		

        $this->load->view('backoffice/message/add_email_template_view', $this->data, FALSE);
    }
    public function save_email_template()
	{
		if($this->email_validData())
		{
			//$time=time();
			$this->data = array(
			'name' => $this->input->post('emailtemplate'),			
			'status' => $this->input->post('status'));
			if((bool)$this->common_model->save('master_email_temp',$this->data) === TRUE)
			{
				//echo "rr";die;
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/email_template_name');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			//echo "B4"; die;

			return $this->add();
		}
	}
	 public function track_message($start=0)
	{
		//print_r($this->input->post());die;
		$this->data['page_form_id']=9;
		$this->data['page_module_id']=5;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message tracking</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM subscriptionmsg ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM subscriptionmsg ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/track_message_view', $this->data);
    }
	public function submenu_view($start=0)
	{		
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		if($this->input->get('form_submit_submenu')=='Search'){
			$menu = $this->input->get('menu_name');	
			if($menu!=''){
				$cond.= "menu_name like '%".$menu."%'";
				$con_use++;	
			}
			$url_cond.='?menu_name='.$menu.'&form_submit_menu=Search';
		}
		if($con_use){ $cond_created_where=' WHERE '; }else{ $cond_created_where=''; }
		/* get count */
		$total_get_sql = "SELECT count(id) as total FROM menu ".$cond_created_where." ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$course_stream_sql="SELECT *,menu.menu_name FROM form_information join menu on menu.id =form_information.module_id order by form_id desc";
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_menu_name_search_submit']=base_url('backoffice/menu/show_nav');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/masters/submenu_view', $this->data);
    }
    public function add_schedule_table()
	{
		//echo '<pre>';print_r($this->session->userdata('admin'));
		$this->data['page'] = 2522;
		$this->data['page_form_id']=35;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Message</li></ol>';
		$this->data['act'] = base_url('backoffice/message/save_schedule_table');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['rec'] = $this->common_model->getRow('provider','*',array('pcustid'=>$this->session->userdata('admin')->id));
		//print_r($this->data['rec']);die;
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM messagecenterposttable"; 
		

        $this->load->view('backoffice/message/add_schedule_table_view', $this->data, FALSE);
    }
    public function add_schedule_date()
	{
		//echo '<pre>';print_r($this->session->userdata('admin'));
		$this->data['page'] = 2522;
		$this->data['page_form_id']=35;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Message</li></ol>';
		$this->data['act'] = base_url('backoffice/message/save_schedule_date');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['rec'] = $this->common_model->getRow('provider','*',array('pcustid'=>$this->session->userdata('admin')->id));
		//print_r($this->data['rec']);die;
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM messagecenterposttable"; 
		

        $this->load->view('backoffice/message/add_schedule_date_view', $this->data, FALSE);
    }
	public function add()
	{
		$this->data['page'] = 2522;
		$this->data['page_form_id']=8;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Message</li></ol>';
		$this->data['act'] = base_url('backoffice/message/save');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM messagecenterposttable"; 
		

        $this->load->view('backoffice/message/add_message_view', $this->data, FALSE);
    }
	public function submenu_add()
	{
		$this->data['page'] = 2522;
		$this->data['page_form_id']=8;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Sub Menu</li><li class="active">Add Sub Menu</li></ol>';
		$this->data['submenuact'] = base_url('backoffice/menu/submenu_save');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM menu"; 
		$maxdisplay = $this->common_model->solveCustomQuery($maxdisplay);
		$this->data['maxdis'] = $maxdisplay[0]->maxdisplay+1;
		$this->data['menu_name_list']=$this->common_model->getRows('menu','id,menu_name',array('status'=>1));
        $this->load->view('backoffice/masters/add_submenu_view', $this->data, FALSE);
    }
	public function submenu_save()
	{
		//echo '<pre>'; print_r($this->input->post());die;
		if($this->submenu_validate()){	
			$time=time();
			$this->data = array(
			'module_id' => $this->input->post('menu_name'),
			'form_name' => $this->input->post('sub_menu_name'),
			'display_order_form' => $this->input->post('display_order'),
			'form_url' => $this->input->post('menu_url'),
			'form_status' => $this->input->post('status'),
			'child' => $this->input->post('child')
			);
			if((bool)$this->common_model->save('form_information',$this->data) === TRUE)
			{
				//echo "rr";die;
				$form_id=$this->db->insert_id();
				$permission_data=array(
				"form_id"=>$form_id,
				"role_id"=>1,
				"form_view"=>1,
				"form_add"=>1,
				"form_edit"=>1,
				"form_delete"=>1
				);
				$this->common_model->save('form_permission',$permission_data);
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/submenu_view');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->submenu_add();
			}
		}
		else
		{
			//echo "B4"; die;

			return $this->submenu_add();
		}
	}
	private function submenu_validate($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('menu_name', 'Menu Name','trim|required|strip_tags|callback_check_course_menu_name['.$id.']');
		}
		else
		{
	$this->form_validation->set_rules('menu_name', 'Menu Name', 'trim|required');		
	$this->form_validation->set_rules('sub_menu_name', 'sub menu name','trim|required|is_unique[form_information.form_name]');
		}
		$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	public function save()
	{
		if($this->_validData())
		{
			//$time=time();
			$this->data = array(
			'Message' => $this->input->post('message'),	
			'message_type_id' => $this->input->post('message_type_id'),			
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'CreatedBy' => $this->data['live_user_id']);
			if((bool)$this->common_model->save('messagecenterposttable',$this->data) === TRUE)
			{
				//echo "rr";die;
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/show');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			//echo "B4"; die;

			return $this->add();
		}
	}
	
	private function _validData($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('message', 'Message', 'trim|required|strip_tags');
		}
		else
		{
		$this->form_validation->set_rules('message', 'Message Name', 'trim|required|strip_tags');	
		
		}		
		return $this->form_validation->run();
    }
	
	private function email_validData()
	{
		$this->form_validation->set_rules('emailtemplate', 'Message', 'trim|required');
		return $this->form_validation->run();
    }
	private function schedule_validData()
	{
		$this->form_validation->set_rules('starttime', 'starttime', 'trim|required');
		$this->form_validation->set_rules('endtime', 'endtime', 'trim|required');
		//$this->form_validation->set_rules('calendardate', 'Fron date', 'trim|required');
		//$this->form_validation->set_rules('todate', 'End date', 'trim|required');
		return $this->form_validation->run();
    }
    private function schedule_validDataTable()
	{
		$this->form_validation->set_rules('starttime', 'starttime', 'trim|required');
		$this->form_validation->set_rules('endtime', 'endtime', 'trim|required');
		return $this->form_validation->run();
    }
	public function delete($message_id=0){
		if((bool)$this->common_model->delete('messagecenterposttable',array('MessageID'=>base64_decode($message_id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/message/show');
	}
	public function submenu_delete($id=0){
		if((bool)$this->common_model->delete('form_information',array('form_id'=>base64_decode($id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/menu/submenu_view');
	}
	
	public function check_course_stream_name($course_stream_name, $course_stream_id)
	{
		$cond=array('course_stream_name'=>$course_stream_name,'course_stream_id !='=>$course_stream_id);
		if((bool)$this->common_model->getRows('course_stream', '', $cond)===true){
			$this->form_validation->set_message('check_course_stream_name', 'This %s is already used.');
			return false;
		}
		return true;
	}
    public function check_nav_type($nav_type, $id)
	{
		$cond=array('nav_type'=>$nav_type,'id !='=>$id);
		if((bool)$this->common_model->getRows('navigation_type', '', $cond)===true){
			$this->form_validation->set_message('check_nav_type', 'This %s is already used.');
			return false;
		}
		return true;
	}
	private function track_msg_validData()
	{
		$this->form_validation->set_rules('message', 'Message', 'trim|required');
		return $this->form_validation->run();
    }
	public function update_track_msg($menu_id)
	{

		if($this->track_msg_validData($menu_id)){
			$this->data = array(
			'messagename' => $this->input->post('message'),			
			'status' => $this->input->post('status'));		
			if((bool)$this->common_model->update('subscriptionmsg',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/track_message');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit_track_msg($menu_id);
			}
			}
			else
			{
				return $this->edit_track_msg($menu_id);
			}
	}	
	public function edit_track_msg($menu_id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec'] = $this->common_model->getRow('subscriptionmsg','*',array('id'=>$menu_id));
		$this->data['act'] = site_url('backoffice/message/update_track_msg/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/message/edit_track_message_view', $this->data, FALSE);
	}
	public function edit($menu_id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec'] = $this->common_model->getRow('messagecenterposttable','*',array('MessageID'=>$menu_id));
		$this->data['act'] = site_url('backoffice/message/update/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/message/add_message_view', $this->data, FALSE);
	}
	public function edit_email_temp($menu_id=0)
	{
		$this->data['page_form_id']=51;
		$this->data['page_module_id']=14;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec'] = $this->common_model->getRow('master_email_temp','*',array('id'=>$menu_id));
		$this->data['act'] = site_url('backoffice/message/update_email_temp/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/message/add_email_template_view', $this->data, FALSE);
	}
	public function update_email_temp($menu_id)
	{

		if($this->email_validData($menu_id)){
			$this->data = array(
			'name' => $this->input->post('emailtemplate'),			
			'status' => $this->input->post('status'));		
			if((bool)$this->common_model->update('master_email_temp',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/email_template_name');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit_email_temp($menu_id);
			}
			}
			else
			{
				return $this->edit_email_temp($menu_id);
			}
	}	
	public function submenu_edit($submenu_id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Sub Menu</li><li class="active">Edit SubMenu</li></ol>';
			
	    $submenu_id=base64_decode($submenu_id);
		
		$this->data['rec'] = $this->common_model->getRow('form_information','*',array('form_id'=>$submenu_id));
		//echo '<pre>'; print_r($this->data['rec']);die;
		$this->data['submenuact'] = site_url('backoffice/menu/submenu_update/'.base64_encode($submenu_id));
		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->data['menu_name_list']=$this->common_model->getRows('menu','id,menu_name',array('status'=>1));
		$this->load->view('backoffice/masters/add_submenu_view', $this->data, FALSE);
	}
	public function submenu_update($submenu_id)
	{
		if($this->schedule_validData())
		{
			$this->data = array(
			'module_id' => $this->input->post('menu_name'),
			'form_name' => $this->input->post('sub_menu_name'),
			'display_order_form' => $this->input->post('display_order'),
			'form_url' => $this->input->post('menu_url'),
			'form_status' => $this->input->post('status'),
			'child' => $this->input->post('child'),
			//'created_date' => date('Y-m-d'),
			//'updated_by' => $this->data['live_user_id']
			);				
		if((bool)$this->common_model->update('form_information',$this->data, array('form_id'=>base64_decode($submenu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/submenu_view');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($submenu_id);
			}
		}
		else
		{
			return $this->edit($submenu_id);
		}
	}
	public function update($menu_id)
	{
		if($this->_validData($menu_id)){ 
			$this->data = array(			
			'Message' => $this->input->post('message'),
			'message_type_id' => $this->input->post('message_type_id'),				
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'updated_by' => $this->data['live_user_id']);				
			if((bool)$this->common_model->update('messagecenterposttable',$this->data, array('MessageID'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/show');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($menu_id);
			}
			}
			else
			{
				return $this->edit($menu_id);
			}
	}
	
	public function ch_status($id=0,$Status=0)
	{		
		if($id)
		{
			$this->data = array('status'=>$Status);
			$Cond=array('country_id'=>base64_decode($id));	
			if($this->common_model->update('country',$this->data, $Cond))
			{
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}
			else
			{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}
		else
		{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode( $this->data['msg_type']);
	}
	public function check_submenu_display_order(){
		$menu_name = $this->input->post('menu_name');
		$display_order_module="SELECT max(display_order_form) as display_order_module FROM form_information where module_id 
		= ".$menu_name.""; 
		$getresult = $this->common_model->solveCustomQuery($display_order_module);
		echo   ($getresult[0]->display_order_module) +1;	exit;	
		}
	public function schedule_date_delete($message_id=0){
		if((bool)$this->common_model->delete('time_slot',array('id'=>base64_decode($message_id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/message/schedule_date');
	}
	public function delete_email_temp($message_id=0){
		if((bool)$this->common_model->delete('master_email_temp',array('id'=>base64_decode($message_id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/message/email_template_name');
	}
	public function schedule_date_edit($menu_id=0){		
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec2'] = $this->common_model->getRow('time_slot','*',array('id'=>$menu_id));
		//print_r($this->data['rec2']);die;
		$this->data['rec'] = $this->common_model->getRow('provider','*',array('pcustid'=>$this->session->userdata('admin')->id));
		$this->data['act'] = site_url('backoffice/message/schedule_date_update/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->load->view('backoffice/message/add_schedule_date_view', $this->data, FALSE);
	}
	public function schedule_date_update($menu_id)
	{
		if($this->schedule_validData($menu_id)){
			$this->data = array(
				'providerid' => $this->input->post('providerid'),
				'calendardate' => date('d-m-Y',strtotime($this->input->post('calendardate'))),
				'timeslot' => $this->input->post('message'),			
				'status' => $this->input->post('status'),
				'created_date' => date('Y-m-d'),
				'created_by' => $this->data['live_user_id']
			);			
			if((bool)$this->common_model->update('time_slot',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/schedule_date');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->schedule_date_edit($menu_id);
			}
			}
			else
			{
				return $this->schedule_date_edit($menu_id);
			}
	}
	
	
	public function show_send_email()
	{
		$this->data['page_form_id']=36;
		$this->data['page_module_id']=14;
		//($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message post</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();			
		$course_stream_sql="SELECT * FROM send_email ".$cond." order by id";
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		//$records_count=$total_get[0]->total;
		//$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);		
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/show_send_email', $this->data, FALSE);
    }
	public function add_send_email()
	{
		$this->data['page'] = 2522;
		$this->data['page_form_id']=36;
		$this->data['page_module_id']=14;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Message</li></ol>';

		$this->data['templateemail']=$this->common_model->getRows('master_email_temp','id,name');

		$this->data['act'] = base_url('backoffice/message/save_send_email');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
        $this->load->view('backoffice/message/send_message_view', $this->data, FALSE);
    }	
	public function save_send_email()
	{
		if($this->valid_send_email())
		{
			$this->data = array(
			'name' => $this->input->post('tempname'),
			'subject_txt' => $this->input->post('subject_txt'),
			'email_description' => preg_replace('/\>\s+\</m', '><',$this->input->post('email_description')),			
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'created_by' => $this->data['live_user_id']);
			if((bool)$this->common_model->save('send_email',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/show_send_email');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_send_email();
			}
		}
		else
		{
			//echo "B4"; die;

			return $this->add_send_email();
		}
	}
	
	private function valid_send_email($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('email_description', 'Email Description', 'trim|required');
		}
		else
		{
			$this->form_validation->set_rules('email_description', 'Email Description', 'trim|required');	
		
		}		
		return $this->form_validation->run();
    }
	public function edit_send_email($menu_id=0)
	{
		$this->data['page_form_id']=36;
		$this->data['page_module_id']=14;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$course_stream_sql="SELECT * FROM send_email where id =".$menu_id." order by id";
		$this->data['rec'] = $this->common_model->solveCustomQuery($course_stream_sql);

		$this->data['templateemail']=$this->common_model->getRows('master_email_temp','id,name');

		
		$this->data['act'] = site_url('backoffice/message/update_send_email/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/message/send_message_view', $this->data, FALSE);
	}
	
	public function update_send_email($menu_id)
	{
		
		if($this->valid_send_email($menu_id)){// echo "dddddd";die;
			$this->data = array(				
			'name' => $this->input->post('tempname'),
			'subject_txt' => $this->input->post('subject_txt'),
			'email_description' => preg_replace('/\>\s+\</m', '><',$this->input->post('email_description')),		
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'created_by' => $this->data['live_user_id']);			
			if((bool)$this->common_model->update('send_email',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/show_send_email');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit_send_email($menu_id);
			}
			}
			else
			{ //echo "ddddfffffffdd";die;
				return $this->edit_send_email($menu_id);
			}
	}
}
?>
