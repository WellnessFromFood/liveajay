<?php
class Cheer extends CI_Controller {

	public $data = array();
    public $msg = array();

 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
			
		}
		
		
		//update these
		$this->data['page'] = 9;
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
    }
    
    public function test()
    {
        echo "Inside test";
        
    }
    
    public function saveNewCheer()
    {
        
        //Is this a new one - or an existing one? - it is always a new one.
        $id = $this->input->post('id');
        
        
        $name = $this->input->post('name');
        $subject = $this->input->post('subject');
        $week = $this->input->post('week') + 1;
        $day = $this->input->post('day')+ 1;
        $description = $this->input->post('description');
        $status = $this->input->post('status');
        
    
     //test code to confirm values   
        echo '$name is '. $name .'<br>';
        echo '$week is '. $week .'<br>';
        echo '$day is '. $day .'<br>';
        echo '$subject is '. $subject .'<br>';
        echo '$description is '. $description .'<br>';
        echo '$status is '. $status .'<br>';
        
       $this->data = array(
           'id' => $this->input->post('id'), 
           'week'=> $this->input->post('week') + 1,
           'day'=> $this->input->post('day') + 1,
           'name'=> $this->input->post('name'),
           'subject'=> $this->input->post('subject'),
           'content'=> $this->input->post('description'),
           'status'=> $this->input->post('status')
           );
        
        if((bool)$this->common_model->save('cheer',$this->data, array('id'=>$id)) === TRUE){
                //echo '<pre>'; print_r($this->data);die;
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/cheer/showCheers');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($id);
			}
    
        
        
    }
    
    public function updateExistingCheer()
    {
        $id = $this->input->post('id');
        //echo 'id is '. $id;
        
        $name = $this->input->post('name');
        $subject = $this->input->post('subject');
        $week = $this->input->post('week') + 1;
        $day = $this->input->post('day')+ 1;
        $description = $this->input->post('description');
        $status = $this->input->post('status');
        
    
     //test code to confirm values   
        echo '$name is '. $name .'<br>';
        echo '$week is '. $week .'<br>';
        echo '$day is '. $day .'<br>';
        echo '$subject is '. $subject .'<br>';
        echo '$description is '. $description .'<br>';
        echo '$status is '. $status .'<br>';
        
       $this->data = array(
           'id' => $this->input->post('id'), 
           'week'=> $this->input->post('week') + 1,
           'day'=> $this->input->post('day') + 1,
           'name'=> $this->input->post('name'),
           'subject'=> $this->input->post('subject'),
           'content'=> $this->input->post('description'),
           'status'=> $this->input->post('status')
           );
        
        if((bool)$this->common_model->update('cheer',$this->data, array('id'=>$id)) === TRUE){
                //echo '<pre>'; print_r($this->data);die;
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/cheer/showCheers');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($id);
			}
        
    }
    
    public function showCheers($start=0)
	{
	    
	    echo "inside Cheer!";
	    
	    //Display the Manage Customer form - populate the controls with data. This presents a list of Customers and waits for user to select a customer/function
	    //view url = backoffice/customer/show (form_name = View Users)
		$this->data['page_form_id']=65;
		$this->data['page_module_id']=14;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage cheers</li></ol>';
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		
		//Show all of the cheers in this view - active and inactive
		$cheerSql="SELECT * FROM cheer order by id desc ";
		
        //Run the query
		$this->data['recs'] = $this->common_model->solveCustomQuery($cheerSql);
		$records_count = count($this->data['recs']);
		
		
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['action_customer_search_submit']=base_url('backoffice/cheer/addCheer');
		$this->data['permission'] = $this->common_model->checkPermission();
	
		//echo '<pre>'; print_r($this->data['recs']);die;
		$this->load->view('backoffice/cheer/cheer_view', $this->data);
	}




    public function addCheer($start=0)
	{
	    //echo '$start is '. $start; die;
	    //Display the Add Cheer form - populate the controls with data. 
	    //view url = backoffice/cheer/show 
		
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		$limit = 100;

        $this->data['page_form_id']=66;
	    $this->data['page_module_id']=14;
	    $this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage Cheer</li></ol>';
	
		if ($start==0)
		{
		    //echo 'new one - figure it out <br>';
		    //$this->data['recs']
		    $arrayOfOne = array(
		        'id' => 0,
		        'name' => 'Default name',
		        'week' => 1,
		        'day' => 1,
		        'subject' => "test",
		        'content' => "Default Content",
		        'status' => 1);
		    
		    $this->data['recs'] = array($arrayOfOne); 
		    $this->data['page_form_id']=66;
		    $this->data['page_module_id']=14;
		    $this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage Cheer</li></ol>';
		        
		    
		    //$this->data['recs'][0]->id = 0;
		    
		    $this->data['submit'] = lang('SAVE_BTN');
    		$this->data['pagigShow']=$this->functions->drawPagination(1,$start,$limit_from=0,$limit=100,$url_cond);
    		$this->data['act']=base_url('backoffice/cheer/saveNewCheer');
    		$this->data['permission'] = $this->common_model->checkPermission();
    		//echo '<pre>'; print_r($this->data['recs']);die;
    		$this->load->view('backoffice/cheer/add_cheer_view', $this->data);
		    
		}
		else
		{
		    
    		//query for getting a specific cheer
    		$cheers="SELECT * FROM cheer where id='". $start ."'";
    		
    		//echo '$cheers is ' . $cheers; die;
    		
            //Run the query
    		$this->data['recs'] = $this->common_model->solveCustomQuery($cheers);
    		//echo '<br> Name is ' . $this->data['recs'][0]->name . '<br>';
    		//echo "The type is " . gettype($this->data['recs']); echo '<pre>'; print_r($this->data['recs']);die;
    		
    		$records_count=count($this->data);
    		
    		
    		$this->data['submit'] = lang('SAVE_BTN');
    		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count=1,$start=0,$limit_from=0,$limit=100,$url_cond);
    		$this->data['act']=base_url('backoffice/cheer/updateExistingCheer');
    		$this->data['permission'] = $this->common_model->checkPermission();
    		//echo '<pre>'; print_r($this->data['recs']);die;
    		$this->load->view('backoffice/cheer/edit_cheer_view', $this->data);
		}
	}
}