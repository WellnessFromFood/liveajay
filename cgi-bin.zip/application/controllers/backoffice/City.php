<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class City extends CI_Controller
 {
    public $data = array();
    public $msg = array();

    public function __construct(){
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE){
			redirect('backoffice/login');
			exit();
		}
		$this->data['FormId'] = 4;
		$this->data['ModuleId'] = 2;
        $this->data['page'] = 4;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
    public function show(){
		$this->data['page_form_id']=29;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">City</li></ol>';
		
		//$this->data['recs'] = $this->common_model->getRows('cities','*','');
		$table = 'cities';
		$join = array('state' => 'state.state_id = cities.state_id');
		
		$fields = 'cities.id,cities.city_name as CityName,cities.state_id as StateId,state.state_name,cities.Status';
		
		$this->data['recs'] = $this->common_model->getJoinRows('cities',$join,'',$fields);
		$this->data['permission'] = $this->common_model->checkPermission();
        $this->load->view('backoffice/masters/city_view', $this->data);
    }
	
    public function add()
	{
		$this->data['page_form_id']=28;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">City</li><li class="active">Add City</li></ol>';
		$this->data['StateList'] = $this->common_model->getRows('state','*',array('status'=>'1'));
		
        $this->data['act'] = base_url('backoffice/city/save');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		
        $this->load->view('backoffice/masters/add_city_view', $this->data, FALSE);
    }
	
	public function save(){
		if($this->_validData()){
			$this->data = array(
				'city_name' => ucwords($this->input->post('CityName')),
				'state_id' => $this->input->post('StateId'),
				'Status' => $this->input->post('Status'),
			);	
			if((bool)$this->common_model->save('cities',$this->data) === TRUE){
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/city/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}else{
			return $this->add();
		}
	}
	
	public function edit($id=0)
	{
		$this->data['page_form_id']=28;
		$this->data['page_module_id']=4;
		
		$stateid=$this->uri->segment(4);
		$citiesid=$this->uri->segment(5);
	    $id=base64_decode($citiesid);
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">City</li><li class="active">Edit City</li></ol>';
		
		$this->data['rec'] = $this->common_model->getRow('cities','*',array('id'=>$id));
		$this->data['StateList'] = $this->common_model->getRows('state','*','');
		
		$this->data['act'] = site_url('backoffice/city/update/'.($stateid).'/'.($citiesid));
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('UPDATE_BTN');
		$this->load->view('backoffice/masters/add_city_view', $this->data, FALSE);
	}
	
	public function update($id){
		$stateid=$this->uri->segment(4);
		$citiesid=$this->uri->segment(5);
		$id=base64_decode($citiesid);
		if($this->_validData($id))
		{
			$this->data = array('city_name' =>$this->input->post('CityName'),
			'state_id' => $this->input->post('StateId'),
			'status' => $this->input->post('Status'));	
			
			$Cond=array('id'=>$id);
			if((bool)$this->common_model->update('cities',$this->data, $Cond) === TRUE){
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/state/citylist/'.($stateid));
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit(base64_encode($id));
			}
		}else{
			return $this->edit(base64_encode($id));
		}
	}
	
	public function delete($id=0){
	   $id=base64_decode($id);
		if((bool)$this->common_model->delete('cities',array('id'=>$id))){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/city/show');
	}
	
	private function _validData($id=0){
		
		$this->form_validation->set_rules('StateId', 'State Name', 'trim|required');
		if($id)
		{
		    $this->form_validation->set_rules('CityName', 'City Name', 'trim|required|strip_tags|callback_check_city_name['.$id.']');
		}
		else
		{
		    $this->form_validation->set_rules('CityName', 'City Name', 'trim|required|strip_tags|is_unique[cities.city_name]');
		}
		$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	
	public function ch_status($id=0,$Status=0){
		if($id){
			$this->data = array(
				'status' => $Status);	
			$Cond=array('id'=>$id);	
			if($this->common_model->update('cities',$this->data, $Cond)){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode( $this->data['msg_type']);
	}
	
	public function getState($id=0){
		$this->data['CountryList'] = $this->city_model->getState($id);
		header('Content-Type: application/json');
		echo json_encode($this->data['CountryList']);
	}
	
	public function getCity($StateId=0,$CountryId=0){
		$this->data['CountryList'] = $this->city_model->getCity($StateId,$CountryId);
		header('Content-Type: application/json');
		echo json_encode($this->data['CountryList']);
	}
	
	public function check_city_name($CityName, $id)
	{
		$cond=array('city_name'=>$CityName, 'id !='=>$id);
		if((bool)$this->common_model->getRows('cities', '', $cond)===true){
			$this->form_validation->set_message('check_city_name', 'This %s is already used.');
			return false;
		}
		return true;
	}
	
}
?>
