<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
    
    
    class apiLimit
{
    public $numberOfCallsLeft;
    public $timeOfNextReset;
    
}

class sugarDataResults
{
    public $breakfastSugars=0;
    public $lunchSugars=0;
    public $dinnerSugars=0;
    public $bedSugars=0;
}


class pressureDataResults
{
    public $morningPressureHigh=0;
    public $morningPressureLow=0;
    public $morningPulse=0;
    
    public $eveningPressureHigh=0;
    public $eveningPressureLow=0;
    public $eveningPulse=0;
}



class carbDataResults
{
    
    public $breakfastCarbs=0;
    public $lunchCarbs=0;
    public $dinnerCarbs=0;
    public $bedCarbs=0;
    public $totalCarbs=0;

}
    
    
class Diets extends CI_Controller
{
    public $data = array();
    public $msg = array();
    
    
   
    
    
    
    public function __construct()
    {
        parent::__construct();
        if ((bool) $this->session->userdata('IsAdminLoggedIn') == FALSE) {
            redirect('backoffice/login');
            exit();
        }
        $this->load->helper('common_helper');
        $this->load->helper('sendinblue');
        $this->data['page_form_id']   = 13;
        $this->data['page_module_id'] = 7;
        
    }
    
   
    
    public function export_diet_features()
	{
	    //Exports the contents of the Master Diet Schedule view to excel
	    
		$week_sql="SELECT * FROM week";
		$this->data['recs'] = $this->common_model->solveCustomQuery($week_sql);
		$num = count($this->data['recs']);
		
        //echo 'In X-port and $num is '. $num; die;
        
        
		$datatbl='';
        $datatbl = '<table cellspacing="2" cellpadding="5" style="border:2px;text-align:center;" border="1" width="60%">';
        $datatbl .= '<tr>
					<th  class="center">Entry No</th>
					<th class="center">Week name</th>
					<th  class="center">DIY Message</th>
					<th  class="center">DIY Allow Meeting</th>
					<th  class="center">DIY Net Gram</th>
					<th class="center">Premium Message</th>
					<th  class="center">Premium Allow Meeting</th>
					<th  class="center">Premium Net Gram</th>
					<th class="center">Special Message</th>
					<th  class="center">Special Allow Meeting</th>
					<th  class="center">Special Net Gram</th>
					<th  class="center">Questionnaire</th>
					<th  class="center">Special Net Carb?</th>
					<th  class="center">Special Hunger Level?</th>
					<th  class="center">Special Blood Pressure?</th>
					<th  class="center">Special Blood Sugar</th>
					<th  class="center">Status</th>
					</tr>'; 
        			$i = 1;
        			$j=0;
        
        
        //echo '<pre>'; print_r($this); die;
        //<td style="text-align:center;">'. $val->week_message_id . '</td>
        
        foreach ($this->data['recs'] as $val) {
				$datatbl .= '<tr> 
				<td style="text-align:center;">'. $val->id . '</td>	
				<td style="text-align:center;">'. $val->number_of_week . '</td>						
			
			    <td style="text-align:center;">'. $this->common_model->getCustomFielddata('messagecenterposttable','Message',
    						array('MessageID'=>$val->week_message_id)) . '</td>
				
				
				
				<td style="text-align:center;">'. $val->allowmeet_id . '</td>
				
				<td style="text-align:center;">'. $this->functions->get_message_name($val->week_netgram_id) . '</td>
				
				
				<td style="text-align:center;">'. $this->common_model->getCustomFielddata('messagecenterposttable','Message',
    						array('MessageID'=>$val->prem_week_message_id)) . '</td>
				
				
				<td style="text-align:center;">'. $val->prem_allowmeet_id . '</td>
				<td style="text-align:center;">'. $this->functions->get_message_name($val->prem_week_netgram_id) . '</td>
				
				<td style="text-align:center;">'. $this->common_model->getCustomFielddata('messagecenterposttable','Message',
    						array('MessageID'=>$val->special_week_message_id)) . '</td>
				
				<td style="text-align:center;">'. $val->special_allowmeet_id . '</td>
				<td style="text-align:center;">'. $this->functions->get_message_name($val->special_week_netgram_id) . '</td>

				<td style="text-align:center;">'. $val->questionnaire_id . '</td>
				<td style="text-align:center;">'. $val->special_net_carb . '</td>
				<td style="text-align:center;">'. $val->special_hunger . '</td>
				<td style="text-align:center;">'. $val->special_blood_pressure . '</td>
				<td style="text-align:center;">'. $val->special_blood_sugar_level . '</td>
                <td style="text-align:center;">'. $val->status . '</td>';
			}	       
			$datatbl .= "</tr></table>";
			
			header('Content-Type: application/force-download');        
			header('Content-disposition: attachment; filename=loggedIn_data_'.date('d-m-Y').'.xls');         
			header("Pragma: ");        
			header("Cache-Control: ");
			echo $datatbl; die;
			
		
	}
    
    public function show($start = 0)
    {
        $this->data['page_form_id']   = 27;
        $this->data['page_module_id'] = 7;
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit                    = 100;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
        $cond                     = '';
        $url_cond                 = '';
        $con                      = '';
        $conds                    = array();
        if ($this->input->post('form_submit_diets') == 'Search') {
            $diets_name = $this->input->post('diets_name');
            if ($diets_name != '') {
                $conds[] = "Message like '%" . $diets_name . "%'";
            }
            $url_cond .= '?diets_name=' . $diets_name . '&form_submit_diets=Search';
        }
        if ($conds) {
            $con = implode('and', $conds);
        }
        if ($con) {
            $cond .= "Where " . $con;
        }
        $this->data['diets_name']              = $this->input->post('diets_name');
        $total_get                             = $this->common_model->getRows('dietsplan', 'count(id) as total', $cond);
        $this->data['recs']                    = $this->common_model->getRows('dietsplan', '*', $cond, 'display_order', 'ASC', $limit_from, $limit);
        //echo '<pre>'; print_r($this->data['recs']);die;
        $records_count                         = $total_get[0]->total;
        $this->data['pagigShow']               = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        $this->data['act_diets_search_submit'] = base_url('backoffice/diets/show');
        $this->data['permission']              = $this->common_model->checkPermission();
        $this->load->view('backoffice/diets/diets_view', $this->data);
    }
    public function delete_message($id = 0, $cid = 0)
    {
        if ((bool) $this->common_model->delete('messagecenterposttable', array(
            'MessageID' => base64_decode($id)
        )) == true) {
            $this->msg = array(
                'msg' => lang('RECORD_DELETED'),
                'msg_type' => 'success'
            );
        } else {
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
        }
        $this->session->set_flashdata($this->msg);
        redirect('backoffice/diets/customer_week_days_list/' . $cid);
    }
    public function delete_week($id = 0)
    {
        if ((bool) $this->common_model->delete('week', array(
            'id' => base64_decode($id)
        )) == true) {
            $this->msg = array(
                'msg' => lang('RECORD_DELETED'),
                'msg_type' => 'success'
            );
        } else {
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
        }
        $this->session->set_flashdata($this->msg);
        redirect('backoffice/diets/week');
    }
    public function delete_label($diets_id = 0)
    {
        if ((bool) $this->common_model->delete('diets_label', array(
            'diet_label_id' => base64_decode($diets_id)
        )) == true) {
            $this->msg = array(
                'msg' => lang('RECORD_DELETED'),
                'msg_type' => 'success'
            );
        } else {
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
        }
        $this->session->set_flashdata($this->msg);
        redirect('backoffice/diets/diet_label');
    }
    
    
    public function create_printable_report($start=0)
    {
        error_reporting(0);
        //print_r($this->input->post()); 
        $custidd = $this->uri->segment(4);
        
        $this->load->library('user_agent');
		$data['previous_url'] = $this->agent->referrer();
        
        $this->data['page_form_id']   = 26;
        $this->data['page_module_id'] = 7;
        
       // echo 'the previous url is ' . $data['previous_url'] . '<br>';
        //echo 'The agent is <pre>'; print_r($this->agent); die;
       
        
        
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit = 10;
        $this->data['breadcrumb'] = '<ol class="breadcrumb">
		<li class="active"><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li>
		<li>Create_printable_report</li>
		</ol>';
        $cond = '';
        $url_cond = '';
        $con = '';
        $conds = array();
        
        //echo '$custidd = '. $custidd; 
        if (isset($custidd) && (!empty($custidd))) 
        {
            $custId = base64_decode($custidd); 
            //echo '$cond is ' . $custId;  
        }
        $userSql = "SELECT * FROM user WHERE id='" . $custId . "'";
        
        //echo '$userSql is '. $userSql . '<br>'; 
        
        $userData = $this->common_model->solveCustomQuery($userSql);
        
        $createdDate = $userData[0]->created_date;
        //echo '$createdDate is ' . $createdDate . '<br>';
        
        $weekInfo = calculate_TheWeek($createdDate);
        
        //echo '$weekInfo is <pre>'; print_r($weekInfo);
        $this->data['customer_weekid'] = $weekInfo['week'];
        $this->data['customer_dayid'] = $weekInfo['day'];
        $this->data['customer_emailid'] = $userData[0]->emailid;
        $this->data['customer_dob'] = $userData[0]->dateofbirth;
        $this->data['customer_startingWt'] = $userData[0]->weight;
        $this->data['customer_height_ft'] = $userData[0]->height;
        $this->data['customer_height_in'] = $userData[0]->inches;
        $this->data['customer_total_height_inches'] = $this->data['customer_height_ft'] * 12 + $this->data['customer_height_in']; 
        $this->data['customer_gender'] = $userData[0]->gender;
        $this->data['customer_picture'] = $userData[0]->profile_image;
        $this->data['customer_phoneNo'] = $userData[0]->contact_no;
        $this->data['customer_createdDate'] = $createdDate;
        $this->data['customer_startingWeek'] = $userData[0]->starting_week;
        $this->data['customer_talentLMSId'] = $userData[0]->lms_id;
        
        $this->data['bmi'] = $this->common_model->calculate_BMI_forUSUnits($this->data['customer_total_height_inches'], $this->data['customer_startingWt']);
        
        
                            //echo 'customer_dob is ' . $this->data['customer_dob'] . '<br>'; 
        $this->data['customer_firstname'] = ucwords(strtolower($userData[0]->first_name));
        $this->data['customer_lastname'] = ucwords(strtolower($userData[0]->last_name));
                            //echo 'first name is ' . $this->data['customer_firstname'] . '<br>';
                            //echo 'last name is ' . $this->data['customer_lastname'] . '<br>';
        
        
        $this->data['customer_id'] = $custId;
        $this->data['diets_name']  = $this->input->post('diets_name');
        //$total_get_sql             = "SELECT count(*) as total FROM diets_plan_mapping " . $cond . " group by customer_id,week_id,day_id";
     //   $total_get                 = $this->common_model->solveCustomQuery($total_get_sql);
     //   $course_stream_sql         = "SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(week_id) as week_id,ANY_VALUE(day_id) as day_id,ANY_VALUE(allowmeet_id) as allowmeet_id,ANY_VALUE(extra_metting) as extra_metting,ANY_VALUE(created_date) as created_date,ANY_VALUE(diet_net_carb_val) AS diet_net_carb_val,ANY_VALUE(diet_hunger_val) AS diet_hunger_val, ANY_VALUE(diet_blood_pressure) AS diet_blood_pressure,ANY_VALUE(diet_blood_sugar_level) AS diet_blood_sugar_level FROM diets_plan_mapping " . $cond . " group by customer_id,week_id,day_id";
        //LIMIT ".$limit_from.",".$limit
        
//$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
        
     //   $records_count                         = $total_get[0]->total;
        $this->data['pagigShow']               = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
      //  $this->data['act_diets_search_submit'] = base_url('backoffice/diets/show');
        $this->data['permission']              = $this->common_model->checkPermission();
        
        
//************  New shit here  ******/

//Gathers data for a customer, and prepares it for presentation
        $segment = $this->uri->segment(4);
        error_reporting(0);
        
        /*
        $total_get_sql = "SELECT count(id) as total FROM customer_diets_plan 
		                    where customer_id=" . $custId . " group by customer_id ";
        
        $total_get = $this->common_model->solveCustomQuery($total_get_sql);
        */
        
        $this->data['rec'] = $this->common_model->getRows('customer_diets_plan', 'id, week_wise_days, customer_id, meeting_date, comments, weeks, weight, 
                                                            customer_diets_plan.created_date, updated_date, steps, exercise_id, staff_comments, created_by,
                                                            updated_by, comment_date, last_modify_date', 
                                                            array('customer_id' => $custId), 'weeks, week_wise_days', 'desc', 0 ,30);
        
        
        
        //echo '<pre>'; print_r($this->data['rec']);exit;
        $max_cust_data     = $this->common_model->solveCustomQuery("SELECT customer_diets_plan_id
								                                    FROM customer_diets_plan_desc
								                                    WHERE customer_diets_plan_id
								                                    IN (
								                                        SELECT id
								                                        FROM  `customer_diets_plan`
								                                        WHERE customer_id ='" . $custId . "'
								                                        )
								                                    GROUP BY (customer_diets_plan_id)
								                                    ORDER BY COUNT( diet_plan_id ) DESC limit 1
							                                           ");
        
        $customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
        $qry_diet_plan_id = array(); 
        
        $dietcond = "customer_diets_plan_desc.customer_diets_plan_id='" . $customer_diets_plan_id . "'";
        $dietfield = 'ANY_VALUE(dietsplan.diet_name) as diet_name, ANY_VALUE(dietsplan.id) as dietsplan_id, ANY_VALUE(input_type) AS input_type, ANY_VALUE(dietsplan.log_detail_label) AS log_detail_label';
        
        
        $dietjoin = array(
                            array(
                                    'join_table' => 'dietsplan',
                                    'on_first_table' => 'dietsplan.id',
                                    'on_second_table' => 'customer_diets_plan_desc.diet_plan_id')
                                );
                                
        $this->data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc", $dietcond, $dietfield, $dietjoin, '', '', 'ANY_VALUE(dietsplan.admin_display_order)', 'asc', 'dietsplan.log_detail_label');
        
        //echo '<pre>';
        //print_r($this->data['diet_label']); 
        
        foreach ($this->data['diet_label'] as $keys => $values) 
        { 
            //echo '<pre>';print_r();die;
            $mappid[] = $values->dietsplan_id;
        }
        
        
        
        
        $this->data['all_segment_id'] = $segment; 
        
       
        $customer_diets_info = $this->common_model->customer_diets_info($custId);
        
     
        $this->data['all_diet_id'] = $mappid;
        $this->data['uidd'] = base64_decode($segment);
        $records_count = $total_get[0]->total;
        
       
        $this->data['dynamic_menu'] = $this->common_model->getRows('dynamicDietslog', '*', array('tbl_status' => 1), 'status', 'desc'); 
 
        
        
        //New stuff from progress - to get the information from TalentLMS
        
        $currentApiHourLimit = getNumberOfApiCallsLeftThisHour();
        
        //echo '<pre'; print_r($currentApiHourLimit);
        
        if ($currentApiHourLimit->numberOfCallsLeft < 300)
        {
            $this->session->set_flashdata('msg', 'Low API limit of '.  $currentApiHourLimit->numberOfCallsLeft   . ' till the end of the hour. Please wait :' . $currentApiHourLimit->timeOfNextReset);
            redirect('backoffice/user/logged_user');
            
        }
        else
        {
            
            //Now that we know that we have API headroom - make the calls to gather the data
            
            
            //Stuff from Progress - to get the TalentLMS data
             /* store the talentLMSId for the user */
             
            
            /* make the call to the TalentLMS API to get info for the user */
            TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
            $userTalentData = TalentLMS_User::retrieve($this->data['customer_talentLMSId']);
            
            $this->data['customer_talentData'] = $userTalentData;
            
                        //echo 'customer id is '. $custId . '<br>';
                        //echo 'customer talentlmsid is ' . $this->data['customer_talentLMSId']; 
            
            $this->data['lmsData']= TalentLMS_User::retrieve($this->data['customer_talentLMSId']);
            
                        //echo 'we have the lmsData <pre>'; print_r($this->data['lmsData']); die;
            
            $lmsCreatedDate = $this->data['lmsData']['created_on'];
            $lmsCreateTimestamp = strtotime($lmsCreatedDate);
                                //echo '$lmsCreateTimestamp is '. $lmsCreateTimestamp; die;
            
                        //echo '$lmsCreatedDate is ' . $lmsCreatedDate;
            
            $arayOfCourses = $this->data['lmsData']['courses'];
                        //echo '$arayOfCourses is <pre>'; print_r($arayOfCourses);
            
            $this->data['lmsCourses'] =   $arayOfCourses;
          
            
                    //echo 'About to get timeline data for ' . $this->data['customer_talentLMSId']  . '<br>';
            $userTimelineData = TalentLMS_Siteinfo::getTimeline(array('event_type'=>'user_login_user', 'user_id' => $this->data['customer_talentLMSId']));
            
            //If there is nothing in the timeline for this user's login, they did not login yet
            if (empty($userTimelineData))
            {
                $thisUserProgress->lastLogToTalent = 'Did not log in yet';
            }
            else
            {
                                //echo 'output from timeline: <br>';
                                //echo '<pre>'; print_r($userTimelineData);
                $thisUserProgress->lastLogToTalent = $userTimelineData[0]['timestamp'];
            }
            
            $thisUserProgress->enrolledOn = $lmsCreateTimestamp;
            
            
            
            if ($userTalentData["created_on"] == ($userTalentData["last_updated"]))
            {
                $thisUserProgress->lastLogToTalent = "Never Logged On";
                $thisUserProgress->coursesAssigned = count($userTalentData["courses"]);
                $thisUserProgress->studyTimeSpent =  "No time";
                
            }
            else
            {
                //Get the count of courses
                $thisUserProgress->coursesAssigned = count($userTalentData["courses"]);
                
                $totalTime='';
                $thisUserProgress->coursesCompleted = 0;
                //loop thru the courses that are assigned to the user and gather any progress
                foreach($userTalentData["courses"] as $key => $eachCourse)
                {
                    
                    if (!empty($eachCourse["total_time"]))
                    {
                        $totalTime = addDurationToTotal($eachCourse["total_time"], $totalTime);
                    }
                    if (!empty($eachCourse["completed_on"]))
                    {
                        $thisUserProgress->coursesCompleted = $thisUserProgress->coursesCompleted + 1;
                    }
                    
                    if ($eachCourse["completion_percentage"] <> 0)
                    {
                        $thisUserProgress->coursesStarted = $thisUserProgress->coursesStarted + 1;
                    }
                    
                }
                if (empty($totalTime)){
                    $thisUserProgress->studyTimeSpent =  "No time";
                }
                else
                {
                    $thisUserProgress->studyTimeSpent = $totalTime;
                }
            }
            
            $this->data['customer_learningProgress'] = $thisUserProgress;
                         //echo 'about to load the report view <br>';
                        //echo '<pre>'; print_r($this->data); die;
            $this->load->view('backoffice/diets/single_report.php', $this->data);
               
            
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
      
        
        
        
        
        
        
        
        
        
    }
    
    
    
    
    public function mapping_view($start = 0)
    {
        error_reporting(0);
        //print_r($this->input->post());die;
        $custidd                      = $this->uri->segment(4);
        $this->data['page_form_id']   = 26;
        $this->data['page_module_id'] = 7;
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit                    = 10;
        $this->data['breadcrumb'] = '<ol class="breadcrumb">
		<li class="active"><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li>
		<li>Manage Mapping</li>
		</ol>';
        $cond                     = '';
        $url_cond                 = '';
        $con                      = '';
        $conds                    = array();
        if (isset($custidd) && (!empty($custidd))) {
            $cond = "Where customer_id =" . base64_decode($custidd);
        }
        
        $this->data['customer_name_list'] = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'first_name', array(
            'id' => base64_decode($custidd)
        ))));
        
        $this->data['customerids'] = $this->uri->segment(4);
        $this->data['diets_name']  = $this->input->post('diets_name');
        $total_get_sql             = "SELECT count(*) as total FROM diets_plan_mapping " . $cond . " group by customer_id,week_id,day_id";
        $total_get                 = $this->common_model->solveCustomQuery($total_get_sql);
        $course_stream_sql         = "SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(week_id) as week_id,ANY_VALUE(day_id) as day_id,ANY_VALUE(allowmeet_id) as allowmeet_id,ANY_VALUE(extra_metting) as extra_metting,ANY_VALUE(created_date) as created_date,ANY_VALUE(diet_net_carb_val) AS diet_net_carb_val,ANY_VALUE(diet_hunger_val) AS diet_hunger_val, ANY_VALUE(diet_blood_pressure) AS diet_blood_pressure,ANY_VALUE(diet_blood_sugar_level) AS diet_blood_sugar_level FROM diets_plan_mapping " . $cond . " group by customer_id,week_id,day_id";
        //LIMIT ".$limit_from.",".$limit
        
        $this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
        
        $records_count                         = $total_get[0]->total;
        $this->data['pagigShow']               = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        $this->data['act_diets_search_submit'] = base_url('backoffice/diets/show');
        $this->data['permission']              = $this->common_model->checkPermission();
        $this->load->view('backoffice/diets/diets_mapping_view', $this->data);
    }
    public function diet_label($start = 0)
    {
        //print_r($this->input->post());die;
        $this->data['page_form_id']   = 24;
        $this->data['page_module_id'] = 7;
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit                    = 100;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Diet label</li></ol>';
        $cond                     = '';
        $url_cond                 = '';
        $con                      = '';
        $conds                    = array();
        if ($this->input->post('form_submit_diets') == 'Search') {
            $diets_name = $this->input->post('diets_name');
            if ($diets_name != '') {
                $conds[] = "Message like '%" . $diets_name . "%'";
            }
            $url_cond .= '?diets_name=' . $diets_name . '&form_submit_diets=Search';
        }
        if ($conds) {
            $con = implode('and', $conds);
        }
        if ($con) {
            $cond .= "Where " . $con;
        }
        $this->data['diets_name'] = $this->input->post('diets_name');
        
        
        //$total_get_sql = "SELECT count(diet_label_id) as total FROM diets_label ".$cond;
        //$total_get = $this->common_model->solveCustomQuery($total_get_sql);
        
        $total_get = $this->common_model->getRows('diets_label', 'count(diet_label_id) as total', $cond);
        
        
        //$course_stream_sql="SELECT * FROM diets_label ".$cond." order by diet_label_id LIMIT ".$limit_from.",".$limit;
        //$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
        
        
        $this->data['recs'] = $this->common_model->getRows('diets_label', '*', $cond, 'diet_label_id', 'ASC', $limit_from, $limit);
        
        
        $records_count                         = $total_get[0]->total;
        $this->data['pagigShow']               = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        $this->data['act_diets_search_submit'] = base_url('backoffice/diets/show');
        $this->data['permission']              = $this->common_model->checkPermission();
        $this->load->view('backoffice/diets/diets_label_view', $this->data);
    }
    public function add_diet_label($start = 0)
    {
        $this->data['page_form_id']   = 24;
        $this->data['page_module_id'] = 7;
        $this->data['breadcrumb']     = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';
        $this->data['submit']         = 'Submit';
        $this->data['cancel']         = 'Cancel';
        $this->data['Submit']         = lang('SAVE_BTN');
        $this->data['act']            = base_url('backoffice/diets/diets_label_save');
        $this->load->view('backoffice/diets/add_diet_label_view', $this->data, FALSE);
        
    }
    public function add_form_attribute($start = 0)
    {
        $this->data['page_form_id']   = 27;
        $this->data['page_module_id'] = 7;
        $this->data['breadcrumb']     = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Diet label</li></ol>';
        $this->data['recs']           = $this->common_model->getRows('diets_label', 'diet_label_id,deit_label_name');
        //print_r($this->data['recs']);
        $this->data['submit']         = 'Submit';
        $this->data['cancel']         = 'Cancel';
        $this->data['Submit']         = lang('SAVE_BTN');
        $this->data['act']            = base_url('backoffice/diets/save_form_attribute');
        $this->load->view('backoffice/diets/add_form_attribute_view', $this->data, FALSE);
        
    }
    public function save_form_attribute()
    {
        //echo '<pre>'; print_r($this->input->post());die;
        //echo '<pre>'; print_r($this->input->post());die;
        if ($this->validate_form_attribute()) {
            //$time=time();
            $this->data = array(
                'diet_name' => $this->input->post('add_form_attribute'),
                'diet_label_id' => $this->input->post('add_form_label'),
                'status' => $this->input->post('status'),
                'display_order' => $this->input->post('display_order'),
                'admin_display_order'=>$this->input->post('admin_display_order'),
                'input_type' => 2,
                'created_date' => date('Y-m-d:H:i:s'),
                'created_by' => $this->session->userdata('admin')->role_type
            );
            if ((bool) $this->common_model->save('dietsplan', $this->data) === TRUE) {
                $this->msg = array(
                    'msg' => lang('RECORD_SAVED'),
                    'msg_type' => 'success'
                );
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/diets/show');
            } else {
                //echo "A4"; die;
                $this->msg = array(
                    'msg' => lang('RECORD_ERROR'),
                    'msg_type' => 'error'
                );
                $this->session->set_flashdata($this->msg);
                return $this->add_form_attribute();
            }
        } else {
            //echo "A4"; die;
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
            $this->session->set_flashdata($this->msg);
            return $this->add_form_attribute();
        }
        
    }
    public function delete_form_attribute($diets_id = 0)
    {
        if ((bool) $this->common_model->delete('dietsplan', array(
            'id' => base64_decode($diets_id)
        )) == true) {
            $this->msg = array(
                'msg' => lang('RECORD_DELETED'),
                'msg_type' => 'success'
            );
        } else {
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
        }
        $this->session->set_flashdata($this->msg);
        redirect('backoffice/diets/show');
    }
    
    public function showmessagedetail()
    {
        $userid               = $this->input->post('userid');
        $fetchDATA            = $this->common_model->getRows('user', 'blood_sugar_levels,blood_pressure_pulse', array(
            'id' => base64_decode($userid)
        ));
        //echo '<pre>';print_r($fetchDATA);die;
        $html                 = '';
        $blood_sugar_levels   = explode(',', $fetchDATA[0]->blood_sugar_levels);
        $blood_pressure_pulse = explode(',', $fetchDATA[0]->blood_pressure_pulse);
        $html .= '<table class="table">
			<thead>
			<tr>
			<th scope="col">Diastolic Morning</th>
			<th scope="col">Diastolic Evening</th>
			<th scope="col">Pulse Morning</th>
			<th scope="col">Pulse Evening</th>
			</tr>';
        $html .= '<tr>';
        foreach ($blood_sugar_levels as $val1) {
            $html .= '<td class="text-center">' . $val1 . '</td>';
        }
        $html .= '</tr>';
        $html .= '</table>';
        $html .= '<table class="table">
			<thead>
			<tr>
			<th scope="col">Awake</th>
			<th scope="col">Before Lunch</th>
			<th scope="col">Before Dinner</th>
			<th scope="col">Before Bed</th>
			</tr>';
        $html .= '<tr>';
        foreach ($blood_pressure_pulse as $val2) {
            $html .= '<td class="text-center">' . $val2 . '</td>';
            
        }
        $html .= '</tr>';
        $html .= '</table>';
        echo $html;
        exit;
        
    }
    
    public function edit_form_attribute($id = 0)
    {
        $this->data['page_form_id']   = 27;
        $this->data['page_module_id'] = 7;
        $this->data['breadcrumb']     = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';
        
        $id                   = base64_decode($id);
        $this->data['recs']   = $this->common_model->getRows('diets_label', 'diet_label_id,deit_label_name');
        $this->data['rec']    = $this->common_model->getRow('dietsplan', '*', array(
            'id' => $id
        ));
        $this->data['act']    = site_url('backoffice/diets/update_form_attribute/' . base64_encode($id));
        $this->data['submit'] = 'Submit';
        $this->data['cancel'] = 'Cancel';
        $this->data['Submit'] = lang('SAVE_BTN');
        //echo '<pre>';print_r($this->data['rec']);die;
        $this->load->view('backoffice/diets/add_form_attribute_view', $this->data, FALSE);
    }
    public function update_form_attribute($id = 0)
    {
        $id         = base64_decode($id);
        $this->data = array(
            'diet_name' => $this->input->post('add_form_attribute'),
            'diet_label_id' => $this->input->post('add_form_label'),
            'display_order' => $this->input->post('display_order'),
            'admin_display_order'=> $this->input->post('admin_display_order'),
            'status' => $this->input->post('status')
        );
        $updatedata = $this->common_model->update('dietsplan', $this->data, array(
            'id' => $id
        ));
        
        if ($updatedata) {
            $this->msg = array(
                'msg' => $msg,
                'msg_type' => 'success'
            );
            $this->session->set_flashdata($this->msg);
            redirect('backoffice/diets/show');
            
        }
    }
    public function validate_form_attribute()
    {
        
        $this->form_validation->set_rules('add_form_attribute', 'Add Form Attribute', 'trim|required|strip_tags');
        return $this->form_validation->run();
        
    }
    public function validate_diets_label()
    {
        
        $this->form_validation->set_rules('add_label', 'Add Label', 'trim|required|strip_tags');
        return $this->form_validation->run();
        
    }
    
    public function diets_label_save()
    {
        //echo '<pre>'; print_r($this->input->post());die;
        //echo '<pre>'; print_r($this->input->post());die;
        if ($this->validate_diets_label()) {
            $time       = time();
            $this->data = array(
                'deit_label_name' => $this->input->post('add_label'),
                'status' => $this->input->post('status')
            );
            if ((bool) $this->common_model->save('diets_label', $this->data) === TRUE) {
                $this->msg = array(
                    'msg' => lang('RECORD_SAVED'),
                    'msg_type' => 'success'
                );
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/diets/diet_label');
            } else {
                //echo "A4"; die;
                $this->msg = array(
                    'msg' => lang('RECORD_ERROR'),
                    'msg_type' => 'error'
                );
                $this->session->set_flashdata($this->msg);
                return $this->add_diet_label();
            }
        } else {
            //echo "A4"; die;
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
            $this->session->set_flashdata($this->msg);
            return $this->add_diet_label();
        }
        
    }
    public function customer_diets_plan($start = 0)
    {
        //echo '<pre>'; print_r($this->input->post());die;
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit                    = 100;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Customer diets plan</li></ol>';
        $cond                     = '';
        $con                      = '';
        $url_cond                 = '';
        //$cond="where customer_diets_plan.meeting_date !='0000-00-00 00:00:00'";
        $conds                    = array();
        if ($this->input->post('form_submit_diet_plan') == 'Search') {
            
            $first_name     = $this->input->post('first_name');
            $last_name      = $this->input->post('last_name');
            $week_id        = $this->input->post('week_id');
            $number_of_week = $this->input->post('number_of_week');
            $select_week_id = $this->input->post('select_week_id');
            $date_search    = $this->input->post('date_search');
            $status         = $this->input->post('status');
            if ($week_id == 'week_equal') {
                $conds[] = "customer_diets_plan.weeks = " . trim($number_of_week) . "";
            }
            if ($week_id == 'week_before') {
                $conds[] = "customer_diets_plan.weeks < " . trim($number_of_week) . "";
            }
            if ($week_id == 'week_after') {
                $conds[] = "customer_diets_plan.weeks > " . trim($number_of_week) . "";
            }
            
            if ($select_week_id == 'date_equal') {
                $conds[] = " date(customer_diets_plan.created_date)>='$date_search' and date(customer_diets_plan.created_date)<='$date_search'";
            }
            if ($select_week_id == 'date_before') {
                $conds[] = " date(customer_diets_plan.created_date)< '$date_search'";
            }
            if ($select_week_id == 'date_after') {
                //$conds[] = "customer_diets_plan.created_date > ".$date_search."";
                $conds[] = " date(customer_diets_plan.created_date)> '$date_search'";
            }
            
            if ($first_name != '') {
                $conds[] = "user.first_name like '%" . trim($first_name) . "%'";
            }
            if ($last_name != '') {
                $conds[] = "user.last_name like '%" . trim($last_name) . "%'";
            }
            
            if ($week_id != '') {
                $conds[] = "customer_diets_plan.weeks like '%" . trim($week_id) . "%'";
            }
            if ($number_of_week != '') {
                $conds[] = "customer_diets_plan.weeks like '%" . trim($number_of_week) . "%'";
            }
            
            if ($date_search != '') {
                $conds[] = "customer_diets_plan.created_date = " . trim($date_search) . "";
            }
            if ($status != '') {
                $conds[] = "user.status =" . trim($status) . "";
            }
        }
        if ($conds) {
            $con = implode(' OR ', $conds);
        }
        if ($con) {
            $cond .= "Where " . $con;
        }
        $data['first_name']      = $this->input->post('first_name');
        $data['last_name']       = $this->input->post('last_name');
        $data['week_id']         = $this->input->post('week_id');
        $data['number_of_week']  = $this->input->post('number_of_week');
        $data['date_equal']      = $this->input->post('select_week_id');
        $data['date_search']     = $this->input->post('date_search');
        $data['status']          = $this->input->post('status');
        $customer_diets_plan_sql = "SELECT ANY_VALUE(customer_diets_plan.id) as id ,ANY_VALUE(customer_id) as customer_id,ANY_VALUE(meeting_date) as meeting_date,ANY_VALUE(comments) as comments,ANY_VALUE(user.first_name) as first_name, ANY_VALUE(user.last_name) as last_name, ANY_VALUE(weeks) as weeks,ANY_VALUE(week_wise_days) as week_wise_days, ANY_VALUE(customer_diets_plan.created_date) as created_date, ANY_VALUE(user.status) as status, ANY_VALUE(user.subscription_plan_id) as subscription_plan_id 
		FROM  `customer_diets_plan`
		JOIN customer_diets_plan_desc ON customer_diets_plan.id = customer_diets_plan_desc.customer_diets_plan_id
		JOIN user ON customer_diets_plan.customer_id = user.id " . $cond . " group by customer_id order by customer_id desc";
        
        
        $this->data['recs'] = $this->common_model->solveCustomQuery($customer_diets_plan_sql);
        
        $this->data['records_count']        = count($this->data['recs']);
        $this->data['pagigShow']            = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        $this->data['act_diet_plan_submit'] = base_url('backoffice/diets/customer_diets_plan');
        $this->data['permission']           = $this->common_model->checkPermission();
        $this->load->view('backoffice/diets/customer_diets_plan', $this->data);
    }
    public function message_history($customer_id = 0)
    {
        $customer_id = base64_decode($customer_id);
        $cond        = "msg.status=1 and cdp.customer_id='" . $customer_id . "'";
        
        $gramfield   = 'msg.Message,cdp.acknowledgment,cdp.week_wise_days,cdp.weeks';
        $gramjoin    = array(
            array(
                'join_table' => 'messagecenterposttable msg',
                'on_first_table' => 'msg.MessageID',
                'on_second_table' => 'cdp.message_id'
            )
        );
        $all_message = $this->common_model->getJoinData("customer_diets_plan cdp", $cond, $gramfield, $gramjoin, '', '', '', '', '');
        /*
        $all_message=$this->common_model->solveCustomQuery("select  from messagecenterposttable msg inner join  customer_diets_plan cdp on msg.MessageID=cdp.message_id where msg.status=1 and cdp.customer_id='".$customer_id."'");
        */
        //echo '<pre>'; print_r($all_message);die;
        
        $data['all_message'] = $all_message;
        $data['customer_id'] = $customer_id;
        $this->load->view('backoffice/diets/customer_message_history', $data);
    }
    public function customer_diets_view($start = 0)
    {
        //Gathers data for a customer, and prepares it for presentation
        $segment = $this->uri->segment(4);
        error_reporting(0);
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit = 100;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Customer Diet View</li></ol>';
        $cond = '';
        $url_cond = '';
        $con = '';
        $conds = array();
        $this->data['diets_name'] = $this->input->post('diets_name');
        
        $total_get_sql = "SELECT count(id) as total FROM customer_diets_plan 
		                    where customer_id=" . base64_decode($segment) . " group by customer_id ";
        
        $total_get = $this->common_model->solveCustomQuery($total_get_sql);
        
        $this->data['rec'] = $this->common_model->getRows('customer_diets_plan', 'id, week_wise_days, customer_id, meeting_date, comments, weeks, weight, 
                                                            customer_diets_plan.created_date, updated_date, steps, exercise_id, staff_comments, created_by,
                                                            updated_by, comment_date, last_modify_date', 
                                                            array('customer_id' => base64_decode($segment)), 'weeks, week_wise_days', 'desc');
        
        //echo '<pre>'; print_r($this->data['rec']);exit;
        $max_cust_data     = $this->common_model->solveCustomQuery("SELECT customer_diets_plan_id
								                                    FROM customer_diets_plan_desc
								                                    WHERE customer_diets_plan_id
								                                    IN (
								                                        SELECT id
								                                        FROM  `customer_diets_plan`
								                                        WHERE customer_id ='" . base64_decode($segment) . "'
								                                        )
								                                    GROUP BY (customer_diets_plan_id)
								                                    ORDER BY COUNT( diet_plan_id ) DESC limit 1
							                                           ");
        
        $customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
        $qry_diet_plan_id = array();
        
        $dietcond = "customer_diets_plan_desc.customer_diets_plan_id='" . $customer_diets_plan_id . "'";
        $dietfield = 'ANY_VALUE(dietsplan.diet_name) as diet_name, ANY_VALUE(dietsplan.id) as dietsplan_id, ANY_VALUE(input_type) AS input_type, ANY_VALUE(dietsplan.log_detail_label) AS log_detail_label';
        
        
        $dietjoin = array(
                            array(
                                    'join_table' => 'dietsplan',
                                    'on_first_table' => 'dietsplan.id',
                                    'on_second_table' => 'customer_diets_plan_desc.diet_plan_id')
                                );
                                
        $this->data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc", $dietcond, $dietfield, $dietjoin, '', '', 'ANY_VALUE(dietsplan.admin_display_order)', 'asc', 'dietsplan.log_detail_label');
        
        /*echo '<pre>';
        print_r($this->data['diet_label']);exit;*/
        
        foreach ($this->data['diet_label'] as $keys => $values) 
        { 
            //echo '<pre>';print_r();die;
            $mappid[] = $values->dietsplan_id;
        }
        
        
        
        
        $this->data['all_segment_id'] = $segment;
        
        $custid = base64_decode($segment);
        
                    //echo "The answer is " . base64_decode($segment);
        $customer_diets_info = $this->common_model->customer_diets_info($custid);
        
        $this->data['customer_weekid'] = $customer_diets_info[0]->week_id;
        $this->data['customer_dayid']  = $customer_diets_info[0]->day_id;
        
        
        $this->data['customer_name_list'] = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'first_name', array('id' => base64_decode($segment)))));
        $this->data['customer_lastname']  = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'last_name', array('id' => base64_decode($segment)))));
        $this->data['customer_dob']       = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'dateofbirth', array('id' => base64_decode($segment)))));
        $this->data['customer_emailid']   = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'emailid', array('id' => base64_decode($segment)))));
        $this->data['customer_gender']    = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'gender', array('id' => base64_decode($segment)))));
        $this->data['customer_height']    = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'height', array('id' => base64_decode($segment)))));
        $this->data['customer_inches']    = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'inches', array('id' => base64_decode($segment)))));
        
        $this->data['all_diet_id'] = $mappid;
        $this->data['uidd'] = base64_decode($segment);
        $records_count = $total_get[0]->total;
        
        $this->data['start'] = $limit_from;
        $this->data['totalrecords'] = $records_count;
        
        $this->data['pagigShow'] = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        //print_r($this->data['uidd']);die;
        $this->data['dynamic_menu'] = $this->common_model->getRows('dynamicDietslog', '*', array('tbl_status' => 1), 'status', 'desc');
        $this->data['act_diets_search_submit'] = base_url('backoffice/diets/show');
        $this->data['permission'] = $this->common_model->checkPermission();
        $this->load->view('backoffice/diets/customer_diets_view', $this->data);
    }
    public function export_customer_diets_data()
    {
        $segment           = $this->uri->segment(4);
        $this->data['rec'] = $this->common_model->getRows('customer_diets_plan', 'id,week_wise_days, customer_id, meeting_date, comments,weeks,weight,customer_diets_plan.created_date,steps,exercise_id,staff_comments,created_by,updated_by', array(
            'customer_id' => base64_decode($segment)
        ), 'weeks,week_wise_days', 'desc');
        //echo '<pre>'; print_r($this->data['rec']);//die;
        
        $max_cust_data = $this->common_model->solveCustomQuery("
								SELECT customer_diets_plan_id
								FROM customer_diets_plan_desc
								WHERE customer_diets_plan_id
								IN (

								SELECT id
								FROM  `customer_diets_plan`
								WHERE customer_id ='" . base64_decode($segment) . "'
								)
								GROUP BY (
								customer_diets_plan_id
								)
								ORDER BY COUNT( diet_plan_id ) DESC limit 1
							");
        
        $customer_diets_plan_id   = $max_cust_data[0]->customer_diets_plan_id;
        $qry_diet_plan_id         = array();
        //echo '<pre>'; print_r($customer_diets_plan_id);die;
        $dietcond                 = "customer_diets_plan_desc.customer_diets_plan_id='" . $customer_diets_plan_id . "'";
        $dietfield                = 'ANY_VALUE(dietsplan.diet_name) as diet_name,ANY_VALUE(dietsplan.id) as dietsplan_id,ANY_VALUE(input_type) AS input_type,ANY_VALUE(dietsplan.log_detail_label) AS log_detail_label';
        $dietjoin                 = array(
            array(
                'join_table' => 'dietsplan',
                'on_first_table' => 'dietsplan.id',
                'on_second_table' => 'customer_diets_plan_desc.diet_plan_id'
            )
        );
        $this->data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc", $dietcond, $dietfield, $dietjoin, '', '', '', 'asc', 'dietsplan.log_detail_label');
        
        foreach ($this->data['diet_label'] as $keys => $values) { //echo '<pre>';print_r();die;
            $mappid[] = $values->dietsplan_id;
        }
        $this->data['all_diet_id'] = $mappid;
        
        $datatbl = '';
        $datatbl = '<table cellspacing="2" cellpadding="5" style="border:2px;text-align:center;" border="1" width="60%">';
        $datatbl .= '<tr>
					<th  class="center">Entry No</th>
					<th width="22">Date (Data Not Enter)</th>
					<th  class="center">Week</th>
					<th  class="center">Day</th>
					<th  class="center">Weight</th>
					<th width="42" class="center">Total Carbs</th>
					<th  class="center">Bed carbs</th>
					<th  class="center">Bed hunger</th>
					
					<th  class="center">Blood Sugar Bed</th>
					<th  class="center">Blood Sugar Breakfast</th>
					<th  class="center">Blood Sugar Dinner</th>
					<th  class="center">Blood Sugar Lunch</th>


					<th  class="center">Breakfast carbs</th>
					<th  class="center">Breakfast hunger</th>
					<th class="center">Dinner carbs</th>
					<th  class="center">Dinner hunger</th>

					<th  class="center">Evening Pressure</th>
					<th  class="center">Evening Pulse</th>

					
					<th  class="center">Lunch carbs</th>
					<th  class="center">Lunch hunger</th>

					<th  class="center">Morning Pressure</th>
					<th  class="center">Morning Pulse</th>

					<th  class="center">Exercise Time</th>
					<th class="center">Steps</th>
					<th  class="center">Comments</th>
					<th  class="center">Staff/admin Comments</th>
					<th  class="center">Comments date/time</th>
					<th  class="center">Comments By</th>
					
        </tr>';
        $i = 1;
        $j = 0;
        //echo '<pre>'; print_r($this->data['rec']);die;
        foreach ($this->data['rec'] as $val) {
            $udateby        = $this->common_model->getCustomFielddata('user', 'first_name', array(
                'id' => $val->updated_by
            ));
            $exerciseid     = $this->common_model->getCustomFielddata('exercise', 'exercise_name', array(
                'id' => $val->exercise_id
            ));
            $weeks          = $val->weeks;
            $week_wise_days = $val->week_wise_days;
            $weight         = $val->weight;
            //$created_date =  $val->created_date;
            $exercise_id    = $val->exercise_id;
            $steps          = $val->steps;
            $comments       = $val->comments;
            $staff_comments = $val->staff_comments;
            $created_date   = $val->created_date;
            $getdietdesc1   = $this->common_model->get_diet_desc1($val->id);
            
            /*$dtk=date('Y-m-d',strtotime($this->common_model->get_last_fill_data($this->session->userdata('customers')->id)));
            
            $date22 =$this->common_model->getRows('user','created_date',array('status'=>'1','id'=>$this->session->userdata('customers')->id),'','DESC');
            foreach($date22 as $key => $val11)
            {
            if($val->exercise_id==0 && $val->weight==0 && $val->steps=='NA' && $val->comments=='NA')
            {
            $ddd= date ("Y-m-d", strtotime("-$j day", strtotime($val11->created_date)));
            }
            else
            {
            $ddd='';
            }
            echo $ddd;					
            }			*/
            
            $ddd  = '';
            $date = date('Y-m-d');
            
            if ($val->exercise_id == 0 && $val->weight == 0 && $val->steps == 'NA' && $val->comments == 'NA') {
                $ddd = date("Y-m-d", strtotime("+$j day", strtotime($date)));
            }
            
            
            $datatbl .= '<tr> 
				<td style="text-align:center;">' . $i++ . '</td>	
				<td style="text-align:center;">' . $ddd . '</td>						
				<td style="text-align:center;">' . $weeks . '</td>
				<td style="text-align:center;">' . $week_wise_days . '</td>
				<td style="text-align:center;">' . $weight . '</td>
				<td>' . $getdietdesc1 . '</td>';
            
            
            if (!empty($this->data['all_diet_id'])) {
                foreach ($this->data['all_diet_id'] as $key => $val1) {
                    
                    $getdietdesc = $this->common_model->get_diet_desc($val1, $val->id);
                    //echo '<pre>'; print_r($getdietdesc);die;			
                    $datatbl .= '<td>';
                    $datatbl .= $getdietdesc;
                    $datatbl .= '</td>';
                }
            }
            
            $datatbl .= '							
				<td style="text-align:center;">' . $exerciseid . '</td>
				<td style="text-align:center;">' . $steps . '</td>
				<td style="text-align:center;">' . $comments . '</td>
				<td style="text-align:center;">' . $staff_comments . '</td>
				<td style="text-align:center;">' . $created_date . '</td>
				<td style="text-align:center;">' . $udateby . '</td>';
            
            $j--;
        }
        $datatbl .= "</tr></table>";
        //echo  $datatbl;die;       
        header('Content-Type: application/force-download');
        header('Content-disposition: attachment; filename=customer_diets_view_' . date('d-m-Y') . '.xls');
        header("Pragma: ");
        header("Cache-Control: ");
        echo $datatbl;
        die;
        
    }
    public function customer_diets_edit($id = 0)
    {
        $customer_id              = $this->uri->segment(4);
        $getid                    = $this->uri->segment(5);
        $date                    = $this->uri->segment(6);


        //echo $id=base64_decode($cdpid);die;
        //$customer_id = $this->uri->segment(5);
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';
        
        //single query
        
        $edit_diet_plan = $this->common_model->solveCustomQuery("SELECT customer_id,meeting_date,weeks,weight,comments,staff_comments,help,created_date,created_by FROM  `customer_diets_plan`
		WHERE customer_diets_plan.id ='" . base64_decode($getid) . "'");
        
        if (isset($edit_diet_plan) && !empty($edit_diet_plan)) {
            $get_edit_diet_plan = @$edit_diet_plan[0]->customer_id;
        }
        
        $edit_diet_plan_desc = $this->common_model->solveCustomQuery("SELECT input_type,diet_plan_id,customer_diets_plan_id,diet_plan_value FROM  `customer_diets_plan_desc` join dietsplan on dietsplan.id=customer_diets_plan_desc.diet_plan_id

		WHERE customer_diets_plan_id ='" . base64_decode($getid) . "'");
        
        foreach ($edit_diet_plan_desc as $k => $kv) {
            
            if ($kv->input_type == 1) {
                $this->data['inputtype1'][] = $kv;
            }
            if ($kv->input_type == 2) {
                $this->data['inputtype2'][] = $kv;
            }
            if ($kv->input_type == 3) {
                $this->data['inputtype3'][] = $kv;
            }
            if ($kv->input_type == 4) {
                $this->data['inputtype4'][] = $kv;
            }
        }
        //echo  '<pre>'; print_r($this->data);die;
        $this->data['inputtype0'] = $edit_diet_plan;
        
        //$this->data['inputtype2']=$edit_diet_plan_desc;
        //$this->data['inputtype3']=$edit_diet_plan_desc;
        //$this->data['inputtype4']=$edit_diet_plan_desc;
        
        
        //$join['customer_diets_plan_desc']='customer_diets_plan.id=customer_diets_plan_desc.customer_diets_plan_id';
        
        //$customer_diets_plan = $this->common_model->getJoinRows('customer_diets_plan_desc',$join	,'inner join', 'comments, //customer_diets_plan_desc.id as cdpdid,diet_plan_id,diet_plan_value,customer_diets_plan.id as cdpid',
        //array('customer_diets_plan.id'=>base64_decode($cdpid)));
        
        
        //$this->data['inputtype1'] =$customer_diets_plan;
        
        //$this->data['inputtype2'] =$customer_diets_plan;
        
        //echo  '<pre>'; print_r($this->data['rec']);die;
        $this->data['get_hidden_id'] = $getid;
        $this->data['customer_id']   = $customer_id;
        $this->data['act']           = site_url('backoffice/diets/update/' . ($customer_id));
        $this->data['submit']        = 'Submit';
        $this->data['cancel']        = 'Cancel';
        $this->data['date']          =  $date;
        $this->data['Submit']        = lang('SAVE_BTN');
        $this->data['permission']    = $this->common_model->checkPermission();
        //echo '<pre>'; print_r($this->data); die;
        
        $this->load->view('backoffice/diets/customer_diets_edit', $this->data);
        
    }
    public function add_week()
    {
        $this->data['page_form_id']       = 30;
        $this->data['page_module_id']     = 4;
        $this->data['breadcrumb']         = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Week</li><li class="active">Edit Week</li></ol>';
        $this->data['submit']             = 'Submit';
        $this->data['cancel']             = 'Cancel';
        $this->data['Submit']             = lang('SAVE_BTN');
        $this->data['act']                = base_url('backoffice/diets/save_week');
        $this->data['msglist']            = $this->common_model->getRows('messagecenterposttable', 'MessageID,Message', array(
            'status' => '1'
        ));
        $this->data['questionnairetable'] = $this->common_model->getRows('createform', 'id, form_name', array(
            'status' => '1'
        ));
        
        //was net_gram
        
        $this->data['net_gram']           = $this->common_model->getRows('net_gram', 'id, net_gram_name', array(
            'status' => '1'
        ));
        
        echo 'the options are <br>';
        echo '<pre>'; print_r($this->data['net_gram']) ;
        
        
        $this->data['allow_meeting']      = $this->common_model->getRows('allow_meeting', 'id, meeting_name', array(
            'status' => '1'
        ));
        
        //echo '<pre>'; print_r($this->data);
        $this->load->view('backoffice/diets/add_week_view', $this->data, FALSE);
    }
    
    public function check_week_type($default_val, $id)
    {
        $cond = array(
            'default_val ' => $default_val,
            'id !=' => $id
        );
        if ((bool) $this->common_model->getRows('week', 'default_val', $cond) === true) {
            $this->form_validation->set_message('check_week_type', 'This %s is already used.');
            return false;
        }
        return true;
    }
    /* public function validate_week()
    {
    $this->form_validation->set_rules('default_val', 'Default ', 'trim|is_unique[week.default_val]');
    $this->form_validation->set_rules('number_of_week', 'Add Week', 'trim|required');
    return $this->form_validation->run();
    
    } */
    
    private function validate_week($id = 0)
    {
        $id = base64_decode($id);
        if ($id) {
            $this->form_validation->set_rules('default_val', 'Default', 'trim|callback_check_week_type[' . $id . ']');
        } else {
            $this->form_validation->set_rules('default_val', 'Default ', 'trim|is_unique[week.default_val]');
            $this->form_validation->set_rules('number_of_week', 'Add Week', 'trim|required');
        }
        $this->form_validation->set_message('is_unique', 'This %s is already used');
        return $this->form_validation->run();
    }
    /*
    private function validate_week($id=0)
    {
    $this->form_validation->set_rules('week_message_id', 'Select Message', 'trim|required');
    return $this->form_validation->run();
    /* $id=base64_decode($id);
    if($id)
    {
    $this->form_validation->set_rules('default_val', 'Default', 'trim|required|strip_tags|callback_check_week_type['.$id.']');
    }
    else
    {
    $this->form_validation->set_rules('default_val', 'Default ', 'trim|is_unique[week.default_val]');
    $this->form_validation->set_rules('number_of_week', 'Add Week', 'trim|required');
    }
    $this->form_validation->set_message('is_unique', 'This %s is already used');
    return $this->form_validation->run();
    
    
    }
    */
    public function week_edit($id = 0)
    {
        $this->data['page_form_id']   = 30;
        $this->data['page_module_id'] = 4;
        $this->data['breadcrumb']     = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';
        
        $id                               = base64_decode($id);
        $this->data['rec']                = $this->common_model->getRow('week', '*', array(
            'id' => $id
        ));
        $this->data['act']                = site_url('backoffice/diets/update_week/' . base64_encode($id));
        $this->data['submit']             = 'Submit';
        $this->data['cancel']             = 'Cancel';
        $this->data['Submit']             = lang('SAVE_BTN');
        $this->data['msglist']            = $this->common_model->getRows('messagecenterposttable', 'MessageID, Message', array(
            'status' => '1'
        ));
        $this->data['questionnairetable'] = $this->common_model->getRows('createform', 'id,form_name', array(
            'status' => '1'
        ));
        //$this->data['questionnairetable'] = $this->common_model->getRows('questionnairetable','id,questionnaire_name',array('status'=>'1'));
        $this->data['net_gram']           = $this->common_model->getRows('net_gram', 'id,net_gram_name', array(
            'status' => '1'
        ));
        $this->data['allow_meeting']      = $this->common_model->getRows('allow_meeting', 'id,meeting_name', array(
            'status' => '1'
        ));
        $this->load->view('backoffice/diets/add_week_view', $this->data, FALSE);
    }
    public function update_week($id)
    {
        error_reporting(0);
        
        $TOTALDATA = $this->input->post();
        //echo '<pre>'; print_r($TOTALDATA);die;
        //For DIY
        if (isset($TOTALDATA['diet_net_carb']) && !empty($TOTALDATA['diet_net_carb'])) {
            $diet_net_carb = 1;
        } else {
            $diet_net_carb = 0;
        }
        
        if (isset($TOTALDATA['diet_hunger']) && !empty($TOTALDATA['diet_hunger'])) {
            $diet_hunger = 1;
        } else {
            $diet_hunger = 0;
        }
        
        if (isset($TOTALDATA['diet_blood_pressure']) && !empty($TOTALDATA['diet_blood_pressure'])) {
            $diet_blood_pressure = 1;
        } else {
            $diet_blood_pressure = 0;
        }
        
        if (isset($TOTALDATA['diet_blood_sugar_level']) && !empty($TOTALDATA['diet_blood_sugar_level'])) {
            $diet_blood_sugar_level = 1;
        } else {
            $diet_blood_sugar_level = 0;
        }
        
        //For premium
        if (isset($TOTALDATA['premium_net_carb']) && !empty($TOTALDATA['premium_net_carb'])) {
            $premium_net_carb = 1;
        } else {
            $premium_net_carb = 0;
        }
        
        if (isset($TOTALDATA['premium_hunger']) && !empty($TOTALDATA['premium_hunger'])) {
            $premium_hunger = 1;
        } else {
            $premium_hunger = 0;
        }
        
        
        if (isset($TOTALDATA['premium_blood_pressure']) && !empty($TOTALDATA['premium_blood_pressure'])) {
            $premium_blood_pressure = 1;
        } else {
            $premium_blood_pressure = 0;
        }
        
        if (isset($TOTALDATA['premium_blood_sugar_level']) && !empty($TOTALDATA['premium_blood_sugar_level'])) {
            $premium_blood_sugar_level = 1;
        } else {
            $premium_blood_sugar_level = 0;
        }
        
        //For Special
        if (isset($TOTALDATA['special_net_carb']) && !empty($TOTALDATA['special_net_carb'])) {
            $special_net_carb = 1;
        } else {
            $special_net_carb = 0;
        }
        
        if (isset($TOTALDATA['special_hunger']) && !empty($TOTALDATA['special_hunger'])) {
            $special_hunger = 1;
        } else {
            $special_hunger = 0;
        }
        
        if (isset($TOTALDATA['special_blood_pressure']) && !empty($TOTALDATA['special_blood_pressure'])) {
            $special_blood_pressure = 1;
        } else {
            $special_blood_pressure = 0;
        }
        
        if (isset($TOTALDATA['special_blood_sugar_level']) && !empty($TOTALDATA['special_blood_sugar_level'])) {
            $special_blood_sugar_level = 1;
        } else {
            $special_blood_sugar_level = 0;
        }
        
        
        $findmessageid = $this->common_model->getRows('messagecenterposttable', 'MessageID', array(
            'Message' => $TOTALDATA['diy_week_netgram_id']
        ));
        
        
        if (!empty($findmessageid)) {
            $getMessageID = $findmessageid[0]->MessageID;
            
        } else {
            $post_data = array(
                'Message' => $TOTALDATA['diy_week_netgram_id'],
                'status' => 1,
                'created_date' => date('Y-m-d:H:i:s'),
                'CreatedBy' => $this->session->userdata('admin')->role_type
            );
            $this->db->insert('messagecenterposttable', $post_data);
            
            $insert_id    = $this->db->insert_id();
            $getMessageID = $insert_id;
        }
        
        
        $findmessageidd = $this->common_model->getRows('messagecenterposttable', 'MessageID', array(
            'Message' => $TOTALDATA['prem_week_netgram_id']
        ));
        
        
        if (!empty($findmessageidd)) {
            $premgetMessageID = $findmessageidd[0]->MessageID;
            
        } else {
            $post_data = array(
                'Message' => $TOTALDATA['prem_week_netgram_id'],
                'status' => 1,
                'created_date' => date('Y-m-d:H:i:s'),
                'CreatedBy' => $this->session->userdata('admin')->role_type
            );
            $this->db->insert('messagecenterposttable', $post_data);
            
            $insert_id        = $this->db->insert_id();
            $premgetMessageID = $insert_id;
        }
        
        
        
        $findmessageiddd = $this->common_model->getRows('messagecenterposttable', 'MessageID', array(
            'Message' => $TOTALDATA['special_week_netgram_id']
        ));
        
        
        if (!empty($findmessageiddd)) {
            $specialMessageID = $findmessageiddd[0]->MessageID;
            
        } else {
            $post_data = array(
                'Message' => $TOTALDATA['special_week_netgram_id'],
                'status' => 1,
                'created_date' => date('Y-m-d:H:i:s'),
                'CreatedBy' => $this->session->userdata('admin')->role_type
            );
            $this->db->insert('messagecenterposttable', $post_data);
            
            $insert_id        = $this->db->insert_id();
            $specialMessageID = $insert_id;
        }
        
        
        
        
        $default_val = '';
        $default_val = $TOTALDATA['default_val'];
        if (isset($default_val) && ($default_val == 1)) {
            $default_val = 1;
        } else {
            $default_val = 0;
        }
        if ($this->validate_week($id)) {
            $this->data = array(
                'week_message_id' => $this->input->post('week_message_id'),
                'week_netgram_id' => $getMessageID, //$this->input->post('week_netgram_id'),
                'allowmeet_id' => $this->input->post('diy_allowmeet_id'),
                'prem_week_message_id' => $this->input->post('prem_week_message_id'),
                'prem_week_netgram_id' => $premgetMessageID, //$this->input->post('week_netgram_id'),
                'prem_allowmeet_id' => $this->input->post('prem_allowmeet_id'),
                'special_week_message_id' => $this->input->post('special_week_message_id'),
                'special_week_netgram_id' => $specialMessageID,
                'special_allowmeet_id' => $this->input->post('special_allowmeet_id'),
                
                'questionnaire_id' => $this->input->post('questionnaire_id'),
                'number_of_week' => $this->input->post('number_of_week'),
                'default_val' => $default_val, //$this->input->post('default_val'),
                'status' => $this->input->post('status'),
                'hide_net_gram' => $this->input->post('hide_net_gram'),
                'hide_premium_net_gram' => $this->input->post('hide_premium_net_gram'),
                'diet_net_carb' => $diet_net_carb,
                'diet_hunger' => $diet_hunger,
                'premium_net_carb' => $premium_net_carb,
                'premium_hunger' => $premium_hunger,
                'diet_blood_pressure' => $diet_blood_pressure,
                'diet_blood_sugar_level' => $diet_blood_sugar_level,
                'premium_blood_pressure' => $premium_blood_pressure,
                'premium_blood_sugar_level' => $premium_blood_sugar_level,
                'special_net_carb' => $special_net_carb,
                'special_hunger' => $special_hunger,
                'special_blood_pressure' => $special_blood_pressure,
                'special_blood_sugar_level' => $special_blood_sugar_level
            );
            if ((bool) $this->common_model->update('week', $this->data, array(
                'id' => base64_decode($id)
            )) === TRUE) {
                $this->msg = array(
                    'msg' => lang('RECORD_UPDATED'),
                    'msg_type' => 'success'
                );
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/diets/week');
            } else {
                $this->msg = array(
                    'msg' => lang('RECORD_ERROR'),
                    'msg_type' => 'error'
                );
                $this->session->set_flashdata($this->msg);
                return $this->week_edit($id);
            }
        } else {
            return $this->week_edit($id);
        }
    }
    
    public function save_week()
    {
        //From the backend, an admin clicked the Submit button on the Add Week page
        //echo '<pre>'; print_r($this->input->post());die;
        if ($this->validate_week()) {
            
            
            echo 'whoa big fella <br>'; die;
            $number_of_week = $this->input->post('number_of_week');
            echo '<pre> Week number is '; print_r($number_of_week); echo '<br>';
            
            echo 'diy_week_message_id is '. $this->input->post('diy_week_message_id') .'<br>';
            echo 'diy_week_netgram_id is '. $this->input->post('diy_week_netgram_id') .'<br>';
            echo '<br>';
             
            echo 'special_week_message_id is '. $this->input->post('special_week_message_id') .'<br>';
            echo '$this->input->post(special_week_netgram_id) is ' . $this->input->post('special_week_netgram_id') . '<br>'  ;
            echo '<br>';
            echo 'prem_week_message_id is '. $this->input->post('prem_week_message_id') .'<br>';
            echo '$this->input->post(prem_week_netgram_id) is ' . $this->input->post('prem_week_netgram_id') . '<br>'  ;
            
            //Looks like we then create new messages - one for each type
            //first the DIY
            $post_data = array(
                'Message' => $this->input->post('diy_week_netgram_id'),
                'status' => 1,
                'created_date' => date('Y-m-d:H:i:s'),
                'CreatedBy' => $this->session->userdata('admin')->role_type
            );
            echo 'Inserting DIY message ... <br>';
            
            $this->db->insert('messagecenterposttable', $post_data);
            $diyInsert_id = $this->db->insert_id();
            
            //now the special
            $post_data = array(
                'Message' => $this->input->post('special_week_netgram_id'),
                'status' => 1,
                'created_date' => date('Y-m-d:H:i:s'),
                'CreatedBy' => $this->session->userdata('admin')->role_type
            );
            echo 'Inserting Special message ... <br>';
            
            $this->db->insert('messagecenterposttable', $post_data);
            $specialInsert_id = $this->db->insert_id();
            
            //now the premium
             $post_data = array(
                'Message' => $this->input->post('prem_week_netgram_id'),
                'status' => 1,
                'created_date' => date('Y-m-d:H:i:s'),
                'CreatedBy' => $this->session->userdata('admin')->role_type
            );
            
            echo 'Inserting Prem message ... <br>';
            
            $this->db->insert('messagecenterposttable', $post_data);
            $premInsert_id = $this->db->insert_id();
            
            
            
            
            $number_of_week = $this->input->post('number_of_week');
            $numberofweek   = explode('-', $number_of_week);
            //echo '<pre>'; print_r($numberofweek[1]);die;
            
            if (isset($numberofweek) && (!empty($numberofweek))) {
                $week_count = $numberofweek[1];
            } else {
                $week_count = $numberofweek;
            }
            $time       = time();
            
            
            //Note diy uses the ones without prefix
            $this->data = array(
                'number_of_week' => $this->input->post('number_of_week'),
                
                //the DIY flags
                'week_message_id' => $this->input->post('diy_week_message_id'),
                'week_netgram_id' => $diyInsert_id,
                'allowmeet_id' => $this->input->post('diy_allowmeet_id'),
                'diet_net_carb' => $this->input->post('diet_net_carb'),
                'diet_hunger' => $this->input->post('diet_hunger'),
                'diet_blood_pressure' => $this->input->post('diet_blood_pressure'),
                'diet_blood_sugar_level' => $this->input->post('diet_blood_sugar_level'),
                
                
                //the Special Flags
                'special_week_message_id' => $this->input->post('special_week_message_id'),
                'special_week_netgram_id' => $specialInsert_id,    
                'special_allowmeet_id' => $this->input->post('special_allowmeet_id'), 
                'special_net_carb' => $this->input->post('special_net_carb'),
                'special_hunger' => $this->input->post('special_hunger'),
                'special_blood_pressure' => $this->input->post('special_blood_pressure'),
                'special_blood_sugar_level' => $this->input->post('special_blood_sugar_level'),
                
                //The Premium flags
                'prem_week_message_id' => $this->input->post('prem_week_message_id'),
                'prem_week_netgram_id' => $premInsert_id,
                'prem_allowmeet_id' => $this->input->post('prem_allowmeet_id'),
                'premium_net_carb' => $this->input->post('premium_net_carb'),
                'premium_hunger' => $this->input->post('premium_hunger'),
                'premium_blood_pressure' => $this->input->post('premium_blood_pressure'),
                'premium_blood_sugar_level' => $this->input->post('premium_blood_sugar_level'),
                
                
                'questionnaire_id' => $this->input->post('questionnaire_id'),
                
                'week_count' => $week_count,
                'default_val' => $this->input->post('default_val'),
                'status' => $this->input->post('status')
                
                
            );
            
            echo 'About to save ... <br>';
            echo '<pre>'; print_r($this->data); 
            
            if ((bool) $this->common_model->save('week', $this->data) === TRUE) {
                $this->msg = array(
                    'msg' => lang('RECORD_SAVED'),
                    'msg_type' => 'success'
                );
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/diets/week');
            } else {
                //echo "A4"; die;
                $this->msg = array(
                    'msg' => lang('RECORD_ERROR'),
                    'msg_type' => 'error'
                );
                $this->session->set_flashdata($this->msg);
                return $this->add_week();
            }
        } else {
            //echo "A4"; die;
            //$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
            //$this->session->set_flashdata($this->msg);
            return $this->add_week();
        }
    }
    public function week($start = 0)
    {
        //print_r($this->input->post());die;
        $this->data['page_form_id']   = 30;
        $this->data['page_module_id'] = 4;
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit                    = 100;
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Diet label</li></ol>';
        $cond                     = '';
        $url_cond                 = '';
        $con                      = '';
        $conds                    = array();
        if ($this->input->post('form_submit_diets') == 'Search') {
            $diets_name = $this->input->post('diets_name');
            if ($diets_name != '') {
                $conds[] = "Message like '%" . $diets_name . "%'";
            }
            $url_cond .= '?diets_name=' . $diets_name . '&form_submit_diets=Search';
        }
        if ($conds) {
            $con = implode('and', $conds);
        }
        if ($con) {
            $cond .= "Where " . $con;
        }
        $this->data['diets_name']              = $this->input->post('diets_name');
        $total_get_sql                         = "SELECT count(id) as total FROM week " . $cond;
        $total_get                             = $this->common_model->solveCustomQuery($total_get_sql);
        $course_stream_sql                     = "SELECT * FROM week " . $cond . " order by id LIMIT " . $limit_from . "," . $limit;
        $this->data['recs']                    = $this->common_model->solveCustomQuery($course_stream_sql);
        //print_r($this->data['recs']);die;
        $records_count                         = $total_get[0]->total;
        $this->data['pagigShow']               = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        $this->data['act_diets_search_submit'] = base_url('backoffice/diets/show');
        $this->data['permission']              = $this->common_model->checkPermission();
        $this->load->view('backoffice/diets/week_view', $this->data);
    }
    public function add()
    {
        $this->data['page']           = 2522;
        $this->data['page_form_id']   = 23;
        $this->data['page_module_id'] = 7;
        $this->data['breadcrumb']     = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Diets mapping</li></ol>';
        $this->data['recs']           = $this->common_model->getRows('dietsplan', 'id,diet_name,diet_label_id', array(
            'status' => 1
        ), 'display_order', 'ASC');
        
        //$customerlist="SELECT id,first_name as name FROM user where role_type=3  order by id";
        $customerlist = "SELECT id,first_name as name FROM user where role_type=3  and active=1 and lms_id !=0
						AND id NOT IN(SELECT user.id  FROM  diets_plan_mapping JOIN user ON user.id = diets_plan_mapping.customer_id)";
        
        $this->data['customer_list'] = $this->common_model->solveCustomQuery($customerlist);
        
        $messagelist                = "SELECT MessageID,Message FROM messagecenterposttable where status=1";
        $this->data['message_list'] = $this->common_model->solveCustomQuery($messagelist);
        
        $this->data['act']    = base_url('backoffice/diets/save');
        $this->data['submit'] = 'Submit';
        $this->data['cancel'] = 'Cancel';
        $maxdisplay           = "SELECT max(display_order) as maxdisplay FROM dietsplan";
        
        
        $this->load->view('backoffice/diets/add_diets_view', $this->data, FALSE);
    }
    public function save()
    {
        
        echo "Customer_week_days is " . '<pre>'; print_r($this->input->post('customer_week_days'));
        echo '<pre>';print_r($this->input->post());die;
        
        $get_customer_message_id = '';
        if ($this->input->post('customer_id') != '') {
            $get_customer_week_days  = $this->input->post('customer_week_days');
            $get_diet_name           = $this->input->post('get_diet_name');
            $get_customer_message_id = $this->input->post('customer_message_id');
            
            if ($get_customer_week_days != '') {
                
                $customer_id = $this->input->post('customer_id');
                $this->common_model->delete('diets_plan_mapping', array(
                    'customer_id' => ($customer_id)
                ));
                foreach ($get_customer_week_days as $k => $val) { //echo $val;
                    $get_customer_values = explode('_', $val);
                    //echo '<pre>';print_r($get_customer_values);die;
                    foreach ($get_diet_name as $k => $val3) {
                        $this->data = array(
                            'week_id' => $get_customer_values[0],
                            'day_id' => $get_customer_values[1],
                            'mapping_id' => $val3,
                            'customer_id' => $customer_id,
                            'created_date' => date('Y-m-d:H:i:s'),
                            'created_by' => $this->session->userdata('admin')->role_type,
                            'message_id' => $get_customer_message_id
                        );
                        $this->common_model->save('diets_plan_mapping', $this->data);
                    }
                    $this->msg = array(
                        'msg' => lang('RECORD_SAVED'),
                        'msg_type' => 'success'
                    );
                    $this->session->set_flashdata($this->msg);
                }
            }
            /*else{
            if($this->input->post('customer_id') !=''){
            $customer_id = $this->input->post('customer_id');
            $this->common_model->delete('diets_plan_mapping',array('customer_id'=>($customer_id)));
            }
            }*/
        } else {
            $this->msg = array(
                'msg1' => lang('RECORD_ERROR1'),
                'msg_type' => 'danger'
            );
            $this->session->set_flashdata($this->msg);
        }
        redirect('backoffice/diets/customer_diets_list');
    }
    public function filter_data_customer_wise()
    {
        $ajax_data      = '';
        $check          = '';
        $select_cust_id = $this->input->post('select_cust_id');
        if (!empty($select_cust_id)) {
            $customer_message_id = $this->input->post('customer_message_id');
            
            $customer_list   = $this->common_model->getRows('diets_plan_mapping', 'mapping_id,message_id,week_id,day_id', array(
                'customer_id' => $select_cust_id
            ));
            $db_option_value = array();
            if (!empty($customer_list)) {
                foreach ($customer_list as $cust_val) {
                    $db_option_value[] = $cust_val->week_id . "_" . $cust_val->day_id;
                }
            }
            $data['show_diet_list'] = $this->common_model->getRows('dietsplan', 'id,diet_name,diet_label_id', array(
                "status" => "1"
            ));
            $customer_list_desc     = $this->common_model->getRows('diets_plan_mapping', 'mapping_id,message_id,week_id,day_id');
            $customer_list_rec      = $this->common_model->getRows('messagecenterposttable', 'MessageID,Message', '');
            
            $ajax_data .= '<tr><td colspan="4" class="center" class="form-control">';
            $ajax_data .= '<select id="dates-field2" class="multiselect-ui form-control" name="customer_week_days[]" multiple="multiple" required>';
            
            if (!empty($select_cust_id)) {
                //$noweeks =  $this->common_model->getCustomFielddata('user','number_week',array('id'=>$select_cust_id));
                $noweeks      = $this->common_model->solveCustomQuery("select count(id) as total from week where status=1");
                $default_week = $this->common_model->getCustomFielddata('week', 'id', array(
                    'default_val' => 1
                ));
            }
            $week     = $noweeks[0]->total;
            $num_days = 7;
            for ($y = 1; $y <= $week; $y++) {
                for ($x = 1; $x <= $num_days; $x++) {
                    $selected     = '';
                    $option_value = $y . "_" . $x;
                    
                    if (!empty($db_option_value) && in_array($option_value, $db_option_value)) {
                        $selected = ' selected';
                    } else if ($default_week >= $y) {
                        $selected = ' selected';
                    } else {
                        $selected = ' ';
                    }
                    
                    $ajax_data .= '<option ' . $selected . ' value="' . $option_value . '">' . "Week-" . $y . "/days-" . $x . '</option>';
                }
            }
            $ajax_data .= '</select>';
            
            $ajax_data .= '</td></tr>';
            $ajax_data .= '<tr><td colspan="4" class="center" class="form-control">';
            $ajax_data .= '<select name="customer_message_id" class="form-control" id="customer_message_id" required>';
            $ajax_data .= '<option value="">Select Customer</option>';
            
            foreach ($customer_list_rec as $kk => $vkkk) {
                $selected = '';
                if (set_value('customer_message_id')) {
                    if (set_value('customer_message_id') == $vkkk->MessageID) {
                        $selected = 'selected';
                    }
                } else {
                    if (isset($customer_list[0]->message_id) && $customer_list[0]->message_id == $vkkk->MessageID) {
                        $selected = 'selected';
                    }
                }
                
                $ajax_data .= '<option ' . $selected . ' value="' . $vkkk->MessageID . '">' . $this->common_model->getCustomFielddata('messagecenterposttable', 'Message', array(
                    'MessageID' => $vkkk->MessageID
                )) . '</option>';
            }
            $ajax_data .= '</select>';
            $ajax_data .= '</td></tr>';
            if (count($data['show_diet_list'])) {
                $ajax_data .= '
						<tr>
							<th width="77">Choose <input type="checkbox" checked id="checkAll"/></th>
							<th width="77">Diet Name</th>
							<th width="77">Diet Label</th>
						</tr>';
                foreach ($data['show_diet_list'] as $key => $val) {
                    $ajax_data .= '<tr>';
                    if (isset($customer_list)) {
                        foreach ($customer_list as $k => $vkk) {
                            $setArray[] = $vkk->mapping_id;
                        }
                    }
                    if (isset($setArray)) {
                        if (in_array($val->id, $setArray)) {
                            $check = ' checked="checked"';
                        } else {
                            $check = '';
                        }
                    }
                    
                    
                    $ajax_data .= '<td class="center">';
                    $ajax_data .= '<input type="checkbox" ' . $check . ' checked name="get_diet_name[]"
									value="' . $val->id . '"></td>';
                    $ajax_data .= '<td>' . $val->diet_name . '</td>';
                    $ajax_data .= '<td>' . $this->common_model->getCustomFielddata('diets_label', 'deit_label_name', array(
                        'diet_label_id' => $val->diet_label_id
                    )) . '</td>';
                    $ajax_data .= '</tr>';
                }
            }
            
            //$ajax_data.='<tr><td colspan="4" class="center" class="form-control">Choose Week/Days</td></tr>';
            
            /*$ajax_data.='<select style="height: 270px;" multiple="multiple" name="customer_week_days[]" class="form-control" id="customer_week_days">';
            $week=2;
            $num_days=7;
            for ($y = 1; $y <=$week; $y++) {
            for ($x = 1; $x <=$num_days; $x++) {
            $selected = '';
            if(set_value('customer_week_days')){
            if(set_value(customer_week_days) == $vkkk->MessageID){
            $selected = 'selected';
            }
            }else{
            if(isset($customer_list[0]->message_id) && $customer_list[0]->message_id == $vkkk->MessageID){
            $selected = 'selected';
            }
            }
            
            $ajax_data.='<option '.$selected.' value="'.$y."_".$x.'">'."Week-".$y."/days-".$x.'</option>';
            }
            }
            $ajax_data.='</select>';*/
            
            
            $ajax_data .= '
			<script>
				$("#checkAll").click(function(){
				$("input:checkbox").not(this).prop("checked", this.checked);
				})</script>';
            echo $ajax_data;
            exit;
            //echo $ajax_data1; exit;
        }
    }
    public function customer_form_delete()
    {
        $customer_id          = base64_decode($this->uri->segment(4));
        //$week_id = base64_decode($this->uri->segment(5));
        //$day_id = base64_decode($this->uri->segment(6));
        $delete_customer_name = $this->common_model->delete('diets_plan_mapping', array(
            'customer_id' => $customer_id
        ));
        
        if ($delete_customer_name) {
            $this->msg = array(
                'msg' => lang('RECORD_DELETED'),
                'msg_type' => 'success'
            );
            $this->session->set_flashdata($this->msg);
            redirect('backoffice/diets/customer_diets_list');
        }
    }
    public function customer_form_edit()
    {
        
        
        $this->data['page_form_id']   = 26;
        $this->data['page_module_id'] = 7;
        
        $customer_id = base64_decode($this->uri->segment(4));
        
        $week_id                         = base64_decode($this->uri->segment(5));
        $day_id                          = base64_decode($this->uri->segment(6));
        $this->data['customer_list']     = $this->common_model->getRows('diets_plan_mapping', 'mapping_id, message_id, allowmeet_id, extra_metting', array(
                                                                                                                                                            'customer_id' => $customer_id,
                                                                                                                                                            'week_id' => $week_id,
                                                                                                                                                            'day_id' => $day_id
        ));
        $this->data['show_diet_list']    = $this->common_model->getRows('dietsplan', 'id,diet_name,diet_label_id', array(
            'status' => 1
        ));
        $this->data['customer_list_rec'] = $this->common_model->getRows('messagecenterposttable', 'MessageID,Message', '');
        $customerlist                    = "SELECT id,first_name as name FROM user where role_type=3  order by id";
        $this->data['customername_list'] = $this->common_model->solveCustomQuery($customerlist);
        $this->data['get_customer_id']   = $customer_id;
        $this->data['get_week_id']       = $week_id;
        $this->data['get_day_id']        = $day_id;
        $this->data['submit']            = 'Submit';
        $this->data['cancel']            = 'Cancel';
        
        $this->data['action'] = site_url('backoffice/diets/customer_diets_update/' . base64_encode($customer_id) . '/' . base64_encode($week_id) . '/' . base64_encode($day_id));
        
        $this->load->view('backoffice/diets/customer_form_edit_view', $this->data, FALSE);
    }
    public function customer_diets_update()
    {
        //echo '<pre>'; print_r($this->input->post());die;
        $get_customer_message_id = '';
        $customer_id             = base64_decode($this->uri->segment(4));
        $week_id                 = base64_decode($this->uri->segment(5));
        $day_id                  = base64_decode($this->uri->segment(6));
        
        
        //$this->common_model->delete('diets_plan_mapping',array('customer_id'=>$customer_id,'week_id'=>$week_id,'day_id'=>$day_id));
        if ($this->input->post('customer_id') != '') {
            $get_customer_week_days = $this->input->post('customer_week_days');
            $get_diet_name          = $this->input->post('get_diet_name');
            
            $get_customer_message_id = $this->input->post('customer_message_id');
            
            if ($get_customer_week_days != '') {
                $customer_id = $this->input->post('customer_id');
                $i           = 0;
                foreach ($get_customer_week_days as $k => $val) {
                    $get_customer_values = explode('_', $val);
                    /*foreach($get_diet_name  as $k=>$val3){
                    $this->data = array(
                    'week_id' => $get_customer_values[0],
                    'day_id' => $get_customer_values[1],
                    'mapping_id' => $val3,
                    'customer_id' => $customer_id,
                    'allowmeet_id'=>$this->input->post('metting'),
                    'created_date' => date('Y-m-d'),
                    'created_by' => $this->session->userdata('admin')->id,
                    'message_id'=>$get_customer_message_id
                    );
                    $this->common_model->save('diets_plan_mapping',$this->data);
                    $i++;}*/
                    $this->common_model->update('diets_plan_mapping', array(
                        'extra_metting' => $this->input->post('extra_meeting')
                    ), array(
                        'week_id' => $week_id,
                        'customer_id' => $customer_id
                    ));
                    $this->msg = array(
                        'msg' => lang('RECORD_UPDATED'),
                        'msg_type' => 'success'
                    );
                    $this->session->set_flashdata($this->msg);
                }
            }
        }
        redirect('backoffice/diets/mapping_view/' . base64_encode($customer_id));
    }
    public function delete($diets_id = 0)
    {
        if ((bool) $this->common_model->delete('dietsplan', array(
            'id' => base64_decode($diets_id)
        )) == true) {
            $this->msg = array(
                'msg' => lang('RECORD_DELETED'),
                'msg_type' => 'success'
            );
        } else {
            $this->msg = array(
                'msg' => lang('RECORD_ERROR'),
                'msg_type' => 'error'
            );
        }
        $this->session->set_flashdata($this->msg);
        redirect('backoffice/diets/show');
    }
    public function edit($id = 0)
    {
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';
        
        $id                   = base64_decode($id);
        $this->data['rec']    = $this->common_model->getRow('dietsplan', '*', array(
            'MessageID' => $id
        ));
        $this->data['act']    = site_url('backoffice/diets/update/' . base64_encode($id));
        $this->data['submit'] = 'Submit';
        $this->data['cancel'] = 'Cancel';
        $this->data['Submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/diets/add_diets_view', $this->data, FALSE);
    }
    public function update($id = 0)
    {
        //The backend user is editing a customer_diets_edit form, if they update the Staff comments
        //  Then send email.  We need to do a better job in surfacing this type of message in the Daily Tracker
        
        //echo '<pre>'; print_r($this->input->post());die;
        //Staff Comments && Created Date
        $ids_id = $this->input->post('get_hidden_id');
        $commDate = $this->input->post('commentDate');
        $this->common_model->update('customer_diets_plan', array(
            'staff_comments' => $this->input->post('staff_comments')
        ), array(
            'id' => base64_decode($ids_id)
        ));
        
        $created_date = $this->common_model->getRows('customer_diets_plan', 'created_date,staff_comments', array(
            'id' => base64_decode($ids_id)
        ));
        
        //echo '<pre>'; print_r($created_date);die;
        if ((isset($created_date[0]->staff_comments)) && ($created_date[0]->staff_comments != '') && ($created_date[0]->staff_comments != 'NA')) {
            //echo '<pre>'; print_r($created_date);die;
            if ((isset($created_date[0]->staff_comments)) && ($created_date[0]->staff_comments != '')) {
                $staffcomments = $created_date[0]->staff_comments;
            } else {
                $staffcomments = $created_date[0]->first_name;
            }
            
            if ((isset($created_date[0]->created_date)) && ($created_date[0]->created_date != '')) {
                $createddate = date('M d Y', strtotime($created_date[0]->created_date));
            } else {
                $createddate = $created_date[0]->first_name;
            }
            //Customer Fullname
            $customer_id = $this->input->post('customer_id');
            $custname    = $this->common_model->getRows('user', 'first_name,last_name', array(
                'id' => base64_decode($customer_id)
            ));
            if ((isset($custname[0]->first_name)) && ($custname[0]->first_name != '') && ((isset($custname[0]->last_name)) && $custname[0]->last_name != '')) {
                $customername = $custname[0]->first_name . " " . $custname[0]->last_name;
            } else {
                $customername = $custname[0]->first_name;
            }
            //Customer Fullname
            //Send Mail
            $emailid = $this->common_model->getCustomFielddata('user', 'emailid', array(
                'id' => base64_decode($customer_id),
                'status' => 1
            ));
            // echo "Sending Email to " .$emailid;
            $sub33   = $this->common_model->getCustomFielddata('send_email', 'subject_txt', array(
                'name' => 20,
                'status' => 1
            ));
            
            //echo "we are here and " .'<pre>'; print_r($sub33); print_r($emailid);die;
            /*
            $this->common_model->commonMail(20, $sub33, $emailid, '', $createddate, $staffcomments, $customername);*/
            $this->common_model->commonMail(20, $sub33, $emailid, '', base64_decode($commDate), $staffcomments, $customername);
            //End Send Mail
        }
        //exit;
        $id                          = base64_decode($id);
        $msg                         = '';
        $diet_value_name             = '';
        $diets_plan_desc_customer_id = '';
        $diet_value_name             = $this->input->post('diet_value_name');
        $diets_plan_desc_customer_id = $this->input->post('diets_plan_desc_customer_id');
        $get_hidden_id               = base64_decode($this->input->post('get_hidden_id'));
        $staff_comments              = $this->input->post('staff_comments');
        $comment_time                = time();
        if (empty($staff_comments)) {
            $staff_comments = '';
            $comment_time   = '';
        }
        $this->data = array(
            'meeting_date' => $this->input->post('meeting_date'),
            //'weight' => $this->input->post('moming_weight'),
            'comments' => $this->input->post('comment'),
            'staff_comments' => $staff_comments,
            'comment_date' => $comment_time,
            'last_modify_date' => time(),
            'created_date' => $this->input->post('created_date'),
            'help' => $this->input->post('help'),
            'updated_by' => $this->session->userdata('admin')->role_type
        );
        
        $updatedata = $this->common_model->update('customer_diets_plan', $this->data, array(
            'id' => $get_hidden_id
        ));
        if (!empty($updatedata)) {
            if (!empty($diet_value_name)) {
                foreach ($diet_value_name as $key => $val) {
                    $this->data = array(
                        'diet_plan_value' => $val
                    );
                    $this->common_model->update('customer_diets_plan_desc', $this->data, array(
                        'customer_diets_plan_id' => $diets_plan_desc_customer_id,
                        'diet_plan_id' => $key
                    ));
                }
            }
        }
        
        
        
        
        $this->msg = array(
            'msg' => $msg,
            'msg_type' => 'success'
        );
        $this->session->set_flashdata($this->msg);
        redirect('backoffice/diets/customer_diets_view/' . base64_encode($id));
    }
    
    public function customer_diets_list($start = 0) //error_reporting(0);
    {
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit                        = 100;
        $cond                         = '';
        $url_cond                     = '';
        $con                          = '';
        $this->data['page_form_id']   = 26;
        $this->data['page_module_id'] = 7;
        $this->data['breadcrumb']     = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
        $diets_list_sql               = "SELECT COUNT( total ) as total  FROM (SELECT COUNT(*) AS total FROM diets_plan_mapping GROUP BY customer_id
						) AS tt";
        $total_gets                   = $this->common_model->solveCustomQuery($diets_list_sql);
        $records_count                = $total_gets[0]->total;
        $customer_diets_list_sql      = "SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(id) as id FROM diets_plan_mapping group by customer_id order by id desc LIMIT " . $limit_from . "," . $limit;
        $this->data['recs']           = $this->common_model->solveCustomQuery($customer_diets_list_sql);
        //echo '<pre>'; print_r($this->data['recs']);die;
        $this->data['pagigShow']      = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        $this->data['permission']     = $this->common_model->checkPermission();
        $this->load->view('backoffice/diets/customer_diets_list_view', $this->data);
    }
    
    public function assign_week($start = 0)
    {
        error_reporting(0);
        ($start) ? ($limit_from = $start) : ($limit_from = 0);
        $limit                        = 10;
        $cond                         = '';
        $url_cond                     = '';
        $con                          = '';
        $this->data['page_form_id']   = 26;
        $this->data['page_module_id'] = 7;
        $this->data['breadcrumb']     = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
        $diets_list_sql               = "SELECT COUNT( total ) as total  FROM (SELECT COUNT(*) AS total FROM diets_plan_mapping GROUP BY customer_id
						) AS tt";
        $total_gets                   = $this->common_model->solveCustomQuery($diets_list_sql);
        $records_count                = $total_gets[0]->total;
        $customer_diets_list_sql      = "SELECT * FROM diets_plan_mapping group by customer_id LIMIT " . $limit_from . "," . $limit;
        $this->data['recs']           = $this->common_model->solveCustomQuery($customer_diets_list_sql);
        
        $this->data['pagigShow']  = $this->functions->drawPagination(@$records_count, $start, $limit_from, $limit, $url_cond);
        $this->data['permission'] = $this->common_model->checkPermission();
        $this->load->view('backoffice/diets/assign_week_view', $this->data);
    }
    public function timeschedule()
    {
        $this->data['page_form_id']   = 33;
        $this->data['page_module_id'] = 12;
        $this->data['submit']         = 'Submit';
        $this->data['cancel']         = 'Cancel';
        $this->data['act']            = base_url('backoffice/diets/savetimeschedule');
        $this->load->view('backoffice/diets/add_timeschedule_view', $this->data, FALSE);
    }
    public function savetimeschedule()
    {
        //echo '<pre>'; print_r($this->input->post());die;
        $this->data['page_form_id']   = 33;
        $this->data['page_module_id'] = 12;
        $field_name                   = $this->input->post('field_name');
        if (!empty($field_name)) {
            foreach ($field_name as $key => $val) {
                $this->data = array(
                    'providerid' => $this->input->post('provider_id'),
                    'timeslot' => $val,
                    'status' => 1,
                    'created_date' => date('Y-m-d:H:i:s'),
                    'created_by' => $this->session->userdata('admin')->role_type
                );
                if ((bool) $this->common_model->save('time_slot', $this->data) === TRUE) {
                    $this->msg = array(
                        'msg' => lang('RECORD_SAVED'),
                        'msg_type' => 'success'
                    );
                    $this->session->set_flashdata($this->msg);
                    
                }
                
            }
        }
        redirect('backoffice/diets/timeschedulelist');
    }
    public function timeschedulelist()
    {
        $this->data['page_form_id']   = 34;
        $this->data['page_module_id'] = 12;
        $this->data['rec']            = $this->common_model->getRows('time_slot', 'id,providerid,timeslot,status,created_date');
        $this->load->view('backoffice/diets/timeschedule_view', $this->data);
    }
    public function check_defaultval()
    {
        //$default_val = $this->input->post('default_val');
        $val = $this->common_model->getRows('week', 'default_val', array(
            'default_val' => 1
        ));
        if (count($val) > 0) {
            echo 1;
            exit;
        } else {
            echo 0;
            exit;
        }
    }
    
    public function addmoreweek($start = 0)
    {
        $this->data['page_form_id']   = 24;
        $this->data['page_module_id'] = 7;
        $this->data['breadcrumb']     = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';
        
        
        $custidd                         = base64_decode($this->uri->segment(4));
        $this->data['customer_list_rec'] = $this->common_model->getRows('messagecenterposttable', 'MessageID,Message', '');
        $addmoreweek                     = "SELECT  max(week_id) as weekid  FROM `diets_plan_mapping` WHERE `customer_id` = '" . $custidd . "'";
        $addmoreweeks                    = $this->common_model->solveCustomQuery($addmoreweek);
        $this->data['addmoreweek']       = $addmoreweeks[0]->weekid;
        
        //$this->data['week'] = $this->common_model->getRows('week','id,number_of_week',array('status'=>'1',"id  NOT BETWEEN  1  AND" //=>$addmoreweeks[0]->weekid));
        
        
        $addmoreweek1       = "SELECT `id`, `number_of_week` FROM `week` WHERE `status` = '1' AND week_count NOT BETWEEN 1 AND " . $addmoreweeks[0]->weekid . "";
        $this->data['week'] = $this->common_model->solveCustomQuery($addmoreweek1);
        
        
        $this->data['customer_name_list'] = ucwords(strtolower($this->common_model->getCustomFielddata('user', 'first_name', array(
            'id' => ($custidd)
        ))));
        $this->data['recs']               = $this->common_model->getRows('dietsplan', 'id,diet_name,diet_label_id', array(
            'status' => 1
        ));
        $this->data['showcustid']         = $custidd;
        $this->data['submit']             = 'Submit';
        $this->data['cancel']             = 'Cancel';
        $this->data['Submit']             = lang('SAVE_BTN');
        $this->data['addmoreact']         = base_url('backoffice/diets/save_more_week');
        $this->load->view('backoffice/diets/add_more_week_view', $this->data, FALSE);
        
    }
    public function save_more_week()
    {
        //echo '<pre>'; print_r($this->input->post());die;
        $custid      = $this->input->post(custid);
        $lastweekid  = "SELECT  week_id as lastweekid  FROM `diets_plan_mapping` WHERE `customer_id` = '" . $custid . "' order by id desc limit 0,1 ";
        $lastweekids = $this->common_model->solveCustomQuery($lastweekid);
        
        $get_diet_name = $this->input->post('get_diet_name');
        $no_more_week  = count($this->input->post('addmorecheckbox'));
        if (!empty($lastweekids)) {
            $week = $lastweekids[0]->lastweekid;
        }
        $num_days = 7;
        for ($y = 1; $y <= $no_more_week; $y++) {
            for ($x = 1; $x <= $num_days; $x++) {
                foreach ($get_diet_name as $k => $val3) {
                    $this->data = array(
                        'week_id' => $week + $y,
                        'day_id' => $x,
                        'mapping_id' => $val3,
                        'customer_id' => $this->input->post('custid'),
                        'created_date' => date('Y-m-d:H:i:s'),
                        'created_by' => $this->session->userdata('admin')->role_type,
                        'message_id' => $this->input->post('customer_message_id')
                    );
                    $this->common_model->save('diets_plan_mapping', $this->data);
                }
                
            }
        }
        $this->msg = array(
            'msg' => lang('RECORD_SAVED'),
            'msg_type' => 'success'
        );
        $this->session->set_flashdata($this->msg);
        redirect('backoffice/diets/addmoreweek/' . base64_encode($custid));
    }
    public function show_hide_hunger_carb($custid)
    {
        
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Show/hide Hunger/Net Carb </li></ol>';
        
        $maxweek      = "SELECT max(weeks) as weekno 
                            FROM `customer_diets_plan`
				            where customer_id=" . base64_decode($custid) . " group by customer_id limit 0,1";
				            
        $maxweekend   = $this->common_model->solveCustomQuery($maxweek);
        $max_week_end = '';
        if (!empty($maxweekend)) 
        {
            $max_week_end = $maxweekend[0]->weekno;
        }
        
        $maxweek2      = 'select count(week_id) as wk 
                                from diets_plan_mapping 
                                where customer_id=' . base64_decode($custid) . '  group by week_id';
                                
        $maxweekend2   = $this->common_model->solveCustomQuery($maxweek2);
        $max_week_end2 = $maxweekend2[0]->wk;
        
        
        //Week disabled
        
        $cweekid = $this->common_model->customer_week_info($custid);
        if ($cweekid > 1) 
        {
            for ($i = 1; $i <= $cweekid-1; $i++) 
            {
                $assignweek[] = $i;
            }
        } else 
        {
            $assignweek[] = 1;
        }
        //echo '<pre>'; print_r($assignweek); exit;
        
        $finalweek = implode(',', $assignweek);
        
        
        //$query ='select week_id from diets_plan_mapping where customer_id='.$customer_id.'  group by week_id';
        if (!empty($max_week_end) && ($maxweekend2)) 
        {
            $query = 'select distinct (week_id) as week_id 
                                from diets_plan_mapping  
                                where week_id BETWEEN ' . $max_week_end . ' 
                                and ' . $max_week_end2 . ' 
                                and week_id not in(' . $finalweek . ') order by week_id';
        } 
        else 
        {
            $query = 'select distinct (week_id) as week_id 
                            from diets_plan_mapping  
                            where customer_id=' . base64_decode($custid) . ' 
                            and week_id NOT IN (' . $finalweek . ') order by week_id';
        }
        
        //echo $query;die;
        //echo $finalweek;die;
        
        $this->data['countweekid'] = $this->common_model->solveCustomQuery($query);
        // echo '<pre>'; print_r($this->data['countweekid']); exit;
        $this->data['customeridd'] = base64_decode($custid);
        
        
        $ans = $this->common_model->customer_diets_info(base64_decode($custid));
                            //echo 'realweek is ' . $ans['realWeek'] . '<br>';
                            //echo '$ans is <pre>'; print_r($ans);
        
        $this->data['customer_weekid'] = $ans[0]->week_id;
        $this->data['customer_dayid']  = $ans[0]->day_id;
        
       // $customer_diets_info = $this->common_model->customer_diets_info(base64_decode($custid));
        // echo '<pre>'; print_r($customer_diets_info); exit;
       // $this->data['customer_weekid'] = $customer_diets_info[0]->week_id;
      //  $this->data['customer_dayid']  = $customer_diets_info[0]->day_id;
        // echo '<pre>'; print_r($this->data['customer_weekid']. " ".$this->data['customer_dayid']); exit;
        
        
        $this->data['act'] = base_url('backoffice/diets/save_show_hide_hunger_carb');
        
        $this->data['show_hide_data'] = $this->common_model->solveCustomQuery("select input_type 
                                                                                from diets_plan_mapping 
                                                                                join dietsplan on dietsplan.id = diets_plan_mapping.mapping_id 
                                                                                where diets_plan_mapping.status =1 
                                                                                and customer_id=" . base64_decode($custid) . " group by input_type");
        
        $show_hide_data         = $this->common_model->getRows('diets_plan_mapping', 'diet_net_carb_val, diet_hunger_val, diet_blood_pressure, diet_blood_sugar_level, week_id', array('customer_id' => base64_decode($custid)));
        //echo '<pre>'; print_R($show_hide_data);die;
        $diet_net_carb_val = array();
        $diet_hunger_val = array();
        $diet_blood_pressure = array();
        $diet_blood_sugar_level = array();
        
        foreach ($show_hide_data as $k => $val) 
        {
            //	echo '<pre>'; print_R($val->diet_net_carb_val);die; 
            if ($val->diet_net_carb_val == 0) 
            {
                $this->data['diet_net_carb_val'][$val->week_id] = $val->diet_net_carb_val;
            }
            
            if ($val->diet_hunger_val == 0) 
            {
                $this->data['diet_hunger_val'][$val->week_id] = $val->diet_hunger_val;
            }
            
            if ($val->diet_blood_pressure == 0) 
            {
                $this->data['diet_blood_pressure'][$val->week_id] = $val->diet_blood_pressure;
            }
            
            if ($val->diet_blood_sugar_level == 0) 
            {
                $this->data['diet_blood_sugar_level'][$val->week_id] = $val->diet_blood_sugar_level;
            }
        }
        
        //echo '<pre>'; print_R($this->data);die;
        $this->load->view('backoffice/diets/show_hide_hunger_carb', $this->data);
    }
    
    public function save_show_hide_hunger_carb_bkp()
    {
        $custid = $this->input->post('customerid');
        if ($this->validate_show_hide()) {
            $DATA = $this->input->post();
            
            $fweekid                  = $this->input->post('week_id');
            $totalweekid              = implode(',', $fweekid);
            $netcarb_show_hide        = $this->input->post('netcarb_show_hide');
            $hunger_show_hide         = $this->input->post('hunger_show_hide');
            $blood_pressure_show_hide = $this->input->post('blood_pressure_show_hide');
            $blood_sugar_show_hide    = $this->input->post('blood_sugar_show_hide');
            
            $netCarbdietsplanData = $this->common_model->getRows('dietsplan', 'id', array(
                'input_type' => 1,
                'status' => 1
            ));
            
            $netHungerdietsplanData   = $this->common_model->getRows('dietsplan', 'id', array(
                'input_type' => 2,
                'status' => 1
            ));
            $netBloodpressureplanData = $this->common_model->getRows('dietsplan', 'id', array(
                'input_type' => 3,
                'status' => 1
            ));
            $netBooldsugarplanData    = $this->common_model->getRows('dietsplan', 'id', array(
                'input_type' => 4,
                'status' => 1
            ));
            
            
            if ($netcarb_show_hide == 0) {
                foreach ($fweekid as $weekid) {
                    //foreach($netCarbdietsplanData as $net_id)
                    //	{
                    $updateData = $this->common_model->update("diets_plan_mapping", array(
                        "diet_net_carb_val" => 0
                    ), array(
                        "customer_id" => $custid,
                        "week_id" => $weekid
                    ));
                    /*echo $this->db->last_query();*/
                    //}
                    
                }
                
            } else {
                
                foreach ($fweekid as $weekid) {
                    //foreach($netCarbdietsplanData as $net_id)
                    //{
                    $updateData = $this->common_model->update("diets_plan_mapping", array(
                        "diet_net_carb_val" => 1
                    ), array(
                        "customer_id" => $custid,
                        "week_id" => $weekid
                    ));
                    
                    //}
                    
                    
                }
            }
            // exit();
            // echo $this->db->last_query(); die();
            if ($hunger_show_hide == 0) {
                
                // $updateData = $this->common_model->solveCustomQuery("UPDATE diets_plan_mapping SET status = 0 WHERE customer_id =".$custid." AND week_id IN(".$totalweekid.") AND mapping_id IN(".$all_dietsplan_id_str1.")");
                foreach ($fweekid as $weekid) {
                    // foreach($netHungerdietsplanData as $hunger_id)
                    // {
                    $updateData = $this->common_model->update("diets_plan_mapping", array(
                        "diet_hunger_val" => 0
                    ), array(
                        "customer_id" => $custid,
                        "week_id" => $weekid
                    ));
                    
                    //}
                    
                }
            } else {
                
                foreach ($fweekid as $weekid) {
                    // foreach($netHungerdietsplanData as $hunger_id)
                    // {
                    $updateData = $this->common_model->update("diets_plan_mapping", array(
                        "diet_hunger_val" => 1
                    ), array(
                        "customer_id" => $custid,
                        "week_id" => $weekid
                    ));
                    //}
                    
                }
                
            }
            
            if ($blood_pressure_show_hide == 0) {
                
                foreach ($fweekid as $weekid) {
                    // foreach($netBloodpressureplanData as $bloodp_id)
                    // {
                    $updateData = $this->common_model->update("diets_plan_mapping", array(
                        "diet_blood_pressure" => 0
                    ), array(
                        "customer_id" => $custid,
                        "week_id" => $weekid
                    ));
                    //	echo $this->db->last_query();
                    //	}
                    
                }
            } else {
                
                foreach ($fweekid as $weekid) {
                    /*foreach($netBloodpressureplanData as $bloodp_id)
                    {*/
                    $updateData = $this->common_model->update("diets_plan_mapping", array(
                        "diet_blood_pressure" => 1
                    ), array(
                        "customer_id" => $custid,
                        "week_id" => $weekid
                    ));
                    //	}
                    
                }
                
            }
            
            if ($blood_sugar_show_hide == 0) {
                
                foreach ($fweekid as $weekid) {
                    /*foreach($netBooldsugarplanData as $sugar_id)
                    {*/
                    $updateData = $this->common_model->update("diets_plan_mapping", array(
                        "diet_blood_sugar_level" => 0
                    ), array(
                        "customer_id" => $custid,
                        "week_id" => $weekid
                    ));
                    //echo $this->db->last_query();
                    //	}
                    
                }
            } else {
                
                foreach ($fweekid as $weekid) {
                    // foreach($netBooldsugarplanData as $sugar_id)
                    // {
                    $updateData = $this->common_model->update("diets_plan_mapping", array(
                        "diet_blood_sugar_level" => 1
                    ), array(
                        "customer_id" => $custid,
                        "week_id" => $weekid
                    ));
                    //	}
                    
                }
                
            }
            //exit();
            if ($updateData) {
                $this->msg = array(
                    'msg' => lang('RECORD_UPDATED'),
                    'msg_type' => 'success'
                );
                $this->session->set_flashdata($this->msg);
                //redirect('backoffice/diets/customer_diets_list/');
                redirect('backoffice/diets/show_hide_hunger_carb/' . base64_encode($custid));
                
            }
            
            
        } else {
            //echo "ddddddd";die;
            $this->msg = array(
                'msg' => 'Please Select Week id',
                'msg_type' => 'error'
            );
            $this->session->set_flashdata($this->msg);
            redirect('backoffice/diets/show_hide_hunger_carb/' . base64_encode($custid));
        }
    }
    
    public function save_show_hide_hunger_carb()
    {
        
        $custid = $this->input->post('customerid');
        if ($this->validate_show_hide()) {
            $DATA                     = $this->input->post();
            $fweekid                  = $this->input->post('week_id');
            $totalweekid              = implode(',', $fweekid);
            $netcarb_show_hide        = $this->input->post('netcarb_show_hide');
            $hunger_show_hide         = $this->input->post('hunger_show_hide');
            $blood_pressure_show_hide = $this->input->post('blood_pressure_show_hide');
            $blood_sugar_show_hide    = $this->input->post('blood_sugar_show_hide');
            
            $netCarbdietsplanData = $this->common_model->getRows('dietsplan', 'id', array(
                'input_type' => 1,
                'status' => 1
            ));
            
            $netHungerdietsplanData   = $this->common_model->getRows('dietsplan', 'id', array(
                'input_type' => 2,
                'status' => 1
            ));
            $netBloodpressureplanData = $this->common_model->getRows('dietsplan', 'id', array(
                'input_type' => 3,
                'status' => 1
            ));
            $netBooldsugarplanData    = $this->common_model->getRows('dietsplan', 'id', array(
                'input_type' => 4,
                'status' => 1
            ));
            $updateData = array();
            if ($netcarb_show_hide != "") 
            {
                if ($netcarb_show_hide == 0) 
                {
                    foreach ($fweekid as $weekid) 
                    {
                        $updateData = $this->common_model->update("diets_plan_mapping", array("diet_net_carb_val" => 0), array("customer_id" => $custid, "week_id" => $weekid));
                    }
                    
                } 
                else 
                {
                    foreach ($fweekid as $weekid) 
                    {
                        $updateData = $this->common_model->update("diets_plan_mapping", array("diet_net_carb_val" => 1), array("customer_id" => $custid, "week_id" => $weekid));
                    }
                }
            }
            
            if ($hunger_show_hide != "") 
            {
                if ($hunger_show_hide == 0)
                {    
                    foreach ($fweekid as $weekid) 
                    {
                        $updateData = $this->common_model->update("diets_plan_mapping", array("diet_hunger_val" => 0), array("customer_id" => $custid, "week_id" => $weekid));
                    }
                } 
                else
                {
                    foreach ($fweekid as $weekid) 
                    {
                        $updateData = $this->common_model->update("diets_plan_mapping", array("diet_hunger_val" => 1), array("customer_id" => $custid, "week_id" => $weekid));
                    }
                }
            }
            
            if ($blood_pressure_show_hide != "") 
            {
                if ($blood_pressure_show_hide == 0) 
                {
                    foreach ($fweekid as $weekid) 
                    {
                        $updateData = $this->common_model->update("diets_plan_mapping", array("diet_blood_pressure" => 0), array("customer_id" => $custid, "week_id" => $weekid));
                    }
                } 
                else 
                {
                    foreach ($fweekid as $weekid) 
                    {
                        $updateData = $this->common_model->update("diets_plan_mapping", array("diet_blood_pressure" => 1), array("customer_id" => $custid, "week_id" => $weekid));
                    }
                }
            }
            
            if ($blood_sugar_show_hide != "") 
            {
                if ($blood_sugar_show_hide == 0) 
                {
                    foreach ($fweekid as $weekid) 
                    {
                        $updateData = $this->common_model->update("diets_plan_mapping", array("diet_blood_sugar_level" => 0), array("customer_id" => $custid, "week_id" => $weekid));
                    }
                } 
                else
                {
                    foreach ($fweekid as $weekid)
                    {
                        $updateData = $this->common_model->update("diets_plan_mapping", array("diet_blood_sugar_level" => 1), array("customer_id" => $custid, "week_id" => $weekid));
                    }
                }
            }
            
            if (!empty($updateData)) 
            {
                $this->msg = array('msg' => lang('RECORD_UPDATED'), 'msg_type' => 'success');
                $this->session->set_flashdata($this->msg);
                
                redirect('backoffice/diets/show_hide_hunger_carb/' . base64_encode($custid));
                
            } 
            else 
            {
                $this->msg = array('msg' => 'Please Select Levels', 'msg_type' => 'error');
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/diets/show_hide_hunger_carb/' . base64_encode($custid));
            }
            
        } 
        else 
        {
            $this->msg = array('msg' => 'Please Select Week id', 'msg_type' => 'error');
            $this->session->set_flashdata($this->msg);
            redirect('backoffice/diets/show_hide_hunger_carb/' . base64_encode($custid));
        }
    }
    
    public function customer_week_days_list()
    {
        
        $this->data['breadcrumb'] = '<ol class="breadcrumb"><li><a href="' . base_url('backoffice') . '"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';
        
        $customer_id = base64_decode($this->uri->segment(4));
        
        $maxweek      = "SELECT max(weeks) as weekno FROM `customer_diets_plan`
				where customer_id=" . $customer_id . " group by customer_id limit 0,1";
        $maxweekend   = $this->common_model->solveCustomQuery($maxweek);
        $max_week_end = '';
        if (!empty($maxweekend)) {
            $max_week_end = $maxweekend[0]->weekno;
        }
        
        
        $maxweek2      = 'select count(week_id) as wk from diets_plan_mapping where customer_id=' . $customer_id . '  group by week_id';
        $maxweekend2   = $this->common_model->solveCustomQuery($maxweek2);
        $max_week_end2 = $maxweekend2[0]->wk;
        //$query ='select week_id from diets_plan_mapping where customer_id='.$customer_id.'  group by week_id';
        if (!empty($max_week_end) && ($maxweekend2)) {
            $query = 'select distinct (week_id) as week_id from diets_plan_mapping  where week_id BETWEEN ' . $max_week_end . ' and ' . $max_week_end2 . ' order by week_id';
        } else {
            $query = 'select distinct (week_id) as week_id from diets_plan_mapping  where customer_id=' . $customer_id . ' order by week_id';
            
        }
        
        $this->data['messagelistDATA'] = $this->common_model->getRows('messagecenterposttable', 'Message,custommsgweekid as week_id,MessageID,customerid', array(
            'customerid' => $customer_id
        ));
        //echo '<pre>';
      //  print_r($this->data['messagelistDATA']);exit;
        //echo '<pre>'; print_r(base64_decode($customer_id));die;
        
        $ans = $this->common_model->customer_diets_info($customer_id);
                            //echo 'realweek is ' . $ans['realWeek'] . '<br>';
                            //echo '$ans is <pre>'; print_r($ans);
        
        $this->data['customer_weekid'] = $ans[0]->week_id;
        $this->data['customer_dayid']  = $ans[0]->day_id;
        
        
        $this->data['countweekid']     = $this->common_model->solveCustomQuery($query);
        $this->data['customeridd']     = $customer_id;
        $this->data['custommsgweekid'] = isset($this->data[0]->week_id) ? $this->data[0]->week_id : '';
        $this->data['MessageIDD']      = isset($this->data[0]->MessageID) ? $this->data[0]->MessageID : '';
        $this->data['act']             = base_url('backoffice/diets/save_customer_week_days_list');
        //echo 'about to view form'; die;
        $this->load->view('backoffice/diets/customer_week_days_list', $this->data);
    }
    public function validate_message()
    {
        
        $this->form_validation->set_rules('txtmessage', 'Write text message', 'trim|required|strip_tags');
        return $this->form_validation->run();
        
    }
    
    public function validate_show_hide()
    {
        
        $this->form_validation->set_rules('week_id[]', 'Week Id', 'required');
        
        return $this->form_validation->run();
        
    }
    
    public function update_week_message()
    {
        $this->data = array(
            'Message' => $this->input->post('updatemsgtxt')
        );
        $updatedata = $this->common_model->update('messagecenterposttable', $this->data, array(
            'MessageID' => $this->input->post('MessageIDD')
        ));
        
        if ($updatedata) {
            echo 1;
            exit;
            
        }
        
        //echo '<pre>'; print_r($this->input->post());die;
    }
    public function save_customer_week_days_list()
    {
        $custid                    = $this->input->post('customerid');
        $this->data['customeridd'] = $custid;
        if ($this->validate_message()) {
            
            $fweekid       = $this->input->post('week_id');
            $totalweekid   = implode(',', $fweekid);
            $txtmessage    = $this->input->post('txtmessage');
            $findmessageid = $this->common_model->getRows('messagecenterposttable', 'MessageID', array(
                'Message' => $txtmessage,
                'customerid'=>$custid,
                'custommsgweekid'=> $totalweekid
            ));
            
            if (!empty($findmessageid)) {
                $getMessageID = $findmessageid[0]->MessageID;
                
            } else {
                $post_data = array(
                    'Message' => $txtmessage,
                    'status' => 1,
                    'custommsgweekid' => $totalweekid,
                    'customerid' => $custid,
                    'created_date' => date('Y-m-d:H:i:s'),
                    'CreatedBy' => $this->session->userdata('admin')->role_type
                );
                $this->db->insert('messagecenterposttable', $post_data);
                
                $insert_id    = $this->db->insert_id();
                $getMessageID = $insert_id;
            }
            if (!empty($getMessageID)) {
                $querry = "Update diets_plan_mapping set admin_msg_id='" . $getMessageID . "'
							where week_id in (" . $totalweekid . ") and customer_id in ('" . $custid . "')";

                $succ   = $this->db->query($querry);
               
                
                if (!empty($succ)) {
                    $this->msg = array(
                        'msg' => lang('RECORD_UPDATED'),
                        'msg_type' => 'success'
                    );
                    $this->session->set_flashdata($this->msg);
                    redirect('backoffice/diets/customer_week_days_list/' . base64_encode($custid));
                }
            }
            
        } else {
            $this->msg = array(
                'msg' => lang('MESSAGENOTBLANK'),
                'msg_type' => 'error'
            );
            $this->session->set_flashdata($this->msg);
            redirect('backoffice/diets/customer_week_days_list/' . base64_encode($custid));
        }
    }
    
}
?>
