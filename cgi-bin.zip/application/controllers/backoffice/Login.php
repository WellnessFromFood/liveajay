<?php 

if(!defined('BASEPATH')) exit('No direct script access allowed');



class Login extends CI_Controller {

    public $data = array();

    public function __construct()

	{

        parent::__construct();

		//echo '<pre>';print_r($this->session->all_userdata());die();

		$this->session->set_userdata('IsAdminLoggedIn', FALSE);

	    $this->load->model("backoffice/login_model","login");

        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');

        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');

        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);

        $this->output->set_header('Pragma: no-cache');

    }



    public function index()

	{

		if(isset($this->session->userdata('admin')->id))

		{

			$this->session->set_userdata('IsAdminLoggedIn',TRUE);

			redirect("backoffice/dashboard");

		}

		$this->data = array('act' => base_url('backoffice/login/verifyLogin'));

		$this->load->view('backoffice/login_view', $this->data);

    }

     

    public function verifyLogin(){

            

        if($this->_validData()){

			redirect("backoffice/dashboard");

		}else{

            return $this->index();

        }

    }

	

	private function _validData(){

        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

        $this->form_validation->set_rules('emailid', 'Email-Id', 'required');

        $this->form_validation->set_rules('password', 'Password', 'required|callback_checkLogin');

        return $this->form_validation->run();

    }	

	public function checkLogin(){

        $this->data = array(

            'emailid' => $this->input->post('emailid'),

            'password' =>$this->input->post('password'),

        );

        $this->data['admin'] = $this->login->getVerifiedLogin($this->data);

        

		if(!empty($this->data['admin'])){			

			$admin_id = $this->login->get_user_id_from_username($this->input->post('emailid'));			

			$admin    = $this->login->get_user($admin_id);

			$this->session->set_userdata('admin', $admin);

            $this->session->set_userdata('IsAdminLoggedIn', TRUE);

			return TRUE;

        }

		$this->form_validation->set_message('checkLogin', lang('VALIDATE_LOGIN'));

		return FALSE;

    }

	

	public function logout()

	{

        if($this->session->userdata('admin'))

		{

            foreach($this->session->userdata as $key=>$val)

			{

                $this->session->unset_userdata($key);

            }

			$this->session->unset_userdata('IsAdminLoggedIn');

        }

        redirect('backoffice/login');

    }

    public function generatePassword(){
        $data = array();
        $data['act'] = base_url('backoffice/login/submit_Generate');
        $this->load->view('backoffice/generatePass',$data);
    }

    public function submit_Generate(){

        $data = trim($this->input->post('data'));
        $inc = trim($this->input->post('inc'));
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('con_password', 'Confirm Password', 'required');

        if($this->form_validation->run() != FALSE){
           
            $hash = base64_decode($inc);
            $email = base64_decode($data);
            $password = $this->input->post('password');
            $con_password = $this->input->post('con_password');
            if($password == $con_password){
                $hashData = $this->common_model->getRow('user','hash',array('emailid'=>$email));
                if($hashData->hash == trim($hash))
                {
                    
                    $respassword=$this->common_model->update('user',array('password'=>$this->hash_password(trim($password))),array('emailid'=>trim($email),'hash'=>trim($hash)));
                    $this->msg = array('msg'=>"Your Password Changeed! Please Login", 'msg_type'=>'success');
                    $this->session->set_flashdata($this->msg);
                    redirect('backoffice');      
                }else{
                    $this->msg = array('msg'=>"Please use latest link", 'msg_type'=>'error');
                    $this->session->set_flashdata($this->msg);
                    redirect('backoffice/generate-password?data='.$data.'&inc='.$inc);
                }
            }else{
                $this->msg = array('msg'=>"Password Not Matched", 'msg_type'=>'error');
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/generate-password?data='.$data.'&inc='.$inc);
            }
        }else{
            $this->msg = array('msg'=>"All Fields are required", 'msg_type'=>'error');
            $this->session->set_flashdata($this->msg);
            redirect('backoffice/generate-password?data='.$data.'&inc='.$inc);
        }
    }

    public function forgetPassword(){
        $data = array();
        $data['act'] = base_url('backoffice/login/submit_forget');
        $this->load->view('backoffice/forgetPassword',$data);
    }
    public function submit_forget(){
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        $this->form_validation->set_rules('email', 'Email', 'required');

        if($this->form_validation->run() != FALSE){
           
            $email = $this->input->post('email');
            $user = $this->common_model->getRow('user','id,first_name,last_name',array('emailid'=>$email,'role_type != '=>3));
            if(!empty($user)){
                $hashCode = md5(rand(0,1000));
                $mailEmail = $this->input->post('email');
                $name = ucwords($user->first_name);
                $this->common_model->update('user',array('hash'=>trim($hashCode)),array('emailid'=>$mailEmail));
                $mail = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>21,'status'=>1));
                $data['hash']=$hashCode;
                $data['email'] =$mailEmail;
                $data['dynamic_content'] = $mail->email_description;
                $data['full_name']=$name;
                $massege = $this->load->view('frontend/email/backoffice_user_mail',$data,true);
                $subject = $mail->subject_txt;

                $email_dat = array(
                'to'=>$mailEmail,
                'subject'=>$subject,
                'msg'=>$massege);
                $res = $this->common_model->Send_GetStarted_Mail($email_dat);
                //echo $massege;
                //Send Email Mail*/

                $this->msg = array('msg'=>"Please Check You Email", 'msg_type'=>'success');
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/login/forgetPassword');
            }else{
                $this->msg = array('msg'=>"Please Enter Valid Email id", 'msg_type'=>'error');
                $this->session->set_flashdata($this->msg);
                redirect('backoffice/login/forgetPassword');
            }
        }else{
            $this->msg = array('msg'=>"All Fields are required", 'msg_type'=>'error');
            $this->session->set_flashdata($this->msg);
            redirect('backoffice/login/forgetPassword');
        }
    }

    private function hash_password($password)
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }

}

?>

