<?php
class Testimonials extends CI_Controller {

	public $data = array();
    public $msg = array();
	
 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 10;
		$this->data['page_form_id']=37;
		$this->data['page_module_id']=15;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }
	
	public function show($start=0)
	{
		$this->data['page_form_id']=37;
		$this->data['page_module_id']=15;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Testimonials</li></ol>';
		$cond='';
		$url_cond='';
		$testimonial='';
		$total_get_sql = "SELECT count(distinct t.testimonial_id) as total FROM testimonials t "; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		$testimonial_sql="SELECT * FROM testimonials t  order by testimonial_id  LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($testimonial_sql);
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);		
			
		$this->data['act_testimonial_search_submit']=base_url('backoffice/testimonials/show');		
		$this->load->view('backoffice/testimonials/testimonials_view', $this->data);
	}	
	public function add()
	{
		$this->data['page'] = 1022;
		$this->data['page_form_id']=37;
		$this->data['page_module_id']=15;
		$campus_ids=array();
		$course_ids=array();
		$faculty_ids=array();
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Add Testimonials</li></ol>';
		$this->data['act'] = site_url('backoffice/testimonials/save');
        $this->data['submit'] = lang('SAVE_BTN');
        $this->load->view('backoffice/testimonials/add_testimonials_view', $this->data, FALSE);
	}
	
	public function save(){
		if($this->validate_testimonial()){
		    $time = time();
			$this->data = array(
				
				'testimonial_name' => $this->input->post('testimonial_name'),
				'testimonial_description' => $this->input->post('testimonial_description'),				
				'display_order' => $this->input->post('display_order'),
				'testimonial_status' => $this->input->post('testimonial_status'),
				'created_date' => date('Y-d-m'),
				'created_by' => $this->data['live_user_id']);
			if($_FILES['testimonial_image']['name']){
				$this->updata = $this->functions->do_upload('uploads/testimonial/', 'testimonial_image');
					if(@$this->updata['res'] === TRUE){
						if($this->input->post('OldBannerImage')){
							unlink('uploads/testimonial/'.$this->input->post('OldBannerImage'));
						}
						$this->data['testimonial_image'] = $this->updata['upload_data']['file_name'];
					}else{
						$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
						$this->session->set_userdata($this->msg);
						return $this->edit($id);
					}
			}	
			$testimonial_id = $this->common_model->saveAndGetLastId('testimonials',$this->data);
			if($testimonial_id!=''){				
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/testimonials/show');
			}else{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			return $this->add();
		}
	}
	
	public function edit($testimonial_id=0){
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Edit Testimonials</li></ol>';
		$testimonial_id=base64_decode($testimonial_id);
		
		$testimonial_sql="SELECT * FROM testimonials WHERE testimonial_id=".$testimonial_id;
		$this->data['rec'] = $this->common_model->solveCustomQuery($testimonial_sql);		
		$this->data['act'] = site_url('backoffice/testimonials/update/'.base64_encode($testimonial_id));
		$this->data['submit'] = lang('UPDATE_BTN');
		$this->load->view('backoffice/testimonials/add_testimonials_view', $this->data, FALSE);
	}
	
	public function delete_image(){
		$testimonial_id = $this->input->post('testimonial_id');		
		if((bool)$this->common_model->update('testimonials',array('testimonial_image'=>''),array('testimonial_id'=>$testimonial_id)) === true){
			if(file_exists('uploads/testimonial/'.$this->input->post('image_path'))){
                unlink('uploads/testimonial/'.$this->input->post('image_path'));
            }
			echo 'true';
		}else{
			echo 'false';
		}
	}
	
	public function update($testimonial_id=0){
	    $testimonial_id=base64_decode($testimonial_id);
		if($this->validate_testimonial($testimonial_id)){
			$time = time();			
			$this->data = array(
				'testimonial_type_id' => $this->input->post('testimonial_type_id'),
				'testimonial_name' => $this->input->post('testimonial_name'),
				'testimonial_designation' => $this->input->post('testimonial_designation'),
				'text_type' => $this->input->post('text_type'),
				'short_description' => $this->input->post('short_description'),
				'testimonial_description' => $this->input->post('testimonial_description'),
				'video_url' => $this->input->post('video_url'),
				'rewrite_url' => $this->input->post('rewrite_url'),
				'display_order' => $this->input->post('display_order'),
				'testimonial_status' => $this->input->post('testimonial_status'),
				'created_date' => $time,
				'created_by' => $this->data['live_user_id']);
			if($_FILES['testimonial_image']['name']){
				$this->updata = $this->functions->do_upload('uploads/testimonial/','testimonial_image');
				if(@$this->updata['res'] === TRUE){
					if($this->input->post('OldBannerImage')){
						unlink('uploads/testimonial/'.$this->input->post('OldBannerImage'));
					}
					$this->data['testimonial_image'] = $this->updata['upload_data']['file_name'];
				}else{
					$this->msg = array('file_msg' => substr($this->updata['msg'],3,-4));
					$this->session->set_userdata($this->msg);
					return $this->edit($testimonial_id);
				}
			}	 
			if((bool)$this->common_model->update('testimonials',$this->data, array('testimonial_id'=>$testimonial_id)) === TRUE){
				}}
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/testimonials/show');
			}
		
	public function delete($testimonial_id=0){
	    $testimonial_id=base64_decode($testimonial_id);
		$testimonial_result=$this->common_model->getRow('testimonials','',array('testimonial_id'=>$testimonial_id));
		if((bool)$this->common_model->delete('testimonials',array('testimonial_id'=>$testimonial_id))==true){
			
			if($testimonial_result->testimonial_image!=''){
				unlink('uploads/testimonial/'.$testimonial_result->testimonial_image);
			}
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		 $this->session->set_flashdata($this->msg);
		redirect('backoffice/testimonials/show');
	}
	
	private function validate_testimonial($id=0)
	{
		//$this->form_validation->set_rules('testimonial_type_id', 'Testimonials Type ', 'trim|required|strip_tags');
		//$this->form_validation->set_rules('course_ids[]', 'Course ', 'trim|required|strip_tags');
		$this->form_validation->set_rules('testimonial_name', 'Testimonials Name', 'trim|required|strip_tags');
		return $this->form_validation->run();
    }
	
	public function ch_status($id=0,$Status=0){
		if($id){
			$time = time();
			$this->data = array('status'=>$Status,'modified_date'=>$time);	
			if($this->common_model->update('testimonials',$this->data,array('id'=>$id))){
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}else{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}else{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode($this->data['msg_type']);
	}

	public function checkImage()
	{
		if(empty($_FILES['BannerImage']['name'])){
			$this->form_validation->set_message('checkImage', 'Banner image is required');
			return FALSE;
		}
		return TRUE;
	}
	public function newsletter($start=0)
	{
		$this->data['page_form_id']=56;
		$this->data['page_module_id']=4;

		($start)?($limit_from=$start):($limit_from=0); $limit=10;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Newsletter</li></ol>';
		$cond='';
		$url_cond='';
		$testimonial='';
		$total_get_sql = "SELECT count(distinct t.id) as total FROM subscriber t "; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		$testimonial_sql="SELECT * FROM subscriber t  order by id  LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($testimonial_sql);
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);		
			
		//echo '<pre>'; print_r($this->data['recs']);die;
		$this->load->view('backoffice/testimonials/newsletter_view', $this->data);
	}	
}
?>