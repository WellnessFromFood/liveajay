<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Week{
	    public $week_no;
	    public $users;
	    public $userCount;
	    public $week_Start;
	    public $week_End;
	    
	}



class Cheerleader extends CI_Controller
{	
    
    public $data = array();
    public $msg = array();
    public function __construct()
	{
        parent::__construct();
        /*
        if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
			
		}
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
		$this->load->model('backoffice/login_model');
		
		*/
    }
	public function calculate_date($get_created_date)
	{
	    //This is wrong - replace it or call a common function
				$nodays='';
				$noweek='';
				$days_info=array();

				$date1 = date('Y-m-d H:i:s');
				$date2 =  $get_created_date;
				$diff = strtotime($date1) - strtotime($date2);
				$days = ceil(($diff)/ (60*60*24));

				if($days >14){
					$noweek =  number_format($days/7,1);
					$totaldays= $days%7;
					$val = explode(".",$noweek);
					if($totaldays==0){
						$days_info['day']=7;
						$days_info['week'] = $val[0];
					}else{
						$days_info['day'] = $totaldays;
						$days_info['week'] = $val[0]+1;
					}
				//	if($totaldays==0){
					//	$days_info['day']=$val[1];
						//$days_info['week'] = $val[0];
				//	}else{
					//	$days_info['day'] = $val[1];
					//	$days_info['week'] = $val[0];
				//	}
					//$days_info['week'] = $val[0]+1;
				}else{
						$days_info['day'] ='';
						$days_info['week']= '';
				}
				//echo '<pre>'; print_r($days_info);die;
				return $days_info;


	}
	public function populateSnake()
	{
	    $theWeeks;
	    echo "inside populateSnake";
	    for ($i=1; $i<=45; $i++)
	    {
	        $newWeek = new Week();
	        $newWeek->week_no = $i;
	        
	        for ($ithDay=1; $ithDay<=7; $ithDay++)
	        {
	            //run a query for this day
	            
	            $dayInPast = $this->getDayInPastIfWeekDay($newWeek->week_no, $ithDay);
	        
	            //echo 'Week is '. $week . ' and Day is '. $day . ' which = ' . $dayInPast;
	        
	            $userSql = 'SELECT * FROM user where role_type=3 and created_date="' . $dayInPast . '" and status=1';
	            //echo '<br>' . '$userSql is '. $userSql . '<br>';
	            
	            $foundUsers = $this->common_model->solveCustomQuery($userSql);
	            $newWeek->users =  $foundUsers;
	            $newWeek->userCount = count($foundUsers);
	            if ($ithDay==1)
	            {
	                $newWeek->week_Start = $dayInPast;
	                
	            }
	            if ($ithDay==7)
	            {
	                $newWeek->week_End = $dayInPast;
	                
	            }
	        }
	        
	        
	        $theWeeks[] = $newWeek;
	        
	    }
	    
	    echo '<pre>'; print_r($theWeeks);
	    
	}
	
	
	
	public function showSnakeView()
	{
	    $start=0;
	    echo "inside showSnakeView!"; 
	    $this->data['page_form_id']=65;
		$this->data['page_module_id']=14;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Manage cheers</li></ol>';
		$cond='';
		$url_cond='';$con='';
		$conds=array();
		
		$cheerSql="SELECT * FROM cheer where status='1'  ".$cond." order by id desc ";
		
        //Run the query
		$this->data['recs'] = $this->common_model->solveCustomQuery($cheerSql);
		$records_count = count($this->data['recs']);
		
		
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['action_customer_search_submit']=base_url('backoffice/cheer/addCheer');
		$this->data['permission'] = $this->common_model->checkPermission();
	
		//echo '<pre>'; print_r($this->data['recs']);die;
	    
	    $this->load->view('backoffice/cheer/snake_cheer_view', $this->data);
	    
	}
	
	
	

	public function automationDetailAction($user_id,$course="",$history_id,$week="")
	{ 
	    //get the user information from the given id
		$user_data = $this->common_model->getRow('user','lms_id,first_name,last_name',array('id'=>$user_id));
		
		$data = array(
			'user_id'=>$user_id,
			'name'=>$user_data->first_name." ".$user_data->last_name,
			'enrolled_on'=>$course,
			'created_date'=>date('Y-m-d h:i:s'),
			'lms_id'=>$user_data->lms_id,
			'automation_history_id'=>$history_id
		);
		
		$this->common_model->save('automation_nextlession',$data);
	}
	
	
	
	public function testEmail()
	{
	    $userId = 1345;
	    
	    $user = $this->common_model->getRow('user','',array('id'=>$userId));
	    $templateId = 309;
	    $this->sendTemplatizedEmail($user, $templateId);
	    
        echo 'Now check to see if the email is sent and arrives';	    

	    
	}
	
	
	public function sendTemplatizedEmail($user, $templateId)
	{
	    //echo 'This is '; echo '<pre>'; print_r($this);
	    //$CI = & get_instance();
		//$userdata = $this->common_model->getRow('user','emailid',array('id'=>$user));
		echo '<br> TemplateId is ' . $templateId;
		$content = $this->common_model->getRow('cheer','subject, content',array('id'=>$templateId,'status'=>1));
		//echo '<pre>'; echo '$user is ' ; print_r($user); echo '<br> Content is '; echo '<pre>'; print_r($content);
		if(!empty($user) && !empty($content)){
			$email_dat = array(
				'to'=>$user->emailid,
				'subject'=>$content->subject,
				'msg'=>$content->content
			);
			
			echo '<br> About to send the email...';
			$this->common_model->Send_GetStarted_Mail($email_dat);
			
			
		}	
	    
	    
	    
	    
	}
	
	public function getDayInPastIfWeekDay($week=1, $day=1)
	{
	    //Use today's date at a given time (say 0:0:0)
	    $date1 = date('m/d/Y h:i:s a', time());
	    //echo $date1 . '<br>';
	    $date = date('m/d/Y', time());
	    $dateStamp = strtotime($date . ' 0:0:0');
	    
	    $todaysDate = date("Y-m-d H:i:s", $dateStamp);
	    
	   // echo '$dateStamp is '. $dateStamp . '<br> and it looks like ' . $todaysDate;
	    
	    $numOfWeekSecs = ($week - 1) * 7 * 24 * 60 * 60;
	    $numOfDaySecs = ($day) * 24 * 60 * 60;
	    
	    $dateInPast = $dateStamp - ($numOfWeekSecs + $numOfDaySecs);
	    
	    //echo '<br> $dateInPast is '. $dateInPast . '<br> and it looks like ' . date("Y-m-d H:i:s", $dateInPast);
	    
	    return date("Y-m-d", $dateInPast);
	   
	    
	    
	    
	}
	
	
	public function step1()
	{
	    
	    
	    
	    
	    
	    //get all of the active cheers
	    $cheersSql = "SELECT * FROM `cheer` where status=1 order by week, day";
	    $cheers = $this->common_model->solveCustomQuery($cheersSql);
	 
	    echo '<br> We have ' . count($cheers) . ' cheers to process: <br>';
	  
	    foreach ($cheers as $thisCheer)
	    {
	        $week = $thisCheer->week;
	        $day = $thisCheer->day;
	        
	        $dayInPast = $this->getDayInPastIfWeekDay($week, $day);
	        
	        //echo 'Week is '. $week . ' and Day is '. $day . ' which = ' . $dayInPast;
	        
	        $userSql = 'SELECT * FROM user where role_type=3 and created_date="' . $dayInPast . '" and status=1 and cheerleader_email=1';
	        //echo '<br>' . '$userSql is '. $userSql . '<br>';
	        $users = $this->common_model->solveCustomQuery($userSql);
	        
	        //$users = $this->common_model->getRows('user','*',array('created_date'=> $dayInPast, 'role_type'=>3 ));
	        
	       
	        
	        //echo ' and We found ' . count($users) . ' users that match <br>';
	        
	        foreach ($users as $thisUser)
	        {
	            //echo 'We need to send ' . $thisUser->first_name . ' '. $thisUser->last_name . ' the cheer with id  = ' . $thisCheer->id .'<br>';
	            //echo $thisUser->first_name . ' '. $thisUser->last_name . ' created_date = ' . $thisUser->created_date . ' Starting week = ' . $thisUser->starting_week . '<br>';
	            //echo 'CheerId is ' . $thisCheer->id .'<br>';
	            $this->sendTemplatizedEmail($thisUser, $thisCheer->id);
	            //echo 'Please check to see if emails went out <br>';
	        }
	        
	        
	        $users = '';
	        
	    }
	    
	    
	    
	    
	}
	

	public function index()
	{
		$action = 0;
		//Check to confirm the cheerleader is not currently running - id = 3 means cheerleader, status of 1 means ok to run
		$check_auto = $this->common_model->getRow('automation_logs','*',array('id'=>3));
		if($check_auto->automation_status == 1){
    		$his = array(
    			'name'=>$check_auto->name,
    			'start_runTime'=>date('Y-m-d h:i:s'),
    			'action_taken'=>0,
    			'automation_type'=>$check_auto->id);
    		
    		//update the db history table - so we know that this is running	
    		$history_id = $this->common_model->saveAndGetLastId('automation_history',$his);
    		
		    $this->common_model->update('automation_logs',array('started_on'=>date('Y-m-d'),'automation_status'=>3),array('id'=>3));
		
    		//get all of the active cheers
    	    $cheersSql = "SELECT * FROM `cheer` where status=1 order by week, day";
    	    $cheers = $this->common_model->solveCustomQuery($cheersSql);
    	 
    	    echo '<br> We have ' . count($cheers) . ' cheers to process: <br>'; 
    	  
    	    foreach ($cheers as $thisCheer)
    	    {
    	        
    	        $week = $thisCheer->week;
    	        $day = $thisCheer->day;
    	        $dayInPast = $this->getDayInPastIfWeekDay($week, $day);
    	        
    	        echo 'Week is '. $week . ' and Day is '. $day . ' which = ' . $dayInPast . '<br>';
    	        
    	        $userSql = 'SELECT * FROM user where role_type=3 and created_date="' . $dayInPast . '" and status=1 and cheerleader_email=1';
    	        //echo '<br>' . '$userSql is '. $userSql . '<br>';
    	        $users = $this->common_model->solveCustomQuery($userSql);
    	        
    	        //$users = $this->common_model->getRows('user','*',array('created_date'=> $dayInPast, 'role_type'=>3 ));
    	        
    	        echo ' and We found ' . count($users) . ' users that match <br>';
    	        
    	        foreach ($users as $thisUser)
    	        {
    	            echo 'We need to send ' . $thisUser->first_name . ' '. $thisUser->last_name . ' the cheer with id  = ' . $thisCheer->id .'<br>';
    	            //echo $thisUser->first_name . ' '. $thisUser->last_name . ' created_date = ' . $thisUser->created_date . ' Starting week = ' . $thisUser->starting_week . '<br>';
    	            //echo 'CheerId is ' . $thisCheer->id .'<br>';
    	            $this->sendTemplatizedEmail($thisUser, $thisCheer->id);
    	            $this->automationDetailAction($thisUser->id, 'Week ' . $thisCheer->week . ' Day '. $thisCheer->day . ' Cheermail to Customer',$history_id);
					$action++;
    	           
    	            //echo 'Please check to see if emails went out <br>';
    	        }
    	        
    	    } 
    	    //.echo 'Tried to send emails about to update the db - we found ' . $action . ' emails to send';   
		    $this->common_model->update('automation_logs',array('date_time_last_run'=>date('Y-m-d h:i:s'),'action_taken'=>$action,'automation_status'=>1),array('id'=>3));  
	        $this->common_model->update('automation_history',array('end_runTime'=>date('Y-m-d h:i:s'),'action_taken'=>$action),array('run_id'=>$history_id));
	}  
}

public function cheerleader_test(){
	$this->index();
}
}

