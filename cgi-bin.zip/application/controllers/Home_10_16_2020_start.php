<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {
		public function __construct()
		{
			parent::__construct();
			$this->load->library('talentlmsapi');
			$this->load->helper('common_helper');
			$this->load->helper('helper');
		}

		public function in2(){
			$this->load->view('frontend/payment');
		}
		public function index(){
			
			$data['freeintrolession'] = $this->common_model->getRows('video','video_title,thumbnail_image,thumbnail_video,re_writeurl',array('video_status'=>'1','type'=>1),'video_id','DESC',0,3);
			$this->load->view('frontend/home',$data);
		}

		public function about(){
			$this->load->view('frontend/about');
		}
		public function signup(){
			$data['subscription_name'] = $this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1'));
			$data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
			$data['state'] = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1'));

			$this->load->view('frontend/sign-up',$data);
		}
		public function register(){
			$this->load->view('frontend/register');
		}

		public function getstarted($form_id='NA'){
			if($form_id=='NA')
			{
		     $findsession_id = $this->session->userdata('find_session_id');
				$form_data=$this->common_model->solveCustomQuery("select id from createform where form_type=1 and id NOT IN(select form_id from savequestionnnairfrmval where customer_id='".$findsession_id."') order by display_order asc limit 1");

				if(!empty($form_data))
				{
					$form_id=$form_data[0]->id;
				}
			}
			else
			{
				$form_id=base64_decode($form_id);
			}
			$total_form=$this->common_model->solveCustomQuery("select count(id) as total_form from createform where form_type=1");
			$total_filled_form=$this->common_model->solveCustomQuery("select count(t.form_id) as total_filled_form from (select form_id from savequestionnnairfrmval where customer_id='".$findsession_id."' group by form_id) as t");
			$data['formid'] = $form_id;
            $data['total_form']=$total_form[0]->total_form;
			$data['total_filled_form']=$total_filled_form[0]->total_filled_form+1;
			//$this->load->view('frontend/getstarted',$data);
			$this->load->view('frontend/formStage',$data);
		}
		public function blogs(){
		    $data['blogs_name'] = $this->common_model->getRows('blog','id,title,short_description,image,created_date',array('status'=>'1','blog_type'=>1),'display_order','asc');
		    $data['recipe'] = false;
			$this->load->view('frontend/blogs',$data);
		}

		public function news(){
			$this->load->view('frontend/news');
		}

		public function blog_details(){
			$this->load->library('user_agent');
			$data['previous_url'] = $this->agent->referrer();
			$blogid =  $this->uri->segment(3);
			$data['blog_details'] = $this->common_model->getRows('blog','*',array('id'=>base64_decode($blogid)));
			// echo '<pre>'; print_r($data); die;
			if(!empty($data['blog_details']))
			{
				$this->load->view('frontend/single_blog',$data);
			}
			else
			{
				redirect('/');
			}

		}
		public function free_intro_lession(){
			$data['main_heading'] = $this->common_model->getRows('video','main_heading,description,main_description',array('video_status'=>'1','main_heading !='=>'','description !='=>''));

			
			$data['freeintrolession'] = $this->common_model->getRows('video','video_title,thumbnail_image,thumbnail_video,re_writeurl',array('video_status'=>'1','type'=>1),'display_order','ASC');
			$data['blog'] = $this->common_model->getRows('video','video_title,thumbnail_image,description,main_description,main_heading',array('video_status'=>'1','type'=>2,'main_blog !='=>1));
			$data['main_blog'] = $this->common_model->getRows('video','video_title,thumbnail_image,description,main_description,main_heading',array('video_status'=>'1','type'=>2,'main_blog'=>1));
			$data['health_tips'] = $this->common_model->getRows('video','video_title,thumbnail_image,description,re_writeurl',array('video_status'=>'1','type'=>3,'main_blog !='=>1,'health_tips !='=>1),'video_id','asc');
			$data['main_health_tips'] = $this->common_model->getRows('video','main_heading,description,thumbnail_image,re_writeurl',array('video_status'=>'1',/*'main_heading !='=>'','description !='=>'',*/'type'=>3,'health_tips'=>1));

			//echo '<pre>'; print_r($data['main_health_tips']);die;
			$find_session_email=$this->session->userdata('find_session_email');
			if($this->session->userdata('IsFrontedLoggedIn')==TRUE || isset($find_session_email)){
				$this->load->view('frontend/free-intro-lession',$data);
			}else{
				$this->load->view('frontend/invalid-access');
			}

		}
		public function subscription()
		{
		    //echo "subscription was called - Testing in progress, please try later"; die;
			$this->session->set_userdata('bmi_sess_data','');
			$this->session->unset_userdata('specialsessionid','');
			$data['medical'] = $this->common_model->getRows('medical','id,description,agree_title',array('status'=>'1'));

			$data['subscription_name'] = $this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1'));
			$data['homepageData'] = $this->common_model->getRow('homepage','home_page_name,home_page_description',array('home_page_id'=>6));
			$this->load->view('frontend/subscriptiondetail',$data);
		}	
		public function checkout()
		{			
			$data['blood_pressure_high']=$this->session->userdata('blood_pressure_high');
			$data['blood_pressure_low']=$this->session->userdata('blood_pressure_low');
			$data['blood_pressure_mng']=$this->session->userdata('blood_pressure_mng');
			$data['blood_pressure_eve']=$this->session->userdata('blood_pressure_eve');
			$data['blood_sugar_awake']=$this->session->userdata('blood_sugar_awake');
			$data['blood_sugar_breakfast']=$this->session->userdata('blood_sugar_breakfast');
			$data['blood_sugar_lunch']=$this->session->userdata('blood_sugar_lunch');
			$data['blood_sugar_dinner']=$this->session->userdata('blood_sugar_dinner');


			if(isset($_GET['subid']) ==1 && isset($_GET['upgrade']) ==2)
			{
				$subdetailplan = $this->common_model->solveCustomQuery("select t2.name,(t2.price-t1.price) as total_price from subscriptionplan t1,subscriptionplan t2 where t2.id=".$_GET['upgrade']." and t1.id=".$_GET['subid']);
				$data['totalamount'] =$subdetailplan[0]->total_price;
				$data['upgradeid'] =$_GET['upgrade'];
				$data['subid'] =$_GET['subid'];

				$data['subscription_name'] = $this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1','id'=>$_GET['upgrade']));

			}
			else
			{
				$data['subid'] =$_GET['subid'];
				$data['subscription_name'] = $this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1','id'=>$_GET['subid']));
				$data['totalamount'] =$data['subscription_name'][0]->price;
			}

			$this->load->view('frontend/checkout',$data);

		}
		
		
		
		
		
		
		public function paynow(){
		    //This is the main function that is called when the user clicks on the Buy now button and then selects on option on the Medical Qualification Form.
		    //  It is called again when a user clicks the submit button with their credit card.  In the later case, the post has data.  This needs to be improved.
		    
			                                //echo '<pre>'; print_r($this->session->userdata); echo '<br>';
	
			$getrecord = $this->session->userdata('specialsessionid');
			if(!empty($getrecord))
			{
				$this->data['store_temp_data'] = $this->common_model->getRows('store_temp_data','*',
						array('session_id'=>$getrecord));
				
				$special = 1;
                    				//echo 'Sorry - testing in progress <br>';
                    				//echo 'User is a special';	
                    				//echo '<pre>'; print_r($this->data['store_temp_data']);
                    			
			    $data['subsc'] = array();
			}
			else
			{
			    	$special = 0;
			    //echo 'User is not a special <br>';
			}
			
			$finduserData = $this->session->userdata('customers');
                    			//echo 'The user data is <br>';
                    			//echo '<pre>'; print_r($finduserData);
                    			//die;

			
			                    //echo '<br> <pre>'; print_r($_POST); 
			if(!empty($_POST))
			{
                			    //echo 'The post is not empty <br>';
                			    //echo 'Lets see what in the session <br>';
                			    //echo '<pre>'; print_r($_SESSION);
			    //This is now being called from the Credit card window - payment_card_detail
			                            
			                            //echo "Post is not empty testing in progress  - please try again later";
			    
			    //Get data from the input form filled out by the user
			    //CardNo - which will not be stored
			    $cardNo = $this->input->post('card_no');
			    
			    //last4 = last 4 digits on card
			    $cardBits = explode(" ", $cardNo);
			    $numOfBits = count($cardBits);
			    $last4 = $cardBits[$numOfBits-1];
			    $emailid = $_POST['emailid'];
			    $phoneNo = $_POST['contact_no'];
			    $currentDate = date('Y-m-d H:i:s');
			    $thisHash = md5(rand(0,1000));
			    //Card expiration date month and year
			    $expiration = $this->input->post('expiry');
				$lastname = $this->input->post('last_name');
				$firstName = $this->input->post('full_name');
				
				
				ini_set('max_execution_time', 18000);
				
				                    //echo 'Check the session data if needed <br>';
				if(!isset($this->session->userdata('customers')->emailid) && !isset($_SESSION['find_session_email']))
				{

                    $week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
					$time = time();

					$user_data = array(
						'first_name' => $firstName,
						'last_name'  => $lastname,
						'emailid' => $emailid,
						'contact_no' => $phoneNo,
						'number_week' =>$week,
						'created_date' => $currentDate,
						'status' => '1',
						'role_type' => 3,
						'hash' => $hash = $thisHash,
						'active' => 1,
						'nag_email' => 1,
						'cheerleader_email' => 1,
						'is_special' => $special,
						'updated_date' => $time);
						
					                                    //echo 'about to save the user for the first time <pre>'; print_r($user_data);
					
					
					/*********** Create a user *************/
					//Save the user data in the user table
					$this->common_model->save('user',$user_data);
					$user_id =  $this->db->insert_id();
					
					$all_cust_data=$this->common_model->getRows("user","*",array("id"=>$user_id));
					$this->session->set_userdata('customerId', $this->input->post('emailid'));
					$this->session->set_userdata('customers', $all_cust_data[0]);			
					$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
					 /***********add user registration*************/
				}
				else
				{
				    echo 'We took this route - I am not sure if this should ever happen in normal operation - please confirm' . '<br>';
				}

				//Not sure if this is needed anymore....
				if(isset($this->session->userdata('customers')->emailid) && $this->session->userdata('customers')->user_type == 0)
				{
				    echo 'This also looks like totally dead code - please confirm if we can never hit this in production <br>'; die;
					$week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
					$time = time();
					$user_data = array(

						'contact_no' => $_POST['contact_no'],
						'number_week' =>$week,
						'created_date' => date('Y-m-d H:i:s'),
						'status' => '1',
						'role_type' => 3,
						'hash' => $hash = $thisHash,
						'active' => 1,
						'updated_date' => $time,
						'user_type'=>1);
					$this->common_model->update('user',$user_data,array('id'=>$this->session->userdata('customers')->id));
					$user_id = $this->session->userdata('customers')->id;
					$all_cust_data=$this->common_model->getRows("user","*",array("id"=>$user_id));
					$this->session->unset_userdata('customers');
					$this->session->set_userdata('customerId', $this->input->post('emailid'));
					$this->session->set_userdata('customers', $all_cust_data[0]);					
					$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
				 /***********add user registration*************/
				}  // End of temp registration
				
				
				//Not sure if this coded is still needed for anything 
				if(isset($_SESSION['find_session_email']))
				{
				    echo 'This is a suspect path.  Do we ever get here normally??  we have find_session_email'; die;
					$week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
					$time = time();
					$user_data = array(

                						'contact_no' => $phoneNo,
                						'number_week' =>$week,
                						'created_date' => $currentDate,
                						'status' => '1',
                						'role_type' => 3,
                						'hash' => $hash = $thisHash,
                						'active' => 1,
                						'updated_date' => $time,
                						'is_special' => $special,
                						'nag_email' => 1,
                						'cheerleader_email' =>1,
                						'user_type'=>1);
                						$this->common_model->update('user',$user_data,array('emailid'=>$_SESSION['find_session_email']));
                						$user_id = $_SESSION['find_session_email'];
                						$all_cust_data=$this->common_model->getRows("user","*",array("emailid"=>$user_id));
                						$this->session->set_userdata('customerId', $this->input->post('emailid'));
                						$this->session->set_userdata('customers', $all_cust_data[0]);
                						$user_id= $all_cust_data[0]->id;
                						$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
					 /***********add user registration*************/
				}

                                            //echo '$user_data is <pre>'; print_r($user_data);
				
				//Looks like the original comment is wrong.  This code is run in normal flow
				if(isset($this->session->userdata('customers')->emailid) && $this->session->userdata('customers')->user_type != 0)
				{
                    				    //echo 'we have a Premium Subscription - could be special based on data <br>';
                    				    //echo 'Session data is: <br>';
                    				    //echo '<pre>'; print_r($this->session->userdata);
					
					$week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
					$time = time();
					$user_data = array(
                						'number_week' =>$week,
                						'created_date' => $currentDate,
                						'status' => '1',
                						'role_type' => 3,
                						'hash' => $hash = $thisHash,
                						'active' => 1,
                						'updated_date' => $time,
                						'user_type'=>1);
					
					//Update a user	with some additional data
					                        //echo 'about to update the user - does not appear that we really need this - commenting for now ...? <br>';
					                        //echo 'Check out the new userdata for anything new  <pre>'; print_r($user_data);
					

                    //Add some data to our users - not sure if this is needed					
					//$this->common_model->update('user',$user_data,array('id'=>$user_id));
					
					
					$all_cust_data=$this->common_model->getRows("user","*",array("id"=>$user_id));
					            //echo '$all_cust_data is <pre> '; print_r($all_cust_data);
					        
					        
					                        //echo 'Not doing the resetting of the data - lets see what happens <br>';
					            
					//echo 'before reset userdata is <pre>'; print_r($this->session->userdata);
					
					            
					//$this->session->unset_userdata('customers');
					
					//$this->session->set_userdata('customerId', $this->input->post('emailid'));
					//$this->session->set_userdata('customers', $all_cust_data[0]);

					$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
					
					//echo 'After reset userdata is <pre>'; print_r($this->session->userdata); die;
				}

				if($user_id !='')
				{
				                            //echo '<br> Updating the form - not sure if this is needed anymore <br>';
					//update formid for  questionnaire :Anil
					//Why do we we update this table????
					//this updates the Customer Id from a guid to a proper user id
					
						$sessid = $this->session->userdata('find_session_id');
						$formdata = array('customer_id'=>$user_id);
						$cond=array('customer_id'=>$sessid);
						$this->common_model->update('savequestionnnairfrmval', $formdata, $cond);
						$this->session->set_userdata('find_session_id', $user_id);
				}
				
			    $expirationBits = explode("/",$expiration);
				                        //echo 'We have a user_id of '. $user_id . ' with userData of <br>';
				                        //echo '<pre>'; print_r($this->session->userdata);
				                        
		//This does not look like it is needed
		
		/*
				 $this->data = array(
					'customer_id'   => $user_id,
					'full_name'    => $_POST['full_name'],
					'email'        => $_POST['emailid'],
					'card_number'  => '',
					'cvvnumber'    => '',
					'exp_month'    => '',
					'exp_year'     => '',
					'created_date' => date('Y-m-d'),
					'created_by'   => $user_id
					);
			*/
			
			    //Start of stripe user interactions
		
		        
                //Create a new stripe customer - needed to create a subscription 
                                        //echo 'The post contains '. '<pre>'; print_r($_POST);
				if(!empty($_POST['stripeToken']))
				{
					if(!empty($_POST['coupon_code']))
					{
					    $coupon = $_POST['coupon_code'];
					}
					else 
					{
					    $coupon = '';
					}
					
					$token  = $_POST['stripeToken'];
					$name = $_POST['full_name']." ".$lastname;
					$email = $_POST['emailid'];
					$price = $_POST['price'];
					$subscriptionType = $_POST['subid'];
					$planStatus = $_POST['plan_status'];
					$custId = $this->session->userdata('customers')->id;
					$itemName = $_POST['plan_name'];
					
					
					
					
					
					$chargeJson = $this->common_model->createStripeUserAndProcess($name, $token, $email, $user_id, $coupon, $orderID);

					//retrieve charge details

				    if($chargeJson['status'] == 'active' && empty($chargeJson['failure_code']))
				    {
    					$amount = $chargeJson['items']['data'][0]['plan']['amount']/100;
    					$balance_transaction = $chargeJson['id'];
    					$currency = $chargeJson['items']['data'][0]['plan']['currency'];
    					$status = $chargeJson['status'];
    					$date = date("Y-m-d H:i:s");


                        echo '$_POST[plan_name] is ' . $_POST['plan_name'];

					    $this->data = array(
                        					'name' => $name,
                        					'subscription_name' =>"PREMIUM from Web",//$_POST['plan_name'],
                        					'subscription_price' => $price,
                        					'subscription_type'=> $subscriptionType,
                        					'upgrade_status'=> $planStatus,
                        					'card_num'=>$last4,
                        					'card_exp_month'=>$expirationBits[0],
                        					'card_exp_year'=>$expirationBits[1],
                        					'custid' => $custId,
                        					'email' => $email,
                        					'item_name' => $itemName,
                        					'item_number' => $orderID,
                        					'item_price' => $price,
                        					'item_price_currency' => $currency,
                        					'paid_amount' =>$amount,
                        					'paid_amount_currency' => $currency,
                        					'txn_id' => $balance_transaction,
                        					'payment_status' => $status,
                        					'created' => $date,
                        					'modified' => $date
				                            );
				                            
					    
					           echo '<br> The $status is ' . $status . ' and $this->data <pre>'; print_r($this->data);
					    
						if($status == 'active')
						{
							$user_id=$this->session->userdata('customers')->id;
							//Update the payment status in the user table for this user - any reason why don't update the other fields?
							$this->common_model->update("user",array('payment_status'=>1),array('id'=>$user_id));
							$this->session->set_userdata('payment_status', 1);
							
							
							//Save the order - the product is now married to the customer
							if((bool)$this->common_model->save('orders', $this->data) === TRUE)
							{
								//Update the columns subscription_plan_id and strip_subscription_id in the user table - are there other columns that need updating?
								$this->common_model->update("user",array('subscription_plan_id'=>$this->input->post('plan_id'),'strip_subscription_id'=>$chargeJson['id']),array('id'=>$user_id));

								$finduserData = $this->session->userdata('customers');
            								//echo 'We found customer data $finduserData = <br>';
            								//echo '<pre>'; print_r($finduserData);die;
								
								//Send the appropriate emails to the user, and potentially the staff
								echo 'The plan_status is '. $_POST['plan_status'] . '<br>';
								
								if($_POST['plan_status']=='Premium from Web')
								{
									$statusMsg =$finduserData->first_name." ".$finduserData->last_name." - Thank you for your payment!  You will receive an email shortly with login instructions. Please check your email.  Thanks and Welcome!";
									$sendMailData=array(
                										'full_name'=>$finduserData->first_name,
                										'emailid'=>$finduserData->emailid,
                										'price'=>$_POST['price'],
                										'contact_no'=>$finduserData->contact_no,
                										'subject'=>'Premium Subscription from Web ',
                										'startWeek'=>1
									);
								}
								else
								
								{
								    if($_POST['plan_status']=='Special Premium from Web')
								    {
    									//$statusMsg = "Your payment has been upgraded successfully done. Now, you can access the program session";
    									$statusMsg =$finduserData->first_name." ".$finduserData->last_name." - Thank you for your payment!  You will receive an email shortly with login instructions. Please check your email.  Thanks and Welcome!";
    									$sendMailData=array(
                    										'full_name'=>$finduserData->first_name." ".$lastname,
                    										'emailid'=>$finduserData->emailid,
                    										'price'=>$_POST['price'],
                    										'contact_no'=>$finduserData->contact_no,
                    										'subject'=>'Special Premium from Web',
                    										'startWeek'=>1
    									                    );
    									                    
                                        
    								}
								}
								
								
								$this->common_model->sendMail($sendMailData);
								$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'success');
								$this->session->set_flashdata($this->msg);
							}
							
							
                            //echo 'userid is '. $user_id . '<br>';
                            $createDate = $this->common_model->getCustomFielddata('user', 'created_date', array('id'=>$user_id));
                            
                                        //echo '$createDate found is '. $createDate . '<br>'; die;
							$week =  $this->common_model->getCustomFielddata('user','number_week',array('id'=>$user_id));
							
							$check_order = $this->common_model->getRows('orders','id',array('custid'=>$user_id));

                            //$all_day_week is an array, where an element represents one day in the program.  This is counted in Week/Day from 1_1 - 40_7
                            
                            
                            $all_day_week = $this->common_model->calculate_day_custom_start_week(1, $week);
                            
                            
                            
						    //$all_day_week = $this->common_model->calculate_day_week($week);                         //$this->common_model->calculate_day_week($week);
						    //$all_day_week = $this->common_model->calculate_day_custom_start_week($this->input->post('starting_week')+1, $weekNumber);
						    
						     //Build the backend tables that define the diet and its features - based on the master template
						    //plan_id = 2 for prem, 3 = special
						    
						    $plan_id = $this->data['subscription_type'];
						    echo '<br> The $plan_id is ' . $plan_id . '<br>';
						    echo 'Check the entire data <pre>'; print_r($this->data);
                            $this->common_model->buildBackendTablesForUser($all_day_week, $user_id, $plan_id, $createDate );
						    
						    
						    /********************************/
            				//Create a new talentLMS user
            				$this->talentlmsapi->lmssignup($finduserData,$_POST['plan_status'],$remove=false);
            				                //echo 'called talent'; die;
                            
                            /********************************/
							//$checklms= $this->talentlmsapi->lmssignup($finduserData,$_POST['plan_status'],						    
						    
						   
						}
							
						else 
						{
						    //This should not really happen
						    $check_order = $this->common_model->getRows('orders','id',array('custid'=>$user_id));
						    echo 'Count of $check_order is ' .count($check_order) . ' and it should be 1 for userId' . $user_id; die;

//								$this->talentlmsapi->lmssignup($finduserData,$_POST['plan_status'],true);

							//update message id and questionaar as per premium user
						
//								$all_remain_week=$this->common_model->solveCustomQuery("SELECT week_id FROM `diets_plan_mapping` where customer_id=".$user_id." GROUP by week_id");
//								if(!empty($all_remain_week))
//								{
//									foreach($all_remain_week  as $week)
//									{

//									$customer_message_id=$this->common_model->getRows('week','prem_week_message_id,prem_week_netgram_id,prem_allowmeet_id',array('id'=>$week->week_id)); 
									//For premium user
//										$get_customer_message_id = $customer_message_id[0]->prem_week_message_id;
//										$netgram_id = $customer_message_id[0]->prem_week_netgram_id;
//										$allowmeet_id = $customer_message_id[0]->prem_allowmeet_id;

//											$data = array(
//											'message_id'=>$get_customer_message_id,
//											'netgram_id'=>$netgram_id,
//											'allowmeet_id'=>$allowmeet_id
//											);
//											$cond = array(
//											'week_id' => $week->week_id,
//											'customer_id' => $user_id);
//											$this->common_model->update('diets_plan_mapping',$data,$cond);

//									}
//								}
						}

							$this->session->set_userdata('current_plan_id',"");
							$this->session->set_userdata('current_plan_price',"");
							$this->session->set_userdata('current_plan_name',"");
							$this->session->set_userdata('plan_status',"");

							//Set subscription data in session
							$checkupgrade = $this->common_model->getRows("orders","subscription_type,subscription_name",array("custid"=>$user_id),'id','desc',0,1);


							if(!empty($checkupgrade))
							{
								$this->session->set_userdata('session_plan_name',$checkupgrade[0]->subscription_name);
								$this->session->set_userdata('session_plan_id',$checkupgrade[0]->subscription_type);
							}
							//Set subscription data in session

							$form_type = $this->common_model->getRows("user","form_type",array("id"=>$user_id));
							//additional-profile
							
							echo 'doing a redirect to either additional-profile or daily-dite-form <br>';
							echo 'based on this value ' . $form_type[0]->form_type .'<br>';
							
							
							
							
							if($form_type[0]->form_type==1)
							{
								redirect('daily-dite-form');
							}
							else
							{
							    //echo 'We are here'; die;
								redirect('additional-profile');
							}

						}
						else
						{
						    
						        echo 'Had an issue and $chargeJson is <pre>'; print_r($chargeJson); die;
						    
								$statusMsg = "Transaction has been failed";
								$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'danger');
								$this->session->set_flashdata($this->msg);
						}

					}
					else
					{
						$statusMsg = "Form submission error.......";
						$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'danger');
						$this->session->set_flashdata($this->msg);
					}

					$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'success');
					$this->session->set_flashdata($this->msg);

                    
					redirect('home/paynow?subid='.$subplanid.'');
				}
				
			else
			{
			                        //echo 'Post was empty ... and $special is  '. $special . '<br>';  //die;
			    //The user clicked on the Pay Now button on the website, and this will prepare and present the payment
			    //  information.  When the user submits the form, paynow is called again, but the post is now set.
				$subplanid = $this->input->get('subid');
				
				if ($special ==1)
				{
				    $subplanid = 3;
				    $planName = 'Special Premium from Web';
				    
				}
				else
				{
				    $subplanid = 2;
				    $planName = 'Premium from Web';
				   
				}
				
			//	if($subplanid==2)
			//	{
				    //Generates a new Premium or Special Premium User from the Web
				    //echo 'About to get the subscriptionPlan';
					$subdetailplan = $this->common_model->getRows("subscriptionplan","*",array("id"=>$subplanid));
					
					                //echo '$subdetailplan = <pre>'; print_r($subdetailplan);
					
					                //echo 'the $subscription_price is ' . $subdetailplan[0]->price;
					
					$data['subsc'] = $subdetailplan;
					if(!empty($subdetailplan))
					{
					    
					    //echo 'the $subscription_price is ' . $subdetailplan[0]->price;
					    
					    
						$subscription_name =$subdetailplan[0]->name;
						$subscription_price =$subdetailplan[0]->price;
						$this->session->set_userdata('current_plan_id',$subplanid);
						$this->session->set_userdata('current_plan_price',$subscription_price);
						$this->session->set_userdata('current_plan_name',$subscription_name);
						$this->session->set_userdata('plan_status',$planName);
						
						//echo '$this->session->userdata is <pre>'; print_r($this->session->userdata); 
					}

			//	}
			//	else
		//		{
		//		    echo 'we have something other than a subplanid of 2 ? ' . $subplanid;
		//		}
				
				//echo 'About to load payment_card_detail <br>'; 
				//echo '<pre>'; print_r($this->session->userdata);  die;
				$this->load->view('frontend/payment_card_detail',$data);
			}
		}

		public function session_diet_status(){

			$this->load->view('frontend/session_diet_status');
		}
		public function questionnaireform(){
			$getfid='';
			$getfid= $this->input->get('formid');
				if(!empty($getfid))
				{
				$this->data['formid'] =base64_decode($getfid);
				$this->data['save_quest'] = site_url('dailyditeform/save_questionnaireform/'.$getfid);
				}

			$this->load->view('frontend/questionnaireform',$this->data);
		}
		public function edit_questionnaireform(){
			$getfid='';
			$getfid= $this->input->get('formid');
			$customersid = $this->session->userdata('customers')->id;
			if(!empty($getfid))
			{
				$this->data['formid'] =base64_decode($getfid);
				$this->data['update_quest'] = site_url('dailyditeform/save_questionnaireform/'.$getfid);
			}

			$this->load->view('frontend/editquestionnaireform',$this->data);
		}

public function daily_dite_form()
	{

		if((bool)$this->session->userdata('payment_status')==FALSE)
		{
			redirect('home/subscription');
			exit();
		}
		$this->next_day_start_session();
		$custid='';
		$custid= $this->session->userdata('customers')->id;
	    $createdDate = $this->common_model->getRow('user', 'created_date', array('id'=>$custid))->created_date; 
	    $data['createdDate'] = $createdDate;
	    //echo '$createdDate is ' . $createdDate; die;    
		
	//	echo 'sorry - we are working an issue - please try later, and ignore the rest <br>';
	//    echo '$custid = ' . $custid; die;
		
		
		
		$Allcustinfo=$this->session->userdata('customers');
	//	echo 'sorry - we are working an issue - please try later, and ignore the rest <br>';
	//	echo '<pre>'; print_r($Allcustinfo);die;
		
		if(isset($custid) && (!empty($custid)))
		{
			if(!empty($custid)){
				$data['customerid']= ($custid);
			}
            
			$customer_diets_info = $this->common_model->customer_diets_edit_info($custid);
    	//echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
		//echo '<pre>'; print_r($customer_diets_info);die;

			if(empty($customer_diets_info)){ 
				$customer_diets_info = $this->common_model->customer_diets_info($custid);
			}
		//echo $this->db->last_query();
			
		//	echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
	
			
			
		    //echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
		   // echo 'customer diets info is: <br>';
		   // echo '<pre>'; print_r($customer_diets_info); die;
		
			$label1=array();
			$label2=array();
			$label3=array();
			$label4=array();
			//echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
			//echo 'customer diets is '; echo '<pre>'; print_r($customer_diets_info); die;
			if(!empty($customer_diets_info))
			{
				foreach($customer_diets_info as $val){
					if($val->input_type==1){
						if($val->status == 1)
						{
							$label1[$val->labelid]=$val;
						}
						
					} 
					else if($val->input_type==2)
					{
						if($val->status == 1)
						{
							$label2[$val->labelid]=$val;
						}

					}
					else if($val->input_type==3)
					{
						if($val->status == 1)
						{
							$label3[$val->labelid]=$val;
						}

					}
					else{
						if($val->status == 1)
						{
							$label4[$val->labelid]=$val;
						}
						
					}
				}

                //echo '<pre>'; print_r($label2);die;
				$data['label1'] = $label1;
				$data['label2'] = $label2;
				$data['label3'] = $label3;
				$data['label4'] = $label4;
				
			 	$data['weekid']= $customer_diets_info[0]->week_id;
				$data['dayid'] = $customer_diets_info[0]->day_id;
				$data['message_id'] = $customer_diets_info[0]->message_id;
				$data['netgram_id'] = $customer_diets_info[0]->netgram_id;
				$data['allowmeet_id'] = $customer_diets_info[0]->allowmeet_id;
				$data['questionnaire_id'] = $customer_diets_info[0]->questionnaire_id;
			    $data['lession_id'] = $customer_diets_info[0]->admin_msg_id;
			   if(isset($customer_diets_info[0]->comments) && (!empty($customer_diets_info[0]->comments)))
			   {
			   	$data['comments'] = $customer_diets_info[0]->comments;
			   }
			   
			   if(isset($customer_diets_info[0]->staff_comments) && (!empty($customer_diets_info[0]->staff_comments)))
			   {
			    $data['staffcomments'] = $customer_diets_info[0]->staff_comments;
			   }


	           /* ==============Check Extra Metting ======================*/
	           $data['extra_meting']=0;
	           $get_extra_from_userTable = $this->common_model->getCustomFielddata('user','extra_metting',array('id'=>$custid));

	          	if($get_extra_from_userTable == 0)
	          	{
							$extra_metting = "SELECT ANY_VALUE(week_id) as week_id,ANY_VALUE(extra_metting) as extra_metting FROM diets_plan_mapping where customer_id =".$custid." and week_id <=".$customer_diets_info[0]->week_id." group by week_id,extra_metting";
							$total_extra = $this->common_model->solveCustomQuery($extra_metting);
							$coun_t=0;
						if(!empty($total_extra))
						{
							foreach($total_extra as $t_val)
							{
								$coun_t += $t_val->extra_metting;
							}
						}
						$data['extra_meting'] = $coun_t;
	          	}
	          	else
	          	{
	          		$data['extra_meting'] = $get_extra_from_userTable;
	          	}
	            /* ================Check Extra Metting ======================*/
				$data['set_time_slot'] = $this->common_model->getRows('time_slot','id,timeslot,providerid',
					array('status'=>'1','providerid'=>2));

				if(!empty($custid))
				{	

				$order_list = $this->common_model->solveCustomQuery('select subscription_name from orders
					where custid='.$custid.' order by id desc limit 1');
				$data['order_list'] = $order_list[0]->subscription_name;
				}
				$data['questionnaire_list'] = $this->common_model->getRows('week','questionnaire_id,hide_net_gram,hide_premium_net_gram',
				array('id'=>$customer_diets_info[0]->week_id));

				$data['check_questionnaire'] = $this->common_model->solveCustomQuery('SELECT 
					ANY_VALUE(createform.id) as id,ANY_VALUE(customer_id) as customer_id,ANY_VALUE(questionnaire_id) as questionnaire_id,ANY_VALUE(weeks) as weeks,ANY_VALUE(week_wise_days) as week_wise_days,ANY_VALUE(createform.form_name) as form_name FROM `customer_diets_plan` join createform on createform.id=customer_diets_plan.questionnaire_id where form_type=0 and mapped_status=1 and customer_id ='.$custid.' and weeks <='.$customer_diets_info[0]->week_id.' group by id,customer_id'); 



  				$gramcond=array('dm.weeks'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>$customer_diets_info[0]->customer_id);
				$gramfield='(m.Message) AS Message';
				$gramjoin=array(
					array(
						'join_table'=>'customer_diets_plan as dm',
						'on_first_table'=>'m.MessageID',
						'on_second_table'=>'dm.netgram_id'
					));	
 	 			$data['net_gram']=  $this->common_model->getJoinData("messagecenterposttable as m",$gramcond,$gramfield,$gramjoin,'','','','','dm.netgram_id'); 
				$lesscond=array('dm.week_id'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>$custid);
				$lessfield='ANY_VALUE(m.Message) as Message';
				$lessjoin=array(
				array(
					'join_table'=>'diets_plan_mapping as dm',
					'on_first_table'=>'m.MessageID',
					'on_second_table'=>'dm.admin_msg_id'
				));	
 	  			$data['lession_msg'] =  $this->common_model->getJoinData("messagecenterposttable as m",$lesscond,$lessfield,$lessjoin,'','','','','dm.admin_msg_id'); 
 	  			//echo $this->db->last_query();exit;
				$data['displaymessage'] = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(m.Message) as Message from messagecenterposttable as m left join diets_plan_mapping as dm on m.MessageID = dm.message_id where dm.week_id = '.$customer_diets_info[0]->week_id.' and dm.customer_id = '.$custid.' group by dm.message_id');
				$acknowment=$this->common_model->getRows("customer_diets_plan","acknowledgment,help,exercise_id,weight,steps",
				array("weeks"=>$customer_diets_info[0]->week_id,
				"week_wise_days"=>$customer_diets_info[0]->day_id,
				"customer_id"=>$customer_diets_info[0]->customer_id));

				if(isset($acknowment[0]->acknowledgment) && ($acknowment[0]->acknowledgment==0)){
					$data['acknow']=$acknowment[0]->acknowledgment;
					$data['help']=$acknowment[0]->help;
				}
				if(isset($acknowment[0]->exercise_id) && (!empty($acknowment[0]->exercise_id))){
					$data['exercise_id']=$acknowment[0]->exercise_id;
				}
				if(isset($acknowment[0]->weight) && (!empty($acknowment[0]->weight))){
					$data['weight'] = $acknowment[0]->weight;
				}
				if(isset($acknowment[0]->steps) && (!empty($acknowment[0]->steps))){
					$data['steps'] = $acknowment[0]->steps;
				}

				//echo '<pre>'; print_r($data);die;
				if($customer_diets_info[0]->message_id !=0){
				$data['showmessage']=$this->common_model->getRows('messagecenterposttable','Message,MessageID',array('Messageid'=>$customer_diets_info[0]->message_id));
				}
				//schedule date
				$data['next_meeting']=$this->common_model->getRows('time_schedule','schedule_date,slottime,providerid',
				array('customerid'=>$customer_diets_info[0]->customer_id),'id','desc');

				//schedule date
				$data['exerciselst']=$this->common_model->getRows('exercise','id,exercise_name,status',
				array('status'=>1));

				$session_plan_id = $this->session->userdata('session_plan_id');
				//echo '<pre>';print_r($session_plan_id);die;
				if($session_plan_id==1 )
				{
					$data['subscription_name'] = $this->common_model->getRows('subscriptionplan',
					'id,name,price,description',array('status'=>'1',
					'id !='=>$this->session->userdata('session_plan_id')));
				}
				
				$data['exit_questionnaire'] = $this->common_model->getRows('user','check_questionnaire',array('status'=>1,
				'id ='=>$custid));
				$data['recipes']=$this->common_model->getRows('recipes','id,image,title,short_description',array('status'=>'1','type'=>2,'week_id'=>$customer_diets_info[0]->week_id));
				//echo $this->db->last_query();exit;
			}
			else
			{
			    //echo "It was empty"; die;
			}

                //echo 'about to load the view and $data is <pre>'; print_r($data); die;
				$this->load->view('frontend/daily_dite_form',$data);
		}else{
				redirect('/');
			}
	}




public function daily_dite_form__billy()
	{
	   //This function is  in production.  it is being used to test some changes
    //This function will present the personalized Daily Tracker for data entry
    
		if((bool)$this->session->userdata('payment_status')==FALSE)
		{
			redirect('home/subscription');
			exit();
		}
		$gradStatus=0;
		$this->next_day_start_session();   
		$custid='';
		$custid= $this->session->userdata('customers')->id;
		
		                    //echo 'sorry - we are working an issue - please try later, and ignore the rest <br>';
	                        // echo '$custid = ' . $custid;
	    	                //echo '<pre>'; print_r($this->session->userdata());die;
		
		
		$Allcustinfo=$this->session->userdata('customers');
		
		//echo 'sorry - we are working an issue - please try later, and ignore the rest <br>';
		//echo '<pre>'; print_r($Allcustinfo);die;
		
		if(isset($custid) && (!empty($custid)))
		{
			
            //First - check to see if the user has already created a record for this day
            
			$ans = $this->common_model->customer_diets_edit_info($custid);
			
			$customer_diets_info = $ans['editPattern'];
			$realDay = $ans['realDay'];
		    $realWeek = $ans['realWeek'];
		    $gradStatus = $ans['gradStatus'];
		    
		    
		                //echo '$realDay is ' . $realDay . '<br>';
		                //echo '$realWeek is ' . $realWeek . '<br>';
			
                                            //echo 'sorry - we are working an issue - please try later - the system should be available soon, and ignore the rest of this jibberish.   <br> Debugging for customerid = '. $custid;    
	                                        //echo 'The previous entered data is <pre>'; print_r($customer_diets_info);die;

			if(empty($customer_diets_info))
			{
            			             echo '$customer_diets_info is empty - so we did not find any saved data for this user on this day <br>'; 
            			            //User has not entered data for this date yet - so get the pattern of what should be displayed to the user
				$ans = $this->common_model->customer_diets_info($custid);
				                    //echo '<br> Just called customer_diets_info <br>';
			                        //echo '<pre>'; print_r($ans);
				
				$realDay = $ans['realDay'];
		        $realWeek = $ans['realWeek'];
		        $gradStatus = $ans['gradStatus'];
		                            //echo '$gradStatus is '. $gradStatus; die;
		        
		                            //echo '<br> realWeek is '. $realWeek;
		        
		        $customer_diets_info = $ans['editPattern'];
		                            //echo '<br> The gradStatus is ' . $gradStatus . '<br>';
		                           // echo 'Customer_diets_info is <pre>'; print_r($customer_diets_info);
		        
                		            //echo 'sorry - we are working an issue - please try later - the system should be available soon, and ignore the rest of this jibberish.   <br> Debugging for customerid = '. $custid;    
                		            //echo '<pre>'; print_r($customer_diets_info);die;
                
                $data = $customer_diets_info;
			}
			else
			{
			                   //echo 'We found data for this customer';
			                   //echo '<pre>'; print_r($customer_diets_info);die;
			    //$realWeek = $customer_diets_info[0]->week_id;
			    //$realDay = $customer_diets_info[0]->day_id;
			    
			    //echo '$realDay is ' . $realDay . '<br>';
		        //echo '$realWeek is ' . $realWeek . '<br>';
			    //echo 'Maybe we should not do those sets...';
			    
			}

			if(empty($customer_diets_info))
			{
			    echo 'Customer_diets_info is still empty ....'; die;
				$customer_diets_info = $this->common_model->expair_customer_diets($custid);
			    $realWeek = $customer_diets_info[0]->week_id;
			    
			    //echo 'customer diets info is: <br>';
                //echo '<pre>'; print_r($customer_diets_info); die;
			    
			}
		      
		      
		      
		      
		                            //echo $this->db->last_query();
			
                            		//	echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
                            		   // echo '<pre>'; print_r($customer_diets_info);die;
			
			
                        		   //echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
                        		   // echo 'customer diets info is: <br>';
                        		   // echo '<pre>'; print_r($customer_diets_info); die;
		
			$label1=array();
			$label2=array();
			$label3=array();
			$label4=array();
                            		//echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    die;
                            		//echo 'customer diets is '; echo '<pre>'; print_r($customer_diets_info); die;
		
		    
		
		
			if(!empty($customer_diets_info))
			{
			    //$data['customerDietsInfo'] = $customer_diets_info;
			    
                			                //echo 'populating the form.... <br>';
                			                //echo '$customer_diets_info is  <pre>'; print_r($customer_diets_info);
				foreach($customer_diets_info as $val)
				{
				   // echo '$val is <pre>' . print_r($val); die;
				    switch ($val->input_type)
				    {
				        case 1:
    						$label1[$val->labelid]=$val;
    						break;
    						
    					case 2:
    					    
    						$label2[$val->labelid]=$val;
    						break;
    						
				        case 3:
    						$label3[$val->labelid]=$val;
    						break;
    						
    					default:
    						$label4[$val->labelid]=$val;
    						
					}
				}

                                     // echo '$label1 is <pre>'; print_r($label1); echo '<br>';
                                    //    echo '$label2 is <pre>'; print_r($label2); echo '<br>';
                                    //   echo '$label3 is <pre>'; print_r($label3); echo '<br>';
                                    //    echo '$label4 is <pre>'; print_r($label4); echo '<br>';
                                    //    die;
                
                
                //echo  'Day id is ' . $customer_diets_info[0]->day_id;
                
				$data['label1'] = $label1;
				$data['label2'] = $label2;
				$data['label3'] = $label3;
				$data['label4'] = $label4;
				
				$data['weekid']= $realWeek;
				
				$data['dayid'] = $realDay;
				$data['message_id'] = $customer_diets_info[0]->message_id;
				$data['netgram_id'] = $customer_diets_info[0]->netgram_id;
				$data['allowmeet_id'] = $customer_diets_info[0]->allowmeet_id;
				$data['questionnaire_id'] = $customer_diets_info[0]->questionnaire_id;
			    $data['lession_id'] = $customer_diets_info[0]->admin_msg_id;
			    
			   if(isset($customer_diets_info[0]->comments) && (!empty($customer_diets_info[0]->comments)))
			   {
			   	    $data['comments'] = $customer_diets_info[0]->comments;
			   }
			   
			   if(isset($customer_diets_info[0]->staff_comments) && (!empty($customer_diets_info[0]->staff_comments)))
			   {
			        $data['staffcomments'] = $customer_diets_info[0]->staff_comments;
			   }


	           /* ==============Check Extra Metting ======================*/
	           $data['extra_meting']=0;
	           $get_extra_from_userTable = $this->common_model->getCustomFielddata('user','extra_metting',array('id'=>$custid));

	          	if($get_extra_from_userTable == 0)
	          	{
							$extra_metting = "SELECT ANY_VALUE(week_id) as week_id,ANY_VALUE(extra_metting) as extra_metting 
							                    FROM diets_plan_mapping where customer_id =".$custid." 
							                    and week_id <=".$customer_diets_info[0]->week_id." group by week_id, extra_metting";
							$total_extra = $this->common_model->solveCustomQuery($extra_metting);
							$coun_t=0;
						if(!empty($total_extra))
						{
							foreach($total_extra as $t_val)
							{
								$coun_t += $t_val->extra_metting;
							}
						}
						$data['extra_meting'] = $coun_t;
	          	}
	          	else
	          	{
	          		$data['extra_meting'] = $get_extra_from_userTable;
	          	}
	            /* ================Check Extra Metting ======================*/
				
				
				
				$data['set_time_slot'] = $this->common_model->getRows('time_slot','id,timeslot,providerid',
					                                                    array('status'=>'1','providerid'=>2));

				if(!empty($custid))
				{	

    				$order_list = $this->common_model->solveCustomQuery('select subscription_name from orders
    					                                                    where custid='.$custid.' order by id desc limit 1');
    				$data['order_list'] = $order_list[0]->subscription_name;
				}
				
				$data['questionnaire_list'] = $this->common_model->getRows('week', 'questionnaire_id, hide_net_gram, hide_premium_net_gram', array('id'=>$realWeek, 'status'=>0));

                            ////$customer_diets_info[0]->week_id.' 
                            //and weeks <='. $realWeek .'       
/*
				$data['check_questionnaire'] = $this->common_model->solveCustomQuery('SELECT 
                                                                    					ANY_VALUE(createform.id) as id,
                                                                    					ANY_VALUE(customer_id) as customer_id,
                                                                    					ANY_VALUE(questionnaire_id) as questionnaire_id,
                                                                    					ANY_VALUE(weeks) as weeks,
                                                                    					ANY_VALUE(week_wise_days) as week_wise_days,
                                                                    					ANY_VALUE(createform.form_name) as form_name 
                                                                    					
                                                                    					FROM `customer_diets_plan` 
                                                                    					
                                                                    					join createform on createform.id=customer_diets_plan.questionnaire_id 
                                                                    					
                                                                    					where form_type=0 
                                                                    					and mapped_status=1 
                                                                    					and customer_id ='.$custid.' 
                                                                    					                                      
                                                                    					
                                                                    					group by id,customer_id'); 

*/
                
                                //echo 'calling getGramWeeklyMessages with '. $customer_diets_info[0]->customer_id . ' $gradStatus = ' . $gradStatus . ' and $realWeek = ' . $realWeek;
                
                $data['net_gram'] = $this->common_model->getGramWeeklyMessage($customer_diets_info[0]->customer_id, $gradStatus, $realWeek, $realDay);
                
  			                        //echo 'Net Gram is <pre>'; print_r($data['net_gram']); 
				
				
				//Now look for any Private Weekly Messages - specific for a given user and week number
				$data['lession_msg'] = $this->common_model->getPrivateWeeklyMessage($customer_diets_info[0]->customer_id, $gradStatus, $realWeek);
				
				                        //echo 'Private Weekly Meesage is <pre>'; print_r($data['lession_msg']);	

 	  			
 	  			$data['displaymessage'] = $this->common_model->getGenericWeeklyMessage($customer_diets_info[0]->customer_id, $gradStatus, $realWeek);
 	  			                        //echo 'Generic Weekly Meesage is <pre>'; print_r($data['displaymessage']); 	
 	  			
 	  			/*
                $genericMessageSql = 'SELECT 
                                            ANY_VALUE(m.Message) as Message 
                                            FROM messagecenterposttable as m left 
                                            JOIN diets_plan_mapping as dm on m.MessageID = dm.message_id 
                                            WHERE 
                                            dm.week_id = '.$realWeek.' 
                                            AND dm.customer_id = '.$custid.' 
                                            GROUP by dm.message_id';
                
				$data['displaymessage'] = $this->common_model->solveCustomQuery($genericMessageSql);
				*/
				
				
				$basicFeatures = $this->common_model->getBasicFeatures($realDay, $realWeek, $customer_diets_info[0]->customer_id, $gradStatus);
				
				                            //echo 'The $basicFeatures are <pre>'; print_r($basicFeatures);
				
				$data['acknow'] = $basicFeatures['acknowledgement'];
				$data['exercise_id'] = $basicFeatures['exercise'];
				$data['weight'] = $basicFeatures['weight'];
				$data['steps'] = $basicFeatures['numberOfsteps'];
				$data['gradStatus'] = $gradStatus;
				
				//echo '$customer_diets_info[0]->message_id = '. $customer_diets_info[0]->message_id;
				
				//if($customer_diets_info[0]->message_id !=0)
				//{
				//    $data['showmessage']=$this->common_model->getRows('messagecenterposttable', 'Message,MessageID', array('Messageid'=>$customer_diets_info[0]->message_id));
			    //}
				
				//echo 'message is <pre>'; print_r($data['showmessage']); die;
				
				//schedule date
				$data['next_meeting']=$this->common_model->getRows('time_schedule', 'schedule_date, slottime, providerid', array('customerid'=>$customer_diets_info[0]->customer_id), 'id', 'desc');

				//schedule date
				$data['exerciselst']=$this->common_model->getRows('exercise','id, exercise_name,status', array('status'=>1));

                //echo 'ExercuseList is <pre>'; print_r($data['exerciselst']); die;


				$session_plan_id = $this->session->userdata('session_plan_id');
				//echo 'Plan_id is <pre>';print_r($session_plan_id);
				
				if($session_plan_id <> 1 )
				{
					$data['subscription_name'] = $this->common_model->getRows('subscriptionplan',
                                                            					'id, name, price, description', array('status'=>'1', 'id !=' => $session_plan_id));
				}
				
				$data['exit_questionnaire'] = $this->common_model->getRows('user','check_questionnaire',array('status'=>1, 'id =' => $custid));
				
				$data['recipes']=$this->common_model->getRows('recipes','id, image, title, short_description', array('status'=>'1', 'week_id' => $realWeek));
				                //echo $this->db->last_query();exit;
			}
			else
			{
			   echo "It was empty"; die;
			}

                                 echo 'just before the load and data is '; echo '<pre>'; print_r($data); die;
				$this->load->view('frontend/daily_dite_form', $data);
		}
		else
		{
		    //echo "we are here?" . '<br>'; die;
			redirect('/');
		}
	}




	public function daily_dite_form_edit()
	{
	    //User was viewing their past data, and selected one of the rows to edit
	    // It could have had previous user data, or it could have been blank (user never entered data for that day)
		$custinfo = $this->session->userdata('customers');
		//echo 'The $custinfo is <pre>'; print_r($custinfo); 
		if(!empty($custinfo))
		{
            $gradStatus='';
            $this->next_day_start_session();                //check this function out - not sure if it is needed, but it was in the addview
            $custid='';
    		$custid= $this->session->userdata('customers')->id;
            //echo $custid; die;
    		$customerid='';$weekids='';$dayids='';
    		
    		
    		
    		//echo base64_decode($customerid); die;
    		$customerid = base64_decode($this->uri->segment(3));
    		$weekids = base64_decode($this->uri->segment(4));
    		$dayids = base64_decode($this->uri->segment(5));
    		$customerCreatedDate = $this->common_model->getRow('user', 'created_date', array('id'=>$customerid))->created_date; 
    		
    		$data['customerid'] = $customerid;
    		
    		//echo 'Sorry - we are investigating an issue - please try again later... <br>';
            //echo 'Passed in parms: $customerId = ' . $customerid . ' weekids is ' . $weekids . ' and dayids = ' . $dayids . ' createdDate = ' . $customerCreatedDate;
           
            if ($weekids < 41)
            {
                //we have a student - and they previously entered data for this specific day
                
                $previousEnteredData = $this->common_model->getPreviousDataOrModel($customerid, $weekids, $dayids);
                //echo '<br> $previousEnteredData is <pre>'; print_r($previousEnteredData);
                
                $gradStatus = 0;
                $carbGramArray = array();
				$hungerArray = array();
				$pressurePulseArray = array();
				$sugarArray = array();
				
				foreach($previousEnteredData as $val)
			    {
    				if($val->input_type==1)
    				{
                        $carbGramArray[$val->labelid]=$val;		
    				} 
    				else if($val->input_type==2)
    				{
    						$hungerArray[$val->labelid]=$val;
    				}
    				else if($val->input_type==3)
    				{
    						$pressurePulseArray[$val->labelid]=$val;
    				}
    				else if($val->input_type==4)
    				{
    					$sugarArray[$val->labelid]=$val;
    				
    				}
			    }
			    
			    
			    
			    
			    
			    $messageId = $previousEnteredData[0]->message_id;
			    $displaymessage = $this->common_model->getCustomFielddata('messagecenterposttable','Message',array('MessageID'=>$messageId));
			    
			    //echo '$messageId is '. $messageId . ' and $displaymessage is ' . $displaymessage . '<br>';
			    
			    $dateString = date("m/d/Y",  $this->common_model->getDateFromWeekDayStart($customerCreatedDate, $weekids, $dayids));
			    //echo '$messageId is ' . $messageId . '<br>';
					
					//echo '<pre>'; print_r($label2);die;
				$data['carbGramArray'] = $carbGramArray;
				$data['hungerArray'] = $hungerArray;
				$data['pressurePulseArray'] = $pressurePulseArray;
				$data['sugarArray'] = $sugarArray;
				$data['weekid']=$previousEnteredData[0]->week_id;
				$data['custid']=$custid;
				$data['dayid']=$previousEnteredData[0]->day_id;
				$data['dateString'] = $dateString;
					//echo '<pre>'; print_r($label2);die;
				$data['message_id']=$messageId;

                $data['gradStatus'] = $gradStatus;
				$data['netgram_id']=$previousEnteredData[0]->netgram_id;
				$data['allowmeet_id']=$previousEnteredData[0]->allowmeet_id;
				$data['questionnaire_id']=$previousEnteredData[0]->questionnaire_id;
				$data['lession_id']=$previousEnteredData[0]->admin_msg_id;
				$data['comments'] = $previousEnteredData[0]->comments;
				$data['staffcomments'] = $previousEnteredData[0]->staff_comments;
				$data['displaymessage']= $displaymessage;
					//echo '<pre>'; print_r($data);die;	
                
                
                
                $basicFeatures = $this->common_model->getBasicFeatures($dayids, $weekids, $customerid, $gradStatus);
				
				                            //echo 'The $basicFeatures are <pre>'; print_r($basicFeatures);
				
				$data['acknow'] = $basicFeatures['acknowledgement'];
				$data['exercise_id'] = $basicFeatures['exercise'];
				$data['weight'] = $basicFeatures['weight'];
				$data['steps'] = $basicFeatures['numberOfsteps'];
				$data['gradStatus'] = $gradStatus;
				
				$data['exerciselst']=$this->common_model->getRows('exercise', 'id, exercise_name, status', array('status'=>1));
                $data['recipes']=$this->common_model->getRows('recipes','id, image, title, short_description', array('status'=>'1', 'week_id' => $weekids));
                
                
                
                //echo 'calling check_netcarb_level';
                $userDetails = $this->common_model->getUserEntryDetails($customerid, $weekids, $dayids);
                //echo '$userDetails is <pre>'; print_r($userDetails);
                
                
                //echo '<br>  $carbGramArray is <pre>'; print_r($carbGramArray);
             //   die;
                
                
                
           //     $chkNetcarb = $this->common_model->check_netcarb_level($weekids, $dayids, $customerid, $gradStatus);
           //     echo '$chkNetcarb is <pre>'; print_r($chkNetcarb);
                
            //    echo '<br>  $carbGramArray is <pre>'; print_r($carbGramArray);
                
            //    die;
                
                
                
                
                
                
                
                
                //echo 'About to load the page and <pre>'; print_r($data);
				$this->load->view('frontend/daily_dite_form_edit', $data);
				
            }
            else
            {
                //we have a graduate
                //echo 'Sorry - I am having an issue right now with this feature - can you please try a little later? ';
                $gradStatus = 1;
                
                //$dateString = date("m/d/Y",  $this->common_model->getDateFromWeekDayStart($customerCreatedDate, $weekids, $dayids));
                $weekDayDate = date("m/d/Y", $this->common_model->getDateFromWeekDayStart($customerCreatedDate, $weekids, $dayids));
                //$graduateModelData = $this->common_model->customer_diets_edit_info_fromList($customerid, $weekids, $dayids, $weekDayDate);
                $graduateModelData = $this->common_model->getGraduateDataOrModel($customerid, $weekids, $dayids);
                
                
                //echo '$customerid is '. $customerid . ' and $weekids is ' . $weekids . ' and $weekDayDate is '. $weekDayDate . ' Finaly - <pre>'; print_r($graduateModelData); die;
                
                
                //echo '$graduateModelData is <pre>'; print_r($graduateModelData); 
                
                $gradStatus = 0;
                $carbGramArray = array();
				$hungerArray = array();
				$pressurePulseArray = array();
				$sugarArray = array();
				
				foreach($graduateModelData as $val)
			    {
    				if($val->input_type==1)
    				{
                        $carbGramArray[$val->labelid]=$val;		
    				} 
    				else if($val->input_type==2)
    				{
    						$hungerArray[$val->labelid]=$val;
    				}
    				else if($val->input_type==3)
    				{
    						$pressurePulseArray[$val->labelid]=$val;
    				}
    				else if($val->input_type==4)
    				{
    					$sugarArray[$val->labelid]=$val;
    				
    				}
			    }
			    $messageId = $graduateModelData[0]->message_id;
			    $dateString = date("m/d/Y",  $this->common_model->getDateFromWeekDayStart($customerCreatedDate, $weekids, $dayids));
			    //echo '$messageId is ' . $messageId . '<br>';
					
					//echo '<pre>'; print_r($label2);die;
				$data['carbGramArray'] = $carbGramArray;
				$data['hungerArray'] = $hungerArray;
				$data['pressurePulseArray'] = $pressurePulseArray;
				$data['sugarArray'] = $sugarArray;
				$data['weekid']=$graduateModelData[0]->week_id;
				$data['custid']=$custid;
				$data['dayid']=$graduateModelData[0]->day_id;
				$data['dateString'] = $dateString;
					//echo '<pre>'; print_r($label2);die;
				$data['message_id']=$messageId;

                $data['gradStatus'] = $gradStatus;
				$data['netgram_id']=$graduateModelData[0]->netgram_id;
				$data['allowmeet_id']=$graduateModelData[0]->allowmeet_id;
				$data['questionnaire_id']=$graduateModelData[0]->questionnaire_id;
				$data['lession_id']=$graduateModelData[0]->admin_msg_id;
				//$data['comments'] = $graduateModelData[0]->comments;
				//$data['staffcomments'] = $graduateModelData[0]->staff_comments;
				$data['displaymessage']= $this->common_model->getCustomFielddata('messagecenterposttable','Message',array('MessageID'=>$messageId));
					//echo '<pre>'; print_r($data);die;	
                
                
                
                $basicFeatures = $this->common_model->getBasicFeatures($dayids, $weekids, $customerid, $gradStatus);
				
				                            //echo 'The $basicFeatures are <pre>'; print_r($basicFeatures);
				
				$data['acknow'] = $basicFeatures['acknowledgement'];
				$data['exercise_id'] = $basicFeatures['exercise'];
				$data['weight'] = $basicFeatures['weight'];
				$data['steps'] = $basicFeatures['numberOfsteps'];
				$data['gradStatus'] = $gradStatus;
				
				$data['exerciselst']=$this->common_model->getRows('exercise', 'id, exercise_name, status', array('status'=>1));
                $data['recipes']=$this->common_model->getRows('recipes','id, image, title, short_description', array('status'=>'1', 'week_id' => $weekids));
                
                
                
                
                
                
                
                
                $gramcond=array('dm.weeks'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>$customer_diets_info[0]->customer_id);
				$gramfield='(m.Message) AS Message';
				$gramjoin=array(
											array(
												'join_table'=>'customer_diets_plan as dm',
												'on_first_table'=>'m.MessageID',
												'on_second_table'=>'dm.netgram_id'
											));	
	 $data['net_gram']=  $this->common_model->getJoinData("messagecenterposttable as m",$gramcond,$gramfield,$gramjoin,'','','','','dm.netgram_id'); 



   /*  $data['lession_msg'] = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(m.Message) as Message from messagecenterposttable as m left join diets_plan_mapping as dm on m.MessageID = dm.admin_msg_id where dm.week_id = '.$customer_diets_info[0]->week_id.' and dm.customer_id = '.base64_decode($customerid).' group by dm.admin_msg_id');*/


				$lesscond=array('dm.week_id'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>base64_decode($customerid));
				$lessfield='ANY_VALUE(m.Message) as Message';
				$lessjoin=array(
											array(
												'join_table'=>'diets_plan_mapping as dm',
												'on_first_table'=>'m.MessageID',
												'on_second_table'=>'dm.admin_msg_id'
											));	
 	  
 	  
 	  $data['lession_msg'] =  $this->common_model->getJoinData("messagecenterposttable as m",$lesscond,$lessfield,$lessjoin,'','','','','dm.admin_msg_id'); 

                
                
                
                
                
                
                
              
              
              
                
                
                
                
                
                
                //echo '<pre>'; print_r($data); die;
                $this->load->view('frontend/daily_dite_form_edit', $data);
            }
		}
		
            

            //Get the users created date
            // calculate the date in question based on the created date, week, and day
 //           $createdDate = $this->common_model->getRow('user', 'created_date', array('id'=>$custid));
 //           $weekDayDate = $this->common_model->getDateFromWeekDayStart($createdDate->created_date, base64_decode($weekids), base64_decode($dayids));
            
            //echo '<br> and dateOfData is <pre>'; print_r($weekDayDate);
           
 //           $dateString = date('m/d/Y H:i:s', $weekDayDate);
            //echo '$datestring is' . $dateString;
            
 //           $data['dateString'] = $dateString;
    
//            $ans = $this->common_model->customer_diets_edit_info($custid);
			
		//echo '<br> and $ans is <pre>'; print_r($ans); die;
			
			
//			$customer_diets_info = $ans['editPattern'];
//			$realDay = $ans['realDay'];
//		    $realWeek = $ans['realWeek'];
//		    $gradStatus = $ans['gradStatus'];
            
         
            
            
            
//			if(isset($customerid) && (!empty($weekids)) && (!empty($dayids)))
//			{
//				if(!empty($customerid))
//				{
//					$data['customerid'] = base64_decode($customerid);
//				}

                //echo '<br> $weekids is ' . base64_decode($weekids); die;

//				$customer_diets_info = $this->common_model->customer_diets_edit_info_fromList(base64_decode($customerid), base64_decode($weekids), base64_decode($dayids), $weekDayDate);
//				if (isset($customer_diets_info) && (!empty($customer_diets_info)))
//				{
  //                      //echo 'found it <br>';
	//			   // echo '$customer_diets_info returned is <pre>'; print_r($customer_diets_info); die;
	//			}
//				else
//				{
//				   // echo 'No data found ';
//				    //echo '$customer_diets_info returned is <pre>'; print_r($customer_diets_info);
//				}
//				//die;
				
                
//				$carbGramArray = array();
//				$hungerArray = array();
//				$pressurePulseArray = array();
//				$sugarArray = array();
//				foreach($customer_diets_info as $val)
//			    {
  //  				if($val->input_type==1)
//    				{
//                        $carbGramArray[$val->labelid]=$val;		
//    				} 
//    				else if($val->input_type==2)
//    				{
//    					
//    						$hungerArray[$val->labelid]=$val;
 //   					
    
  //  				}
//    				else if($val->input_type==3)
//    				{
    					
//    						$pressurePulseArray[$val->labelid]=$val;
    					
    
 //   				}
 //   				else
 //   				{
 //   					$sugarArray[$val->labelid]=$val;
    				
   // 				}
//			    }
					
					//echo '<pre>'; print_r($label2);die;
//						$data['carbGramArray'] = $carbGramArray;
//						$data['hungerArray'] = $hungerArray;
//						$data['pressurePulseArray'] = $pressurePulseArray;
//						$data['sugarArray'] = $sugarArray;
//						$data['weekid']=$customer_diets_info[0]->week_id;
//						$data['custid']=$custid;
//						$data['dayid']=$customer_diets_info[0]->day_id;
//					//echo '<pre>'; print_r($label2);die;
//					$data['message_id']=$customer_diets_info[0]->message_id;
///
//                    $data['gradStatus'] = $gradStatus;
//					$data['netgram_id']=$customer_diets_info[0]->netgram_id;
//					$data['allowmeet_id']=$customer_diets_info[0]->allowmeet_id;
//					$data['questionnaire_id']=$customer_diets_info[0]->questionnaire_id;
//					$data['lession_id']=$customer_diets_info[0]->admin_msg_id;
//					$data['comments'] = $customer_diets_info[0]->comments;
//					$data['staffcomments'] = $customer_diets_info[0]->staff_comments;
//					//echo '<pre>'; print_r($data);die;	
//				
                  
				    
				    
				            // echo "here we are Message Id is " . $customer_diets_info[0]->message_id; die;
				    
				    //if there the message Id is zero - that is because the user is a graduate - so we should display a random message
//				    if ($customer_diets_info[0]->message_id == 0)
//				    {
//				        $message_id = $this->common_model->getRandomMessageIdForGrad();
//				    }
//				    else
//				    {
//				        $message_id = $customer_diets_info[0]->message_id;
//				    }
//				    $data['message_id'] = $message_id;
				    
                                            //echo 'using message id of '. $message_id; 
//					$data['displaymessage']= $this->common_model->getCustomFielddata('messagecenterposttable','Message',array('MessageID'=>$message_id));

                                            //echo 'The message is ' .  $data['displaymessage'];

					

				/*	 $data['net_gram'] = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(m.Message) AS Message from messagecenterposttable as m left join customer_diets_plan as dm on m.MessageID = dm.netgram_id where dm.weeks = '.$customer_diets_info[0]->week_id.' and dm.customer_id = '.$customer_diets_info[0]->customer_id.' group by dm.netgram_id');*/


//			$gramcond=array('dm.weeks'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>$customer_diets_info[0]->customer_id);
//				$gramfield='(m.Message) AS Message';
//				$gramjoin=array(
//											array(
//												'join_table'=>'customer_diets_plan as dm',
//												'on_first_table'=>'m.MessageID',
//												'on_second_table'=>'dm.netgram_id'
//											));	
 //	 $data['net_gram']=  $this->common_model->getJoinData("messagecenterposttable as m",$gramcond,$gramfield,$gramjoin,'','','','','dm.netgram_id'); 



   /*  $data['lession_msg'] = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(m.Message) as Message from messagecenterposttable as m left join diets_plan_mapping as dm on m.MessageID = dm.admin_msg_id where dm.week_id = '.$customer_diets_info[0]->week_id.' and dm.customer_id = '.base64_decode($customerid).' group by dm.admin_msg_id');*/


//				$lesscond=array('dm.week_id'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>base64_decode($customerid));
//				$lessfield='ANY_VALUE(m.Message) as Message';
//				$lessjoin=array(
//											array(
//												'join_table'=>'diets_plan_mapping as dm',
//												'on_first_table'=>'m.MessageID',
//												'on_second_table'=>'dm.admin_msg_id'
//											));	
 	  
 	  
// 	  $data['lession_msg'] =  $this->common_model->getJoinData("messagecenterposttable as m",$lesscond,$lessfield,$lessjoin,'','','','','dm.admin_msg_id'); 



					//echo '<pre>';print_r($acknowment);die;
//					if(isset($acknowment[0]->acknowledgment) && ($acknowment[0]->acknowledgment==0)){
//						$data['acknow']=$acknowment[0]->acknowledgment;
//						$data['help']=$acknowment[0]->help;
//					}
//					if(isset($acknowment[0]->exercise_id) && ($acknowment[0]->exercise_id !=0)){
//						$data['exercise_id']=$acknowment[0]->exercise_id;
//					}
//					//$data['weight'] = $acknowment[0]->weight;
///					if(isset($acknowment[0]->weight) && (!empty($acknowment[0]->weight))){
//						$data['weight'] = $acknowment[0]->weight;
//					}
//					if(isset($acknowment[0]->steps) && (!empty($acknowment[0]->steps))){
//						$data['steps'] = $acknowment[0]->steps;
//					}
//					if($message_id !=0)
//					{ 
//					    $data['showmessage']= $data['displaymessage'];                                   //$this->common_model->getRows('messagecenterposttable', 'Message, MessageID', array('Messageid'=>$message_id));
//					}
//					//schedule date
//					$data['next_meeting']=$this->common_model->getRows('time_schedule','schedule_date,slottime,providerid',
//					array('customerid'=>$customer_diets_info[0]->customer_id));
//
					//schedule date
//					$data['exerciselst']=$this->common_model->getRows('exercise','id,exercise_name,status',
//					array('status'=>1));
//
//					$data['subscription_name'] = $this->common_model->getRows('subscriptionplan',
//					'id,name,price,description',array('status'=>'1',
//					'id !='=>$this->session->userdata('session_plan_id')));
//					$data['exit_questionnaire'] = $this->common_model->getRows('user','check_questionnaire',array('status'=>1,
//					'id ='=>base64_decode($customerid)));

  //                  $data['recipes']=$this->common_model->getRows('recipes','id, image, title, short_description', array('status'=>'1', 'week_id' => $realWeek));
                    
                    //echo '<pre>'; print_r($data);die;
//					$this->load->view('frontend/daily_dite_form_edit', $data);
//			}
//			else
//			{
//				redirect('/');
//			}

//		}
//		else
//		{
//				redirect('/');
//		}

	}
	public function find_state_by_country_id($country_id=0)
	{

		if(!empty($country_id)){
			$state = $this->common_model->getRows('state','state_id,country_id,state_name',array('status'=>'1','country_id'=>$country_id));
			$html="<option value=''>Please Select</option>";
			if(!empty($state)){ foreach($state as $state_val){
			if($country_id==$state_val->country_id){ $selected='selected'; }else{ $selected=''; }
			$html.="<option value='".$state_val->state_id."' ".$selected.">".$state_val->state_name."</option>";
			}}
		}
		echo $html;
	}
	public function find_state_by_state_id($state_id=0)
	{
		if(!empty($state_id)){
			$state = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1','state_id'=>$state_id));
			$html="<option value=''>Please Select</option>";
			if(!empty($state)){ foreach($state as $state_val){
			if($country_id==$state_val->country_id){ $selected='selected'; }else{ $selected=''; }
			$html.="<option value='".$state_val->state_id."' ".$selected.">".$state_val->state_name."</option>";
			}}
		}
		echo $html;
	}
	public function update_time_slot_calender(){
		//echo '<pre>'; print_r($this->input->post());die;
		 $timeslote = $this->input->post('timeslote');
		 $date =  date('d-m-Y');
		 $timeslote = date('Y-m-d',strtotime($timeslote));
	    if(strtotime($timeslote) < strtotime($date)) $timeslote = $date;
		$weekid = $this->input->post('weekid');
		$dayid = $this->input->post('dayid');
		//echo '<pre>'; print_r($this->input->post());die;

		 if(!empty($timeslote)){//&& !empty($weekid) && !empty($dayid)
						 $this->common_model->update_time_slot_calender($timeslote,$weekid,$dayid);exit;
					}
			}
	
	public function cancel_meeting()
	{
		$custinfo = $this->session->userdata('customers');
		//echo '<pre>'; print_r($custinfo);die;
		if(!empty($custinfo))
		{
        $today = date('Y-m-d');
		$custids =$this->input->post('custid');
		$time_schedule_data = $this->common_model->getRows('time_schedule','id,schedule_date,providerid,slottime',array('customerid'=>$custids,'status'=>1),'id','DESC');
		if(isset($time_schedule_data) && (!empty($time_schedule_data)))
		{
			$ccond=array('p.id'=>$time_schedule_data[0]->providerid);
			$cfield='u.emailid,u.first_name as providername';
			$cjoin=array(
				array(
				'join_table'=>'provider p',
				'on_first_table'=>'p.pcustid',
				'on_second_table'=>'u.id'
			));	
	 		$provider_email = $this->common_model->getJoinData("user u",$ccond,$cfield,$cjoin,'','','u.id','asc',''); 
		}
		$sc_date =@date('M d Y',strtotime($time_schedule_data[0]->schedule_date));
		$slote_time =@$time_schedule_data[0]->slottime;

		

			if($this->db->delete('time_schedule',array('customerid'=>$custids,'id'=>@$time_schedule_data[0]->id))){
				$data4 = array(
					'meeting_date' =>'0000-00-00 00:00:00'
				);
			$this->common_model->update("customer_diets_plan",$data4,
			array('customer_id'=>$this->input->post('custid'),'weeks'=>$this->input->post('num_weeks'),'week_wise_days'=>$this->input->post('week_wise_days')));

			$sub1= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>4,'status'=>1));
				//Email send to customer $custinfo->emailid

				$fname=$custinfo->first_name;
				$lname=$custinfo->last_name;
				if((isset($fname)) && ($fname !='') && ((isset($lname)) && $lname !=''))
				{
					$customername =$fname." ".$lname;
				}
				else
				{
					$customername =$fname;
				}
				
                /* Send email to the Customer to confirm cancellation */
				$this->common_model->commonMail(4,$sub1,$custinfo->emailid,'',@$slote_time,$sc_date,$customername);
				
				$sub11= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>11,'status'=>1));
				//Email send to provide $provider_email[0]->emailid
				/* Send email to the Staff provider when Customer cancels meeting */
				$this->common_model->commonMail(14,$sub11,$provider_email[0]->emailid,'',@$slote_time,$sc_date,$provider_email[0]->providername);


				echo 1;exit;
			}else{
				echo 0;exit;
			}

		}
		else
		{
			echo 2;exit;
		}
	   
	}
	public function update_time_schedule_data(){
		
		$custmess =$this->session->userdata('customers');
		if(!empty($custmess))
		{

		$cid = $this->session->userdata('customers')->id;
			$data = array(
				'customerid' => $this->input->post('custid'),
				'providerid' => $this->input->post('providerid'),
				'slotvalue' => $this->input->post('slotval'),
				'slottime' => $this->input->post('slottext'),
				'weekid' => $this->input->post('weekidd'),
				'dayid' => $this->input->post('dayidd'),
				'status' =>1,
				'schedule_date' =>date('Y-m-d',strtotime($this->input->post('appointmentdate'))),
				'created_date' =>date('Y-m-d'),
				'created_by' =>$cid
			);
			$data3 = array(
				'meeting_date' =>date('Y-m-d',strtotime($this->input->post('appointmentdate')))." ".$this->input->post('slottext')
			);

			/*==================Check Extra Metting ========================*/
                   $extra_meting=0;
                   $get_extra_from_userTable = $this->common_model->getCustomFielddata('user','extra_metting',array('id'=>$this->input->post('custid')));
                  	if($get_extra_from_userTable == 0)
                  	{
                  		$extra_metting = "SELECT ANY_VALUE(week_id) as week_id,ANY_VALUE(extra_metting) as extra_metting FROM diets_plan_mapping where customer_id =".$this->input->post('custid')." and week_id <=".$this->input->post('weekidd')." group by week_id,extra_metting";
							$total_extra = $this->common_model->solveCustomQuery($extra_metting);
							$coun_t=0;
							if(!empty($total_extra))
							{
								foreach($total_extra as $t_val)
								{
									$coun_t += $t_val->extra_metting;
								}
							}
							$extra_meting= $coun_t;
                  	}
                  	else
                  	{
                  		$extra_meting =$get_extra_from_userTable;
                  	}
            /*===========================Check Extra Metting ======================*/

			$alreadyval = $this->common_model->getRows('time_schedule','id',array('customerid'=>$this->input->post('custid'),'status'=>1),'id','DESC');

			$check_limit = $this->common_model->getRows('diets_plan_mapping','allowmeet_id',array('customer_id'=>$this->input->post('custid'),'week_id'=>$this->input->post('weekidd')),'id','DESC',0,1);

			$total_metting_limit = $extra_meting+$check_limit[0]->allowmeet_id;


			//
			/*$provider_emailId = "SELECT u.emailid,u.first_name as providename from user u left join provider p on p.pcustid = u.id where p.id = ".$this->input->post('providerid');
				$provider_email = $this->common_model->solveCustomQuery($provider_emailId);*/

			$updatecond=array('p.id'=>$this->input->post('providerid'));
			$updatefield='u.emailid,u.first_name as providename';
			$updatejoin=array(
											array(
												'join_table'=>'provider p',
												'on_first_table'=>'p.pcustid',
												'on_second_table'=>'u.id'
											));	
  $provider_email = $this->common_model->getJoinData("user u",$updatecond,$updatefield,$updatejoin,'','','u.id','asc',''); 


			$flag=0;
			 if($total_metting_limit > count($alreadyval))
			    {
			    	$return = $this->common_model->save('time_schedule',$data);
				    $this->common_model->update("customer_diets_plan",$data3,array('weeks'=>$this->input->post('weekidd')." ".$this->input->post('slottext'),'week_wise_days'=>$this->input->post('dayidd'),'customer_id'=>$this->input->post('custid')));
				    $flag=1;
					$sdate = date('M d Y',strtotime($this->input->post('appointmentdate')));
				    $stime = $this->input->post('slottext');


			    //$customername = $this->session->userdata('customers')->first_name;

			    $ffname=$this->session->userdata('customers')->first_name;
				$llname=$this->session->userdata('customers')->last_name;

				if((isset($ffname)) && ($ffname !='') && ((isset($llname)) && $llname !=''))
				{
					$customername =$ffname." ".$llname;
				}
				else
				{
					$customername =$ffname;
				}


			    $emailid = $this->session->userdata('customers')->emailid;
				//This is used for customer schedule mail

				$done_schedule_data = $this->common_model->getprovidername($cid);
								if(!empty($done_schedule_data))
								{
									$proname = $done_schedule_data;
								}

				$sub33= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>3,'status'=>1));	
				$this->common_model->commonMail(3,$sub33,$emailid,'',
					@$stime,@$sdate,$customername,$proname,$provider_email[0]->emailid);	

				//This is used for Admin schedule mail				
				$sub122= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>12,'status'=>1));
				$this->common_model->commonMail(15,$sub122,$provider_email[0]->emailid,'',
					@$stime,@$sdate,$customername,$proname,$emailid);

			    }
			    
			if($flag==1){
				echo 1;exit;
			}else{
				echo 0;exit;
			}

			}
			else
			{
				echo 2;exit;
			}
				
		}

public function time_schedule_data(){
			
			$custmess =$this->session->userdata('customers');

			if(!empty($custmess))
			{
			$cid = $this->session->userdata('customers')->id;
			$data = array(
				'customerid' => $this->input->post('custid'),
				'providerid' => $this->input->post('providerid'),
				'slotvalue' => $this->input->post('slotval'),
				'slottime' => $this->input->post('slottext'),
				'weekid' => $this->input->post('weekidd'),
				'dayid' => $this->input->post('dayidd'),
				'status' =>1,
				'schedule_date' =>date('Y-m-d',strtotime($this->input->post('appointmentdate'))),
				'created_date' =>date('Y-m-d'),
				'created_by' => $cid
			);

			$data3 = array(
				'meeting_date' =>date('Y-m-d',strtotime($this->input->post('appointmentdate')))." ".$this->input->post('slottext')
			);



				/*==================Check Extra Metting ========================*/
     $extra_meting=0;
     $get_extra_from_userTable = $this->common_model->getCustomFielddata('user','extra_metting',array('id'=>$this->input->post('custid')));
    	if($get_extra_from_userTable == 0)
    	{
    		$extra_metting = "SELECT ANY_VALUE(week_id) as week_id,ANY_VALUE(extra_metting) as extra_metting FROM diets_plan_mapping where customer_id =".$this->input->post('custid')." and week_id <=".$this->input->post('weekidd')." group by week_id,extra_metting";
							$total_extra = $this->common_model->solveCustomQuery($extra_metting);
							$coun_t=0;
							if(!empty($total_extra))
							{
								foreach($total_extra as $t_val)
								{
									$coun_t += $t_val->extra_metting;
								}
							}
							$extra_meting= $coun_t;
                  	}
                  	else
                  	{
                  		$extra_meting =$get_extra_from_userTable;
                  	}

     /*========================Check Extra Metting ======================*/
               
			$alreadyval = $this->common_model->getRows('time_schedule','id',array('customerid'=>$this->input->post('custid'),'status'=>1),'id','DESC');
			$check_limit = $this->common_model->getRows('diets_plan_mapping','allowmeet_id',array('customer_id'=>$this->input->post('custid'),'week_id'=>$this->input->post('weekidd')),'id','DESC',0,1);

			$total_metting_limit = $extra_meting+$check_limit[0]->allowmeet_id;

			$flag=0;

			/*$provider_emailId = "SELECT u.emailid,u.first_name as providename from user u left join provider p on p.pcustid = u.id where p.id = ".$this->input->post('providerid');
				$provider_email = $this->common_model->solveCustomQuery($provider_emailId);
				*/

			$provcond=array('p.id'=>$this->input->post('providerid'));
			$provfield='u.emailid,u.first_name as providename';
			$provjoin=array(
											array(
												'join_table'=>'provider p',
												'on_first_table'=>'p.pcustid',
												'on_second_table'=>'u.id'
											));	
  $provider_email = $this->common_model->getJoinData("user u",$provcond,$provfield,$provjoin,'','','u.id','asc',''); 

			 if($total_metting_limit > count($alreadyval))
			    {

								$return = $this->common_model->save('time_schedule',$data);
								$this->common_model->update("customer_diets_plan",$data3,array('weeks'=>$this->input->post('weekidd')." ".$this->input->post('slottext'),'week_wise_days'=>$this->input->post('dayid'),'customer_id'=>$this->input->post('custid')));
								$flag=1;
								$sdate = date('M d Y',strtotime($this->input->post('appointmentdate')));
								$stime = $this->input->post('slottext');

								$emailid= $this->session->userdata('customers')->emailid;

								$ffname=$this->session->userdata('customers')->first_name;
								$llname=$this->session->userdata('customers')->last_name;

								if((isset($ffname)) && ($ffname !='') && ((isset($llname)) && $llname !=''))
								{
								$customername =$ffname." ".$llname;
								}
								else
								{
								$customername =$ffname;
								}



								//This is used for customer schedule mail
								$done_schedule_data = $this->common_model->getprovidername($cid);
								if(!empty($done_schedule_data))
								{
									$proname = $done_schedule_data;
								}
								
								$sub33= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>3,'status'=>1));	
								$this->common_model->commonMail(3,$sub33,$emailid,'',
								@$stime,@$sdate,$customername,$proname,$provider_email[0]->emailid);	

								//This is used for Admin schedule mail				
								$sub122= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>12,'status'=>1));
								$this->common_model->commonMail(15,$sub122,$provider_email[0]->emailid,'',
								@$stime,@$sdate,$customername,$proname,$emailid);
			
			    }


			if($flag==1)
				{
					echo 1;exit;
				}
				else
				{
					echo 0;exit;
				}

			}
			else
			{
				echo 2;exit;
			}
		}
		
		
	public function daily_dite_log_details_Test($page=0)
	{
		//user either clicks the Diaeta Log menu item, or they were redirected to this page after entering 
		// data in their Daily Tracker
		/**********************************************/
        echo 'made it here';
		$segment='';
		$segment = $this->session->userdata('customers')->id;
		echo 'In View and segment is '. $segment;
		
		$sql = "SELECT customer_diets_plan_id 
                    FROM customer_diets_plan_desc 
                    WHERE customer_diets_plan_id 
                        IN (SELECT id FROM  customer_diets_plan WHERE customer_id ='" . $segment . "') 
                        
                        GROUP BY (customer_diets_plan_id) 
                        ORDER BY COUNT( diet_plan_id ) DESC limit 1";
                        
		$max_cust_data = $this->common_model->solveCustomQuery($sql);
		echo '$max_cust_data = <pre>'; print_r($max_cust_data);
		//What do we do with max_cust_data??
		
		/* Billy - Changed to sort by a new column called sort_order, used ot be 'status' */
		$data['dynamic_menu'] = $this->common_model->getRows('dynamicDietslog', '*', array('tbl_status'=>1,) , 'sort_order', 'asc');
		
		//echo 'Dynamic_menu is <pre>'; print_r($data['dynamic_menu']);
		
		
		if(isset($max_cust_data) && !empty($max_cust_data))
		{
			$customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
			echo '$customer_diets_plan_id is '. $customer_diets_plan_id;
			
			$qry_diet_plan_id=array();
			
			$scond=array('customer_diets_plan_desc.customer_diets_plan_id'=>$customer_diets_plan_id);
			$sfield='ANY_VALUE(dietsplan.diet_name) as diet_name, ANY_VALUE(dietsplan.id) as dietsplan_id, ANY_VALUE(input_type) AS input_type, ANY_VALUE(dietsplan.log_detail_label) AS log_detail_label';
			$sjoin=array(
						array(
							'join_table'=>'dietsplan',
							'on_first_table'=>'dietsplan.id',
							'on_second_table'=>'customer_diets_plan_desc.diet_plan_id'
						));
						
			$data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc", $scond, $sfield, $sjoin, '', '', 'ANY_VALUE(dietsplan.display_order)', 'asc', 'dietsplan.log_detail_label');
			//echo 'The Diet_label contains <pre>'; print_r($data['diet_label']); die;
		}

		/*************************************************/

		$startDate='';
		$endDate='';
		$cond='';
		$submit = $this->input->post('submit');
		
		echo '<br> $submit is ' . $submit; 
		
		$custid=''; 
		$custid= $this->session->userdata('customers')->id;
                                            //echo 'Inside daily_dite_log_details and CustId = '. $custid; die;
        $data['custid'] = $custid;
		$data['startDate']=$startDate = $this->input->post('startDate');
		$data['endDate']=$endDate = $this->input->post('endDate');

        echo '<br> custid is ' . $data['custid']; 
        echo '<br> startDate is ' . $data['startDate'];
        echo '<br> endDate is ' . $data['endDate'];
    

		if($submit !='')
		{
			if($startDate !='' && $endDate !='')
			{
				$cond=" date(c.created_date)>='".date('Y-m-d',strtotime($startDate))."'
						   AND date(c.created_date)<='".date('Y-m-d',strtotime($endDate))."'";
			}
			elseif($startDate !='')
			{
				$cond=" date(c.created_date)>='".date('Y-m-d',strtotime($startDate))."'";
			}
			elseif($endDate !='')
			{
				$cond=" date(c.created_date)<='".date('Y-m-d',strtotime($startDate))."'";
			}
			if(!empty($cond))
			{
					$cond="and " . $cond;
			}
		}
			
		$data['act'] = base_url('home/daily_dite_log_details');

		if((bool)$this->session->userdata('payment_status')==FALSE)
		{
			redirect('home/subscription');
			exit();
		}
		
		if(!empty($custid))
		{
    		$page_id=$this->input->get('page_id');
    		$limit = 250;
    		
    		if (isset($_GET["pageno"])) 
    		{
    		    $page  = base64_decode($_GET["pageno"]);
			} 
			else 
			{
				$page=1;
			};

			$start_from = ($page-1) * $limit;
		
			$photo_data= "SELECT c.id,
			                        c.week_wise_days,
			                        c.customer_id,
			                        c.meeting_date,
			                        c.comments,c.weeks,
			                        c.weight,
			                        c.created_date,
			                        c.staff_comments,
			                        c.created_by,
			                        c.updated_by,
			                        c.steps,
			                        e.exercise_name	
			                        from customer_diets_plan as c 
			                        left join exercise as e on c.exercise_id=e.id 
			                        
			                        WHERE c.customer_id=".$custid."  ".$cond." 
			                        ORDER BY c.weeks DESC, c.week_wise_days desc 
			                        LIMIT " . $start_from . "," . $limit . "";
			  
			  
			echo '$photo_data is ' . $photo_data; die;                        
			$data['rec']= $this->common_model->solveCustomQuery($photo_data);

					/*$logdetaildata="c.id1,c.week_wise_days,c.customer_id,c.meeting_date,c.comments,c.weeks,c.weight,c.created_date,c.staff_comments,c.created_by,c.updated_by,c.steps,e.exercise_name";
					$logcond=array('c.customer_id'=>$custid." ".$cond);
					$logjoin=array(
					array(
						'join_table'=>'exercise as e',
						'on_first_table'=>'c.exercise_id',
						'on_second_table'=>'e.id'
					));	

					$data['rec'] = $this->common_model->getJoinData("customer_diets_plan as c",$logcond,$logdetaildata,$logjoin,$start_from,$limit,'',
					'asc','c.weeks,c.week_wise_days');*/

                    //echo '<pre>'; print_r($data['rec']); die;


					if(!empty($data['rec'][0]->weeks)){
						$data['weekno']=$data['rec'][0]->weeks;
					}

					$data['total_pages']='';
					//$data['pid']=$page;
					$total_get_sql = "SELECT count(*) as total FROM customer_diets_plan where customer_id='".$custid."'";
					$total_get = $this->common_model->solveCustomQuery($total_get_sql);
					if(isset($total_get[0]->total) && !empty($total_get[0]->total)){
					$total_records=$total_get[0]->total;
					$data['total_pages'] = ceil($total_records / $limit);
					$data['start']=$start_from;
					$data['totalrecords']=$total_records;
					}
					$max_cust_data = $this->common_model->solveCustomQuery("
									SELECT customer_diets_plan_id
									FROM customer_diets_plan_desc
									WHERE customer_diets_plan_id
									IN (

									SELECT id
									FROM  `customer_diets_plan`
									WHERE customer_id ='".$custid."'
									)
									GROUP BY (
									customer_diets_plan_id
									)
									ORDER BY COUNT( diet_plan_id ) DESC limit 1
								");
			if(isset($max_cust_data[0]->customer_diets_plan_id) && !empty($max_cust_data[0]->customer_diets_plan_id)){
			$customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
			$qry_diet_plan_id=array();
			

/*
			$qry_diet_plan_id = "SELECT dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type FROM customer_diets_plan_desc  join dietsplan on dietsplan.id=customer_diets_plan_desc.diet_plan_id
			where customer_diets_plan_desc.customer_diets_plan_id = '".$customer_diets_plan_id."' order by display_order asc";

			$data['diet_label']= $this->common_model->solveCustomQuery($qry_diet_plan_id);*/

			/*	$scond=array('customer_diets_plan_desc.customer_diets_plan_id'=>$customer_diets_plan_id);
				$sfield='dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type';
				$sjoin=array(
												array(
													'join_table'=>'dietsplan',
													'on_first_table'=>'dietsplan.id',
													'on_second_table'=>'customer_diets_plan_desc.diet_plan_id'
												));	
				$data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc",$scond,$sfield,$sjoin,'','','',
				'asc','');
			*/



				foreach($data['diet_label'] as $keys=>$values){             //echo '<pre>';print_r();die;
					$mappid[] =$values->dietsplan_id;
				}
			}
				if(isset($mappid) && !empty($mappid)){
					$data['all_diet_id']=$mappid;
				}
				$data['cust_id']= $custid;
				$data['cust_registration_date']=$this->common_model->getRow('user','registration_date',array('id'=>$custid));
				
				//echo '<pre>';print_r($data);die;
				$this->load->view('frontend/daily_dite_log_details',$data);
		}else{
			redirect('/');
			}
	}
		
		
		
	public function daily_dite_log_details($page=0)
	{

	   // echo '$page is ' . $page;
		//user either clicks the Diaeta Log menu item, or they were redirected to this page after entering 
		// data in their Daily Tracker
		/**********************************************/
        
		$segment='';
		$segment = $this->session->userdata('customers')->id;
		//echo 'In View and segment is '. $segment; die;
		$max_cust_data = $this->common_model->solveCustomQuery("SELECT customer_diets_plan_id FROM customer_diets_plan_desc WHERE customer_diets_plan_id IN (SELECT id FROM  `customer_diets_plan` WHERE customer_id ='".$segment."') GROUP BY (customer_diets_plan_id) ORDER BY COUNT( diet_plan_id ) DESC limit 1");
		
		
		/* Billy - Changed to sort by a new column called sort_order, used ot be 'status' */
		$data['dynamic_menu'] = $this->common_model->getRows('dynamicDietslog','*',array('tbl_status'=>1,),'sort_order','asc');
			if(isset($max_cust_data) && !empty($max_cust_data))
			{
				$customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
				$qry_diet_plan_id=array();
				$scond=array('customer_diets_plan_desc.customer_diets_plan_id'=>$customer_diets_plan_id);
				$sfield='ANY_VALUE(dietsplan.diet_name) as diet_name,ANY_VALUE(dietsplan.id) as dietsplan_id,ANY_VALUE(input_type) AS input_type,ANY_VALUE(dietsplan.log_detail_label) AS log_detail_label';
				$sjoin=array(
							array(
								'join_table'=>'dietsplan',
								'on_first_table'=>'dietsplan.id',
								'on_second_table'=>'customer_diets_plan_desc.diet_plan_id'
							));	
				$data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc",$scond,$sfield,$sjoin,'','','ANY_VALUE(dietsplan.display_order)',
				'asc','dietsplan.log_detail_label');
			}

		/*************************************************/

		$startDate='';$endDate='';
		$cond='';
		$submit = $this->input->post('submit');
		$custid=''; $custid= $this->session->userdata('customers')->id;
        //echo 'Inside daily_dite_log_details and CustId = '. $custid; die;
        $data['custid'] = $custid;

			$data['startDate']=$startDate = $this->input->post('startDate');
			$data['endDate']=$endDate = $this->input->post('endDate');


			if($submit !=''){
				if($startDate !='' && $endDate !=''){
					$cond=" date(c.created_date)>='".date('Y-m-d',strtotime($startDate))."'
							   AND date(c.created_date)<='".date('Y-m-d',strtotime($endDate))."'";
				}elseif($startDate !=''){
					$cond=" date(c.created_date)>='".date('Y-m-d',strtotime($startDate))."'";
				}elseif($endDate !=''){
					$cond=" date(c.created_date)<='".date('Y-m-d',strtotime($startDate))."'";
				}
				if(!empty($cond)){
						$cond="and ".$cond;
				}
			}
			
			$data['act'] = base_url('home/daily_dite_log_details');

		if((bool)$this->session->userdata('payment_status')==FALSE)
		{
			redirect('home/subscription');
			exit();
		}
		if(!empty($custid)){
				$page_id=$this->input->get('page_id');
				$limit = 250;
				if (isset($_GET["pageno"])) {
				$page  = base64_decode($_GET["pageno"]);

				} else {
					$page=1;
					};

					$start_from = ($page-1) * $limit;
				
					$photo_data= "SELECT   c.id,c.week_wise_days,c.customer_id,c.meeting_date,c.comments,c.weeks,c.weight,c.created_date,c.staff_comments,c.created_by,c.updated_by,c.steps,e.exercise_name	from customer_diets_plan as c left join exercise as e on c.exercise_id=e.id WHERE c.customer_id=".$custid."  ".$cond."  ORDER BY c.weeks DESC,c.week_wise_days desc LIMIT ".$start_from.",".$limit."";
					$data['rec']= $this->common_model->solveCustomQuery($photo_data);

					/*$logdetaildata="c.id1,c.week_wise_days,c.customer_id,c.meeting_date,c.comments,c.weeks,c.weight,c.created_date,c.staff_comments,c.created_by,c.updated_by,c.steps,e.exercise_name";
					$logcond=array('c.customer_id'=>$custid." ".$cond);
					$logjoin=array(
					array(
						'join_table'=>'exercise as e',
						'on_first_table'=>'c.exercise_id',
						'on_second_table'=>'e.id'
					));	

					$data['rec'] = $this->common_model->getJoinData("customer_diets_plan as c",$logcond,$logdetaildata,$logjoin,$start_from,$limit,'',
					'asc','c.weeks,c.week_wise_days');*/

                    //echo '<pre>'; print_r($data['rec']); die;


					if(!empty($data['rec'][0]->weeks)){
						$data['weekno']=$data['rec'][0]->weeks;
					}

					$data['total_pages']='';
					//$data['pid']=$page;
					$total_get_sql = "SELECT count(*) as total FROM customer_diets_plan where customer_id='".$custid."'";
					$total_get = $this->common_model->solveCustomQuery($total_get_sql);
					if(isset($total_get[0]->total) && !empty($total_get[0]->total)){
					$total_records=$total_get[0]->total;
					$data['total_pages'] = ceil($total_records / $limit);
					$data['start']=$start_from;
					$data['totalrecords']=$total_records;
					}
					$max_cust_data = $this->common_model->solveCustomQuery("
									SELECT customer_diets_plan_id
									FROM customer_diets_plan_desc
									WHERE customer_diets_plan_id
									IN (

									SELECT id
									FROM  `customer_diets_plan`
									WHERE customer_id ='".$custid."'
									)
									GROUP BY (
									customer_diets_plan_id
									)
									ORDER BY COUNT( diet_plan_id ) DESC limit 1
								");
			if(isset($max_cust_data[0]->customer_diets_plan_id) && !empty($max_cust_data[0]->customer_diets_plan_id)){
			$customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
			$qry_diet_plan_id=array();
			

/*
			$qry_diet_plan_id = "SELECT dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type FROM customer_diets_plan_desc  join dietsplan on dietsplan.id=customer_diets_plan_desc.diet_plan_id
			where customer_diets_plan_desc.customer_diets_plan_id = '".$customer_diets_plan_id."' order by display_order asc";

			$data['diet_label']= $this->common_model->solveCustomQuery($qry_diet_plan_id);*/

			/*	$scond=array('customer_diets_plan_desc.customer_diets_plan_id'=>$customer_diets_plan_id);
				$sfield='dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type';
				$sjoin=array(
												array(
													'join_table'=>'dietsplan',
													'on_first_table'=>'dietsplan.id',
													'on_second_table'=>'customer_diets_plan_desc.diet_plan_id'
												));	
				$data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc",$scond,$sfield,$sjoin,'','','',
				'asc','');
			*/



				foreach($data['diet_label'] as $keys=>$values){             //echo '<pre>';print_r();die;
					$mappid[] =$values->dietsplan_id;
				}
			}
				if(isset($mappid) && !empty($mappid)){
					$data['all_diet_id']=$mappid;
				}
				$data['cust_id']= $custid;
				$data['cust_registration_date']=$this->common_model->getRow('user','registration_date',array('id'=>$custid));
				
				//echo '<pre>';print_r($data);die;
				$this->load->view('frontend/daily_dite_log_details',$data);
		}else{
			redirect('/');
			}
	}

//This function is used to search daily diet data on front end
	public function search_daily_diet_log()
	{

			$from_date = $this->input->post('from_date');
			$to_date = $this->input->post('to_date');
			

		/*	$search_daily_diet_log= "SELECT id,week_wise_days, customer_id, meeting_date, comments,weeks,weight,dietsd.created_date,staff_comments,created_by,updated_by	FROM customer_diets_plan as dietsd where customer_id='".$custid."' and date(dietsd.created_date)>='".date('Y-m-d',strtotime($from_date))."' and date(dietsd.created_date)<='".date('Y-m-d',strtotime($to_date))."' ORDER BY id desc";
			$data['rec']= $this->common_model->solveCustomQuery($search_daily_diet_log);*/

$selectdata ='SELECT id,week_wise_days, customer_id, meeting_date, comments,weeks,weight,dietsd.created_date,staff_comments,created_by,updated_by';
$searchcond=array('customer_id'=>$custid,'date(dietsd.created_date)>='=>date('Y-m-d',strtotime($from_date)),'date(dietsd.created_date)<='=>date('Y-m-d',strtotime($to_date)));

$data['rec']= $this->common_model->getRows('customer_diets_plan',$selectdata,$searchcond);



/*			$total_get_sql = "SELECT count(*) as total FROM customer_diets_plan where customer_id='".$custid."'";
			$total_get = $this->common_model->solveCustomQuery($total_get_sql);*/
$total_get = $this->common_model->getRows('customer_diets_plan','count(*) as total',array('customer_id'=>$custid));



			if(isset($total_get[0]->total) && !empty($total_get[0]->total)){
			$total_records=$total_get[0]->total;
			$data['total_pages'] = ceil($total_records / $limit);
			}

			$max_cust_data = $this->common_model->solveCustomQuery("
								SELECT customer_diets_plan_id
								FROM customer_diets_plan_desc as dietdesd
								WHERE customer_diets_plan_id
								IN (
								SELECT id
								FROM  `customer_diets_plan`
								WHERE customer_id ='".$custid."' and date(dietdesd.created_date)>='".date('Y-m-d',strtotime($from_date))."' and date(dietdesd.created_date)<='".date('Y-m-d',strtotime($to_date))."'
								)
								GROUP BY (
								customer_diets_plan_id
								)
								ORDER BY COUNT( diet_plan_id ) DESC limit 1
							");
		
			if(isset($max_cust_data[0]->customer_diets_plan_id) && !empty($max_cust_data[0]->customer_diets_plan_id))
			{
			$customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
			$qry_diet_plan_id=array();

		/*	$qry_diet_plan_id = "SELECT dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type FROM customer_diets_plan_desc  join dietsplan on dietsplan.id=customer_diets_plan_desc.diet_plan_id where customer_diets_plan_desc.customer_diets_plan_id
			= '".$customer_diets_plan_id."' order by display_order asc";
			$data['diet_label']= $this->common_model->solveCustomQuery($qry_diet_plan_id);*/

			//Conditions---------------------
			$scond=array('customer_diets_plan_desc.customer_diets_plan_id'=>$customer_diets_plan_id);
			$sfield='dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type';
			$sjoin=array(
										array(
											'join_table'=>'dietsplan',
											'on_first_table'=>'dietsplan.id',
											'on_second_table'=>'customer_diets_plan_desc.diet_plan_id'
										));	
			$data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc",$scond,$sfield,$sjoin,'','','',
			'asc','display_order');

   	//End Conditions---------------------


				foreach($data['diet_label'] as $keys=>$values)
				{
					$mappid[] =$values->dietsplan_id;
				}
			}
			if(isset($mappid) && !empty($mappid)){
				$data['all_diet_id']=$mappid;
			}
	}


	//This function is used to diaplay content on home page
	public function homepage($page=0)
	{
			$page_id=$this->input->get('page_id');
			
			$data['page_data']=$this->common_model->getRows("page","*",array("page_status"=>1,"page_id"=>base64_decode($page_id)));
			//print_r($data['page_data']);exit;

			if(!empty($data['page_data']))
			{
					if(isset($data['page_data']) && (!empty($data['page_data'])))
					{
						$data['page_data']=$this->common_model->getRows("page","*",array("page_status"=>1,"page_id"=>base64_decode($page_id)));
					}
					else
					{
						$data['recordnotfound']=$this->recordnotfound();
					}
					$this->load->view('frontend/homepage',$data);
					}
					else
					{
							redirect('/');
					}
	}
	//This function is diaplay all customer message list
	public function customer_message()
	{
		$custmess = $this->session->userdata('customers');
		//print_r($custmess);die;
		if(empty($custmess))
		{
			redirect('/');
		}
		else
		{
		$updatedata = array
		(
				'weeks' => $this->input->post('num_weeks'),
				'week_wise_days' => $this->input->post('week_wise_days'),
				'customer_id' => $this->input->post('customerid')
			);
			$page_id=$this->input->get('page_id');
			$limit = 15;
			if (isset($_GET["pageno"]))
			{
					$page  = base64_decode($_GET["pageno"]);
			} 
			else
			{
						$page=1;
			}

			$start_from = ($page-1) * $limit;

  		//First query
		$cond=array('cdp.customer_id'=>@$this->session->userdata('customers')->id);
		$field='ANY_VALUE( m.Message) as Message,ANY_VALUE(cdp.acknowledgment) as acknowledgment ,ANY_VALUE(cdp.message_id) as message_id,ANY_VALUE(cdp.weeks) as week_id,ANY_VALUE(cdp.week_wise_days) as day_id';
		$join=array(
											array(
												'join_table'=>'messagecenterposttable as m',
												'on_first_table'=>'m.MessageID',
												'on_second_table'=>'cdp.message_id'
											));		  
		$data['rec'] = $this->common_model->getJoinData("customer_diets_plan as cdp",$cond,$field,$join,$limit,$start_from,'',
		'DESC','message_id');
		
	
if(!empty($custmess))
{
	$cond2=array('d.customer_id'=>$this->session->userdata('customers')->id);
	$field2='count(distinct message_id) as total';
	$join2=array(			array(
									'join_table'=>'messagecenterposttable as m',
									'on_first_table'=>'m.MessageID',
									'on_second_table'=>'d.message_id'
								));

$total_get_sql= $this->common_model->getJoinData("customer_diets_plan as d",$cond2,$field2,$join2,$limit,$start_from,'',
'DESC','message_id');

$total_get = $total_get_sql;

	if(!empty($total_get))
	{
				$total_records=$total_get[0]->total;
				$data['total_pages'] = ceil($total_records / $limit);
	}
}
$this->load->view('frontend/customer_message',$data);
}
}

 //This function is used to confirm acknowledgement
	public function update_acknowledgement()
	{
			$updatedata = array
			(
					'weeks' => $this->input->post('num_weeks'),
					'week_wise_days' => $this->input->post('week_wise_days'),
					'customer_id' => $this->input->post('customerid')
				);
				$data = array
				(
					'acknowledgment' =>1
				);
			$update= $this->common_model->update("customer_diets_plan",$data,$updatedata);
			if(!empty($update))
			{
				echo 1;exit;
			}
			else
			{
				echo 0;exit;
			}
	}	
//This function is used to get create date of cutomer
	public function next_day_start_session()
	{
		$finalval =$this->common_model->next_day_start_session();
		if($finalval==0)
		{
		    //echo "now we are her"; die;
			//redirect('profile');                  //let's see what happens 
		}
	}

		//This function is used for additional profile page
	public function check_additional_profile()
	{
		$customer_id=$this->session->userdata('customers')->id;
		$customer_data =$this->common_model->getRows("user","weight",array("id"=>$customer_id));
		//print_r($customer_data);
		if(empty($customer_data))
		{
		    //echo 'We are here'; die;
			redirect('additional-profile');
		}
	}

	//This function is used to verify the mail
	public function verify_email()
	{
			$email=$this->input->get('email');
			$hash=$this->input->get('hash');
			$udata=array("active" =>1,"verified_date"=>date('Y-m-d H:i:s'));
			$cust_data=$this->common_model->getRows("user","*",array("emailid"=>$email));
			if($cust_data)
			{
					if($cust_data[0]->hash==$hash && $cust_data[0]->active==0)
					{
						$activate = $this->common_model->update('user', $udata, $cond=array("emailid"=>$email));
						$this->msg = array('msg'=>'Your account has been activated, you can now login', 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
						$this->load->view('frontend/sign-up');
					}
					else
					{
						$this->msg = array('msg'=>'The url is either invalid or you already have activated your account.', 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
						$this->load->view('frontend/sign-up');
					}
		}
	}

	//This function is used to show contact us page
	public function contactus()
	{
			$this->load->view('frontend/contactus');
 }
	//This function is used to save contact us data	
	public function savecontactus()
	{
			$config = array(
					array(
						'field' => 'firstname',
						'label' => 'first name',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => 'Please enter %s.',
						),
				    ),
					array(
						'field' => 'emailid',
						'label' => 'Email id',
						'rules' => 'trim|required|valid_email',
						'errors' => array(
								'required' => 'Please enter %s.',
						),
				    ),
			);

			$this->form_validation->set_rules($config);
			if($this->form_validation->run() == false)
				{
					return $this->contactus();
				}
				else
				{
					$url="https://www.google.com/recaptcha/api/siteverify";
    				$secret='6LfVHuUUAAAAAMIpKQS_jDG03CsWHL-YvZgQXypT';
    				$recaptcha = $_POST['g-recaptcha-response'];
    				$post_field = array('secret'=>$secret,'response'=>$recaptcha);
    				$ch=curl_init();  
         			curl_setopt($ch, CURLOPT_HEADER, 0); 
			        curl_setopt($ch, CURLOPT_VERBOSE, 0);  
			        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  
			        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  
			        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); 
			        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');  
			        $url.='?'.http_build_query($post_field); 
			        curl_setopt($ch, CURLOPT_URL, $url);
			        $response=curl_exec($ch); 
			        curl_close($ch); 
			        $res_arr = json_decode($response,true);
    				if($res_arr['success'] == 1){
    					$data = array(
					'firstname' => $this->input->post('firstname'),
					'lastname' => $this->input->post('lastname'),
					'emailid' => $this->input->post('emailid'),
					'mobileno' => $this->input->post('mobileno'),
					'description' =>$this->input->post('description'),
					'created_date' => date('Y-m-d H:i:s'),
					'status' => '1'
				);

					if((bool)$this->common_model->save('contactus',$data) === TRUE)
					{
						//$to = 'p9006614336@gmail.com';
						$to = 'info@wellnessfromfood.com';
						$message ="<p><strong>First Name</strong> : ".$this->input->post('firstname')."</p><p><strong>Last Name</strong> : ".$this->input->post('lastname')."</p><p><strong>Email Id</strong> : ".$this->input->post('emailid')."</p><p><strong>Mobile</strong> : ".$this->input->post('mobileno')."</p><p><strong>Description</strong> : ".$this->input->post('description');
						
						$subject = "Contact us";

						$this->common_model->Send_GetStarted_Mail(array('to'=>$to,'subject'=>$subject,'msg'=>$message));
					
						$this->msg = array('msg'=>'Thank you for contact us.', 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
						redirect('home/contactus');
					}
					else
					{	$this->msg = array('msg'=>$this->lang->line('RECORD_ERROR'), 'msg_type'=>'danger');
						$this->session->set_flashdata($this->msg);
						redirect('home/contactus');
					}
    				}
			}
		}

		//This function is used to check user availability
		public function checkuser_availability()
		{
					$checkemailid = $this->input->post('emailid');
					$query = $this->db->query("select id from user where emailid='".$checkemailid."' and user_type=1");
					$res = $query->result();
					$row = $res[0];
					if(!empty($row))
					{
						echo 1; exit;
					}else
					{
						echo 0; exit;
					}
		}

		//This is used to send password mail
	 public function PasswordMail($emailid)
	  {
				$password=$this->randomPassword();
				$md = 	$this->hash_password($password);
				$udata=array("password" =>$md);
				$cust_data=$this->common_model->getRows("user","first_name",array("emailid"=>$emailid));
				$data['sendpass'] =$password;
				$data['email'] =$emailid; //'gla.anilgupta88@gmail';//
				$name=ucwords(strtolower($cust_data[0]->first_name));
				$data['customer_name']=$name;
				$status = '';
				$updatepass="";
				//$updatepass = $this->common_model->update('user', $udata, $cond=array("emailid"=>$emailid));
			if($updatepass)
			{
						$message=$this->load->view('frontend/email/forgot_password',$data,true);
						$subject=$name.',Wellness From Food';
						$to = $emailid;
						$this->common_model->Send_GetStarted_Mail(array('to'=>$to,'subject'=>$subject,'msg'=>$message));
			}
}


	//This is used for password hashing code 
	private function hash_password($password)
	{
		return password_hash($password, PASSWORD_BCRYPT);
	}
	public function randomPassword()
	 {
				$alphabet = "abcdefghijklmnopqrstuwxyz@#!$0123456789";
				$pass = array();
				$alphaLength = strlen($alphabet) - 1;
				for ($i = 0; $i <= 6; $i++)
				 {
						$n = rand(0, $alphaLength);
						$pass[] = $alphabet[$n];
				}
				return implode($pass);
	}

//This test mail code
	public function test()
	{
		$maildata= array(
			'emailid'=>"gla.anilgupta88@gmail.com",
			'full_name'=>"Anil Gupta",
			'contact_no'=>9006614336,
			'price'=>500);
		$user_data= $this->common_model->getRows('user','type,hash',array('emailid'=>$maildata['emailid']));
		$data['hash']=$user_data[0]->hash;
		$data['type']=$user_data[0]->type;
		$password=$this->randomPassword();
		$md = 	$this->hash_password($password);
		$udata=array("password" =>trim($md));
		$data['sendpass'] =$password;
		$data['email'] =$maildata['emailid']; //'gla.anilgupta88@gmail';//
		$data['full_name']=$name=ucwords(strtolower($maildata['full_name']));
		$data['customer_name']=$name;
		$data['contact_no'] =$maildata['contact_no'];
		$data['price']=$maildata['price'];
		$massege = $this->load->view('frontend/email/welcomeEmail',$data,true);
		$subject ="Wellness";
		$email_dat = array(
							'to'=>"cchaubey55@gmail.com",
							'subject'=>$subject,
							'msg'=>$massege);
		$res = $this->common_model->Send_GetStarted_Mail($email_dat);
		echo $res;
	}


 //This function is show subscription message
	public function subsuscriptionmsg()
	{
		$id = $this->input->post('id');
		$msgname= $this->common_model->getRows('subscriptionmsg','messagename',array('id'=>$id));
		if(!empty($msgname))
				{
					echo "<h6>".$msgname[0]->messagename."</h6>"; exit;
				}
	}

	public function testimonials(){
		    $data['testimonial_data'] = $this->common_model->getRows('testimonials','testimonial_id,testimonial_name,testimonial_description,testimonial_image,created_date',array('testimonial_status'=>'1'),'display_order','asc');
			$this->load->view('frontend/testimonials',$data);
		}
	public function testimonial_details(){
			$testimonial_id =  $this->uri->segment(3);
			$data['testimonial_details'] = $this->common_model->getRow('testimonials','testimonial_name,testimonial_description,testimonial_image,created_date',array('testimonial_id'=>base64_decode($testimonial_id)));
			if(!empty($data['testimonial_details']))
			{
				$this->load->view('frontend/single_testimonial',$data);
			}
			else
			{
				redirect('/');
			}

		}
	public function mail_tt(){
		
		$to = array("Chandra"=>"cchaubey55@gmail.com","chaubey"=>"p9006614336@gmail.com");
		$a=array();
		foreach($to as $k=>$y){
			$b = array("email"=>$y,"name"=>$k);
			$a[]=$b;
		}
		$subject = "Need to contact customer – WellnessFromFood";
		$msg = "this is test mail";

		$mail_data = array(
  					'sender' => array(
    							'name' => 'WellnessFromFood',
    							'email' => 'info@wellnessfromfood.com'),
  					'to' => $a,
  					'htmlContent' => $msg,
  					'textContent' => $msg,
  					'subject' => $subject,
  					//'replyTo' => ,
  					'tags' => array(array('Wellness'))
  				);

		  $curl = curl_init();
		  curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://api.sendinblue.com/v3/smtp/email",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => json_encode($mail_data),
		  CURLOPT_HTTPHEADER => array("Content-Type: application/json","api-key: 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",
		    "cache-control: no-cache"),));

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		print_r($response);
	}

	public function update_menuStatus()
	{
		$val = $this->input->post('val');
		if(!empty($val)){
			$this->common_model->update('dynamicDietslog',array('status'=>0),array('tbl_status'=>1));
		$sql = "UPDATE dynamicDietslog SET status = 1 WHERE id IN (".$val.")";
		$result = $this->common_model->mauti_update($sql);
		echo $result;
	}else{
		echo 2;
	}
		
		
	}

	public function recipes(){
	    $data['blogs_name'] = $this->common_model->getRows('recipes','id,title,short_description,image,created_date',array('status'=>'1','type'=>1),'display_order','asc');
	    $data['recipe'] = true;
		$this->load->view('frontend/blogs',$data);
	}
	public function recipe_details()
	{
		$this->load->library('user_agent');
		$data['previous_url'] = $this->agent->referrer();
		$blogid =  $this->uri->segment(3);
		$data['recipe_details'] = $this->common_model->getRows('recipes','*',array('id'=>base64_decode($blogid)));
		if(!empty($data['recipe_details']))
		{
			$this->load->view('frontend/single_recipe',$data);
		}
		else
		{
			redirect('/');
		}
	}

	public function check_couponCode(){
		$plan = $this->input->post('plan');
		$coupon = $this->input->post('coupon');
		$data = $this->common_model->getRow('subscriptionplan','id,coupon_code',array('id'=>$plan));
		if(!empty($data)) {
			if(trim($coupon) === trim($data->coupon_code)){
				echo true;
			}else{
				echo false;
			}

		}else{
			 echo false;
		}
		

	}
	public function synk(){
		$data = $this->common_model->getRows('user','created_date,id');
		foreach($data as $value){
			$new =  array('registration_date'=>$value->created_date." 00-00-00");
			$this->common_model->update('user',$new,array('id'=>$value->id));
		}
	}

	
	

	
}
