<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller
{	
	/*public function index()
	{
		

      /* $checksession= $this->session->userdata('customers');
        if(empty($checksession))
        {
        	redirect('/');
        }
        else
        {*/
				/*$getDate = $this->common_model->solveCustomQuery("SELECT created_date FROM customer_diets_plan where customer_id=".$checksession->id." order by created_date desc limit 1");
				$getDate = $this->common_model->solveCustomQuery("SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(created_date) as created_date FROM `customer_diets_plan` group by customer_id desc");

				echo '<pre>'; print_r($getDate);die;
				if(!empty($getDate))
				{
					foreach($getDate as $k=>$val)
					{
						$getDateval = $val->created_date;					
						$currentDate = date('Y-m-d H:i:s');
						$previousDate = $getDateval;
						$diff = strtotime($currentDate) - strtotime($previousDate);
						$days = ceil(($diff)/ (60*60*24));
						//print_r($days."<br>");

						if($days ==4)
						{ 
							$email_dat = array
							(
							'to'=>"gla.anilgupta88@gmail.com",
							'subject'=>date('Y-m-d H:i:s'),
							'msg'=>"days: ".$days."  customer_id : ".$val->customer_id ."created_date : ".$val->created_date
							);

							$this->common_model->Send_GetStarted_Mail($email_dat);
						}
						else
						{
							//cron should not be work
						}

					}

	        	}
	        	else
				{
					//cron should not be work
				}        
        
       /* }
		
	}*/
	

}
