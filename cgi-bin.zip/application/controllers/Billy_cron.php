<?php

class Billy_cron extends CI_Controller
{	
    public $data = array();
    public $msg = array();
    
    public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
			
		}
		
		
		$this->data['page'] = 9;
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->load->library('talentlmsapi');
    }

public function what(){
        echo "Hello What" ; 
        $customer_diets_info = $this->common_model->customer_diets_info(1156);
        echo '<pre>'; print_r($customer_diets_info);die;
        
    }
    

	public function enrolleddata($user_id,$course='',$history_id)
	{ 
		$user_data = $this->common_model->getRow('user','lms_id,first_name,last_name',array('id'=>$user_id));
		$data = array(
			'user_id'=>$user_id,
			'name'=>$user_data->first_name.' '.$user_data->last_name,
			'enrolled_on'=>$course,
			'created_date'=>date('Y-m-d h:i:s'),
			'lms_id'=>$user_data->lms_id,
			'automation_history_id'=>$history_id
		);
		$this->common_model->save('automation_nextlession',$data);
	}
	public function index()
	{
	    
	    echo "We are in index";
		$GetDays=0;
		$getDays = $this->common_model->solveCustomQuery('SELECT days,no_of_email from automation where status=1 order by id desc limit 1');
		
		echo '<pre>'; print_r($getDays); die;
		
		if(isset($getDays) && !empty($getDays))
		{
			$GetDays = $getDays[0]->days;
		}
		//echo $getDays[0]->no_of_email;exit;
		$today =date('Y-m-d', strtotime('-'.$GetDays.' days'));
		/*$getDate = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(created_date) as created_date FROM `customer_diets_plan` where created_date <= "'.$today.'" group by customer_id desc');*/
		
		$getDate = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(created_date) as created_date FROM `customer_diets_plan` WHERE id IN ( SELECT MAX(id) FROM `customer_diets_plan` GROUP BY customer_id) and created_date <= "'.$today.'" ORDER BY customer_id desc');
		
		$fullname='';
		$check_auto = $this->common_model->getRow('automation_logs','id,name,automation_status',array('id'=>1));

		if(!empty($getDate) && $check_auto->automation_status == 1)
		{   
			$action = 0;
			
			$his = array(
			    'name'=>$check_auto->name,
			    'start_runTime'=>date('Y-m-d h:i:s'),
		    	'action_taken'=>0,
			    'automation_type'=>$check_auto->id);
			$history_id = $this->common_model->saveAndGetLastId('automation_history',$his);
			$this->common_model->update('automation_logs',array('started_on'=>date('Y-m-d'),'automation_status'=>3),array('id'=>1));

			foreach($getDate as $k=>$val)
			{
				$getDateval = date('d-m-Y',strtotime($val->created_date));		
				$getUserData = $this->common_model->getRows('user','first_name,last_name,emailid,id,contact_no,group_lms_name,nag_email,no_of_sentMail',
				array('id'=>$val->customer_id));

				if(isset($getUserData) && (!empty($getUserData)) && $getUserData[0]->nag_email ==1)
				{	
					$fullname= $getUserData[0]->first_name;
					$emailid = $getUserData[0]->emailid;
					$userid = $getUserData[0]->id;
					$phone = $getUserData[0]->contact_no;
					if($getUserData[0]->no_of_sentMail < $getDays[0]->no_of_email)
					{	    
						$template ="<p>Dear ".$fullname.",</p><p>We noticed you haven't input your Daily Tracker information since ".date('M d Y',strtotime($getDateval)).".";
						$sub = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>22));
						$template .= $sub->email_description;

						$email_dat = array
						(
						'to'=>$emailid,
						'subject'=>$sub->subject_txt,
						'msg'=>$template
						);
						
						/*$data=array(
						'emailid'=>$emailid,
						'userid'=>$userid,
						'created_date'=>date('Y-m-d H:i:s')
						);
						$this->common_model->save('automation_detail',$data);*/
						
						$this->common_model->update('user',array('no_of_sentMail'=>$getUserData[0]->no_of_sentMail+1),array('id'=>$userid));
						$this->enrolleddata($userid,'Email to Customer',$history_id);
						$action++;
					}else
					{
						$template ="<p>Dear,</p>
						<p>Mr ".$fullname." haven't input his Daily Tracker information since ".date('M d Y',strtotime($getDateval))." Please Contact them as soon as possible. phone no ".$phone."</p>";

						$subData = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>23));
						$template .= $subData->email_description;
					   
						$sub= $subData->subject_txt;
						$staff = $this->common_model->getRows('user','first_name,emailid',array('role_type'=>2));
						$staff_data=array();
						if(!empty($staff)){
							foreach ($staff as $svalue) {
								$staff_data[] = array('email'=>$svalue->emailid,'name'=>$svalue->first_name);
							}
							
						}
						if($getUserData[0]->group_lms_name == 'WellnessFromFood - Premium'){
						$this->common_model->sendMultipleMail($staff_data,$sub,$template);
						$this->enrolleddata($userid,'Email to Monitoring Team',$history_id);
						}
						$action++;
						$this->common_model->update('user',array('nag_email'=>0),array('id'=>$userid));
					}
					if(!empty($email_dat)){
						$this->common_model->Send_GetStarted_Mail($email_dat);	
					}
										
				}
			}
			$this->common_model->update('automation_logs',array('date_time_last_run'=>date('Y-m-d h:i:s'),'action_taken'=>$action,'automation_status'=>1),array('id'=>1));  
			$this->common_model->update('automation_history',array('end_runTime'=>date('Y-m-d h:i:s'),'action_taken'=>$action),array('run_id'=>$history_id));
		}
	}
	public function mail(){
		$staff = $this->common_model->getRows('user','first_name,emailid',array('role_type'=>2));
		
		if(!empty($staff)){
			foreach ($staff as $svalue) {
				$staff_data[] = array('name'=>$svalue->first_name,'email'=>$svalue->emailid);
			}
			
		}
		$a= $this->common_model->sendMultipleMail($staff_data,'Subject','MSg');
		print_r($a);
	}

	public function test(){
		$template ="<table role='presentation' border='0' cellpadding='0' 
							cellspacing='0' class='body'><tr>
					        <td>&nbsp;</td>
					        <td class='container'>
					          <div class='content'>
					            <table role='presentation' class='main'>
					              <tr>
					                <td class='wrapper'>
					                  <table role='presentation' border='0' cellpadding='0' cellspacing='0'>
					                    <tr>
					                      <td>
					                        <p>Dear,</p>
					                        <p>Mr Chandra haven\'t input his Daily Tracker information since 12-05-2020 Please Contact them  as soon as possible. phone no 9006614336</p>
						
											<p>It\'s important to track your information everyday so that it\'s as accurate as possible. If you\'re having any issues with logging in, or entering data, please contact us at </p><p>

											<a href='mailto:info@WellnessFromFood.com'>info@WellnessFromFood.com.</a>

											</p>
											<p>Thank you,</p>
											<p>The WellnessFromFood Team</p>            	    
					                      </td>
					                    </tr>
					                  </table>
					                </td>
					              </tr>
					            </table>
					          </div>
					        </td>
					        <td>&nbsp;</td>
					      </tr>
					    </table>";
			/*$email_dat = array
			(
			'to'=>'cchaubey55@gmail.com',
			'subject'=>'We need your data – WellnessFromFood',
			'msg'=>$template
			);*/
		$sub = 'WellnessFromFood';
		$staff_data =   array('rajput8955@gmail.com','cchaubey55@gmail.com','p9006614336@gmail.com','anujkch1947@gmail.com');
		$a = $this->common_model->sendMultipleMail($staff_data,$sub,$template);
		print_r($a);	

	}
}

