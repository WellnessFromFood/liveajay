<?php
class Chandra extends CI_Controller {

	public $data = array();
    public $msg = array();

 	public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
			
		}
		$this->data['page'] = 9;
		$this->data['page_form_id']=4;
		$this->data['page_module_id']=3;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->load->library('talentlmsapi');
    }
    
    
   
    public function deleteLmsCustomer(){
    	try{
		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
									TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
				TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');

		$lms_id = $this->common_model->getRow('user','lms_id',array('id'=>1100));
		if(!empty($lms_id) && ($lms_id->lms_id !=0))
		{
			$deleteuser =TalentLMS_User::delete(array('user_id' =>$lms_id->lms_id,'permanent'=>'yes'));
		}
		}catch(Exception $e) {
			echo $e->getMessage();

		}
    }

    public function addCustomerLms(){
    	$getuserdata = $this->common_model->getRow('user','id,emailid,first_name,last_name',array('status'=>'1','id'=>1100));
		$this->talentlmsapi->lmssignup($getuserdata,"Special Premium Customer",$remove=false);
    }

    public function addWeek(){
    	require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
		TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
    	try{
	    	TalentLMS_Course::addUser(array('user_id' =>1474, 'course_id' => '140'));
        }catch(Exception $e){
            $e->getMessage();
        }
    }

    public function test($id=29,$pid=36,$schedultedate=0,$uid=794){
    	$hashCode = md5(rand(0,1000));
    	$mailEmail = 'p9006614336@gmail.com';//$this->input->post('email');
    	$name = ucwords('Chandra');//$this->input->post('first_name');
		$this->common_model->update('user',array('hash'=>trim($hashCode)),array('emailid'=>$mailEmail));
		$mail = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>21,'status'=>1));
		$data['hash']=$hashCode;
		$data['email'] =$mailEmail;
		$data['dynamic_content'] = $mail->email_description;
		$data['full_name']=$name;
		$massege = $this->load->view('frontend/email/backoffice_user_mail',$data,true);
		$subject = $mail->subject_txt;

		$email_dat = array(
		'to'=>$mailEmail,
		'subject'=>$subject,
		'msg'=>$massege);
		$res = $this->common_model->Send_GetStarted_Mail($email_dat);
	}

	public function test_email(){
		$fullname ="Chandra";
		$getDateval = date('Y-m-d');
		
		$template ="<p>Dear,</p>
		<p>Mr ".$fullname." haven't input his Daily Tracker information since ".date('M d Y',strtotime($getDateval))." Please Contact them as soon as possible. phone no ".$phone."</p>";

		$subData = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>23));
		$template .= $subData->email_description;
		$staff_data=array();
		$staff_data[] = array('email'=>"cchaubey55@gmail.com",'name'=>"chandra");
		$sub = $subData->subject_txt;

		echo $this->common_model->sendMultipleMail($staff_data,$sub,$template);	
    }

    public function nagEmailTest(){
    	$GetDays=0;
		$getDays = $this->common_model->solveCustomQuery('SELECT days,no_of_email from automation where status=1 order by id desc limit 1');
		if(isset($getDays) && !empty($getDays))
		{
			$GetDays = $getDays[0]->days;
		}
		//echo $getDays[0]->no_of_email;exit;
		$today =date('Y-m-d', strtotime('2020-08-10 -'.$GetDays.' days'));
		//$today =date('Y-m-d', strtotime('-'.$GetDays.' days'));
		$getDate = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(created_date) as created_date FROM `customer_diets_plan` where created_date <= "'.$today.'" group by customer_id desc');
		echo $this->db->last_query();
		echo '<pre>';
		print_r($getDate);
    }
    public function indexTest()
	{
		$GetDays=0;
		$getDays = $this->common_model->solveCustomQuery('SELECT days,no_of_email from automation where status=1 order by id desc limit 1');
		if(isset($getDays) && !empty($getDays))
		{
			$GetDays = $getDays[0]->days;
		}
		 $today =date('Y-m-d', strtotime('-'.$GetDays.' days'));
		$getDate = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(created_date) as created_date FROM `customer_diets_plan` WHERE id IN ( SELECT MAX(id) FROM `customer_diets_plan` GROUP BY customer_id) and created_date <= "'.$today.'" ORDER BY customer_id desc');
		
		$fullname='';
		$check_auto = $this->common_model->getRow('automation_logs','id,name,automation_status',array('id'=>1));

		if(!empty($getDate))
		{   
			$action = 0;
			
			$his = array(
			'name'=>$check_auto->name,
			'start_runTime'=>date('Y-m-d h:i:s'),
			'action_taken'=>0,
			'automation_type'=>$check_auto->id);

			foreach($getDate as $k=>$val)
			{
				$getDateval = date('d-m-Y',strtotime($val->created_date));		
				$getUserData = $this->common_model->getRows('user','first_name,last_name,emailid,id,contact_no,group_lms_name,nag_email,no_of_sentMail',
				array('id'=>$val->customer_id));

				if(isset($getUserData) && (!empty($getUserData)) && $getUserData[0]->nag_email ==1)
				{	
					$fullname= $getUserData[0]->first_name;
					echo $emailid = $getUserData[0]->emailid;
					$userid = $getUserData[0]->id;
					$phone = $getUserData[0]->contact_no;
					$action++;
					/*if($getUserData[0]->no_of_sentMail < $getDays[0]->no_of_email)
					{	    
						$template ="<p>Dear ".$fullname.",</p><p>We noticed you haven't input your Daily Tracker information since ".date('M d Y',strtotime($getDateval)).".";
						$sub = $this->common_model->getRow('send_email','subject_txt,email_description',array('id'=>22));
						$template .= $sub->email_description;

						$action++;
					}else
					{	
						$action++;
					}*/
										
				}
			}
		}
		echo $action;
	}

	public function testLms(){
		$data = $this->talentlmsapi->forAll(1488);
		echo '<pre>';
		print_r($data);
	}

}