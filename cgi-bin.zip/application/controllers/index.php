<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Index extends CI_Controller 
{
    public $data = array();
    public $msg = array();

    public function __construct()
	{
        parent::__construct();
    }
	
	public function index()
	{
		$this->load->view('frontend/home');
	}	
}
