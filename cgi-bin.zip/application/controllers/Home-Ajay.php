<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {
		public function __construct()
		{
			parent::__construct();
			$this->load->library('talentlmsapi');
			$this->load->helper('common_helper');
		}
		public function index(){
			
			$data['freeintrolession'] = $this->common_model->getRows('video','video_title,thumbnail_image,thumbnail_video,re_writeurl',array('video_status'=>'1','type'=>1),'video_id','DESC',0,3);
			$this->load->view('frontend/home',$data);
		}

		public function about(){
			$this->load->view('frontend/about');
		}
		public function signup(){
			$data['subscription_name'] = $this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1'));
			$data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
			$data['state'] = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1'));

			$this->load->view('frontend/sign-up',$data);
		}
		public function register(){
			$this->load->view('frontend/register');
		}

		public function getstarted($form_id='NA'){
			if($form_id=='NA')
			{
		     $findsession_id = $this->session->userdata('find_session_id');
				$form_data=$this->common_model->solveCustomQuery("select id from createform where form_type=1 and id NOT IN(select form_id from savequestionnnairfrmval where customer_id='".$findsession_id."') order by display_order asc limit 1");

				if(!empty($form_data))
				{
					$form_id=$form_data[0]->id;
				}
			}
			else
			{
				$form_id=base64_decode($form_id);
			}
			$total_form=$this->common_model->solveCustomQuery("select count(id) as total_form from createform where form_type=1");
			$total_filled_form=$this->common_model->solveCustomQuery("select count(t.form_id) as total_filled_form from (select form_id from savequestionnnairfrmval where customer_id='".$findsession_id."' group by form_id) as t");
			$data['formid'] = $form_id;
            $data['total_form']=$total_form[0]->total_form;
			$data['total_filled_form']=$total_filled_form[0]->total_filled_form+1;
			//$this->load->view('frontend/getstarted',$data);
			$this->load->view('frontend/formStage',$data);
		}
		public function blogs(){
		    $data['blogs_name'] = $this->common_model->getRows('blog','id,title,short_description,image,created_date',array('status'=>'1','blog_type'=>1),'display_order','asc');
		    $data['recipe'] = false;
			$this->load->view('frontend/blogs',$data);
		}

		public function news(){
			$this->load->view('frontend/news');
		}

		public function blog_details(){
			$this->load->library('user_agent');
			$data['previous_url'] = $this->agent->referrer();
			$blogid =  $this->uri->segment(3);
			$data['blog_details'] = $this->common_model->getRows('blog','*',array('id'=>base64_decode($blogid)));
			// echo '<pre>'; print_r($data); die;
			if(!empty($data['blog_details']))
			{
				$this->load->view('frontend/single_blog',$data);
			}
			else
			{
				redirect('/');
			}

		}
		public function free_intro_lession(){
			$data['main_heading'] = $this->common_model->getRows('video','main_heading,description,main_description',array('video_status'=>'1','main_heading !='=>'','description !='=>''));

			
			$data['freeintrolession'] = $this->common_model->getRows('video','video_title,thumbnail_image,thumbnail_video,re_writeurl',array('video_status'=>'1','type'=>1),'display_order','ASC');
			$data['blog'] = $this->common_model->getRows('video','video_title,thumbnail_image,description,main_description,main_heading',array('video_status'=>'1','type'=>2,'main_blog !='=>1));
			$data['main_blog'] = $this->common_model->getRows('video','video_title,thumbnail_image,description,main_description,main_heading',array('video_status'=>'1','type'=>2,'main_blog'=>1));
			$data['health_tips'] = $this->common_model->getRows('video','video_title,thumbnail_image,description,re_writeurl',array('video_status'=>'1','type'=>3,'main_blog !='=>1,'health_tips !='=>1),'video_id','asc');
			$data['main_health_tips'] = $this->common_model->getRows('video','main_heading,description,thumbnail_image,re_writeurl',array('video_status'=>'1',/*'main_heading !='=>'','description !='=>'',*/'type'=>3,'health_tips'=>1));

			//echo '<pre>'; print_r($data['main_health_tips']);die;
			$find_session_email=$this->session->userdata('find_session_email');
			if($this->session->userdata('IsFrontedLoggedIn')==TRUE || isset($find_session_email)){
				$this->load->view('frontend/free-intro-lession',$data);
			}else{
				$this->load->view('frontend/invalid-access');
			}

		}
		public function subscription()
		{
			$this->session->set_userdata('bmi_sess_data','');
			$this->session->unset_userdata('specialsessionid','');
			$data['medical'] = $this->common_model->getRows('medical','id,description,agree_title',array('status'=>'1'));

			$data['subscription_name'] = $this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1'));
			$data['homepageData'] = $this->common_model->getRow('homepage','home_page_name,home_page_description',array('home_page_id'=>6));
			$this->load->view('frontend/subscriptiondetail',$data);
		}	
		public function checkout()
		{			
			$data['blood_pressure_high']=$this->session->userdata('blood_pressure_high');
			$data['blood_pressure_low']=$this->session->userdata('blood_pressure_low');
			$data['blood_pressure_mng']=$this->session->userdata('blood_pressure_mng');
			$data['blood_pressure_eve']=$this->session->userdata('blood_pressure_eve');
			$data['blood_sugar_awake']=$this->session->userdata('blood_sugar_awake');
			$data['blood_sugar_breakfast']=$this->session->userdata('blood_sugar_breakfast');
			$data['blood_sugar_lunch']=$this->session->userdata('blood_sugar_lunch');
			$data['blood_sugar_dinner']=$this->session->userdata('blood_sugar_dinner');


			if(isset($_GET['subid']) ==1 && isset($_GET['upgrade']) ==2)
			{
				$subdetailplan = $this->common_model->solveCustomQuery("select t2.name,(t2.price-t1.price) as total_price from subscriptionplan t1,subscriptionplan t2 where t2.id=".$_GET['upgrade']." and t1.id=".$_GET['subid']);
				$data['totalamount'] =$subdetailplan[0]->total_price;
				$data['upgradeid'] =$_GET['upgrade'];
				$data['subid'] =$_GET['subid'];

				$data['subscription_name'] = $this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1','id'=>$_GET['upgrade']));

			}
			else
			{
				$data['subid'] =$_GET['subid'];
				$data['subscription_name'] = $this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1','id'=>$_GET['subid']));
				$data['totalamount'] =$data['subscription_name'][0]->price;
			}

			$this->load->view('frontend/checkout',$data);

		}
	public function paynow()
	{	
		$array1="";
		$array2="";		
		$getrecord = $this->session->userdata('specialsessionid');
		if(!empty($getrecord))
		{
			$this->data['store_temp_data'] = $this->common_model->getRows('store_temp_data','*',array('session_id'=>$getrecord));
		}
		if(isset($_GET['upgrade']))
		{
			$this->common_model->getRows('subscriptionplan','id,name,price,description',array('status'=>'1','id'=>$_GET['upgrade']));
		}
		if(!empty($_POST))
		{
			ini_set('max_execution_time', 18000);
			$special = 0;
		if(!empty($this->session->userdata('special')))
		{
			$special = 1;
		}			
		if(!isset($this->session->userdata('customers')->emailid) && !isset($_SESSION['find_session_email']))
		{

			$blood_pressure_high=$this->input->post('blood_pressure_high');
			$blood_pressure_low=$this->input->post('blood_pressure_low');
			$blood_pressure_mng=$this->input->post('blood_pressure_mng');
			$blood_pressure_eve=$this->input->post('blood_pressure_eve');

			$blood_sugar_awake=$this->input->post('blood_sugar_awake');
			$blood_sugar_breakfast=$this->input->post('blood_sugar_breakfast');
			$blood_sugar_lunch=$this->input->post('blood_sugar_lunch');
			$blood_sugar_dinner=$this->input->post('blood_sugar_dinner');

			if($blood_pressure_high !=''|| $blood_pressure_low='' || $blood_pressure_mng='' || $blood_pressure_eve='')
			{
				$arr1=	array($blood_pressure_high,$blood_pressure_low,$blood_pressure_mng,$blood_pressure_eve);
			}

			if($blood_sugar_awake !=''|| $blood_sugar_breakfast='' || $blood_sugar_lunch='' || $blood_sugar_dinner='')
			{
				$arr2=	array($blood_sugar_awake,$blood_sugar_breakfast,$blood_sugar_lunch,$blood_sugar_dinner);
			}
			if(!empty($arr2) || !empty($arr1))
			{
				$array1= implode(',',$arr1);
		 	 	$array2= implode(',',$arr2);
			}
			$week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
			$time = time();
			$user_data = array(
				'first_name' => $this->input->post('full_name'),
				'emailid' => $_POST['emailid'],
				'contact_no' => $_POST['contact_no'],
				'number_week' =>$week,
				'created_date' => date('Y-m-d H:i:s'),
				'status' => '1',
				'role_type' => 3,
				'hash' => $hash = md5( rand(0,1000) ),
				'active' => 1,
				'blood_sugar_levels'=>$array1,
				'blood_pressure_pulse'=>$array2,
				'is_special' => $special,
				'updated_date' => $time
			);
			$this->common_model->save('user',$user_data);
			$user_id =  $this->db->insert_id();
			$all_cust_data=$this->common_model->getRows("user","*",array("id"=>$user_id));
			$this->session->set_userdata('customerId', $this->input->post('emailid'));
			$this->session->set_userdata('customers', $all_cust_data[0]);			
			$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
		 	/***********add user registration*************/
		}

		//TEMPORARY REGISTRATION--NO PAYMENT
		if(isset($this->session->userdata('customers')->emailid) && $this->session->userdata('customers')->user_type == 0)
		{
			$week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
			$time = time();
			$user_data = array(
				'contact_no' => $_POST['contact_no'],
				'number_week' =>$week,
				'created_date' => date('Y-m-d H:i:s'),
				'status' => '1',
				'role_type' => 3,
				'hash' => $hash = md5( rand(0,1000) ),
				'active' => 1,
				'updated_date' => $time,
				'user_type'=>1
			);
			$this->common_model->update('user',$user_data,array('id'=>$this->session->userdata('customers')->id));
			$user_id = $this->session->userdata('customers')->id;
			$all_cust_data=$this->common_model->getRows("user","*",array("id"=>$user_id));
			$this->session->unset_userdata('customers');
			$this->session->set_userdata('customerId', $this->input->post('emailid'));
			$this->session->set_userdata('customers', $all_cust_data[0]);					
			$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
		 	/***********add user registration*************/
		}
		//GET STARTED : PAYMENT AT TIME
		if(isset($_SESSION['find_session_email']))
		{
			$week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
			$time = time();
			$user_data = array(
				'contact_no' => $_POST['contact_no'],
				'number_week' =>$week,
				'created_date' => date('Y-m-d H:i:s'),
				'status' => '1',
				'role_type' => 3,
				'hash' => $hash = md5( rand(0,1000) ),
				'active' => 1,
				'updated_date' => $time,
				'is_special' => $special,
				'user_type'=>1
			);
			$this->common_model->update('user',$user_data,array('emailid'=>$_SESSION['find_session_email']));
			$user_id = $_SESSION['find_session_email'];
			$all_cust_data=$this->common_model->getRows("user","*",array("emailid"=>$user_id));
			$this->session->set_userdata('customerId', $this->input->post('emailid'));
			$this->session->set_userdata('customers', $all_cust_data[0]);
			$user_id= $all_cust_data[0]->id;
			$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
		 /***********add user registration*************/
		}

		if(isset($this->session->userdata('customers')->emailid) && $this->session->userdata('customers')->user_type != 0)
		{
			$week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
			$time = time();
			$user_data = array(
				'number_week' =>$week,
				'created_date' => date('Y-m-d H:i:s'),
				'status' => '1',
				'role_type' => 3,
				'hash' => $hash = md5( rand(0,1000) ),
				'active' => 1,
				'updated_date' => $time,
				'user_type'=>1
			);
			$this->common_model->update('user',$user_data,array('id'=>$this->session->userdata('customers')->id));
			$user_id = $this->session->userdata('customers')->id;
			$all_cust_data=$this->common_model->getRows("user","*",array("id"=>$user_id));
			$this->session->unset_userdata('customers');
			$this->session->set_userdata('customerId', $this->input->post('emailid'));
			$this->session->set_userdata('customers', $all_cust_data[0]);

			$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
		}

		if($user_id !='')
		{
			//update formid for  questionnaire :Anil
				$sessid = $this->session->userdata('find_session_id');
				$formdata = array('customer_id'=>$user_id);
				$cond=array('customer_id'=>$sessid);
				$this->common_model->update('savequestionnnairfrmval', $formdata, $cond);
				$this->session->set_userdata('find_session_id', $user_id);
		}
		if(!empty($_POST['stripeToken']))
		{
			$token  = $_POST['stripeToken'];
			$name = $_POST['full_name'];
			$email = $_POST['emailid'];
			require_once APPPATH."third_party/stripe/init.php";
			//set api key
			/*$stripe = array(
			"secret_key"      => "sk_live_UGqWfiDw0bEKk4YsL5Ghuxzh",
			"publishable_key" => "pk_live_jbvHOZjfPqcwpPYR7XNoTjiR"
			);*/
			$stripe = array(
			"secret_key"      => "sk_test_Q0Ug05YQjLJRlgArYI0An5Ns00TCKxEKPM",
			"publishable_key" => "pk_test_Bls82ZpAvdkKCYehZOZcAyue00LG3V0I5C"
			);
			\Stripe\Stripe::setApiKey($stripe['secret_key']);
			//add customer to stripe
			$errormsg=''; $actual_link='';
			try
			{
				$customer = \Stripe\Customer::create(
					array(
						'email' => $email,
						'source'  => $token,
						'name'   => $_POST['full_name'],
						'address' => [
					    'line1' => '510 Townsend St',
					    'postal_code' => '98140',
					    'city' => 'San Francisco',
					    'state' => 'CA',
					    'country' => 'US',
						],
					)
				);
			} catch(Exception $e)
			{
				$errormsg= $e->getMessage(); 
			}
			if(!empty($errormsg))
			{
				$actual_link = "https://wellnessfromfood.com/staging/home/subscription";
				$statusMsg = "Your credential are incorrect";
				$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'danger');
				$this->session->set_flashdata($this->msg);
				redirect($actual_link);
			}
			$itemName = $_POST['plan_name'];
			$currency = "usd";
			$orderID = "WELLNESS".$user_id;
			$charge = \Stripe\Subscription::create([
		        "customer" => $customer->id,
		        "items" => [
		            [
		               // "plan" => 'plan_GztlraBSoyZriN',
		            	"plan"  => "price_HLIytVWFEH7B8l",
		            ],
		        ]
	    	]);
			$chargeJson = $charge->jsonSerialize();
			if($chargeJson['status'] == 'active' && empty($chargeJson['failure_code']))
			{
				$amount = $chargeJson['items']['data'][0]['plan']['amount']/100;
				$balance_transaction = $chargeJson['id'];
				$currency = $chargeJson['items']['data'][0]['plan']['currency'];
				$status = $chargeJson['status'];
				$date = date("Y-m-d H:i:s");

				$this->data = array(
					'name' => $name,
					'subscription_name' =>$_POST['plan_name'],
					'subscription_price' =>$_POST['price'],
					'subscription_type'=>$_POST['subid'],
					'upgrade_status'=>$_POST['plan_status'],
					'custid' => $this->session->userdata('customers')->id,
					'email' => $email,
					'item_name' => $_POST['plan_name'],//$itemName,
					'item_number' => $orderID,
					'item_price' =>$_POST['price'],
					'item_price_currency' => $currency,
					'paid_amount' =>$amount,
					'paid_amount_currency' => $currency,
					'txn_id' => $balance_transaction,
					'payment_status' => $status,
					'created' => $date,
					'modified' => $date
				);
				$status='succeeded';
				if($status == 'succeeded')
				{
					$user_id=$this->session->userdata('customers')->id;
					$this->common_model->update("user",array('payment_status'=>1),array('id'=>$user_id));
					$this->session->set_userdata('payment_status', 1);
					if((bool)$this->common_model->save('orders',$this->data) === TRUE)
					{
						$this->common_model->update("user",array('subscription_plan_id'=>$this->input->post('plan_id'),'strip_subscription_id'=>$chargeJson['id']),array('id'=>$user_id));
						$finduserData = $this->session->userdata('customers');
						//echo '<pre>'; print_r($finduserData);die;
						if($_POST['plan_status']=='Normal')
						{
							$statusMsg =$finduserData->first_name." ".$finduserData->last_name." - Thank you for your payment!  You will receive an email shortly with login instructions. Please check your email.  Thanks and Welcome!";


							$sendMailData=array(
								'full_name'=>$finduserData->first_name,
								'emailid'=>$finduserData->emailid,
								'price'=>$_POST['price'],
								'contact_no'=>$finduserData->contact_no,
								'subject'=>'Normal Plan'
							);
						}
						else
						{
							//$statusMsg = "Your payment has been upgraded successfully done. Now, you can access the program session";
							$statusMsg =$finduserData->first_name." ".$finduserData->last_name." - Thank you for your payment!  You will receive an email shortly with login instructions. Please check your email.  Thanks and Welcome!";

							$sendMailData=array(
								'full_name'=>$finduserData->first_name,
								'emailid'=>$finduserData->emailid,
								'price'=>$_POST['price'],
								'contact_no'=>$finduserData->contact_no,
								'subject'=>'Premium Plan'
							);

						}
						$this->common_model->sendMail($sendMailData);
						$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);

					}
					$week =  $this->common_model->getCustomFielddata('user','number_week',array('id'=>$user_id));
					/*$check_order = $this->common_model->solveCustomQuery("select id from orders where custid=".$user_id);*/
					$check_order = $this->common_model->getRows('orders','id',array('custid'=>$user_id));
				 	$all_day_week = $this->common_model->calculate_day_week($week);
					//echo '<pre>';print_r($check_order);die;
					if(!empty($all_day_week) && count($check_order)==1)
					{
						$checklms= $this->talentlmsapi->lmssignup($finduserData,$_POST['plan_status'],false);
						try {
							if($checklms)
							{
								$this->db->delete('diets_plan_mapping',array('customer_id'=>($user_id)));
								foreach($all_day_week  as $k=>$val)
								{ //echo $val;
									$get_customer_values = explode('_',$val);
									$customer_message_id=$this->common_model->getRows('week','week_message_id,week_netgram_id,allowmeet_id,questionnaire_id,
										prem_week_message_id,prem_week_netgram_id,prem_allowmeet_id,
											special_week_message_id,special_week_netgram_id,special_allowmeet_id,
										diet_net_carb,
										diet_hunger,
										diet_blood_pressure,	
										diet_blood_sugar_level,
										premium_hunger,
										premium_net_carb,
										premium_blood_pressure,	
										premium_blood_sugar_level,
										special_hunger,
										special_net_carb,
										special_blood_pressure,	
										special_blood_sugar_level',array('id'=>$get_customer_values[0])
									);
									if($_POST['subid']==1)
									{
										//For diy user display message
										$get_customer_message_id = $customer_message_id[0]->week_message_id;
										$netgram_id = $customer_message_id[0]->week_netgram_id;
										$allowmeet_id = $customer_message_id[0]->allowmeet_id;

										$diet_net_carb_val = $customer_message_id[0]->diet_net_carb;
										$diet_hunger_val = $customer_message_id[0]->diet_hunger;
										$diet_blood_pressure = $customer_message_id[0]->diet_blood_pressure;
										$diet_blood_sugar_level = $customer_message_id[0]->diet_blood_sugar_level;
									}
									else if($_POST['special_user']=='special' && $_POST['subid'] ==2)
									{ 
										$get_customer_message_id = $customer_message_id[0]->special_week_message_id;
										$netgram_id =$customer_message_id[0]->special_week_netgram_id;
										$allowmeet_id = $customer_message_id[0]->special_allowmeet_id;
										$diet_net_carb_val = $customer_message_id[0]->special_net_carb;
										$diet_hunger_val = $customer_message_id[0]->special_hunger;
										$diet_blood_pressure = $customer_message_id[0]->special_blood_pressure;
										$diet_blood_sugar_level = $customer_message_id[0]->special_blood_sugar_level;
									}else{
										if($_POST['subid'] ==2 && $_POST['special_user'] !='special') 
										{
											$get_customer_message_id = $customer_message_id[0]->prem_week_message_id;
											$netgram_id = $customer_message_id[0]->prem_week_netgram_id;
											$allowmeet_id = $customer_message_id[0]->prem_allowmeet_id;
											$diet_net_carb_val = $customer_message_id[0]->premium_net_carb;
											$diet_hunger_val = $customer_message_id[0]->premium_hunger;
											$diet_blood_pressure = $customer_message_id[0]->premium_blood_pressure;
											$diet_blood_sugar_level = $customer_message_id[0]->premium_blood_sugar_level;
										}
									}
									$questionnaire_id = $customer_message_id[0]->questionnaire_id;
	 								$get_diet_name = $this->common_model->getRows('dietsplan','id',array("status"=>"1"),'display_order','ASC');		       
									foreach($get_diet_name  as $k=>$val3)
									{
										$data = array(
											'week_id' => $get_customer_values[0],
											'day_id' => $get_customer_values[1],
											'mapping_id' => $val3->id,
											'customer_id' => $user_id,
											'created_date' => date('Y-m-d 00:01:10'),
											'created_by' => 1,
											'message_id'=>$get_customer_message_id,
											'netgram_id'=>$netgram_id,
											'allowmeet_id'=>$allowmeet_id,
											'questionnaire_id'=>$questionnaire_id,												
											'diet_net_carb_val'=>$diet_net_carb_val,
											'diet_hunger_val'=>$diet_hunger_val,
											'diet_blood_pressure'=>$diet_blood_pressure,
											'diet_blood_sugar_level'=>$diet_blood_sugar_level
										);										
										$insert_batch[]=$data;
									}
									if($questionnaire_id > 0)
									{
										$this->common_model->update("createform",array('mapped_status'=>1),array('id'=>$questionnaire_id));
									}
								}
							 	/*end main foreach and code for insert batch*/
							 	$this->common_model->insert_arrays('diets_plan_mapping',$insert_batch);
						 	}
						}
						catch(Exception $e) {
							echo "Data is not got LMS".'Message: ' .$e->getMessage();

						}
					}
					else if(!empty($all_day_week) && count($check_order)==2)
					{
						//echo "dddddd"; die;
						$this->talentlmsapi->lmssignup($finduserData,$_POST['plan_status'],true);
						//update message id and questionaar as per premium user
						$all_remain_week=$this->common_model->solveCustomQuery("SELECT week_id FROM `diets_plan_mapping` where customer_id=".$user_id." GROUP by week_id");
						if(!empty($all_remain_week))
						{
							foreach($all_remain_week  as $week)
							{
								$customer_message_id=$this->common_model->getRows('week','prem_week_message_id,prem_week_netgram_id,prem_allowmeet_id',array('id'=>$week->week_id)); 
								//For premium user
								$get_customer_message_id = $customer_message_id[0]->prem_week_message_id;
								$netgram_id = $customer_message_id[0]->prem_week_netgram_id;
								$allowmeet_id = $customer_message_id[0]->prem_allowmeet_id;
								$data = array(
									'message_id'=>$get_customer_message_id,
									'netgram_id'=>$netgram_id,
									'allowmeet_id'=>$allowmeet_id
								);
								$cond = array(
									'week_id' => $week->week_id,
									'customer_id' => $user_id
								);
								$this->common_model->update('diets_plan_mapping',$data,$cond);

							}
						}
					}
					$this->session->set_userdata('current_plan_id',"");
					$this->session->set_userdata('current_plan_price',"");
					$this->session->set_userdata('current_plan_name',"");
					$this->session->set_userdata('plant_status',"");
					$checkupgrade = $this->common_model->getRows("orders","subscription_type,subscription_name",array("custid"=>$user_id),'id','desc',0,1);
					if(!empty($checkupgrade))
					{
						$this->session->set_userdata('session_plan_name',$checkupgrade[0]->subscription_name);
						$this->session->set_userdata('session_plan_id',$checkupgrade[0]->subscription_type);
					}
					$form_type = $this->common_model->getRows("user","form_type",array("id"=>$user_id));
					if($form_type[0]->form_type==1){
						redirect('daily-dite-form');
					}
					else
					{
						redirect('additional-profile');
					}
				}
				else
				{
					$statusMsg = "Transaction has been failed";
					$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'danger');
					$this->session->set_flashdata($this->msg);
				}
			}else{
				$statusMsg = "Form submission error.......";
				$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'danger');
				$this->session->set_flashdata($this->msg);
			}
			$this->msg = array('msg'=>$statusMsg, 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			redirect('home/paynow?subid='.$subplanid.'');
			}
			redirect('home/paynow?subid='.$subplanid.'');
		}
		else
		{
			print_r($_GET);exit;
			$subplanid = $this->input->get('subid');
			$upgradeId = $this->input->get('upgrade');
			if($upgradeId=='' && $subplanid==1)
			{
				$subdetailplan = $this->common_model->getRows("subscriptionplan","name,price",array("id"=>$subplanid));
				if(!empty($subdetailplan))
				{
					$subscription_name =$subdetailplan[0]->name;
					$subscription_price =$subdetailplan[0]->price;
					$caltax =$this->common_model->calculate_tax($subscription_price);
					$this->session->set_userdata('current_plan_id',$subplanid);
					$this->session->set_userdata('current_plan_price',$subscription_price);
					$this->session->set_userdata('current_plan_name',$subscription_name);
					$this->session->set_userdata('plant_status',"Normal");
				}
			}		
			elseif($upgradeId=='' && $subplanid==2)
			{
				$subdetailplan = $this->common_model->getRows("subscriptionplan","name,price",array("id"=>$subplanid));
				if(!empty($subdetailplan))
				{
					$subscription_name =$subdetailplan[0]->name;
					$subscription_price =$subdetailplan[0]->price;
					$caltax =$this->common_model->calculate_tax($subscription_price);
					$this->session->set_userdata('current_plan_id',$subplanid);
					$this->session->set_userdata('current_plan_price',$subscription_price);
					$this->session->set_userdata('current_plan_name',$subscription_name);
					$this->session->set_userdata('plant_status',"Upgraded With Premium");
				}
			}
			else
			{
				$subdetailplan = $this->common_model->solveCustomQuery("select t2.name,(t2.price-t1.price) as total_price from subscriptionplan t1,subscriptionplan t2 where t2.id=".$upgradeId." and t1.id=".$subplanid);
				if(!empty($subdetailplan))
				{
					$subscription_name =$subdetailplan[0]->name;
					$subscription_price =$subdetailplan[0]->total_price;
					$caltax =$this->common_model->calculate_tax($subscription_price);
					$this->session->set_userdata('current_plan_id',$upgradeId);
					$this->session->set_userdata('current_plan_price',$subscription_price);
					//$this->session->set_userdata('current_plan_price',$subscription_price+$caltax);
					$this->session->set_userdata('current_plan_name',$subscription_name);
					$this->session->set_userdata('plant_status',"Upgraded With Premium");
				}
			}
			$this->load->view('frontend/payment_card_detail');
		}
	}

		public function session_diet_status(){

			$this->load->view('frontend/session_diet_status');
		}
		public function questionnaireform(){
			$getfid='';
			$getfid= $this->input->get('formid');
				if(!empty($getfid))
				{
				$this->data['formid'] =base64_decode($getfid);
				$this->data['save_quest'] = site_url('dailyditeform/save_questionnaireform/'.$getfid);
				}

			$this->load->view('frontend/questionnaireform',$this->data);
		}
		public function edit_questionnaireform(){
			$getfid='';
			$getfid= $this->input->get('formid');
			$customersid = $this->session->userdata('customers')->id;
			if(!empty($getfid))
			{
				$this->data['formid'] =base64_decode($getfid);
				$this->data['update_quest'] = site_url('dailyditeform/save_questionnaireform/'.$getfid);
			}

			$this->load->view('frontend/editquestionnaireform',$this->data);
		}

	public function daily_dite_form()
	{

		if((bool)$this->session->userdata('payment_status')==FALSE)
		{
			redirect('home/subscription');
			exit();
		}
		$this->next_day_start_session();
		$custid='';
		$custid= $this->session->userdata('customers')->id;
		
	//	echo 'sorry - we are working an issue - please try later, and ignore the rest <br>';
	//    echo '$custid = ' . $custid; die;
	//	echo '<pre>'; print_r($this->session->userdata());die;
		
		
		$Allcustinfo=$this->session->userdata('customers');
	//	echo 'sorry - we are working an issue - please try later, and ignore the rest <br>';
	//	echo '<pre>'; print_r($Allcustinfo);die;
		
		if(isset($custid) && (!empty($custid)))
		{
			if(!empty($custid)){
				$data['customerid']= base64_encode($custid);
			}
            
			$customer_diets_info = $this->common_model->customer_diets_edit_info($custid);
    	//echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
		//echo '<pre>'; print_r($customer_diets_info);die;

			if(empty($customer_diets_info)){
				$customer_diets_info = $this->common_model->customer_diets_info($custid);
			}
		echo $this->db->last_query();
			
		//	echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
		//    echo '<pre>'; print_r($customer_diets_info);die;
			
			
		    //echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
		   // echo 'customer diets info is: <br>';
		   // echo '<pre>'; print_r($customer_diets_info); die;
		
			$label1=array();
			$label2=array();
			$label3=array();
			$label4=array();
		//	echo 'sorry - we are working an issue - please try later, and ignore the rest.   <br> for customerid = '. $custid;    
		//	echo 'customer diets is '; echo '<pre>'; print_r($customer_diets_info); die;
			if(!empty($customer_diets_info))
			{
				foreach($customer_diets_info as $val){
					if($val->input_type==1){
						if($val->status == 1)
						{
							$label1[$val->labelid]=$val;
						}
						
					} 
					else if($val->input_type==2)
					{
						if($val->status == 1)
						{
							$label2[$val->labelid]=$val;
						}

					}
					else if($val->input_type==3)
					{
						if($val->status == 1)
						{
							$label3[$val->labelid]=$val;
						}

					}
					else{
						if($val->status == 1)
						{
							$label4[$val->labelid]=$val;
						}
						
					}
				}

                //echo '<pre>'; print_r($label2);die;
				$data['label1'] = $label1;
				$data['label2'] = $label2;
				$data['label3'] = $label3;
				$data['label4'] = $label4;
				
			 	$data['weekid']= $customer_diets_info[0]->week_id;
				$data['dayid'] = $customer_diets_info[0]->day_id;
				$data['message_id'] = $customer_diets_info[0]->message_id;
				$data['netgram_id'] = $customer_diets_info[0]->netgram_id;
				$data['allowmeet_id'] = $customer_diets_info[0]->allowmeet_id;
				$data['questionnaire_id'] = $customer_diets_info[0]->questionnaire_id;
			    $data['lession_id'] = $customer_diets_info[0]->admin_msg_id;
			   if(isset($customer_diets_info[0]->comments) && (!empty($customer_diets_info[0]->comments)))
			   {
			   	$data['comments'] = $customer_diets_info[0]->comments;
			   }
			   
			   if(isset($customer_diets_info[0]->staff_comments) && (!empty($customer_diets_info[0]->staff_comments)))
			   {
			    $data['staffcomments'] = $customer_diets_info[0]->staff_comments;
			   }


	           /* ==============Check Extra Metting ======================*/
	           $data['extra_meting']=0;
	           $get_extra_from_userTable = $this->common_model->getCustomFielddata('user','extra_metting',array('id'=>$custid));

	          	if($get_extra_from_userTable == 0)
	          	{
							$extra_metting = "SELECT ANY_VALUE(week_id) as week_id,ANY_VALUE(extra_metting) as extra_metting FROM diets_plan_mapping where customer_id =".$custid." and week_id <=".$customer_diets_info[0]->week_id." group by week_id,extra_metting";
							$total_extra = $this->common_model->solveCustomQuery($extra_metting);
							$coun_t=0;
						if(!empty($total_extra))
						{
							foreach($total_extra as $t_val)
							{
								$coun_t += $t_val->extra_metting;
							}
						}
						$data['extra_meting'] = $coun_t;
	          	}
	          	else
	          	{
	          		$data['extra_meting'] = $get_extra_from_userTable;
	          	}
	            /* ================Check Extra Metting ======================*/
				$data['set_time_slot'] = $this->common_model->getRows('time_slot','id,timeslot,providerid',
					array('status'=>'1','providerid'=>2));

				if(!empty($custid))
				{	

				$order_list = $this->common_model->solveCustomQuery('select subscription_name from orders
					where custid='.$custid.' order by id desc limit 1');
				$data['order_list'] = $order_list[0]->subscription_name;
				}
				$data['questionnaire_list'] = $this->common_model->getRows('week','questionnaire_id,hide_net_gram,hide_premium_net_gram',
				array('id'=>$customer_diets_info[0]->week_id));

				$data['check_questionnaire'] = $this->common_model->solveCustomQuery('SELECT 
					ANY_VALUE(createform.id) as id,ANY_VALUE(customer_id) as customer_id,ANY_VALUE(questionnaire_id) as questionnaire_id,ANY_VALUE(weeks) as weeks,ANY_VALUE(week_wise_days) as week_wise_days,ANY_VALUE(createform.form_name) as form_name FROM `customer_diets_plan` join createform on createform.id=customer_diets_plan.questionnaire_id where form_type=0 and mapped_status=1 and customer_id ='.$custid.' and weeks <='.$customer_diets_info[0]->week_id.' group by id,customer_id'); 



  				$gramcond=array('dm.weeks'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>$customer_diets_info[0]->customer_id);
				$gramfield='(m.Message) AS Message';
				$gramjoin=array(
					array(
						'join_table'=>'customer_diets_plan as dm',
						'on_first_table'=>'m.MessageID',
						'on_second_table'=>'dm.netgram_id'
					));	
 	 			$data['net_gram']=  $this->common_model->getJoinData("messagecenterposttable as m",$gramcond,$gramfield,$gramjoin,'','','','','dm.netgram_id'); 
				$lesscond=array('dm.week_id'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>$custid);
				$lessfield='ANY_VALUE(m.Message) as Message';
				$lessjoin=array(
				array(
					'join_table'=>'diets_plan_mapping as dm',
					'on_first_table'=>'m.MessageID',
					'on_second_table'=>'dm.admin_msg_id'
				));	
 	  			$data['lession_msg'] =  $this->common_model->getJoinData("messagecenterposttable as m",$lesscond,$lessfield,$lessjoin,'','','','','dm.admin_msg_id'); 
 	  			//echo $this->db->last_query();exit;
				$data['displaymessage'] = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(m.Message) as Message from messagecenterposttable as m left join diets_plan_mapping as dm on m.MessageID = dm.message_id where dm.week_id = '.$customer_diets_info[0]->week_id.' and dm.customer_id = '.$custid.' group by dm.message_id');
				$acknowment=$this->common_model->getRows("customer_diets_plan","acknowledgment,help,exercise_id,weight,steps",
				array("weeks"=>$customer_diets_info[0]->week_id,
				"week_wise_days"=>$customer_diets_info[0]->day_id,
				"customer_id"=>$customer_diets_info[0]->customer_id));

				if(isset($acknowment[0]->acknowledgment) && ($acknowment[0]->acknowledgment==0)){
					$data['acknow']=$acknowment[0]->acknowledgment;
					$data['help']=$acknowment[0]->help;
				}
				if(isset($acknowment[0]->exercise_id) && (!empty($acknowment[0]->exercise_id))){
					$data['exercise_id']=$acknowment[0]->exercise_id;
				}
				if(isset($acknowment[0]->weight) && (!empty($acknowment[0]->weight))){
					$data['weight'] = $acknowment[0]->weight;
				}
				if(isset($acknowment[0]->steps) && (!empty($acknowment[0]->steps))){
					$data['steps'] = $acknowment[0]->steps;
				}

				//echo '<pre>'; print_r($data);die;
				if($customer_diets_info[0]->message_id !=0){
				$data['showmessage']=$this->common_model->getRows('messagecenterposttable','Message,MessageID',array('Messageid'=>$customer_diets_info[0]->message_id));
				}
				//schedule date
				$data['next_meeting']=$this->common_model->getRows('time_schedule','schedule_date,slottime,providerid',
				array('customerid'=>$customer_diets_info[0]->customer_id),'id','desc');

				//schedule date
				$data['exerciselst']=$this->common_model->getRows('exercise','id,exercise_name,status',
				array('status'=>1));

				$session_plan_id = $this->session->userdata('session_plan_id');
				//echo '<pre>';print_r($session_plan_id);die;
				if($session_plan_id==1 )
				{
					$data['subscription_name'] = $this->common_model->getRows('subscriptionplan',
					'id,name,price,description',array('status'=>'1',
					'id !='=>$this->session->userdata('session_plan_id')));
				}
				
				$data['exit_questionnaire'] = $this->common_model->getRows('user','check_questionnaire',array('status'=>1,
				'id ='=>$custid));
				$data['recipes']=$this->common_model->getRows('recipes','id,image,title,short_description',array('status'=>'1','type'=>2,'week_id'=>$customer_diets_info[0]->week_id));
				//echo $this->db->last_query();exit;
			}
			else
			{
			    //echo "It was empty"; die;
			}

                
				$this->load->view('frontend/daily_dite_form',$data);
		}else{
				redirect('/');
			}
	}
	public function daily_dite_form_edit()
	{
		$custinfo = $this->session->userdata('customers');
		if(!empty($custinfo))
		{

        $custid='';
		$custid= $this->session->userdata('customers')->id;
        //echo $custid; die;
		$customerid='';$weekids='';$dayids='';
		$customerid =  $this->uri->segment(3);
		//echo base64_decode($customerid); die;
		$weekids =  $this->uri->segment(4);
		$dayids =  $this->uri->segment(5);

			if(isset($customerid) && (!empty($weekids)) && (!empty($dayids)))
			{
				if(!empty($customerid)){
					$data['customerid']=base64_decode($customerid);
				}

				$customer_diets_info = $this->common_model->customer_diets_edit_info1($customerid,$weekids,$dayids);

					$label1=array();
					$label2=array();
					$label3=array();
					$label4=array();
					foreach($customer_diets_info as $val){
					if($val->input_type==1){
						/*if($val->status == 1)
						{*/
							$label1[$val->labelid]=$val;
						/*}*/
						
					} 
					else if($val->input_type==2)
					{
						/*if($val->status == 1)
						{*/
							$label2[$val->labelid]=$val;
						/*}*/

					}
					else if($val->input_type==3)
					{
						/*if($val->status == 1)
						{*/
							$label3[$val->labelid]=$val;
						/*}*/

					}
					else{
						/*if($val->status == 1)
						{*/
							$label4[$val->labelid]=$val;
						/*}*/
						
					}
					}
					
					//echo '<pre>'; print_r($label2);die;
						$data['label1'] = $label1;
						$data['label2'] = $label2;
						$data['label3'] = $label3;
						$data['label4'] = $label4;
						$data['weekid']=$customer_diets_info[0]->week_id;
						$data['custid']=$custid;
						$data['dayid']=$customer_diets_info[0]->day_id;
					//echo '<pre>'; print_r($label2);die;
					$data['message_id']=$customer_diets_info[0]->message_id;

					$data['netgram_id']=$customer_diets_info[0]->netgram_id;
					$data['allowmeet_id']=$customer_diets_info[0]->allowmeet_id;
					$data['questionnaire_id']=$customer_diets_info[0]->questionnaire_id;
					$data['lession_id']=$customer_diets_info[0]->admin_msg_id;
					$data['comments'] = $customer_diets_info[0]->comments;
					$data['staffcomments'] = $customer_diets_info[0]->staff_comments;
					//echo '<pre>'; print_r($data);die;	
					/* ==============Check Extra Metting ======================*/
					if(isset($customer_diets_info) && (!empty($customer_diets_info)))
					{
	                   $data['extra_meting']=0;
	                   $get_extra_from_userTable = $this->common_model->getCustomFielddata('user','extra_metting',array('id'=>base64_decode($customerid)));
	                  	if($get_extra_from_userTable == 0)
	                  	{
	                  		$extra_metting = "SELECT ANY_VALUE(week_id) as week_id,ANY_VALUE(extra_metting) as extra_metting FROM diets_plan_mapping where customer_id =".base64_decode($customerid)." and week_id <=".$customer_diets_info[0]->week_id." group by week_id,extra_metting";
								$total_extra = $this->common_model->solveCustomQuery($extra_metting);
								$coun_t=0;
								if(!empty($total_extra))
								{
									foreach($total_extra as $t_val)
									{
										$coun_t += $t_val->extra_metting;
									}
								}
								$data['extra_meting']= $coun_t;
	                  	}
	                  	else
	                  	{
	                  		$data['extra_meting'] =$get_extra_from_userTable;
	                  	}
                }



                    /* ================Check Extra Metting ======================*/
                    if(isset($customer_diets_info) && (!empty($customer_diets_info)))
					{
					$data['check_questionnaire'] = $this->common_model->solveCustomQuery('SELECT
					* FROM createform where id='.$customer_diets_info[0]->questionnaire_id.' and mapped_status=1');
				    }
					$data['displaymessage']= $this->common_model->getCustomFielddata('messagecenterposttable','Message',array('Messageid'=>$customer_diets_info[0]->message_id));



					$acknowment=$this->common_model->getRows("customer_diets_plan","acknowledgment,help,exercise_id,weight,steps",
					array("weeks"=>$customer_diets_info[0]->week_id,
					"week_wise_days"=>$customer_diets_info[0]->day_id,
					"customer_id"=>$customer_diets_info[0]->customer_id));

				/*	 $data['net_gram'] = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(m.Message) AS Message from messagecenterposttable as m left join customer_diets_plan as dm on m.MessageID = dm.netgram_id where dm.weeks = '.$customer_diets_info[0]->week_id.' and dm.customer_id = '.$customer_diets_info[0]->customer_id.' group by dm.netgram_id');*/


			$gramcond=array('dm.weeks'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>$customer_diets_info[0]->customer_id);
				$gramfield='(m.Message) AS Message';
				$gramjoin=array(
											array(
												'join_table'=>'customer_diets_plan as dm',
												'on_first_table'=>'m.MessageID',
												'on_second_table'=>'dm.netgram_id'
											));	
 	 $data['net_gram']=  $this->common_model->getJoinData("messagecenterposttable as m",$gramcond,$gramfield,$gramjoin,'','','','','dm.netgram_id'); 



   /*  $data['lession_msg'] = $this->common_model->solveCustomQuery('SELECT ANY_VALUE(m.Message) as Message from messagecenterposttable as m left join diets_plan_mapping as dm on m.MessageID = dm.admin_msg_id where dm.week_id = '.$customer_diets_info[0]->week_id.' and dm.customer_id = '.base64_decode($customerid).' group by dm.admin_msg_id');*/


				$lesscond=array('dm.week_id'=>$customer_diets_info[0]->week_id,'dm.customer_id'=>base64_decode($customerid));
				$lessfield='ANY_VALUE(m.Message) as Message';
				$lessjoin=array(
											array(
												'join_table'=>'diets_plan_mapping as dm',
												'on_first_table'=>'m.MessageID',
												'on_second_table'=>'dm.admin_msg_id'
											));	
 	  $data['lession_msg'] =  $this->common_model->getJoinData("messagecenterposttable as m",$lesscond,$lessfield,$lessjoin,'','','','','dm.admin_msg_id'); 



					//echo '<pre>';print_r($acknowment);die;
					if(isset($acknowment[0]->acknowledgment) && ($acknowment[0]->acknowledgment==0)){
						$data['acknow']=$acknowment[0]->acknowledgment;
						$data['help']=$acknowment[0]->help;
					}
					if(isset($acknowment[0]->exercise_id) && ($acknowment[0]->exercise_id !=0)){
						$data['exercise_id']=$acknowment[0]->exercise_id;
					}
					//$data['weight'] = $acknowment[0]->weight;
					if(isset($acknowment[0]->weight) && (!empty($acknowment[0]->weight))){
						$data['weight'] = $acknowment[0]->weight;
					}
					if(isset($acknowment[0]->steps) && (!empty($acknowment[0]->steps))){
						$data['steps'] = $acknowment[0]->steps;
					}
					if($customer_diets_info[0]->message_id !=0){
					$data['showmessage']=$this->common_model->getRows('messagecenterposttable','Message,MessageID',array('Messageid'=>$customer_diets_info[0]->message_id));
					}
					//schedule date
					$data['next_meeting']=$this->common_model->getRows('time_schedule','schedule_date,slottime,providerid',
					array('customerid'=>$customer_diets_info[0]->customer_id));

					//schedule date
					$data['exerciselst']=$this->common_model->getRows('exercise','id,exercise_name,status',
					array('status'=>1));

					$data['subscription_name'] = $this->common_model->getRows('subscriptionplan',
					'id,name,price,description',array('status'=>'1',
					'id !='=>$this->session->userdata('session_plan_id')));
					$data['exit_questionnaire'] = $this->common_model->getRows('user','check_questionnaire',array('status'=>1,
					'id ='=>base64_decode($customerid)));

                    
                    //echo '<pre>'; print_r($data);die;
					$this->load->view('frontend/daily_dite_form_edit',$data);
			}
			else
			{
				redirect('/');
			}

		}
		else
		{
				redirect('/');
		}

	}
	public function find_state_by_country_id($country_id=0)
	{

		if(!empty($country_id)){
			$state = $this->common_model->getRows('state','state_id,country_id,state_name',array('status'=>'1','country_id'=>$country_id));
			$html="<option value=''>Please Select</option>";
			if(!empty($state)){ foreach($state as $state_val){
			if($country_id==$state_val->country_id){ $selected='selected'; }else{ $selected=''; }
			$html.="<option value='".$state_val->state_id."' ".$selected.">".$state_val->state_name."</option>";
			}}
		}
		echo $html;
	}
	public function find_state_by_state_id($state_id=0)
	{
		if(!empty($state_id)){
			$state = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1','state_id'=>$state_id));
			$html="<option value=''>Please Select</option>";
			if(!empty($state)){ foreach($state as $state_val){
			if($country_id==$state_val->country_id){ $selected='selected'; }else{ $selected=''; }
			$html.="<option value='".$state_val->state_id."' ".$selected.">".$state_val->state_name."</option>";
			}}
		}
		echo $html;
	}
	public function update_time_slot_calender(){
		//echo '<pre>'; print_r($this->input->post());die;
		 $timeslote = $this->input->post('timeslote');
		 $date =  date('d-m-Y');
		 $timeslote = date('Y-m-d',strtotime($timeslote));
	    if(strtotime($timeslote) < strtotime($date)) $timeslote = $date;
		$weekid = $this->input->post('weekid');
		$dayid = $this->input->post('dayid');
		//echo '<pre>'; print_r($this->input->post());die;

		 if(!empty($timeslote)){//&& !empty($weekid) && !empty($dayid)
						 $this->common_model->update_time_slot_calender($timeslote,$weekid,$dayid);exit;
					}
			}
	
	public function cancel_meeting()
	{
		$custinfo = $this->session->userdata('customers');
		//echo '<pre>'; print_r($custinfo);die;
		if(!empty($custinfo))
		{
        $today = date('Y-m-d');
		$custids =$this->input->post('custid');
		$time_schedule_data = $this->common_model->getRows('time_schedule','id,schedule_date,providerid,slottime',array('customerid'=>$custids,'status'=>1),'id','DESC');
		if(isset($time_schedule_data) && (!empty($time_schedule_data)))
		{
			$ccond=array('p.id'=>$time_schedule_data[0]->providerid);
			$cfield='u.emailid,u.first_name as providername';
			$cjoin=array(
				array(
				'join_table'=>'provider p',
				'on_first_table'=>'p.pcustid',
				'on_second_table'=>'u.id'
			));	
	 		$provider_email = $this->common_model->getJoinData("user u",$ccond,$cfield,$cjoin,'','','u.id','asc',''); 
		}
		$sc_date =@date('M d Y',strtotime($time_schedule_data[0]->schedule_date));
		$slote_time =@$time_schedule_data[0]->slottime;

		

			if($this->db->delete('time_schedule',array('customerid'=>$custids,'id'=>@$time_schedule_data[0]->id))){
				$data4 = array(
					'meeting_date' =>'0000-00-00 00:00:00'
				);
			$this->common_model->update("customer_diets_plan",$data4,
			array('customer_id'=>$this->input->post('custid'),'weeks'=>$this->input->post('num_weeks'),'week_wise_days'=>$this->input->post('week_wise_days')));

			$sub1= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>4,'status'=>1));
				//Email send to customer $custinfo->emailid

				$fname=$custinfo->first_name;
				$lname=$custinfo->last_name;
				if((isset($fname)) && ($fname !='') && ((isset($lname)) && $lname !=''))
				{
					$customername =$fname." ".$lname;
				}
				else
				{
					$customername =$fname;
				}
				
                /* Send email to the Customer to confirm cancellation */
				$this->common_model->commonMail(4,$sub1,$custinfo->emailid,'',@$slote_time,$sc_date,$customername);
				
				$sub11= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>11,'status'=>1));
				//Email send to provide $provider_email[0]->emailid
				/* Send email to the Staff provider when Customer cancels meeting */
				$this->common_model->commonMail(14,$sub11,$provider_email[0]->emailid,'',@$slote_time,$sc_date,$provider_email[0]->providername);


				echo 1;exit;
			}else{
				echo 0;exit;
			}

		}
		else
		{
			echo 2;exit;
		}
	   
	}
	public function update_time_schedule_data(){
		
		$custmess =$this->session->userdata('customers');
		if(!empty($custmess))
		{

		$cid = $this->session->userdata('customers')->id;
			$data = array(
				'customerid' => $this->input->post('custid'),
				'providerid' => $this->input->post('providerid'),
				'slotvalue' => $this->input->post('slotval'),
				'slottime' => $this->input->post('slottext'),
				'weekid' => $this->input->post('weekidd'),
				'dayid' => $this->input->post('dayidd'),
				'status' =>1,
				'schedule_date' =>date('Y-m-d',strtotime($this->input->post('appointmentdate'))),
				'created_date' =>date('Y-m-d'),
				'created_by' =>$cid
			);
			$data3 = array(
				'meeting_date' =>date('Y-m-d',strtotime($this->input->post('appointmentdate')))." ".$this->input->post('slottext')
			);

			/*==================Check Extra Metting ========================*/
                   $extra_meting=0;
                   $get_extra_from_userTable = $this->common_model->getCustomFielddata('user','extra_metting',array('id'=>$this->input->post('custid')));
                  	if($get_extra_from_userTable == 0)
                  	{
                  		$extra_metting = "SELECT ANY_VALUE(week_id) as week_id,ANY_VALUE(extra_metting) as extra_metting FROM diets_plan_mapping where customer_id =".$this->input->post('custid')." and week_id <=".$this->input->post('weekidd')." group by week_id,extra_metting";
							$total_extra = $this->common_model->solveCustomQuery($extra_metting);
							$coun_t=0;
							if(!empty($total_extra))
							{
								foreach($total_extra as $t_val)
								{
									$coun_t += $t_val->extra_metting;
								}
							}
							$extra_meting= $coun_t;
                  	}
                  	else
                  	{
                  		$extra_meting =$get_extra_from_userTable;
                  	}
            /*===========================Check Extra Metting ======================*/

			$alreadyval = $this->common_model->getRows('time_schedule','id',array('customerid'=>$this->input->post('custid'),'status'=>1),'id','DESC');

			$check_limit = $this->common_model->getRows('diets_plan_mapping','allowmeet_id',array('customer_id'=>$this->input->post('custid'),'week_id'=>$this->input->post('weekidd')),'id','DESC',0,1);

			$total_metting_limit = $extra_meting+$check_limit[0]->allowmeet_id;


			//
			/*$provider_emailId = "SELECT u.emailid,u.first_name as providename from user u left join provider p on p.pcustid = u.id where p.id = ".$this->input->post('providerid');
				$provider_email = $this->common_model->solveCustomQuery($provider_emailId);*/

			$updatecond=array('p.id'=>$this->input->post('providerid'));
			$updatefield='u.emailid,u.first_name as providename';
			$updatejoin=array(
											array(
												'join_table'=>'provider p',
												'on_first_table'=>'p.pcustid',
												'on_second_table'=>'u.id'
											));	
  $provider_email = $this->common_model->getJoinData("user u",$updatecond,$updatefield,$updatejoin,'','','u.id','asc',''); 


			$flag=0;
			 if($total_metting_limit > count($alreadyval))
			    {
			    	$return = $this->common_model->save('time_schedule',$data);
				    $this->common_model->update("customer_diets_plan",$data3,array('weeks'=>$this->input->post('weekidd')." ".$this->input->post('slottext'),'week_wise_days'=>$this->input->post('dayidd'),'customer_id'=>$this->input->post('custid')));
				    $flag=1;
					$sdate = date('M d Y',strtotime($this->input->post('appointmentdate')));
				    $stime = $this->input->post('slottext');


			    //$customername = $this->session->userdata('customers')->first_name;

			    $ffname=$this->session->userdata('customers')->first_name;
				$llname=$this->session->userdata('customers')->last_name;

				if((isset($ffname)) && ($ffname !='') && ((isset($llname)) && $llname !=''))
				{
					$customername =$ffname." ".$llname;
				}
				else
				{
					$customername =$ffname;
				}


			    $emailid = $this->session->userdata('customers')->emailid;
				//This is used for customer schedule mail

				$done_schedule_data = $this->common_model->getprovidername($cid);
								if(!empty($done_schedule_data))
								{
									$proname = $done_schedule_data;
								}

				$sub33= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>3,'status'=>1));	
				$this->common_model->commonMail(3,$sub33,$emailid,'',
					@$stime,@$sdate,$customername,$proname,$provider_email[0]->emailid);	

				//This is used for Admin schedule mail				
				$sub122= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>12,'status'=>1));
				$this->common_model->commonMail(15,$sub122,$provider_email[0]->emailid,'',
					@$stime,@$sdate,$customername,$proname,$emailid);

			    }
			    
			if($flag==1){
				echo 1;exit;
			}else{
				echo 0;exit;
			}

			}
			else
			{
				echo 2;exit;
			}
				
		}

public function time_schedule_data(){
			
			$custmess =$this->session->userdata('customers');

			if(!empty($custmess))
			{
			$cid = $this->session->userdata('customers')->id;
			$data = array(
				'customerid' => $this->input->post('custid'),
				'providerid' => $this->input->post('providerid'),
				'slotvalue' => $this->input->post('slotval'),
				'slottime' => $this->input->post('slottext'),
				'weekid' => $this->input->post('weekidd'),
				'dayid' => $this->input->post('dayidd'),
				'status' =>1,
				'schedule_date' =>date('Y-m-d',strtotime($this->input->post('appointmentdate'))),
				'created_date' =>date('Y-m-d'),
				'created_by' => $cid
			);

			$data3 = array(
				'meeting_date' =>date('Y-m-d',strtotime($this->input->post('appointmentdate')))." ".$this->input->post('slottext')
			);



				/*==================Check Extra Metting ========================*/
     $extra_meting=0;
     $get_extra_from_userTable = $this->common_model->getCustomFielddata('user','extra_metting',array('id'=>$this->input->post('custid')));
    	if($get_extra_from_userTable == 0)
    	{
    		$extra_metting = "SELECT ANY_VALUE(week_id) as week_id,ANY_VALUE(extra_metting) as extra_metting FROM diets_plan_mapping where customer_id =".$this->input->post('custid')." and week_id <=".$this->input->post('weekidd')." group by week_id,extra_metting";
							$total_extra = $this->common_model->solveCustomQuery($extra_metting);
							$coun_t=0;
							if(!empty($total_extra))
							{
								foreach($total_extra as $t_val)
								{
									$coun_t += $t_val->extra_metting;
								}
							}
							$extra_meting= $coun_t;
                  	}
                  	else
                  	{
                  		$extra_meting =$get_extra_from_userTable;
                  	}

     /*========================Check Extra Metting ======================*/
               
			$alreadyval = $this->common_model->getRows('time_schedule','id',array('customerid'=>$this->input->post('custid'),'status'=>1),'id','DESC');
			$check_limit = $this->common_model->getRows('diets_plan_mapping','allowmeet_id',array('customer_id'=>$this->input->post('custid'),'week_id'=>$this->input->post('weekidd')),'id','DESC',0,1);

			$total_metting_limit = $extra_meting+$check_limit[0]->allowmeet_id;

			$flag=0;

			/*$provider_emailId = "SELECT u.emailid,u.first_name as providename from user u left join provider p on p.pcustid = u.id where p.id = ".$this->input->post('providerid');
				$provider_email = $this->common_model->solveCustomQuery($provider_emailId);
				*/

			$provcond=array('p.id'=>$this->input->post('providerid'));
			$provfield='u.emailid,u.first_name as providename';
			$provjoin=array(
											array(
												'join_table'=>'provider p',
												'on_first_table'=>'p.pcustid',
												'on_second_table'=>'u.id'
											));	
  $provider_email = $this->common_model->getJoinData("user u",$provcond,$provfield,$provjoin,'','','u.id','asc',''); 

			 if($total_metting_limit > count($alreadyval))
			    {

								$return = $this->common_model->save('time_schedule',$data);
								$this->common_model->update("customer_diets_plan",$data3,array('weeks'=>$this->input->post('weekidd')." ".$this->input->post('slottext'),'week_wise_days'=>$this->input->post('dayidd'),'customer_id'=>$this->input->post('custid')));
								$flag=1;
								$sdate = date('M d Y',strtotime($this->input->post('appointmentdate')));
								$stime = $this->input->post('slottext');

								$emailid= $this->session->userdata('customers')->emailid;

								$ffname=$this->session->userdata('customers')->first_name;
								$llname=$this->session->userdata('customers')->last_name;

								if((isset($ffname)) && ($ffname !='') && ((isset($llname)) && $llname !=''))
								{
								$customername =$ffname." ".$llname;
								}
								else
								{
								$customername =$ffname;
								}



								//This is used for customer schedule mail
								$done_schedule_data = $this->common_model->getprovidername($cid);
								if(!empty($done_schedule_data))
								{
									$proname = $done_schedule_data;
								}
								
								$sub33= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>3,'status'=>1));	
								$this->common_model->commonMail(3,$sub33,$emailid,'',
								@$stime,@$sdate,$customername,$proname,$provider_email[0]->emailid);	

								//This is used for Admin schedule mail				
								$sub122= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>12,'status'=>1));
								$this->common_model->commonMail(15,$sub122,$provider_email[0]->emailid,'',
								@$stime,@$sdate,$customername,$proname,$emailid);
			
			    }


			if($flag==1)
				{
					echo 1;exit;
				}
				else
				{
					echo 0;exit;
				}

			}
			else
			{
				echo 2;exit;
			}
		}
	public function daily_dite_log_details($page=0)
	{
		
		/**********************************************/
        
		$segment='';
		$segment = $this->session->userdata('customers')->id;
		//echo 'In View and segment is '. $segment; die;
		$max_cust_data = $this->common_model->solveCustomQuery("SELECT customer_diets_plan_id FROM customer_diets_plan_desc WHERE customer_diets_plan_id IN (SELECT id FROM  `customer_diets_plan` WHERE customer_id ='".$segment."') GROUP BY (customer_diets_plan_id) ORDER BY COUNT( diet_plan_id ) DESC limit 1");
		$data['dynamic_menu'] = $this->common_model->getRows('dynamicDietslog','*',array('tbl_status'=>1,),'status','desc');
			if(isset($max_cust_data) && !empty($max_cust_data))
			{
				$customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
				$qry_diet_plan_id=array();
				$scond=array('customer_diets_plan_desc.customer_diets_plan_id'=>$customer_diets_plan_id);
				$sfield='ANY_VALUE(dietsplan.diet_name) as diet_name,ANY_VALUE(dietsplan.id) as dietsplan_id,ANY_VALUE(input_type) AS input_type,ANY_VALUE(dietsplan.log_detail_label) AS log_detail_label';
				$sjoin=array(
							array(
								'join_table'=>'dietsplan',
								'on_first_table'=>'dietsplan.id',
								'on_second_table'=>'customer_diets_plan_desc.diet_plan_id'
							));	
				$data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc",$scond,$sfield,$sjoin,'','','ANY_VALUE(dietsplan.display_order)',
				'asc','dietsplan.log_detail_label');
			}

		/*************************************************/

		$startDate='';$endDate='';
		$cond='';
		$submit = $this->input->post('submit');
		$custid=''; $custid= $this->session->userdata('customers')->id;
        //echo 'Inside daily_dite_log_details and CustId = '. $custid; die;
        $data['custid'] = $custid;

			$data['startDate']=$startDate = $this->input->post('startDate');
			$data['endDate']=$endDate = $this->input->post('endDate');


			if($submit !=''){
				if($startDate !='' && $endDate !=''){
					$cond=" date(c.created_date)>='".date('Y-m-d',strtotime($startDate))."'
							   AND date(c.created_date)<='".date('Y-m-d',strtotime($endDate))."'";
				}elseif($startDate !=''){
					$cond=" date(c.created_date)>='".date('Y-m-d',strtotime($startDate))."'";
				}elseif($endDate !=''){
					$cond=" date(c.created_date)<='".date('Y-m-d',strtotime($startDate))."'";
				}
				if(!empty($cond)){
						$cond="and ".$cond;
				}
			}
			
			$data['act'] = base_url('home/daily_dite_log_details');

		if((bool)$this->session->userdata('payment_status')==FALSE)
		{
			redirect('home/subscription');
			exit();
		}
		if(!empty($custid)){
				$page_id=$this->input->get('page_id');
				$limit = 250;
				if (isset($_GET["pageno"])) {
				$page  = base64_decode($_GET["pageno"]);

				} else {
					$page=1;
					};

					$start_from = ($page-1) * $limit;
				
					$photo_data= "SELECT   c.id,c.week_wise_days,c.customer_id,c.meeting_date,c.comments,c.weeks,c.weight,c.created_date,c.staff_comments,c.created_by,c.updated_by,c.steps,e.exercise_name	from customer_diets_plan as c left join exercise as e on c.exercise_id=e.id WHERE c.customer_id=".$custid."  ".$cond."  ORDER BY c.weeks DESC,c.week_wise_days desc LIMIT ".$start_from.",".$limit."";
					$data['rec']= $this->common_model->solveCustomQuery($photo_data);

					/*$logdetaildata="c.id1,c.week_wise_days,c.customer_id,c.meeting_date,c.comments,c.weeks,c.weight,c.created_date,c.staff_comments,c.created_by,c.updated_by,c.steps,e.exercise_name";
					$logcond=array('c.customer_id'=>$custid." ".$cond);
					$logjoin=array(
					array(
						'join_table'=>'exercise as e',
						'on_first_table'=>'c.exercise_id',
						'on_second_table'=>'e.id'
					));	

					$data['rec'] = $this->common_model->getJoinData("customer_diets_plan as c",$logcond,$logdetaildata,$logjoin,$start_from,$limit,'',
					'asc','c.weeks,c.week_wise_days');*/

                    //echo '<pre>'; print_r($data['rec']); die;


					if(!empty($data['rec'][0]->weeks)){
						$data['weekno']=$data['rec'][0]->weeks;
					}

					$data['total_pages']='';
					//$data['pid']=$page;
					$total_get_sql = "SELECT count(*) as total FROM customer_diets_plan where customer_id='".$custid."'";
					$total_get = $this->common_model->solveCustomQuery($total_get_sql);
					if(isset($total_get[0]->total) && !empty($total_get[0]->total)){
					$total_records=$total_get[0]->total;
					$data['total_pages'] = ceil($total_records / $limit);
					$data['start']=$start_from;
					$data['totalrecords']=$total_records;
					}
					$max_cust_data = $this->common_model->solveCustomQuery("
									SELECT customer_diets_plan_id
									FROM customer_diets_plan_desc
									WHERE customer_diets_plan_id
									IN (

									SELECT id
									FROM  `customer_diets_plan`
									WHERE customer_id ='".$custid."'
									)
									GROUP BY (
									customer_diets_plan_id
									)
									ORDER BY COUNT( diet_plan_id ) DESC limit 1
								");
			if(isset($max_cust_data[0]->customer_diets_plan_id) && !empty($max_cust_data[0]->customer_diets_plan_id)){
			$customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
			$qry_diet_plan_id=array();
			

/*
			$qry_diet_plan_id = "SELECT dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type FROM customer_diets_plan_desc  join dietsplan on dietsplan.id=customer_diets_plan_desc.diet_plan_id
			where customer_diets_plan_desc.customer_diets_plan_id = '".$customer_diets_plan_id."' order by display_order asc";

			$data['diet_label']= $this->common_model->solveCustomQuery($qry_diet_plan_id);*/

			/*	$scond=array('customer_diets_plan_desc.customer_diets_plan_id'=>$customer_diets_plan_id);
				$sfield='dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type';
				$sjoin=array(
												array(
													'join_table'=>'dietsplan',
													'on_first_table'=>'dietsplan.id',
													'on_second_table'=>'customer_diets_plan_desc.diet_plan_id'
												));	
				$data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc",$scond,$sfield,$sjoin,'','','',
				'asc','');
			*/



				foreach($data['diet_label'] as $keys=>$values){//echo '<pre>';print_r();die;
					$mappid[] =$values->dietsplan_id;
				}
			}
				if(isset($mappid) && !empty($mappid)){
					$data['all_diet_id']=$mappid;
				}
				$data['cust_id']= $custid;
				$data['cust_registration_date']=$this->common_model->getRow('user','registration_date',array('id'=>$custid));
				
				//echo '<pre>';print_r($data);die;
				$this->load->view('frontend/daily_dite_log_details',$data);
		}else{
			redirect('/');
			}
	}

//This function is used to search daily diet data on front end
	public function search_daily_diet_log()
	{

			$from_date = $this->input->post('from_date');
			$to_date = $this->input->post('to_date');
			

		/*	$search_daily_diet_log= "SELECT id,week_wise_days, customer_id, meeting_date, comments,weeks,weight,dietsd.created_date,staff_comments,created_by,updated_by	FROM customer_diets_plan as dietsd where customer_id='".$custid."' and date(dietsd.created_date)>='".date('Y-m-d',strtotime($from_date))."' and date(dietsd.created_date)<='".date('Y-m-d',strtotime($to_date))."' ORDER BY id desc";
			$data['rec']= $this->common_model->solveCustomQuery($search_daily_diet_log);*/

$selectdata ='SELECT id,week_wise_days, customer_id, meeting_date, comments,weeks,weight,dietsd.created_date,staff_comments,created_by,updated_by';
$searchcond=array('customer_id'=>$custid,'date(dietsd.created_date)>='=>date('Y-m-d',strtotime($from_date)),'date(dietsd.created_date)<='=>date('Y-m-d',strtotime($to_date)));

$data['rec']= $this->common_model->getRows('customer_diets_plan',$selectdata,$searchcond);



/*			$total_get_sql = "SELECT count(*) as total FROM customer_diets_plan where customer_id='".$custid."'";
			$total_get = $this->common_model->solveCustomQuery($total_get_sql);*/
$total_get = $this->common_model->getRows('customer_diets_plan','count(*) as total',array('customer_id'=>$custid));



			if(isset($total_get[0]->total) && !empty($total_get[0]->total)){
			$total_records=$total_get[0]->total;
			$data['total_pages'] = ceil($total_records / $limit);
			}

			$max_cust_data = $this->common_model->solveCustomQuery("
								SELECT customer_diets_plan_id
								FROM customer_diets_plan_desc as dietdesd
								WHERE customer_diets_plan_id
								IN (
								SELECT id
								FROM  `customer_diets_plan`
								WHERE customer_id ='".$custid."' and date(dietdesd.created_date)>='".date('Y-m-d',strtotime($from_date))."' and date(dietdesd.created_date)<='".date('Y-m-d',strtotime($to_date))."'
								)
								GROUP BY (
								customer_diets_plan_id
								)
								ORDER BY COUNT( diet_plan_id ) DESC limit 1
							");
		
			if(isset($max_cust_data[0]->customer_diets_plan_id) && !empty($max_cust_data[0]->customer_diets_plan_id))
			{
			$customer_diets_plan_id = $max_cust_data[0]->customer_diets_plan_id;
			$qry_diet_plan_id=array();

		/*	$qry_diet_plan_id = "SELECT dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type FROM customer_diets_plan_desc  join dietsplan on dietsplan.id=customer_diets_plan_desc.diet_plan_id where customer_diets_plan_desc.customer_diets_plan_id
			= '".$customer_diets_plan_id."' order by display_order asc";
			$data['diet_label']= $this->common_model->solveCustomQuery($qry_diet_plan_id);*/

			//Conditions---------------------
			$scond=array('customer_diets_plan_desc.customer_diets_plan_id'=>$customer_diets_plan_id);
			$sfield='dietsplan.diet_name,dietsplan.id as dietsplan_id,input_type';
			$sjoin=array(
										array(
											'join_table'=>'dietsplan',
											'on_first_table'=>'dietsplan.id',
											'on_second_table'=>'customer_diets_plan_desc.diet_plan_id'
										));	
			$data['diet_label'] = $this->common_model->getJoinData("customer_diets_plan_desc",$scond,$sfield,$sjoin,'','','',
			'asc','display_order');

   	//End Conditions---------------------


				foreach($data['diet_label'] as $keys=>$values)
				{
					$mappid[] =$values->dietsplan_id;
				}
			}
			if(isset($mappid) && !empty($mappid)){
				$data['all_diet_id']=$mappid;
			}
	}


	//This function is used to diaplay content on home page
	public function homepage($page=0)
	{
			$page_id=$this->input->get('page_id');
			
			$data['page_data']=$this->common_model->getRows("page","*",array("page_status"=>1,"page_id"=>base64_decode($page_id)));
			//print_r($data['page_data']);exit;

			if(!empty($data['page_data']))
			{
					if(isset($data['page_data']) && (!empty($data['page_data'])))
					{
						$data['page_data']=$this->common_model->getRows("page","*",array("page_status"=>1,"page_id"=>base64_decode($page_id)));
					}
					else
					{
						$data['recordnotfound']=$this->recordnotfound();
					}
					$this->load->view('frontend/homepage',$data);
					}
					else
					{
							redirect('/');
					}
	}
	//This function is diaplay all customer message list
	public function customer_message()
	{
		$custmess = $this->session->userdata('customers');
		//print_r($custmess);die;
		if(empty($custmess))
		{
			redirect('/');
		}
		else
		{
		$updatedata = array
		(
				'weeks' => $this->input->post('num_weeks'),
				'week_wise_days' => $this->input->post('week_wise_days'),
				'customer_id' => $this->input->post('customerid')
			);
			$page_id=$this->input->get('page_id');
			$limit = 15;
			if (isset($_GET["pageno"]))
			{
					$page  = base64_decode($_GET["pageno"]);
			} 
			else
			{
						$page=1;
			}

			$start_from = ($page-1) * $limit;

  		//First query
		$cond=array('cdp.customer_id'=>@$this->session->userdata('customers')->id);
		$field='ANY_VALUE( m.Message) as Message,ANY_VALUE(cdp.acknowledgment) as acknowledgment ,ANY_VALUE(cdp.message_id) as message_id,ANY_VALUE(cdp.weeks) as week_id,ANY_VALUE(cdp.week_wise_days) as day_id';
		$join=array(
											array(
												'join_table'=>'messagecenterposttable as m',
												'on_first_table'=>'m.MessageID',
												'on_second_table'=>'cdp.message_id'
											));		  
		$data['rec'] = $this->common_model->getJoinData("customer_diets_plan as cdp",$cond,$field,$join,$limit,$start_from,'',
		'DESC','message_id');
		
	
if(!empty($custmess))
{
	$cond2=array('d.customer_id'=>$this->session->userdata('customers')->id);
	$field2='count(distinct message_id) as total';
	$join2=array(			array(
									'join_table'=>'messagecenterposttable as m',
									'on_first_table'=>'m.MessageID',
									'on_second_table'=>'d.message_id'
								));

$total_get_sql= $this->common_model->getJoinData("customer_diets_plan as d",$cond2,$field2,$join2,$limit,$start_from,'',
'DESC','message_id');

$total_get = $total_get_sql;

	if(!empty($total_get))
	{
				$total_records=$total_get[0]->total;
				$data['total_pages'] = ceil($total_records / $limit);
	}
}
$this->load->view('frontend/customer_message',$data);
}
}

 //This function is used to confirm acknowledgement
	public function update_acknowledgement()
	{
			$updatedata = array
			(
					'weeks' => $this->input->post('num_weeks'),
					'week_wise_days' => $this->input->post('week_wise_days'),
					'customer_id' => $this->input->post('customerid')
				);
				$data = array
				(
					'acknowledgment' =>1
				);
			$update= $this->common_model->update("customer_diets_plan",$data,$updatedata);
			if(!empty($update))
			{
				echo 1;exit;
			}
			else
			{
				echo 0;exit;
			}
	}	
//This function is used to get create date of cutomer
	public function next_day_start_session()
	{
			$finalval =$this->common_model->next_day_start_session();
			if($finalval==0){
				redirect('profile');
			}
		}

		//This function is used for additional profile page
	public function check_additional_profile()
	{
		$customer_id=$this->session->userdata('customers')->id;
		$customer_data =$this->common_model->getRows("user","weight",array("id"=>$customer_id));
		//print_r($customer_data);
		if(empty($customer_data))
		{
			redirect('additional-profile');
		}
	}

	//This function is used to verify the mail
	public function verify_email()
	{
			$email=$this->input->get('email');
			$hash=$this->input->get('hash');
			$udata=array("active" =>1,"verified_date"=>date('Y-m-d H:i:s'));
			$cust_data=$this->common_model->getRows("user","*",array("emailid"=>$email));
			if($cust_data)
			{
					if($cust_data[0]->hash==$hash && $cust_data[0]->active==0)
					{
						$activate = $this->common_model->update('user', $udata, $cond=array("emailid"=>$email));
						$this->msg = array('msg'=>'Your account has been activated, you can now login', 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
						$this->load->view('frontend/sign-up');
					}
					else
					{
						$this->msg = array('msg'=>'The url is either invalid or you already have activated your account.', 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
						$this->load->view('frontend/sign-up');
					}
		}
	}

	//This function is used to show contact us page
	public function contactus()
	{
			$this->load->view('frontend/contactus');
 }
	//This function is used to save contact us data	
	public function savecontactus()
	{
			$config = array(
					array(
						'field' => 'firstname',
						'label' => 'first name',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => 'Please enter %s.',
						),
				    ),
					array(
						'field' => 'emailid',
						'label' => 'Email id',
						'rules' => 'trim|required|valid_email',
						'errors' => array(
								'required' => 'Please enter %s.',
						),
				    ),
			);

			$this->form_validation->set_rules($config);
			if($this->form_validation->run() == false)
				{
					return $this->contactus();
				}
				else
				{
					$url="https://www.google.com/recaptcha/api/siteverify";
    				$secret='6LfVHuUUAAAAAMIpKQS_jDG03CsWHL-YvZgQXypT';
    				$recaptcha = $_POST['g-recaptcha-response'];
    				$post_field = array('secret'=>$secret,'response'=>$recaptcha);
    				$ch=curl_init();  
         			curl_setopt($ch, CURLOPT_HEADER, 0); 
			        curl_setopt($ch, CURLOPT_VERBOSE, 0);  
			        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  
			        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  
			        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); 
			        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');  
			        $url.='?'.http_build_query($post_field); 
			        curl_setopt($ch, CURLOPT_URL, $url);
			        $response=curl_exec($ch); 
			        curl_close($ch); 
			        $res_arr = json_decode($response,true);
    				if($res_arr['success'] == 1){
    					$data = array(
					'firstname' => $this->input->post('firstname'),
					'lastname' => $this->input->post('lastname'),
					'emailid' => $this->input->post('emailid'),
					'mobileno' => $this->input->post('mobileno'),
					'description' =>$this->input->post('description'),
					'created_date' => date('Y-m-d H:i:s'),
					'status' => '1'
				);

					if((bool)$this->common_model->save('contactus',$data) === TRUE)
					{
						//$to = 'p9006614336@gmail.com';
						$to = 'info@wellnessfromfood.com';
						$message ="<p><strong>First Name</strong> : ".$this->input->post('firstname')."</p><p><strong>Last Name</strong> : ".$this->input->post('lastname')."</p><p><strong>Email Id</strong> : ".$this->input->post('emailid')."</p><p><strong>Mobile</strong> : ".$this->input->post('mobileno')."</p><p><strong>Description</strong> : ".$this->input->post('description');
						
						$subject = "Contact us";

						$this->common_model->Send_GetStarted_Mail(array('to'=>$to,'subject'=>$subject,'msg'=>$message));
					
						$this->msg = array('msg'=>'Thank you for contact us.', 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
						redirect('home/contactus');
					}
					else
					{	$this->msg = array('msg'=>$this->lang->line('RECORD_ERROR'), 'msg_type'=>'danger');
						$this->session->set_flashdata($this->msg);
						redirect('home/contactus');
					}
    				}
			}
		}

		//This function is used to check user availability
		public function checkuser_availability()
		{
					$checkemailid = $this->input->post('emailid');
					$query = $this->db->query("select id from user where emailid='".$checkemailid."' and user_type=1");
					$res = $query->result();
					$row = $res[0];
					if(!empty($row))
					{
						echo 1; exit;
					}else
					{
						echo 0; exit;
					}
		}

		//This is used to send password mail
	 public function PasswordMail($emailid)
	  {
				$password=$this->randomPassword();
				$md = 	$this->hash_password($password);
				$udata=array("password" =>$md);
				$cust_data=$this->common_model->getRows("user","first_name",array("emailid"=>$emailid));
				$data['sendpass'] =$password;
				$data['email'] =$emailid; //'gla.anilgupta88@gmail';//
				$name=ucwords(strtolower($cust_data[0]->first_name));
				$data['customer_name']=$name;
				$status = '';
				$updatepass="";
				//$updatepass = $this->common_model->update('user', $udata, $cond=array("emailid"=>$emailid));
			if($updatepass)
			{
						$message=$this->load->view('frontend/email/forgot_password',$data,true);
						$subject=$name.',Wellness From Food';
						$to = $emailid;
						$this->common_model->Send_GetStarted_Mail(array('to'=>$to,'subject'=>$subject,'msg'=>$message));
			}
}


	//This is used for password hashing code 
	private function hash_password($password)
	{
		return password_hash($password, PASSWORD_BCRYPT);
	}
	public function randomPassword()
	 {
				$alphabet = "abcdefghijklmnopqrstuwxyz@#!$0123456789";
				$pass = array();
				$alphaLength = strlen($alphabet) - 1;
				for ($i = 0; $i <= 6; $i++)
				 {
						$n = rand(0, $alphaLength);
						$pass[] = $alphabet[$n];
				}
				return implode($pass);
	}

//This test mail code
	public function test()
	{
		$maildata= array(
			'emailid'=>"gla.anilgupta88@gmail.com",
			'full_name'=>"Anil Gupta",
			'contact_no'=>9006614336,
			'price'=>500);
		$user_data= $this->common_model->getRows('user','type,hash',array('emailid'=>$maildata['emailid']));
		$data['hash']=$user_data[0]->hash;
		$data['type']=$user_data[0]->type;
		$password=$this->randomPassword();
		$md = 	$this->hash_password($password);
		$udata=array("password" =>trim($md));
		$data['sendpass'] =$password;
		$data['email'] =$maildata['emailid']; //'gla.anilgupta88@gmail';//
		$data['full_name']=$name=ucwords(strtolower($maildata['full_name']));
		$data['customer_name']=$name;
		$data['contact_no'] =$maildata['contact_no'];
		$data['price']=$maildata['price'];
		$massege = $this->load->view('frontend/email/normal',$data,true);
		$subject ="Wellness";
		$email_dat = array(
							'to'=>"cchaubey55@gmail.com",
							'subject'=>$subject,
							'msg'=>$massege);
		$res = $this->common_model->Send_GetStarted_Mail($email_dat);
		echo $res;
	}


 //This function is show subscription message
	public function subsuscriptionmsg()
	{
		$id = $this->input->post('id');
		$msgname= $this->common_model->getRows('subscriptionmsg','messagename',array('id'=>$id));
		if(!empty($msgname))
				{
					echo "<h6>".$msgname[0]->messagename."</h6>"; exit;
				}
	}

	public function testimonials(){
		    $data['testimonial_data'] = $this->common_model->getRows('testimonials','testimonial_id,testimonial_name,testimonial_description,testimonial_image,created_date',array('testimonial_status'=>'1'),'display_order','asc');
			$this->load->view('frontend/testimonials',$data);
		}
	public function testimonial_details(){
			$testimonial_id =  $this->uri->segment(3);
			$data['testimonial_details'] = $this->common_model->getRow('testimonials','testimonial_name,testimonial_description,testimonial_image,created_date',array('testimonial_id'=>base64_decode($testimonial_id)));
			if(!empty($data['testimonial_details']))
			{
				$this->load->view('frontend/single_testimonial',$data);
			}
			else
			{
				redirect('/');
			}

		}
	public function mail_tt(){
		
		$to = array("Chandra"=>"cchaubey55@gmail.com","chaubey"=>"p9006614336@gmail.com");
		$a=array();
		foreach($to as $k=>$y){
			$b = array("email"=>$y,"name"=>$k);
			$a[]=$b;
		}
		$subject = "Need to contact customer – WellnessFromFood";
		$msg = "this is test mail";

		$mail_data = array(
  					'sender' => array(
    							'name' => 'WellnessFromFood',
    							'email' => 'info@wellnessfromfood.com'),
  					'to' => $a,
  					'htmlContent' => $msg,
  					'textContent' => $msg,
  					'subject' => $subject,
  					//'replyTo' => ,
  					'tags' => array(array('Wellness'))
  				);

		  $curl = curl_init();
		  curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://api.sendinblue.com/v3/smtp/email",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => json_encode($mail_data),
		  CURLOPT_HTTPHEADER => array("Content-Type: application/json","api-key: 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",
		    "cache-control: no-cache"),));

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		print_r($response);
	}

	public function update_menuStatus()
	{
		$val = $this->input->post('val');
		if(!empty($val)){
			$this->common_model->update('dynamicDietslog',array('status'=>0),array('tbl_status'=>1));
		$sql = "UPDATE dynamicDietslog SET status = 1 WHERE id IN (".$val.")";
		$result = $this->common_model->mauti_update($sql);
		echo $result;
	}else{
		echo 2;
	}
		
		
	}

	public function recipes(){
	    $data['blogs_name'] = $this->common_model->getRows('recipes','id,title,short_description,image,created_date',array('status'=>'1','type'=>1),'display_order','asc');
	    $data['recipe'] = true;
		$this->load->view('frontend/blogs',$data);
	}
	public function recipe_details(){
		$this->load->library('user_agent');
		$data['previous_url'] = $this->agent->referrer();
		$blogid =  $this->uri->segment(3);
		$data['blog_details'] = $this->common_model->getRows('recipes','*',array('id'=>base64_decode($blogid)));
		if(!empty($data['blog_details']))
		{
			$this->load->view('frontend/single_recipe',$data);
		}
		else
		{
			redirect('/');
		}
	}
	public function synk(){
		$data = $this->common_model->getRows('user','created_date,id');
		foreach($data as $value){
			$new =  array('registration_date'=>$value->created_date." 00-00-00");
			$this->common_model->update('user',$new,array('id'=>$value->id));
		}
	}

	
	

	
}
