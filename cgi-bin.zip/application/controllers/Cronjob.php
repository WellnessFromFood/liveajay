<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cronjob extends CI_Controller
{	
	public function index()
	{
		

     			$GetDays='';
				$getDate = $this->common_model->solveCustomQuery("SELECT ANY_VALUE(customer_id) as customer_id,ANY_VALUE(created_date) as created_date FROM `customer_diets_plan` group by customer_id desc");

				$getDays = $this->common_model->solveCustomQuery("SELECT days from automation where status=1 order by id desc limit 1");
				if(isset($getDays) && !empty($getDays))
				{
					$GetDays = $getDays[0]->days;
				}
				//echo '<pre>'; print_r($GetDays);die;
			
				$fullname='';
				if(!empty($getDate))
				{
					foreach($getDate as $k=>$val)
					{

						$getDateval = $val->created_date;					
						$currentDate = date('Y-m-d H:i:s');
						$previousDate = $getDateval;
						$diff = strtotime($currentDate) - strtotime($previousDate);
						$days = ceil(($diff)/ (60*60*24));

						$getUserData = $this->common_model->getRows('user','first_name,last_name,emailid,id',
							array('id'=>$val->customer_id));

						if(isset($getUserData) && (!empty($getUserData)))
						{							
							$fullname= $getUserData[0]->first_name;
							//." ".$getUserData[0]->last_name
							$emailid = $getUserData[0]->emailid;
							$userid = $getUserData[0]->id;
						}
						$template ='<table role="presentation" border="0" cellpadding="0" 
							cellspacing="0" class="body"><tr>
					        <td>&nbsp;</td>
					        <td class="container">
					          <div class="content">
					            <table role="presentation" class="main">
					              <tr>
					                <td class="wrapper">
					                  <table role="presentation" border="0" cellpadding="0" cellspacing="0">
					                    <tr>
					                      <td>
					                        <p>Dear '.$fullname.',</p>
					                        <p>We noticed you haven\'t input your Daily Tracker information since '.$getDateval.' Please go to the <a target="_blank" href="https://wellnessfromfood.com/login">WellnessFromFood</a> site as soon as you can to log this information.</p>
						
											<p>It\'s important to track your information everyday so that it\'s as accurate as possible. If you\'re having any issues with logging in, or entering data, please contact us at </p><p>

											<a href="mailto:info@WellnessFromFood.com">info@WellnessFromFood.com.</a>

											</p>
											<p>Thank you,</p>
											<p>The WellnessFromFood Team</p>            	    
					                      </td>
					                    </tr>
					                  </table>
					                </td>
					              </tr>
					            </table>
					          </div>
					        </td>
					        <td>&nbsp;</td>
					      </tr>
					    </table>';
					    					   
						if($days >=$GetDays)
						{ 

							$email_dat = array
							(
							'to'=>$emailid,
							'subject'=>"We need your data – WellnessFromFood",
							'msg'=>$template
							);
							$this->common_model->Send_GetStarted_Mail($email_dat);
							$data=array(
								'emailid'=>$emailid,
								'userid'=>$userid,
								'created_date'=>date('Y-m-d H:i:s')
							);
							$this->common_model->save('automation_detail',$data);
						}
						else
						{
							//cron should not be work
						}

					}

	        	}
	        	else
				{
					//cron should not be work
				}        
        
       /* }*/
		
	}
	

}

