<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Automation extends CI_Controller
{	
    public function __construct()
	{
        parent::__construct();
        require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
    }
	public function calculate_date($get_created_date)
	{
				$nodays='';
				$noweek='';
				$days_info=array();

				$date1 = date('Y-m-d H:i:s');
				$date2 =  $get_created_date;
				$diff = strtotime($date1) - strtotime($date2);
				$days = ceil(($diff)/ (60*60*24));

				if($days >14){
					$noweek =  number_format($days/7,1);
					$totaldays= $days%7;
					$val = explode(".",$noweek);
					if($totaldays==0){
						$days_info['day']=7;
						$days_info['week'] = $val[0];
					}else{
						$days_info['day'] = $totaldays;
						$days_info['week'] = $val[0]+1;
					}
				//	if($totaldays==0){
					//	$days_info['day']=$val[1];
						//$days_info['week'] = $val[0];
				//	}else{
					//	$days_info['day'] = $val[1];
					//	$days_info['week'] = $val[0];
				//	}
					//$days_info['week'] = $val[0]+1;
				}else{
						$days_info['day'] ='';
						$days_info['week']= '';
				}
				//echo '<pre>'; print_r($days_info);die;
				return $days_info;


	}

	public function enrolleddata($user_id,$course="",$history_id)
	{ 
		$user_data = $this->common_model->getRow('user','lms_id,first_name,last_name',array('id'=>$user_id));
		$data = array(
			'user_id'=>$user_id,
			'name'=>$user_data->first_name." ".$user_data->last_name,
			'enrolled_on'=>$course,
			'created_date'=>date('Y-m-d h:i:s'),
			'lms_id'=>$user_data->lms_id,
			'automation_history_id'=>$history_id
		);
		$this->common_model->save('automation_nextlession',$data);
	}

	public function index()
	{
		$GetDays='';
		$getDateval='';
		$WFF='';
		//and id=764
		$check_auto = $this->common_model->getRow('automation_logs','*',array('id'=>2));
		if($check_auto->automation_status == 1){

		$his = array(
			'name'=>$check_auto->name,
			'start_runTime'=>date('Y-m-d h:i:s'),
			'action_taken'=>0,
			'automation_type'=>$check_auto->id);
		$history_id = $this->common_model->saveAndGetLastId('automation_history',$his);
		$this->common_model->update('automation_logs',array('started_on'=>date('Y-m-d'),'automation_status'=>3),array('id'=>2));
		$getDate = $this->common_model->solveCustomQuery("SELECT id,created_date,first_name,last_name,emailid,lms_id,subscription_plan_id FROM `user` where status=1  and created_date <>'0000-00-00' order by created_date desc");
		$action = 0;
	
		if(!empty($getDate))
		{
				
			foreach($getDate as $k=>$val)
			{
			    $emailid = $val->emailid;
		    	$lmsid = $val->lms_id;
			    $plan_id = $val->subscription_plan_id;
			    $user_id= $val->id;
			    if($plan_id==1)
			    {
			        TalentLMS::setDomain('diy-healthtransitionsuniversity.talentlms.com');
			    }else
			    {
			     	TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
			    }
				$getDateval = $val->created_date;	
				$noofweek = $this->calculate_date($getDateval);
				if(!empty($noofweek))
				{
					if($noofweek['week']==3 && $noofweek['day'] ==1)
					{
						
						try{
						    	TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '140'));
						        $this->enrolleddata($user_id,'WFF 3: Getting Started',$history_id);
						        $action++;
					        }catch(Exception $e){
	                            $e->getMessage();
	                        }
					
					}
					elseif($noofweek['week']==10 && $noofweek['day']==1)
					{
						//$WFF='WFF 4: A Quick Fix vs. A Way of Life';
						try{
						    TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '142'));
						$this->enrolleddata($user_id,'WFF 4: A Quick Fix vs. A Way of Life',$history_id);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }	
					}
					elseif($noofweek['week']==15 && $noofweek['day']==1)
					{
						//$WFF='WFF 5: Transition to Everyday Foods';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '144'));
						$this->enrolleddata($user_id,'WFF 5: Transition to Everyday Foods',$history_id);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==20 && $noofweek['day']==1)
					{
						//$WFF='WFF 6: Exercise?';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '146'));
						$this->enrolleddata($user_id,'WFF 6: Exercise?',$history_id);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==25 && $noofweek['day']==1)
					{
						//$WFF='WFF 7: "Cheating" and Experiencing Setbacks';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '148'));
						$this->enrolleddata($user_id,'WFF 7: "Cheating" and Experiencing Setbacks',$history_id);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==30 && $noofweek['day']==1)
					{
						//$WFF='WFF 8: Therapeutic Fasting';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '150'));
						$this->enrolleddata($user_id,'WFF 8: Therapeutic Fasting',$history_id);
						
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==35 && $noofweek['day']==1)
					{
						//$WFF='WFF 9: Managing Temptations';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '152'));
						$this->enrolleddata($user_id,'WFF 9: Managing Temptations',$history_id);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}
					elseif($noofweek['week']==40 && $noofweek['day']==1)
					{
						//$WFF='WFF 10: Graduation!';
						try{
						TalentLMS_Course::addUser(array('user_id' => $lmsid, 'course_id' => '154'));
						$this->enrolleddata($user_id,'WFF 10: Graduation!',$history_id);
						$action++;
						}catch(Exception $e){
	                            $e->getMessage();
	                        }
					}	
				}
			}

		
		}
		$this->common_model->update('automation_logs',array('date_time_last_run'=>date('Y-m-d h:i:s'),'action_taken'=>$action,'automation_status'=>1),array('id'=>2));  
	    $this->common_model->update('automation_history',array('end_runTime'=>date('Y-m-d h:i:s'),'action_taken'=>$action),array('run_id'=>$history_id));

	}  
	       
}

public function cron_test(){
	$this->index();
}
}

