<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {
		function  __construct() {
			parent::__construct();
			$this->load->database();
			$this->load->model('backoffice/common_model');
			require_once APPPATH."third_party/instamojo_lib/src/Instamojo.php";
}
		public function index(){
			$data['act']=base_url('Payment/pay');;
			$this->load->view('frontend/payment/mojo',$data);			
		}

		public function courseAPI(){ 
				require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
				TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
				TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');
				//$user_data = TalentLMS_Course::all();
				$user_data =TalentLMS_Course::getUserStatus(array('user_id' => '1103', 'course_id' => '140'));

				//$user_data =TalentLMS_Course::addUser(array('user_id' => '1103', 'course_id' => '140'));
				echo '<pre>';print_r($user_data);die;

		}

		public function groupAPI(){ 

		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
		TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');
		$user_data = TalentLMS_Group::all();
		

		$group_val= array(
					'user_id'=>653,
			    	'group_key' =>'jp58pMhSr'
				);
		$group_info = TalentLMS_Group::addUser($group_val);
		echo '<pre>';print_r($group_info);die;
		}

		public function directloginLMS(){ 
		try{
		$emailid ='gla.anilgupta88@gmail.com';
		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
		TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');
		
		$expemailid = explode('@',$emailid);
		//print_r($expemailid);die;
		if(isset($expemailid) && ($expemailid !=''))
		{

			 $user_data = TalentLMS_User::retrieve(764);
			//$user_data = TalentLMS_Branch::all();

			echo '<pre>'; print_r($user_data); exit;
			$response = TalentLMS_User::login(array('login' =>trim($expemailid[0]), 
				'password' =>trim($expemailid[0]),'logout_redirect' =>base_url('loginsignup/logout')));

			print_r($response);die;

		}
		if(!empty($response))
		{
			$this->redirect($response['login_key']);
		}
		
		}catch(Exception $e) {
			echo "Password not match".'Message: ' .$e->getMessage();

		}
	}

	public function userINFO()
	{ 
		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
		TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');
		$user_data = TalentLMS_User::retrieve(1103);

		foreach($user_data['courses'] as $key=>$val)
		{
	        $data = array
		        (
	        		'name'=>$val['name'],        		
	        		'enrolled_on'=>$val['enrolled_on'],
	        		'enrolled_on_timestamp'=>$val['enrolled_on_timestamp'],
	        		'external_id'=>$val['id'],
	        		'created_date'=>date('Y-m-d H:i:s')   		
		        );  

	        $this->common_model->save('automation_nextlession',$data);
		}
		 /*[id] => 140
                    [name] => WFF 3: Getting Started
                    [role] => learner
                    [enrolled_on] => 2019/08/30, 22:41:41
                    [enrolled_on_timestamp] => 1567230101*/
             
		
	}

	public function signupAPI()
	{ 
				require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
				TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
				TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');
				
				

				//$expemailid = explode('@',$getuserdata->emailid);
				
				$info = array(			
					'custom_field_1' => 'WellnessFromFood',
					'first_name' => 'Test23aug19',
					'last_name' => 'Test23aug9',
					 'email' => 'Test23aug19@gmail.com',
					 'login' => 'Test23aug',
					 'password' => '123456'
					);

				$usersignup =TalentLMS_User::signup($info);

				if(!empty($usersignup))
				{
				$info1 = array(
					'user_id'=> $usersignup['id'],
			    	'branch_id' => $branch_id
				);
				TalentLMS_Branch::addUser($info1);

				$group_val= array(
					'user_id'=>$usersignup['id'],
					'group_key' =>$group_key
				);
				$group_info = TalentLMS_Group::addUser($group_val);

				$created_on = explode(',',$usersignup['created_on']);			
				$updateinfo = $CI->common_model->update("user",
				array('lms_id'=>$usersignup['id'],
					'group_lms_id'=>$group_info['group_id'],
					'group_lms_name'=>$group_info['group_name'],
					'lms_created_date'=>date('Y-m-d H:i:s',strtotime(date('Y-m-d H:i:s'),$created_on[0]." ".$created_on[1]))),
				array('id'=>$getuserdata->id));

				}

		}


















		public function pay(){
			
			require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
			
			ini_set('display_errors', false);
			
			header('Content-Type: text/html; charset=utf-8');
			
			echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">';
			
			echo "<html><head><title>Branch Reports</title></head><body>";
			
			try{
			
			// TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
			// TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');
				$emailid ='washi.host@gmail.com';
			TalentLMS::setApiKey('gfKQd266a5BG6DauIIezMMMMmjpnGj');
			TalentLMS::setDomain('anil123.talentlms.com');
			
		$expemailid = explode('@',$emailid);
		//print_r($expemailid);die;
		if(isset($expemailid) && ($expemailid !=''))
		{

			$response = TalentLMS_User::login(array('login' =>trim($expemailid[0]), 
				'password' =>trim($expemailid[0]),'logout_redirect' =>base_url('loginsignup/logout')));

			print_r($response);die;

		}


			/*$info = array(			
					'custom_field_1' => 'WellnessFromFood',
					'first_name' => 'rgganghgeet',
					'last_name' => 'rwanghgeet',
					 'email' => 'rtadfghngeet@gmail.com',
					 'login' => 'rtadfdghngeet',
					 'password' => '1234567'
						);
				
			$usersignup =TalentLMS_User::signup(
								$info
			);
*/
			/*$branches =TalentLMS_Branch::all();

			foreach($branches as $branch)
			{
				echo '<pre>'; print_r($branch);
				if()
			}*/
			echo '<pre>'; print_r($usersignup);
die;
			/*if(!empty($usersignup))
			{
				$info1 = array(
					'user_id'=> $usersignup['id'],
			    	'branch_id' => '1'			    	
				);

				$usersbranch = TalentLMS_Branch::addUser($info1);
			}*/
			
			}
			catch(Exception $e) {
  				echo 'Message: ' .$e->getMessage();
				}


		}
			/*$branches = TalentLMS_Branch::all();
				foreach($branches as $branch){
					$currentBranch = TalentLMS_Branch::retrieve($branch['id']);
					$users = $currentBranch['users'];
						if(count($users) > 0){
							echo 'Users of branch <b>'.$currentBranch['name'].'</b>
							are:<br/>';
							echo '<ul>';
							foreach($users as $user){
							echo '<li>'.$user['name'].'</li>';
						}
					echo '</ul>';
					}
			}*/
			


			//echo '<pre>'; print_r($usersbranch);die;	
			
			//echo '<pre>'; print_r($usersignup);die;
		
			/*foreach($branches as $branch){
			
			$branchInfo = TalentLMS_Branch::retrieve($branch['id']);
			$branchUsers = $branchInfo['users'];
			$branchUsersIds = array();
			foreach($branchUsers as $user){
			array_push($branchUsersIds, $user['id']);
			}
			echo "<h3><u>Branch: {$branch['name']}</u></h3>";
			
			echo "Number of users: ".count($branchInfo['users'])."<br/>";
			
			echo "Number of courses:
			".count($branchInfo['courses'])."<br/>";
			echo "<ul>";
				
			foreach($branchInfo['courses'] as $course){
				
			
			$courseInfo = TalentLMS_Course::retrieve($course['id']);
			$assignedUsers = 0; // number of users in this course
			
			$completedUsers = 0;
			$learners = 0; // number of learners
			$instructors = 0; // number of instructors
			$completedUsersList = ''; // list of completed users
			$nonCompletedUsersList = ''; // list of non completed
			
			foreach($courseInfo['users'] as $user){
			// check if user
			
			if(in_array($user['id'], $branchUsersIds)){
			$assignedUsers++;
			if($user['role'] == 'learner'){
			$learners++;
			}
			else if($user['role'] == 'instructor'){
			$instructors++;
			}
			if(!empty($user['completed_on'])){
			$completedUsers++;
			$completedUsersList .=
			"<li><b>{$user['name']}</b> - {$user['role']} (Completed on:{$user['completed_on']})</li>";
			
			}
			else{
			$nonCompletedUsersList .="<li>{$user['name']} - {$user['role']}</li>";
			}
			}
			}
			echo "<li style='padding: 6px 0px;'>";
			echo "Course: <u><b>{$course['name']}</b></u><br/><br/>";
			echo "Number of assigned users: {$assignedUsers}<br/>";
			echo "Number of completed users: {$completedUsers}<br/>";
			echo "Number of learners: {$learners}<br/>";
			echo "Number of instructors: {$instructors}<br/>";
			if(isset($_GET['users']) && $_GET['users'] == '1'){
			echo
			"<br/><ol>{$completedUsersList}{$nonCompletedUsersList}</ol>";
			}
			echo "</li>";
			}
			echo "</ul>";
			}
			}
			catch(Exception $e){
			echo $e->getMessage();
			}
			echo "</body></html>";
			
		}		
		*/
		/* public function pay(){			
			$purpose = "purpose";
			$amount = 45;
			$name = "anil";
			$phone = 9911358039;
			$email = "a@gmail.com";
			$api = new Instamojo\Instamojo('3eb9562b97bdd2a2cf503f5335549119','569e684fb8f4ce64979d88c77246a38d');
			//print_r($api);die;
			try {
				$response = $api->paymentRequestCreate(array(
					"purpose" => $purpose,
					"amount" => $amount,
					"buyer_name" => $name,
					"phone" => $phone,
					"send_email" => false,
					"send_sms" => false,
					"email" => $email,
					'allow_repeated_payments' => false,
					"redirect_url" => "http://stercodigitex.net/wellness/payment/success",  //success page where gateway should redirect after payment,should always be an absolute url
					"webhook" => "http://stercodigitex.net/wellness/payment/webhook"  //notification page where instamojo sends payment gateway response, should always be an absolute url
					));
				//print_r($response);die;
				$payment_id = $response['id'];
				$this->session->set_userdata(array('payment_id'=>$payment_id));
				$pay_ulr = $response['longurl'];


				header("Location: $pay_ulr");
				exit();

			}
			catch (Exception $e) {
				print('Error: ' . $e->getMessage());
			}

		}
	public function success(){
		//echo "ssssssssssssssss";die;
		$api = new Instamojo\Instamojo('3eb9562b97bdd2a2cf503f5335549119','569e684fb8f4ce64979d88c77246a38d');
		//echo $payid = $this->db->get('payment_id');die;
		//$PAYMENTID =$this->input->get('payment_id');
		$PAYMENTID =$this->session->userdata('payment_id'); 
		try {
			$response = $api->paymentRequestStatus($PAYMENTID);
		echo "<h4>Payment ID: " . $response['payments'][0]['payment_id'] . "</h4>" ;
			echo "<h4>Payment Name: " . $response['payments'][0]['buyer_name'] . "</h4>" ;
			echo "<h4>Payment Email: " . $response['payments'][0]['buyer_email'] . "</h4>" ;
		  print_r($response);die;
		}
		catch (Exception $e) {
			print('Error: ' . $e->getMessage());
		}
	}
	public function webhook(){
			$data = $_POST;
			$mac_provided = $data['mac'];  // Get the MAC from the POST data
			unset($data['mac']);  // Remove the MAC key from the data.

			$ver = explode('.', phpversion());
			$major = (int) $ver[0];
			$minor = (int) $ver[1];

			if($major >= 5 and $minor >= 4){
				 ksort($data, SORT_STRING | SORT_FLAG_CASE);
			}
			else{
				 uksort($data, 'strcasecmp');
			}

					//if(LOG_MODE){
					//	if(LOG_TO_FILE){
							$myFile = 'payment_instamojo.log';
							$fh = fopen($myFile, 'a') or die('can\'t open file');				
					///	}
				  
						$log_data .= $nl.$nl.'=== ['.date('Y-m-d H:i:s').'] ==================='.$nl;
						$log_data .= '<br />---------------<br />'.$nl;
						$log_data .= '<br />POST<br />'.$nl;
						foreach($_POST as $key=>$value) {
							$log_data .= $key.'='.$value.'<br />'.$nl;        
						}
						$log_data .= '<br />---------------<br />'.$nl;
						$log_data .= '<br />GET<br />'.$nl;
						foreach($_GET as $key=>$value) {
							$log_data .= $key.'='.$value.'<br />'.$nl;        
						}        
				//	} 

			// You can get the 'salt' from Instamojo's developers page(make sure to log in first): https://www.instamojo.com/developers
			// Pass the 'salt' without the <>.
			$mac_calculated = hash_hmac("sha1", implode("|", $data), '3eb9562b97bdd2a2cf503f5335549119');

			if($mac_provided == $mac_calculated){
				echo "MAC is fine";
				// Do something here
				if($data['status'] == "Credit"){
				   // Payment was successful, mark it as completed in your database  
							
							$to = $admin_email;
							$subject = 'Website Payment Request ' .$data['buyer_name'].'';
							$message = "<h1>Payment Details</h1>";
							$message .= "<hr>";
							$message .= '<p><b>ID:</b> '.$data['payment_id'].'</p>';
							$message .= '<p><b>Amount:</b> '.$data['amount'].'</p>';
							$message .= "<hr>";
							$message .= '<p><b>Name:</b> '.$data['buyer_name'].'</p>';
							$message .= '<p><b>Email:</b> '.$data['buyer'].'</p>';
							$message .= '<p><b>Phone:</b> '.$data['buyer_phone'].'</p>';
							
							
							$message .= "<hr>";

						  
							$headers .= "MIME-Version: 1.0\r\n";
							$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
							// send email
							mail($to, $subject, $message, $headers);




				}
				else{
				   // Payment was unsuccessful, mark it as failed in your database
				}
			}
			else{
				echo "Invalid MAC passed";
			}

				//	if(LOG_MODE){
						$log_data .= '<br />'.$nl.$message.'<br />'.$nl;    
					//	if(LOG_TO_FILE){
							fwrite($fh, strip_tags($log_data));
							fclose($fh);        				
					//	}

					//}	

	}		 */
}
