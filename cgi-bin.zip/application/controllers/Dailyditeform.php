<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Dailyditeform extends CI_Controller
{
    public $data = array();
    public $msg = array();
    public function __construct()
	{
        parent::__construct();
		//$this->load->helper(array('cookie'));
		$idiom = $this->lang->load('message_lang');
		$this->lang->load('message_lang', $idiom);
    }
	public function refill_data()
	{
		$data=array();
		$customerid=$this->input->post('customerid');
		$customer_diets_info=$this->common_model->customer_prevoius_data($customerid);
		if(!empty($customer_diets_info))
		{
			foreach($customer_diets_info as $val)
			{
				if($val->input_type==1){
					$data['lblvalid'.$val->labelid]=$val->diet_plan_value;
				}else{
					$data['lblvalid'.$val->labelid]=$val->diet_plan_value;
				}
			}
			$data['weekid']=$customer_diets_info[0]->week_id;
			$data['dayid']=$customer_diets_info[0]->day_id;
			$data['Comments']=$customer_diets_info[0]->comments;
			$data['weight']=$customer_diets_info[0]->weight;
			$data['steps']=$customer_diets_info[0]->steps;
			$data['exercise_id']=$customer_diets_info[0]->exercise_id;
		}
		echo json_encode($data);
	}
	public function save_questionnaireform()
	{
		$getdata='';
	       //echo '<pre>'; print_r($this->input->post());die;
	    $customers=  $this->session->userdata('customers')->id;
	    $form_id = $this->input->post('formid');

		$getdata = $this->common_model->getRows('savequestionnnairfrmval','id',array('customer_id'=>$customers,'form_id'=>$form_id));
		if(!empty($getdata))
		{
		$this->db->query("delete from savequestionnnairfrmval where customer_id='".$customers."' and form_id='".$form_id."'");
		}


		$formid=''; $finalsubmit='';
		$formid =  $this->uri->segment(3);
		$save_questiondata = $this->input->post();
		foreach($save_questiondata as $k=>$val)
		{
			if(is_array($val) )
			{
				$val = implode(',',$val);
			}
			else
			{
				$val = $val;
			}

			//echo $val;die;
			$save_question = array(
							'customer_id' =>$this->session->userdata('customers')->id,
							'form_id' =>$this->input->post('formid'),
							'field_name' => $k,
							'field_value' =>$val
						);
			$finalsubmit= $this->common_model->save('savequestionnnairfrmval',$save_question);

		}
		if($finalsubmit !='')
		{

			$this->common_model->update('user',array('check_questionnaire'=>1),array('id'=>$this->session->userdata('customers')->id));

			$emailid = $this->common_model->getCustomFielddata('user','emailid',array('id'=>$this->session->userdata('customers')->id));
			//$sub='Wellness From Food Survey Results';
			$sub= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>6));
			$this->common_model->commonMail(6,$sub,$emailid);

			$this->msg = array('msg'=>lang('FORM_QUEST'), 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			//redirect('home/questionnaireform?formid='.($formid).'');
			redirect('daily-dite-form');
		}
	 // }
	//  echo "not fill data";exit;

	}
	public function medical_form()
	{   //echo "ddddddddddddd";die;
		//echo '<pre>'; print_r($this->input->post());die;
		//$this->session->unset_userdata('getsessionid');
		$email='';
		$blood_pressure_high='';
		$blood_pressure_low='';
		$blood_pressure_mng='';
		$blood_pressure_eve='';
		$blood_sugar_awake='';
		$blood_sugar_breakfast='';
		$blood_sugar_lunch='';
		$blood_sugar_dinner='';
		$checkstatus = $this->input->post('checkstatus');
		if($checkstatus ==1)
		{
			$getsessid = session_id();
			$this->session->set_userdata('specialsessionid',$getsessid);
		}
	
		
		$getsubid = $this->input->post('getsubid');
        $special = $this->input->post('special');
        $blood_pressure_high=$this->input->post('blood_pressure_high');
        $blood_pressure_low=$this->input->post('blood_pressure_low');
        $blood_pressure_mng=$this->input->post('blood_pressure_mng');
        $blood_pressure_eve=$this->input->post('blood_pressure_eve');
        $blood_sugar_awake=$this->input->post('blood_sugar_awake');
        $blood_sugar_breakfast=$this->input->post('blood_sugar_breakfast');
        $blood_sugar_lunch=$this->input->post('blood_sugar_lunch');
        $blood_sugar_dinner=$this->input->post('blood_sugar_dinner');

        if($special != '')
        {
            $this->session->set_userdata('special','special');
        }
       /* if($checkstatus==1)
        {
        	$insertdata= "insert into store_temp_data (blood_pressure_high,blood_pressure_low,blood_pressure_mng,
			blood_pressure_eve,blood_sugar_awake,blood_sugar_breakfast,blood_sugar_lunch
			,blood_sugar_dinner,session_id,special_user) values ($blood_pressure_high,$blood_pressure_low,$blood_pressure_mng,$blood_pressure_eve,$blood_sugar_awake,$blood_sugar_breakfast,$blood_sugar_lunch,$blood_sugar_dinner,'$getsessid','$special')";
		$this->db->query($insertdata);
        }*/
		
		     
		$message ="";
		$sub='Welcome to Wellness From Food!';
		$this->session->set_userdata('blood_pressure_high',$blood_pressure_high);
		$find_session_lname=$this->session->userdata('find_session_lname');
		$find_session_fname=$this->session->userdata('find_session_fname');
		$name=$find_session_fname." ".$find_session_lname;
        $user_id = 0;
		if($this->session->userdata('customers'))
		{
			$user_id=  $this->session->userdata('customers')->id;
		}
		if(isset($_SESSION['find_session_email']))
		{
			$email =$_SESSION['find_session_email'];
		}
		if($checkstatus==1 && $getsubid==2){
			//$this->common_model->sendmedicalMail(9,$name,$email,$sub,$message,$user_id);
			//$this->common_model->sendmedicalMail(9,$name,$email,$sub,$message,$user_id);
			echo 1; exit;
        }else{
           echo 'redirect to paynow'; exit;
           // echo 0; exit;

			}

	}
	public function savequestionnaireform()
		{
			//echo '<pre>'; print_r($this->input->post());die;
			$name='';$email='';$message='';
			$name = $this->input->post('name');
			$email = $this->input->post('email');
			$message = $this->input->post('message');
			$savequestion = array(
							'firstname' =>$this->input->post('fname'),
							'emailid' => $this->input->post('femail'),
							'description' =>$this->input->post('fmessage'),
							'created_date' => date('Y-m-d H:i:s'),
						);

				$finalsubmit= $this->common_model->save('contactus',$savequestion);
				//echo "dddddddddd".$finalsubmit;die;
				if($finalsubmit ==1){
					$sub='You contact us form has been submit.';
					$this->common_model->sendmedicalMail($name,'info@wellness.com',$sub,$message);
						/*if($sendmail !='')
						{

						}
						else
						{
						echo 0; exit;
						}*/
					echo 1; exit;
				}

		}
	public function save_getstarted()
	{
		//echo $this->input->post('name');
		//echo '<pre>'; print_r($this->input->post());die;
		$tempId = $this->input->post('tempId');
		
//If the user exists in the temp table - delete that entry
		if(!empty($tempId)){
			$this->common_model->delete('free_sample_lessons',array('id'=>trim($tempId)));
		}
		
		$xbreakfast = "Healthy breakfast snippet";
		$ybreakfast="Carb snippet";
		$zbreakfast="Add processed juice snippet";
		$abreakfast="Add unhealthy Snack snippet";
		$bbreakfast= "Add alcohol snippet";

		$formid=''; $finalsubmit='';

		$formid =  $this->uri->segment(3);
		$save_questiondata = $this->input->post();
		$save_medical = $this->input->post('medical');
		$password = $this->randomPassword();
		$md = 	$this->hash_password($password);
		$user_id = "";
		if($this->input->post('email') !="")
		{
			$user_input = array(
				'first_name'=>$this->input->post('first_name'),
				'last_name'=>$this->input->post('last_name'),
				'height'=>$this->input->post('height'),
				'weight'=>$this->input->post('weight'),
				'age'=>$this->input->post('age'),
				'emailid'=>$this->input->post('email'),
				'hash' => $hash = md5( rand(0,1000) ),
				'user_type'=>0,
				'status'=>1,
				'active'=>1,
				'role_type'=>4,                 //original value was 3
				'type'=>'get');
				$user_id = $this->common_model->saveAndGetLastId('user',$user_input);

		}

		foreach($save_questiondata as $k=>$val)
		{
			if(is_array($val) )
			{
				$val = implode(',',$val);
			}
			else
			{
				$val = $val;
			}
			if($k=='food_option')
			{
				$tempxyza_val=array();
				$tempsnack_val=array();
				$templunch_val=array();
				$tempnoon_val=array();
				$tempdinner_val=array();
				$finaltempxyza_val=array();
				$finaltempsnack_val=array();
				$finaltemplunch_val=array();
				$finaltempnoon_val=array();
				$finaltempdinner_val=array();
				$finaltempdinnersnk_val=array();
				$uniquefoodoption=$this->input->post('food_option');

				foreach($uniquefoodoption as $uk=>$uv)
					{
						$db_data = $this->common_model->getRows('foodoption','breakfast,morningsnack,lunch,afternoonsnack,dinner,dinnersnack',array('page_name'=>$uv));

						if(!empty($db_data))
						{
							$breakfst_val=explode(",",$db_data[0]->breakfast);
							$morningsnack_val=explode(",",$db_data[0]->morningsnack);
							$lunch_val=explode(",",$db_data[0]->lunch);
							$afternoonsnack_val=explode(",",$db_data[0]->afternoonsnack);
							$dinner_val=explode(",",$db_data[0]->dinner);
							$dinnersnack_val=explode(",",$db_data[0]->dinnersnack);

							if(isset($db_data[0]->breakfast))
							{
								foreach($breakfst_val as $single_val){
								$tempxyza_val[]=$single_val;
								}
							}
							if(isset($db_data[0]->morningsnack))
							{
								foreach($morningsnack_val as $msnack_val){
								$tempsnack_val[]=$msnack_val;
								}
							}
							if(isset($db_data[0]->lunch))
							{
								foreach($lunch_val as $mlnch_val){
								$templunch_val[]=$mlnch_val;
								}
							}
							if(isset($db_data[0]->afternoonsnack))
							{
								foreach($afternoonsnack_val as $noon_val){
								$tempnoon_val[]=$noon_val;
								}
							}
							if(isset($db_data[0]->dinner))
							{
								foreach($dinner_val as $din_val){
								$tempdinner_val[]=$din_val;
								}
							}
							if(isset($db_data[0]->dinnersnack))
							{
								foreach($dinnersnack_val as $dinsnack_val){
								$tempddinner_val[]=$dinsnack_val;
								}
							}



						}


					}
				$final_xyza_unique=array_filter(array_unique($tempxyza_val));
				$final_snack_unique=array_filter(array_unique($tempsnack_val));
				$final_lunch_unique=array_filter(array_unique($templunch_val));
				$final_noon_unique=array_filter(array_unique($tempnoon_val));
				$final_dinner_unique=array_filter(array_unique($tempdinner_val));
				$final_dinnersnack_unique=array_filter(array_unique($tempddinner_val));
				//echo '<pre>'; print_r(($final_xyza_unique));die;
				foreach($final_xyza_unique as $fval)
							{
								$fval = trim($fval);
								if($fval=='x')
								{
									$finaltempxyza_val[$fval]=$xbreakfast;
								}
								elseif($fval=='y')
								{
									$finaltempxyza_val[$fval]=$ybreakfast;
								}
								elseif($fval=='z')
								{
									$finaltempxyza_val[$fval]=$zbreakfast;
								}
								elseif($fval=='a')
								{
									$finaltempxyza_val[$fval]=$abreakfast;
								}
								elseif($fval=='b')
								{
									$finaltempxyza_val[$fval]=$bbreakfast;
								}

							}

				foreach($final_snack_unique as $fval)
							{
								$fval = trim($fval);
								if($fval=='x')
								{
									$finaltempsnack_val[$fval]=$xbreakfast;
								}
								elseif($fval=='y')
								{
									$finaltempsnack_val[$fval]=$ybreakfast;
								}
								elseif($fval=='z')
								{
									$finaltempsnack_val[$fval]=$zbreakfast;
								}
								elseif($fval=='a')
								{
									$finaltempsnack_val[$fval]=$abreakfast;
								}
								elseif($fval=='b')
								{
									$finaltempsnack_val[$fval]=$bbreakfast;
								}

							}
				foreach($final_lunch_unique as $fval)
							{
								$fval = trim($fval);
								if($fval=='x')
								{
									$finaltemplunch_val[$fval]=$xbreakfast;
								}
								elseif($fval=='y')
								{
									$finaltemplunch_val[$fval]=$ybreakfast;
								}
								elseif($fval=='z')
								{
									$finaltemplunch_val[$fval]=$zbreakfast;
								}
								elseif($fval=='a')
								{
									$finaltemplunch_val[$fval]=$abreakfast;
								}
								elseif($fval=='b')
								{
									$finaltemplunch_val[$fval]=$bbreakfast;
								}

							}
				foreach($final_noon_unique as $fval)
							{
								$fval = trim($fval);
								if($fval=='x')
								{
									$finaltempnoon_val[$fval]=$xbreakfast;
								}
								elseif($fval=='y')
								{
									$finaltempnoon_val[$fval]=$ybreakfast;
								}
								elseif($fval=='z')
								{
									$finaltempnoon_val[$fval]=$zbreakfast;
								}
								elseif($fval=='a')
								{
									$finaltempnoon_val[$fval]=$abreakfast;
								}
								elseif($fval=='b')
								{
									$finaltempnoon_val[$fval]=$bbreakfast;
								}

							}

				foreach($final_dinner_unique as $fval)
							{
								$fval = trim($fval);
								if($fval=='x')
								{
									$finaltempdinner_val[$fval]=$xbreakfast;
								}
								elseif($fval=='y')
								{
									$finaltempdinner_val[$fval]=$ybreakfast;
								}
								elseif($fval=='z')
								{
									$finaltempdinner_val[$fval]=$zbreakfast;
								}
								elseif($fval=='a')
								{
									$finaltempdinner_val[$fval]=$abreakfast;
								}
								elseif($fval=='b')
								{
									$finaltempdinner_val[$fval]=$bbreakfast;
								}

							}
				foreach($final_dinnersnack_unique as $fval)
							{
								$fval = trim($fval);
								if($fval=='x')
								{
									$finaltempdinnersnk_val[$fval]=$xbreakfast;
								}
								elseif($fval=='y')
								{
									$finaltempdinnersnk_val[$fval]=$ybreakfast;
								}
								elseif($fval=='z')
								{
									$finaltempdinnersnk_val[$fval]=$zbreakfast;
								}
								elseif($fval=='a')
								{
									$finaltempdinnersnk_val[$fval]=$abreakfast;
								}
								elseif($fval=='b')
								{
									$finaltempdinnersnk_val[$fval]=$bbreakfast;
								}

							}
                            // echo '<pre>'; print_r(($finaltempxyza_val));//die;
                            // echo '<pre>'; print_r(($finaltempsnack_val));//die;
                            // echo '<pre>'; print_r(($finaltemplunch_val));//die;
                            // echo '<pre>'; print_r(($finaltempnoon_val));//die;
                            // echo '<pre>'; print_r(($finaltempdinner_val));//die;
    						// echo '<pre>'; print_r(($finaltempsnack_val)); die;
                            $final_food_option_message = array_merge($finaltempxyza_val,$finaltempsnack_val,$finaltemplunch_val,$finaltempnoon_val,$finaltempdinner_val,$finaltempsnack_val);
                            // print_r($final_food_option_message);
                            // die;
							$breakft="";
                            foreach ($final_food_option_message as $food_key => $food_value)
                            {
                                if($food_key == 'x')
                                {
                                    $breakft .= '<p>It’s important to start your day off with a protein and fat filled breakfast to start off your morning. Unlike supposedly “healthy” breakfasts, Dr. Pruchno recommends no cereal, waffles, or pancakes. He also will teach you why fat-free milk is worse than whole milk! You’d also be surprised to learn that Dr. Pruchno supports having bacon or sausage with your breakfast.</p>';
                                }
                                if($food_key == 'y')
                                {
                                    $breakft .= '<p>It seems like you eat carbohydrate heavy meals. Like most Americans you were likely taught that healthy grains are the most important food to consume. After all, they are the largest category of the food pyramid. Dr. Pruchno will teach you that the food pyramid was based on politics more than nutrition, and why grains were recommended so highly.</p>';
                                }
                                if($food_key == 'z')
                                {
                                    $breakft .= '<p>At any grocery store there’s almost an unlimited number of different drink options. Sodas, orange juices, and vegetable juices are just some of the many options available. Unfortunately, many of these juices contain sugar and carbohydrates which will increase blood sugar and lead to weight gain.  WellnessFromFood will educate you on how your body processes differently oranges and orange juice.  Dr. Pruchno will show you how to create tasty smoothies to enjoy and how to drink different flavored drinks without the negative effects.</p>';
                                }
                                if($food_key == 'a')
                                {
                                    $breakft .= '<p>Temptations to snack on carbohydrates are all around us.  Almost all the snack food in vending machines or the middle of the grocery store will actually make you hungrier rather than satisfying your initial hunger!  Sounds crazy – eating food makes you feel hungrier?  When you go through the WellnessFromFood program you will experience this.  Once we get the poison out of your system, you will be eating less, and feeling less hungry than an average day.</p>';
                                }
                                if($food_key == 'b')
                                {
                                    $breakft .= '<p>Alcohol will add more calories to your daily intake but it provides 0 nutritional value! It’s shocking how quickly the liquid calories add up, and it’s a double whammy: these calories will make you hungrier and alcohol will decrease your inhibition, making you more likely to eat more things that are bad for you! This doesn’t mean you can never relax with a beer, but Dr. Pruchno will walk you through the important timeline of how alcohol relates to your weight loss so that you don’t sabotage yourself.</p>';
                                }
                                if($food_key == 'tomato')
                                {
                                    $breakft .= '<p>Sugar and high fructose corn syrup is a substance as addictive as tobacco. Throughout our lives we’ve had sugary treats to celebrate good grades, a birthday, or virtually any happy occasion. Dr. Pruchno will teach you about how sugar interacts with your body and why it has no place in a human diet.</p>';
                                }
                            }

						//==================================END-----------------------------

						$this->session->set_userdata('foodmail',$breakft);
			}
			            $save_question = array(
							'customer_id' =>$this->session->userdata('find_session_id'),
							'field_name' => $k,
							'form_id' =>$this->input->post('formid'),
							'field_value' =>$val,
							'user' => $user_id
						);
						$find_session_email = $this->session->userdata('find_session_email');
						$find_session_lname = $this->session->userdata('find_session_lname');
						$find_session_fname = $this->session->userdata('find_session_fname');
						if(!isset($find_session_email))
						{
							$check_exixts = $this->common_model->solveCustomQuery("select id from createform where form_type=1 order by display_order asc limit 1");
							if(!empty($check_exixts) )
							{
								if(filter_var($val, FILTER_VALIDATE_EMAIL) && $check_exixts[0]->id==$this->input->post('formid'))
								{
									$this->session->set_userdata('find_session_email',$val);
								}
							}
						}
            			if(!isset($find_session_fname))
            			{
            				if($val==$this->input->post('first_name'))
            				{
            					$this->session->set_userdata('find_session_fname',$val);

            				}

            			}
            			if(!isset($find_session_lname))
            			{
            				if($val==$this->input->post('last_name'))
            				{
            					$this->session->set_userdata('find_session_lname',$val);

            				}
            			}
			            $finalsubmit= $this->common_model->save('savequestionnnairfrmval',$save_question);
		}
		if($finalsubmit !='')
		{


			if($save_medical==1)
			{
				$this->msg = array('msg'=>lang('FORM_QUEST'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('home/paynow');
			}
			else
			{
				$form_id=$this->input->post('formid');
				$next_form_data=$this->common_model->solveCustomQuery("select prev_form.id from createform prev_form join (select display_order,id,form_type from createform where id=".$form_id.") as curr_form on prev_form.form_type=curr_form.form_type where prev_form.id!=curr_form.id and prev_form.display_order>=curr_form.display_order order by prev_form.display_order asc limit 1");
				if(!empty($next_form_data))
				{
					$form_id=$next_form_data[0]->id;
					//redirect('home/getstarted/'.base64_encode($form_id));
					redirect('getstarted');
				}
				else
				{
					$find_session_id=$this->session->userdata('find_session_id');
					$bmi_data=$this->common_model->solveCustomQuery("select field_name,field_value from savequestionnnairfrmval where customer_id='".$find_session_id."' and (field_name='height_feet' or field_name='height_inches' or field_name='weight')  order by form_id,field_name asc limit 3");
					//echo '<pre>';print_r($bmi_data); die;
					if(!empty($bmi_data))
					{
						$height_cm=$bmi_data[0]->field_value;
						//$height_cm1 = preg_replace('/[^A-Za-z0-9\-]/', '', $height_cm);
						//$height_cm2 = str_split($height_cm1);
						//$height_cm3 = array_splice($height_cm2, 0, 1);
						//echo '<pre>';print_r($height_cm3);
						//$getfoot= implode('',$height_cm3);//30.48
						//$getinches= implode('',$height_cm2);//2.54

						$getfoot= $bmi_data[0]->field_value;//30.48
						$getinches= $bmi_data[1]->field_value;//2.54

						$totalcal= ($getfoot*30.48) + ($getinches*2.54);
						//echo '<pre>';print_r($height_cm2); die;
						$height=$totalcal/100; //height convert to inches

						$weight=($bmi_data[2]->field_value*0.453592); //weight convert to KG

						$weight1=($bmi_data[2]->field_value);

						$bmi_calculation=$weight/($height*$height);

						$messagename=$this->common_model->getRows("subscriptionmsg","messagename",array('status'=>1,'chktype'=>1));
						if(!empty($messagename))
						{
							$bmi_sess_data=array("bmi_email_id"=>$messagename[0]->messagename);
						}
						//echo '<pre>';print_r($messagename); die;
						$this->session->set_userdata('bmi_sess_data',$bmi_sess_data);
					}

					//get started send mail
					$setemailid = $this->session->userdata('find_session_email');
					if($setemailid){
						$getuselist = $this->common_model->getRows("user","first_name,emailid,hash",array('emailid'=>$setemailid));
						if(isset($getuselist))
						{

						//$this->common_model->update('user',array('password'=>$md),array('emailid'=>$setemailid));

						$data['customer_name']=$getuselist[0]->first_name;
						$data['bmical']=round($bmi_calculation, 1);
						$data['websitelink']=base_url();
						$data['email']=$setemailid;
						$data['hash'] = $getuselist[0]->hash;
						$foodmail = $this->session->userdata('foodmail');
						$data['setfood']='';
						if(isset($foodmail) && (!empty($foodmail)))
						{
							$data['setfood'] = $this->session->userdata('foodmail');
						}

						$message=$this->load->view('frontend/email/questionnaire_form_template',$data,true);
						$subject="WellnessFromFood Survey Results";
						$to = $getuselist[0]->emailid;
						$email_dat = array(
							'to'=>$to,
							'subject'=>$subject,
							'msg'=>$message);
						 $this->common_model->Send_GetStarted_Mail($email_dat);

						$this->session->unset_userdata('foodmail');
						}

					}
					//end: get started send mail
					redirect('home/free_intro_lession');
				}

			}

		}

	}
	public function updatedata()
	{
	    //This is called after the user makes an edit from the Previous data view
	    
	   // echo 'Sorry  - doing some maintenance - you cannot save your data at this time - please try again later'; die;
	    //User is editing a past data record exosed via the Dieta Log view.
	    // update the appropriate records
		//echo '<pre>'; print_r($this->input->post());die;

		$customerid= $this->input->post('customerid');
		$num_weeks= $this->input->post('num_weeks');
		$week_wise_days= $this->input->post('week_wise_days');
		$exercise_id= $this->input->post('exercise_id');
		$weight = $this->input->post('weight');
		$steps = $this->input->post('steps');

        $firstName= $this->common_model->getCustomFielddata('user','first_name',array('id' => $customerid));

		/*********************end previous mapping data entry with NA************************/

        
	    $this->db->delete('customer_diets_plan',array('customer_id'=>$customerid,'weeks'=>$num_weeks,'week_wise_days'=>$week_wise_days));
		
	    $data = array(
        				'customer_id' => $this->input->post('customerid'),
        				'message_id' => $this->input->post('message_id'),
        				'netgram_id' => $this->input->post('netgram_id'),
        				'allowmeet_id' => $this->input->post('allowmeet_id'),
        				'questionnaire_id' => $this->input->post('questionnaire_id'),
                        'admin_msg_id' =>$this->input->post('lession_id'),
                        'meeting_date' => '',//$this->input->post('meeting_date'),
        				'weeks' => $this->input->post('num_weeks'),
        				'exercise_id' => $exercise_id,
        				'weight' => $weight,
        				'steps' => $steps,
        				'week_wise_days' => $this->input->post('week_wise_days'),
        				'help' => $this->input->post('help_val'),
        				'comments' => $this->input->post('Comments'),
        				'staff_comments' => $this->input->post('staff_comments'),
        				'created_date' => date('Y-m-d H:i:s'),
        				'last_modify_date'=>time(),
        				'status' => '1',
        				'updated_date' => date('Y-m-d H:i:s'),
        				);
        				
		if((bool)$this->common_model->save('customer_diets_plan', $data) === TRUE)
		{
			$insert_id = $this->db->insert_id();
			if(!empty($insert_id))
			{

				$alldata= $this->input->post('diet_label');
				//echo '<pre>'; print_r($alldata);die;
				if(!empty($alldata)){
				foreach($alldata as $k=>$val)
				{
					//$vk = explode('_',$k);
					$anotherdata = array(
                    						'diet_plan_id' =>$k,//vk[0],
                    						//'type' =>$vk[1],
                    						'customer_diets_plan_id' => $insert_id,
                    						'diet_plan_value' =>$val,
                    						'status' => '1',
                    						'created_date' => date('Y-m-d H:i:s')
					);
					$this->common_model->save('customer_diets_plan_desc',$anotherdata);
				}
			   }
			}

            $statusDiteform = "Thanks " . $firstName . ", - we received your updated data.";

			$this->msg = array('msg'=> $statusDiteform, 'msg_type'=>'success');
			
			
			$this->session->set_flashdata($this->msg);
			redirect('home/daily_dite_log_details');
		}
		else
		
		{
			$this->msg = array('msg'=>'Something Error', 'msg_type'=>'error');
			$this->session->set_flashdata($this->msg);
			redirect('home/daily_dite_form');
		}
		//echo '<pre>'; print_r($data);die;
	}
	
	public function save()
	{
	    //from backup of 10_10_2020
	    //User was entering data in their Daily Tracker, and clicked ok.  Now, save all of his new updates
	    //
	    //echo 'Sorry - doing some system maintenance - please try again.  It that still does not work, than please try in a few minutes <br>';
	    //echo 'the input is <pre>'; print_r($this->input->post());
        //echo 'save was called'; die;
                        
        //Gather some of the users entered data
		$exercise_id= $this->input->post('exercise_id');
		$customerid= $this->input->post('customerid');
		$num_weeks= $this->input->post('num_weeks');
		$week_wise_days= $this->input->post('week_wise_days');
		$weight  = $this->input->post('weight');
		$steps = $this->input->post('steps');
		
		
		$firstName= $this->common_model->getCustomFielddata('user','first_name',array('id' => $customerid));
		 
		
		
		//$customerid = base64_decode($customerid);
		/*********************previous mapping data entry with NA************************/
		$previous_day=$week_wise_days-1;
		$previous_week=$num_weeks-1;
		$all_previous_record=$this->common_model->solveCustomQuery("SELECT 
			                                                        ANY_VALUE(customer_id) AS customer_id,
			                                                        ANY_VALUE(message_id) AS message_id,
			                                                        ANY_VALUE(netgram_id) as netgram_id,
			                                                        ANY_VALUE(allowmeet_id) as allowmeet_id,
			                                                        ANY_VALUE(questionnaire_id) as questionnaire_id,
			                                                        ANY_VALUE(week_id) as week_id,
			                                                        ANY_VALUE(day_id) as day_id,
			                                                        ANY_VALUE(created_date) as created_date,
			                                                        ANY_VALUE(admin_msg_id) as admin_msg_id 
			                                                        FROM  `diets_plan_mapping` 
			                                                        WHERE  `customer_id` ='".$customerid."' 
			                                                        and ((`week_id` ='".$num_weeks."' 
			                                                        and `day_id` <='".$previous_day."') 
			                                                        or `week_id` <='".$previous_week."')  
			                                                        group BY week_id,day_id");

		if(!empty($all_previous_record))
		{

			/*=======For Insert Total Extra Metting in user table==============*/

			$max_week = $this->common_model->solveCustomQuery("SELECT week_id FROM user WHERE id=".$customerid);
			if($num_weeks > $max_week[0]->week_id)
			{
				$extraMeetingSql = "SELECT week_id,
				                    extra_metting 
				                    FROM diets_plan_mapping 
				                    where customer_id =".$customerid." 
				                    and week_id <=".$num_weeks." 
				                    group by week_id, extra_metting"; 
				                    
				$total_extra = $this->common_model->solveCustomQuery($extraMeetingSql);
				
				$coun_t=0;
				if(!empty($total_extra))
				{
					foreach($total_extra as $t_val)
					{
						$coun_t += $t_val->extra_metting;
					}
				}
				$this->common_model->update('user',array('week_id'=>$num_weeks,'extra_metting'=>$coun_t));
			}
			/*=======End Insert Total Extra Metting in user table==============*/
			
			foreach($all_previous_record as $previous_record)
			{ 
			    /*************check already data exist in customer_diets_plan table*****************/
				$all_check_record=$this->common_model->getRows("customer_diets_plan", "*", array('customer_id'=>$previous_record->customer_id, 'weeks'=>$previous_record->week_id, 'week_wise_days '=>$previous_record->day_id));
				if(empty($all_check_record))
				{
					if($previous_record->admin_msg_id !='')
					{
						$admin_msg_id = $previous_record->admin_msg_id;
					}
					else
					{
						$admin_msg_id='';
					}
					$data_previous = array(
                    						'customer_id' => $previous_record->customer_id,
                    						'message_id' => $previous_record->message_id,
                    						'netgram_id' =>$previous_record->netgram_id,
                    						'allowmeet_id'=>$previous_record->allowmeet_id,
                    						'questionnaire_id'=>$previous_record->questionnaire_id,
                    						'admin_msg_id'=>$admin_msg_id,
                    						'meeting_date' => '',
                    						'exercise_id' => 0,
                    						'weight'   => 0,
                    						'steps'    => 'NA',
                    						'weeks' => $previous_record->week_id,
                    						'week_wise_days' => $previous_record->day_id,
                    						'help' => 0,
                    						'comments' => 'NA',
                    						'staff_comments' =>'NA',
                    						'created_date' => $previous_record->created_date,
                    						'status' => '1',						
                    						'updated_date' => $previous_record->created_date
                    						);
					if((bool)$this->common_model->save('customer_diets_plan',$data_previous) === TRUE)
					{
						$last_insert_id = $this->db->insert_id();
						$all_mapping_record=$this->common_model->getRows("diets_plan_mapping","*",array('customer_id'=>$customerid,'week_id'=>$previous_record->week_id,'day_id '=>$previous_record->day_id));
						if(!empty($last_insert_id) && !empty($all_mapping_record))
						{

							$alldata= $this->input->post('diet_label');
							if(!empty($alldata))
							{
							    foreach($all_mapping_record as $k=>$previous_record_val)
							    {
								    $previous_anotherdata = array(
                                									'diet_plan_id' =>$previous_record_val->mapping_id,
                                									'customer_diets_plan_id' => $last_insert_id,
                                									'diet_plan_value' =>'NA',
                                									'status' => '1',
                                									'created_date' => date('Y-m-d H:i:s'));
								    
								    $this->common_model->save('customer_diets_plan_desc',$previous_anotherdata);
							    }
						   }
						}
					}
				}

			}
		}
		/*********************end previous mapping data entry with NA************************/
		$this->db->delete('customer_diets_plan', array('customer_id'=>$customerid, 'weeks'=>$num_weeks, 'week_wise_days'=>$week_wise_days));
		$data = array(
        				'customer_id' => $this->input->post('customerid'),
        				'message_id' => $this->input->post('messageid'),
        
        				'netgram_id' => $this->input->post('netgram_id'),
        				'allowmeet_id' => $this->input->post('allowmeet_id'),
        				'questionnaire_id' => $this->input->post('questionnaire_id'),
                        'admin_msg_id'=>$this->input->post('lession_id'),
                        'meeting_date' => '',//$this->input->post('meeting_date'),
        				'exercise_id' => $exercise_id,
        				'weight'   => $weight,
        				'steps'    => $steps,
        				'weeks' => $this->input->post('num_weeks'),
        				'week_wise_days' => $this->input->post('week_wise_days'),
        				'help' => $this->input->post('help_val'),
        				'comments' => $this->input->post('Comments'),
        				'staff_comments' => $this->input->post('staff_comments'),
        				'created_date' => date('Y-m-d H:i:s'),
        				'status' => '1',
        				'updated_date' => date('Y-m-d H:i:s'),   );
			
			if((bool)$this->common_model->save('customer_diets_plan',$data) === TRUE)
			{
				$insert_id = $this->db->insert_id();
				if(!empty($insert_id))
				{

					$alldata= $this->input->post('diet_label');
					//echo '<pre>'; print_r($alldata);die;
					if(!empty($alldata))
					{
    					foreach($alldata as $k=>$val)
    					{
    						//$vk = explode('_',$k);
    						$anotherdata = array(
                        							'diet_plan_id' =>$k,//vk[0],
                        							//'type' =>$vk[1],
                        							'customer_diets_plan_id' => $insert_id,
                        							'diet_plan_value' =>$val,
                        							'status' => '1',
                        							'created_date' => date('Y-m-d H:i:s'));
                        							
    						$this->common_model->save('customer_diets_plan_desc', $anotherdata);
    			    	}
		            }
				}
				
				$emailid = $this->common_model->getCustomFielddata('user', 'emailid', array('id'=>$this->input->post('customerid')));	
				
				//$sub='Your diet form has been save successfully.';
				$sub= $this->common_model->getCustomFielddata('send_email', 'subject_txt', array('id'=>5));
				
				//$this->common_model->commonMail(5,$sub,$emailid);
				//$this->db->delete('diets_plan_mapping',array('customer_id'=>$customerid,'week_id'=>$num_weeks,'day_id <= '=>$week_wise_days-1));
				$this->db->query("delete from `diets_plan_mapping` WHERE  `customer_id` ='".$customerid."' and ((`week_id` ='".$num_weeks."' and `day_id` <='".$previous_day."') or `week_id` <='".$previous_week."')");

				//$this->msg = array('msg'=>$this->lang->line('FORM_SUBMITTED'), 'msg_type'=>'success');
				//$this->session->set_flashdata($this->msg);
					$statusDiteform = "Thanks " . $firstName . ", - we received your data.";
					$this->msg = array('msg'=>$statusDiteform, 'msg_type'=>'success');
					$this->session->set_flashdata($this->msg);
				redirect('home/daily_dite_log_details');
			}else{
				$this->msg = array('msg'=>'Something Error', 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				redirect('home/daily_dite_form');
			}
			//echo '<pre>'; print_r($data);die;
	}
	
	
	

	public function directloginLMS(){
		try{
		$emailid = base64_decode($this->uri->segment(3));
		$getsessid = base64_decode($this->uri->segment(4));
		
		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
		if($getsessid==1)
		{
			TalentLMS::setDomain('diy-healthtransitionsuniversity.talentlms.com');
		}
		else
		{
			TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
		}

		$expemailid = explode('@',$emailid);
		//print_r(array('login' =>trim($emailid), 'password' =>trim($expemailid[0]),'logout_redirect' =>base_url('loginsignup/logout'))); die;
		if(isset($expemailid) && ($expemailid !=''))
		{
			$response = TalentLMS_User::login(
				array(
				'login' =>trim($emailid), 
				'password'=>trim($expemailid[0]),
				'logout_redirect' =>base_url('loginsignup/logout')));

		}
		
		if(!empty($response))
		{
			$login_key = '';
			if(isset($getsessid))
			{
				if($getsessid == 2)
				{
					$login_key = 'https://premium-'.explode('://',$response['login_key'])[1];
				}else{

					$login_key = 'https://diy-'.explode('://',$response['login_key'])[1];	
				}	
			}
			
			// print_r($login_key); die;
			// $this->redirect($response['login_key']);
			if($login_key !='')
			{
				$this->redirect($login_key);	
			}
			
		}

		}catch(Exception $e) {

	        $this->msg = array('msg'=>' Password not match. '.$e->getMessage(), 'msg_type'=>'danger');
			$this->session->set_flashdata($this->msg);
			redirect('daily-dite-form');

			/*echo "Passwords do not match. ".'Message from LearningManagementSystem: ' .$e->getMessage() . ".  Please contact Info@WellnessFromFood.com to address this issue.";*/

		}
	}

	function redirect($url){
			header("location:$url");
			exit;
	}
	private function hash_password($password)
	{
		return password_hash($password, PASSWORD_BCRYPT);
	}

	public function randomPassword() {
		$alphabet = "abcdefghijklmnopqrstuwxyz@#!$0123456789";
		$pass = array();
		$alphaLength = strlen($alphabet) - 1;
		for ($i = 0; $i <= 6; $i++) {
			$n = rand(0, $alphaLength);
			$pass[] = $alphabet[$n];
		}
		return implode($pass);
	}

	public function saveSample(){
	    //Saves the temp data in case the user bails
		$fname = $this->input->post('fname'); 
		$lname = $this->input->post('lname');
		$email = $this->input->post('email');
		$gender = $this->input->post('gender');
		$data  = array(
			'first_name'	=> 	$fname,
			'last_name'	 	=> 	$lname,
			'email'			=>	$email,
			'gender'		=>	$gender,
			'created_date'	=> 	date('Y-m-d H:i:s')
		);
		$id = $this->common_model->saveAndGetLastId('free_sample_lessons',$data);
		echo $id;
	}


}
