<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Loginsignup extends CI_Controller

{

    public $data = array();

    public $msg = array();



    public function __construct()
	{

        parent::__construct();
		$this->load->model('backoffice/login_model');
		$this->load->helper(array('cookie'));
		$idiom = $this->lang->load('message_lang');
		$this->lang->load('message_lang', $idiom);
    }



	public function index()
	{

		//$this->data['Captcha'] = $this->functions->CaptchaImageChange();

		//$this->data['actRegister'] = base_url('loginsignup/save');

		//$this->data['act'] = base_url('loginsignup/verifyLogin');

		//$this->load->view('frontend/loginsignup',$this->data);

	}



	private function _validData()
	{
		$this->form_validation->set_rules('email_id', 'Email', 'trim|required|valid_email'); //|is_unique[customer.email_id]
		$this->form_validation->set_rules('pass', 'Password', 'required|trim'); //min_length[6]|
		return $this->form_validation->run();
    }

    /*public function verifyLogin(){
    	 if($this->login_validation()){

			redirect('home');

		}
		else{

			return $this->index();

        }

    }*/

	public function forgotPassword(){
	        $data['act']=base_url().'loginsignup/post_forgetPassword';
        	$this->load->view('frontend/forgot_password',$data);
	}
	
	public function post_forgetPassword(){
	    $email = $this->input->post('forgot');
	    $data = array();
	    $check_user = $this->common_model->getRow('user','id,first_name',array('emailid'=>$email,'role_type'=>3));
	    if($check_user){
	        $hash = $this->randomPassword();
	        $data['hash']= base64_encode(md5($hash));
	        $data['email']= base64_encode($email);
	        $this->common_model->update('user',array('hash'=>md5($hash)),array('emailid'=>$email,'role_type'=>3));
	        $data['customer_name'] =$check_user->first_name;
	        $msg = $this->load->view('frontend/email/forgot_password_new',$data,true);
	        
	        $to = $email;
	        $subject = $check_user->first_name.", Wellness From Food";
	        $res = $this->common_model->Send_GetStarted_Mail(array('to'=>$to,'subject'=>$subject,'msg'=>$msg));
	       
	        $this->msg = array('msg'=>'Email has been send', 'msg_type'=>'success');
			$this->session->set_flashdata($this->msg);
			redirect('loginsignup/forgotPassword');
	       
	    }
	    else{
	        $this->msg = array('msg'=>'Email id is not correct.', 'msg_type'=>'danger');
			$this->session->set_flashdata($this->msg);
			redirect('loginsignup/forgotPassword');
	    }
	    
	}
	public function updatepassword(){
		//echo '<pre>'; print_r($this->input->post());die;

		$this->form_validation->set_rules('old_password', 'Password', 'required');
		$this->form_validation->set_rules('new_password', 'Password', 'required');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[new_password]');
		$this->form_validation->run();

		$old_password = $this->input->post('old_password');
		$new_password = $this->input->post('new_password');
		$confirm_password = $this->input->post('confirm_password');
		$sessid = $this->session->userdata('customers')->id;
		//echo '<pre>'; print_r($sessid); die;
		if($this->form_validation->run())
		{ //echo "sssssss";die;
		if($new_password)
    		{
    			$respassword=$this->common_model->changepassword($sessid,$old_password,$new_password,$confirm_password);
    			//echo "yyyyy".$respassword;die;
				if($respassword==1){
					$this->msg = array('msg'=>$this->lang->line('RECORD_UPDATED'), 'msg_type'=>'success');
					$this->session->set_flashdata($this->msg);
					$this->session->unset_userdata('IsFrontedLoggedIn');
					redirect('home/signup');
					//$this->logout();
				}else{
					$this->msg = array('msg'=>$this->lang->line('OLDPASS'), 'msg_type'=>'danger');
					$this->session->set_flashdata($this->msg);
					$this->load->view('frontend/change_password');
				}

    		}
		}else{  //echo "eeeeee";die;
					$this->load->view('frontend/change_password');
			}
	}

	public function forgotPassword_bkp_08_11_2019(){

		//$this->data['act'] = base_url('loginsignup/updateforgotPass');
		$this->load->view('frontend/forgot_password');

	}
	public function updateforgotPass(){

			//echo '<pre>'; print_r($this->input->post()); die;
			//$this->form_validation->set_rules('forgot', 'forgot', 'required');
			/*$config = array(
						array(
								'field' => 'forgot',
								'label' => 'correct email id',
								'rules' => 'required|trim',
								'errors' => array(
										'required' => 'Please enter %s.',
								),
						),
					);
			$this->form_validation->set_rules($config);*
			$get_email_id = $this->input->post('forgot');
			//print_r($get_email_id);die;
			if(!empty($get_email_id))
			{
				$get_email_id = $this->input->post('forgot');
				$findemail = $this->common_model->ForgotPassword($get_email_id);
				//print_r($findemail);die;
				if(!empty($findemail))
				{
				$status=$this->forgotPasswordMail($findemail);
				$this->msg = array('msg'=>$status, 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('loginsignup/forgotPassword');
				}else{
					$this->msg = array('msg'=>'Email id is not correct.', 'msg_type'=>'danger');
					$this->session->set_flashdata($this->msg);
					redirect('loginsignup/forgotPassword');
				}
			}else{
				$this->msg = array('msg'=>'Invalid email', 'msg_type'=>'danger');
				$this->session->set_flashdata($this->msg);
				$this->load->view('frontend/forgot_password');
			}	*/


		//$this->form_validation->set_rules('forgot', 'forgot', 'trim|required');
			$config = array(
						array(
								'field' => 'forgot',
								'label' => 'valid email id',
								'rules' => 'required|trim|valid_email',
								'errors' => array(
										'required' => 'Please enter %s.',
								),
						),
					);
		$this->form_validation->set_rules($config);
		if ($this->form_validation->run() == FALSE)
		{
			//$this->msg = array('msg'=>'Email id is not correct.', 'msg_type'=>'danger');
			//$this->session->set_flashdata($this->msg);
			$this->load->view('frontend/forgot_password');

		}
		else
		{
			$get_email_id = $this->input->post('forgot');
			if(!empty($get_email_id))
			{
				$get_email_id = $this->input->post('forgot');
				$findemail = $this->common_model->ForgotPassword($get_email_id);
				if(!empty($findemail))
				{
					$status=$this->forgotPasswordMail($findemail);
					if($status)
					{
						$this->msg = array('msg'=>'Email has been send', 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
						redirect('loginsignup/forgotPassword');

					}
					else
					{
						$this->msg = array('msg'=>'Email is not send', 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
						redirect('loginsignup/forgotPassword');

					}

				}/*else{
					$this->msg = array('msg'=>'Email id is not correct.', 'msg_type'=>'danger');
					$this->session->set_flashdata($this->msg);
					redirect('loginsignup/forgotPassword');
				}*/
			}else{
				$this->msg = array('msg'=>'Invalid email', 'msg_type'=>'danger');
				$this->session->set_flashdata($this->msg);
				$this->load->view('frontend/forgot_password');
			}

		}

	}
	public function checkLogin(){
			//echo '<pre>'; print_r($this->input->post()); die;
			$remember_id= $this->input->post('remember');
			$login_email_id= $this->input->post('login_email_id');

			if($remember_id =='on'){
				$remember_id=1;
			}
			if ($remember_id == 1) {
				$cookies_user=array("emailid"=>$this->input->post('login_email_id'),
									"password"=>$this->input->post('login_password'),
									"remember_id"=>1);

				 $cookie_value = serialize($cookies_user);
					 $cookie= array(
						  'name'   => "rememberMe",
						  'value'   => $cookie_value,
						  'expire' => 60*60*24*30,
						  'domain' => "",
						  'path'   => '/',
					);
					$this->input->set_cookie($cookie);
            }else {
					$cookies_user=array("emailid"=>'',
										"password"=>'',
										"remember_id"=>'');
					$cookie_value = serialize($cookies_user);
					$cookie= array(
						  'name'   => "rememberMe",
						  'value'   => $cookie_value,
						  'expire' => 60*60*24*30,
						  'domain' => "",
						  'path'   => '/',
					);
					$this->input->set_cookie($cookie);
			}

			$data = array(
				'emailid' => $this->input->post('login_email_id'),
				'password' => $this->input->post('login_password')
			);
			$config = array(
						array(
								'field' => 'login_email_id',
								'label' => 'user name',
								'rules' => 'required|trim',
								'errors' => array(
										'required' => 'Please enter %s.',
								),
						),
						array(
								'field' => 'login_password',
								'label' => 'password',
								'rules' => 'required',
								'errors' => array(
										'required' => 'Please enter %s.',

								),
						),
					);
			$this->form_validation->set_rules($config);
			if($this->form_validation->run())
			{
				$data['customers'] = $this->common_model->checkVerifiedLogin($data);
					if(!empty($data['customers'])){
						
							$online =array('logged_in'=>date('Y-m-d h:i:s'),'nag_email'=>1,'no_of_sentMail'=>0);
							$this->common_model->update('user', $online,array('id' =>$this->session->userdata('customers')->id));

							$uid = $this->common_model->get_user_id_from_username($login_email_id);
							$data['customers']= $this->common_model->get_user($uid);

							$all_cust_data=$data['customers'];
							if($all_cust_data->active==1)
							{
								$user_id = $all_cust_data->id;
								$this->session->set_userdata('customerId', $all_cust_data->emailid);
								$this->session->set_userdata('customers', $all_cust_data);
								$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
								$update_online =array('online'=>1,'logged_in'=>date('Y-m-d h:i:s'));
								$this->common_model->update('user', $update_online,array('id' =>$this->session->userdata('customers')->id));
								//update formid for  questionnaire :Anil
								$sessid = $this->session->userdata('find_session_id');
								$formdata = array('customer_id'=>$user_id);
								$cond=array('customer_id'=>$sessid);
								$this->common_model->update('savequestionnnairfrmval', $formdata, $cond);
								$this->session->set_userdata('find_session_id', $user_id);


								/*$checkupgrade = $this->common_model->solveCustomQuery("SELECT subscription_type,subscription_name FROM orders WHERE custid = ".$user_id." order by id desc limit 0,1");*/

								$checkupgrade = $this->common_model->getRows('orders','subscription_type,subscription_name',array('custid'=>$user_id),
									'id','DESC',0,1);
								
								//echo $this->db->last_query();exit;

								if($all_cust_data->user_type == 0)
								{
									redirect('home/free_intro_lession');
								}

								if(!empty($checkupgrade))
								{
									/********for membership user********/
									$this->session->set_userdata('payment_status', $all_cust_data->payment_status);
									/********end for membership user********/
									$this->session->set_userdata('session_plan_name',$checkupgrade[0]->subscription_name);
									$this->session->set_userdata('session_plan_id',$checkupgrade[0]->subscription_type);
									redirect('daily-dite-form');
								}else{

									redirect('home/subscription');
								}

							}
							else
							{
								$this->msg = array('msg'=>'Please verify your email before login', 'msg_type'=>'danger');
								$this->session->set_flashdata($this->msg);
								$this->load->view('frontend/sign-up');
							}

			}else{
					$this->msg = array('msg'=>$this->lang->line('INVALID_USER'), 'msg_type'=>'danger');
					$this->session->set_flashdata($this->msg);

					$this->load->view('frontend/sign-up');
			}
		}else{
					$this->load->view('frontend/sign-up');
			}

	}
	public function logout()
	{
  if($this->session->userdata('customers'))
		{
			$date = date('Y-m-d H:i:s');
			$update_online =array('logged_in'=>$date);
			$this->common_model->update('user', $update_online,array('id' =>$this->session->userdata('customers')->id));


		  foreach($this->session->userdata as $key=>$val)

			{

				//$onlineusrs = array('online_users'=>'0');

				//$condts = array('id'=>$this->session->userdata('customers')->id);

				//$this->common_fmodel->update('customers',$onlineusrs,$condts);

				$this->session->unset_userdata($key);

            }



			$this->session->unset_userdata('IsFrontedLoggedIn');



        }

        redirect('/');

    }



	private function _validRegisterData()

	{

		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('emailid', 'Email', 'trim|required|valid_email|is_unique[user.emailid]'); //
		$this->form_validation->set_rules('mobile', 'Mobile No', 'trim|required');//|min_length[10]|max_length[12]
		$this->form_validation->set_rules('password', 'Password', 'required|trim|max_length[20]'); //min_length[6]|
		return $this->form_validation->run();
    }

	public function subscribe_form()
	{
		$this->data = array(
				'subscriber_email' => $this->input->post('email'),
				'created_date' => date('Y-m-d h:i:s'),
				'status' => '1'
				);

				$val = $this->common_model->save('subscriber',$this->data);
				if($val){
					echo 1; exit;
				}else{
					echo 0; exit;
				}
	}
    public function fb_data_save()
	{
		$userData=json_decode($this->input->post("userData"));
		//echo "<pre>";
		//echo $userData->id;
		//print_r($userData); die;
		 $time = time();
         $email_verify= md5(mcrypt_create_iv(32, MCRYPT_DEV_URANDOM));
		 $this->data = array(

				'first_name' => $userData->first_name,
				'email_id' => $userData->email,

				/*'password' => md5($this->input->post('password')),

				'contact_no' => $this->input->post('phone'),
				'student_name' => $this->input->post('student_name'),
				'school_name' => $this->input->post('school_name'),
				'admission_no' => $this->input->post('admission_no'),
				'class_name' => $this->input->post('class_name'),
				'section_name' => $this->input->post('section_name'),
				'mobile_verify' => '1',*/
				'status' => '1',
				'registration_date' => date('Y-m-d H:i:s'),
				'created_date' => date('Y-m-d H:i:s'),
				'email_verify' => $email_verify,
				'modified_date' => $time);
				$check_user=$this->common_model->get_rows("customer","id",array("email_id"=>$userData->email));
				if(!empty($check_user))
				{
					$user_id=$check_user[0]->id;
				}
				else
				{
					$this->common_model->save('customer',$this->data);
					$this->sendregiMail($userData->email,$userData->first_name,$email_verify);
					$user_id =  $this->db->insert_id();
				}
					$all_cust_data=$this->common_model->get_rows("eso_customer","*",array("id"=>$user_id));
					$this->session->set_userdata('customerId', $this->input->post('email_id'));
					$this->session->set_userdata('customers', $all_cust_data[0]);

					$sessid = $this->session->userdata('find_session_id');
					$this->session->set_userdata('find_session_id',$user_id);
					$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
					if($user_id!=""){

							$data = array('session_id'=>$user_id);
							$cond=array('session_id'=>$sessid);
							$this->common_model->update('eso_temp_order_master', $data, $cond);

							$data9 = array('customer_id'=>$user_id);
							$cond9=array('customer_id'=>$sessid);
							$this->common_model->update('eso_wishlist', $data9, $cond9);

					}
					$url = $this->session->userdata('redirectUrl1');
					if($url !=''){
						$this->session->unset_userdata('redirectUrl1');
					}else{
						$url =base_url('Customer_address/myprofile');
					}
		echo $url; exit;
	}
	public function register()
	{
		$emailid = $this->input->post('emailid');
		$time = time();
        $email_verify= md5(mcrypt_create_iv(32, MCRYPT_DEV_URANDOM));
		$week=$this->common_model->getCustomFielddata('week','id',array('default_val'=>1));
		$data = array(

				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'password' => $this->hash_password($this->input->post('password')),//md5($this->input->post('password')),
				'emailid' => $emailid,
                'contact_no' => $this->input->post('mobile'),
				'number_week' =>$week,
				'created_date' => date('Y-m-d H:i:s'),
				'status' => '1',
				'role_type' => 3,
				'hash' => $hash = md5( rand(0,1000) ),
				'active' => 0,
				'updated_date' => $time);
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('emailid', 'Email', 'trim|required|valid_email'); //
		$this->form_validation->set_rules('mobile', 'Mobile No', 'trim|required');//|min_length[10]|max_length[12]
		$this->form_validation->set_rules('password', 'Password', 'trim|required');//|min_length[10]|max_length[12]
		if($this->form_validation->run())
		{

			if($this->isEmailAvailable()== true){

			if((bool)$this->common_model->save('user',$data) === TRUE)
			{
		       // $this->sendregiMail($get_email_id,$this->input->post('uname'),$email_verify);
		        $user_id =  $this->db->insert_id();
				//$all_cust_data=$this->common_model->getRows("user","*",array("id"=>$user_id));
		      	//$this->session->set_userdata('customerId', $this->input->post('emailid'));
				//$this->session->set_userdata('customers', $all_cust_data[0]);

				//$sessid = $this->session->userdata('find_session_id');
				//$this->session->set_userdata('find_session_id',$user_id);
				//$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
				$this->msg = array('msg'=>'Your account has been made, <br /> please verify it by clicking the activation link that has been sent on your email.', 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				$this->varifyMail($emailid , $hash , $this->input->post('first_name'));
				redirect('register');

			}
			else
			{
				$this->msg = array('msg'=>$this->lang->line('RECORD_ERROR'), 'msg_type'=>'danger');
				$this->session->set_flashdata($this->msg);
                   redirect('register');
			}
			 }else{
				$this->msg = array('msg'=>'Email id already exist', 'msg_type'=>'danger');
				$this->session->set_flashdata($this->msg);

                   redirect('register');
			 }

		}
		else
		{
			$this->load->view('frontend/register');
		}
	}
	public function update_profile()
	{
			$config = array(

				array(
						'field' => 'weight',
						'label' => 'The field is not blank',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => '%s.',
						),
				),
				array(
						'field' => 'height',
						'label' => 'The field is not blank',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => '%s.',
						),
				),
				array(
						'field' => 'inches',
						'label' => 'The field is not blank',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => '%s.',
						),
				),

			);
		$this->form_validation->set_rules($config);
		if($this->form_validation->run())
		{
		$customerid='';
	    $customerid= $this->input->post('customerid');
		if(isset($customerid) && (!empty($customerid))){
		$data = array(

				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'emailid' => $this->input->post('emailid'),
                'contact_no' => $this->input->post('mobile'),
				//'password' => md5($this->input->post('password')),
				'dateofbirth' => date('Y-m-d',strtotime($this->input->post('dob'))),
				'country_id' => $this->input->post('country_id'),
				'state_id' => $this->input->post('state_id'),
				'city_id' => $this->input->post('city'),
				'medications' =>'',//$implodeval,
				'profile_image' => $this->input->post('updateprofilphoto'),
				'address' => $this->input->post('address'),
				'weight' => $this->input->post('weight'),
				'height' => $this->input->post('height'),
				'gender' => $this->input->post('gender'),
				'inches' => $this->input->post('inches'),
				'age' => $this->input->post('age'),
				);

			if((bool)$this->common_model->update('user',$data,array('id'=>$customerid)) === TRUE)
			{
				$data = array('form_type'=>1);$cond = array('id'=>$customerid);

				$this->common_model->update('user',$data,$cond);

				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('daily-dite-form');

			}

		}

		}else{
			$data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
			$data['state'] = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1','country_id'=>'231'));
			$data['customers'] = $this->common_model->getRows('user','*',array('status'=>'1','id'=>$this->session->userdata('customers')->id));
			$this->load->view('frontend/additional-profile',$data);
			}

	}
	private function hash_password($password)
	{
		return password_hash($password, PASSWORD_BCRYPT);
	}
	public function save()
	{
		$implodeval='';
		$arrr[]=$this->input->post('medications1');
		$arrr[]=$this->input->post('medications2');
		$arrr[]=$this->input->post('medications3');
		$implodeval = implode(',',$arrr);
		$emailid = $this->input->post('emailid');
		$time = time();
        $email_verify= md5(mcrypt_create_iv(32, MCRYPT_DEV_URANDOM));

		$data = array(

				'first_name' => $this->input->post('first_name'),
				'emailid' => $emailid,
                'contact_no' => $this->input->post('mobile'),
				'password' => $this->hash_password($this->input->post('password')),
				'dateofbirth' => date('Y-m-d',strtotime($this->input->post('dob'))),
				'country_id' => $this->input->post('country_id'),
				'state_id' => $this->input->post('state_id'),
				'city_id' => $this->input->post('city'),
				'medications' =>$implodeval,
				'weight' => $this->input->post('weight'),
				'height' => $this->input->post('height'),
				'gender' => $this->input->post('gender'),
				'inches' => $this->input->post('inches'),
				'number_week' =>9,
				'age' => $this->input->post('age'),
				'created_date' => date('Y-m-d H:i:s'),
				'status' => '1',
				'role_type' => 3,
				'updated_date' => $time);
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('emailid', 'Email', 'trim|required|valid_email'); //
		$this->form_validation->set_rules('mobile', 'Mobile No', 'trim|required');//|min_length[10]|max_length[12]
		$this->form_validation->set_rules('password', 'Password', 'required|trim|max_length[20]'); //min_length[6]|
		if($this->form_validation->run())
		{
			if((bool)$this->common_model->save('user',$data) === TRUE)
			{
				 $sub= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>6));
				  $this->common_model->commonMail(6,$sub);

		       // $this->sendregiMail($get_email_id,$this->input->post('uname'),$email_verify);
		        $user_id =  $this->db->insert_id();
				$all_cust_data=$this->common_model->getRows("user","*",array("id"=>$user_id));
		      	$this->session->set_userdata('customerId', $this->input->post('emailid'));
				$this->session->set_userdata('customers', $all_cust_data[0]);

				$sessid = $this->session->userdata('find_session_id');
				$this->session->set_userdata('find_session_id',$user_id);
				$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
				$this->msg = array('msg'=>$this->lang->line('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('profile');

			}
			else
			{

				$this->msg = array('msg'=>$this->lang->line('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);

                   redirect('signup');
			}

		}
		else
		{
			$this->load->view('frontend/sign-up');
		}

	}
	public function profile()
	{
		/* $finalval =$this->common_model->next_day_start_session();
			if($finalval==0){
				$this->msg = array('msg'=>'Your diet paln will be start  tomorrow.', 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
			} */


		if($this->session->userdata('customers'))
		{
		$data['profile']= ucwords(strtolower($this->uri->segment(1)));
		/* if((bool)$this->session->userdata('payment_status')==FALSE)
		{
			redirect('home/paynow');
			exit();
		} */

		}else{
			redirect('signup');
		}
		$data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
		$data['state'] = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1'));
		$data['customers'] = $this->common_model->getRows('user','*',array('status'=>'1','id'=>$this->session->userdata('customers')->id));
		//echo '<pre>'; print_r($data['customers']);die;
		$this->load->view('frontend/profile',$data);
	}
	public function additional_profile(){
		if((bool)$this->session->userdata('payment_status')==FALSE)
		{
			redirect('home/paynow');
			exit();
		}
		if($this->session->userdata('customers'))
			{

			$data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
			$data['state'] = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1','country_id'=>231));
			$data['userinfo'] = $this->common_model->getRows('user','*',array('id'=>$this->session->userdata('customers')->id));
			$this->load->view('frontend/additional-profile',$data);
			}else{
				 redirect('/');
			}
		}
	public function myorders()
	{
		$chksess = $this->session->userdata('customers');
		if(!empty($chksess))
		{
			$data['myorders'] = $this->common_model->getRows('orders','*',array('custid'=>$this->session->userdata('customers')->id));
		}
		else
		{
			redirect('/');
		}		
		//echo '<pre>'; print_r($data['myorders']);die;
		$this->load->view('frontend/myorders',$data);
	}
	public function changepassword()
	{
		$this->load->view('frontend/change_password');

	}
	public function updateprofile()
	{
		//echo '<pre>'; print_r($this->input->post());die;

		//$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		//$this->form_validation->set_rules('contact_no', 'Password', 'required|trim'); //min_length[6]|
		//$this->form_validation->set_rules('dateofbirth', 'Date Of Birth', 'trim|required');
		//$this->form_validation->set_rules('weight', 'Weight', 'trim|required');
		//$this->form_validation->set_rules('height', 'Height', 'trim|required');
		//$this->form_validation->set_rules('inches', 'Inches', 'trim|required');
		//$this->form_validation->set_rules('age', 'Age', 'trim|required');
		$config = array(
				array(
						'field' => 'dateofbirth',
						'label' => 'The field is not blank',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => '%s.',
						),
				),
			);
		$this->form_validation->set_rules($config);
		if($this->form_validation->run())
		{

	/* $all_medications=$this->input->post('medications');
	array_push($all_medications,$this->input->post('othercomments'));

	if(!empty($all_medications)){
		$implodeval = implode(',',$all_medications);
		} */

		$customerid='';
	    $customerid= $this->input->post('customerid');
		if(isset($customerid) && (!empty($customerid))){
		$data = array(

				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'emailid' => $this->input->post('emailid'),
                'contact_no' => $this->input->post('contact_no'),
				//'password' => md5($this->input->post('password')),
				'dateofbirth' => date('Y-m-d',strtotime($this->input->post('dateofbirth'))),
				'country_id' => $this->input->post('country_id'),
				'state_id' => $this->input->post('state_id'),
				'city_id' => $this->input->post('city'),
				'medications' =>'',//$implodeval,
				'profile_image' => $this->input->post('updateprofilphoto'),
				'address' => $this->input->post('address'),
				'weight' => $this->input->post('weight'),
				'height' => $this->input->post('height'),
				'gender' => $this->input->post('gender'),
				'inches' => $this->input->post('inches'),
				'age' => $this->input->post('age'),
				//'facebook_id' => $this->input->post('facebook_id'),
				//'skype_id' => $this->input->post('skype_id')
				//'number_week' => $this->input->post('number_week')
				);
			//	echo '<pre>'; print_r($data);die;
			if((bool)$this->common_model->update('user',$data,array('id'=>$customerid)) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('profile');

			}

		}
		}else{
			$data['country'] = $this->common_model->getRows('country','country_id,country_name',array('status'=>'1'));
			$data['state'] = $this->common_model->getRows('state','state_id,state_name',array('status'=>'1'));
			$data['customers'] = $this->common_model->getRows('user','*',array('status'=>'1','id'=>$this->session->userdata('customers')->id));
			$this->load->view('frontend/profile',$data);
			}
		//redirect('loginsignup/myprofile','refresh');
		//
	}
	public function profile_pic()
	{
		$original  = explode('.', $_FILES["file"]["name"]);
		$extension  = array_pop($original);
		if(0 < $_FILES['file']['error'] ) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';

		}else {
        $response = array();
        $newname = time(). '.'.$extension;
        $is_uploaded = 	move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/profile_images/'.$newname);
        if($is_uploaded){
            $response = array('status'=>'success','result'=>$newname);
        } else{
            $response = array('status'=>'fail','result'=>'unable to upload');
        }

        echo json_encode($response);
      }

	}
	public function isEmailAvailable()
	{

		$emailid = $this->input->post('emailid');

		$result=$this->common_model->getRows("user","*",array("emailid"=>$emailid));

		if(!empty($result)){

			return false;

		}else{

			return true;

		}
	}
	public function check_verify_email(){
		$email_id = $this->input->get('email_id');
		$verify_code = $this->input->get('verify_code');
		//$check_email_id = "select email_id from eso_customer where email_id='".$email_id."' and email_verify='".$verify_code."'";
		$check_emailid = $this->common_model->get_rows('customer','email_id', array('email_id'=>$email_id, 'email_verify'=>$verify_code));
		if(!empty($check_emailid)){
			$this->common_model->update('customer', array("email_verify"=>1), array('email_id'=>$email_id, 'email_verify'=>$verify_code));
			echo $msg ='your email has been verified successfully.';
		}else{
			echo $msg ='Some thing wrong';
		}

		//echo '<br><a href="'.base_url().'">Go To School Shop</a>';
		redirect('Customer_address/myprofile','refresh');
	}
	public function randomPassword() {
		$alphabet = "abcdefghijklmnopqrstuwxyz@#!$0123456789";
		$pass = array();
		$alphaLength = strlen($alphabet) - 1;
		for ($i = 0; $i < 6; $i++) {
			$n = rand(0, $alphaLength);
			$pass[] = $alphabet[$n];
		}
		return implode($pass);
	}
	public function forgotPasswordMail($emailid)
	{
		$this->common_model->forgotPasswordMail($emailid);
	}

	public function varifyMail($emailid , $hash , $name)
	{
		$data['customer_name']=$name;
		$data['verifylink'] =$hash;
		$data['email'] =$emailid;
		$message=$this->load->view('frontend/email/verify_email',$data,true);
		$subject=$name.',Wellness From Food';
		$to = $emailid;
		$this->common_model->Send_GetStarted_Mail(array('to'=>$to,'subject'=>$subject,'msg'=>$message));

	}

	public function myaccount(){
		$id = $this->uri->segment(3);
		$data['accountid']=base64_decode($id);
		$data['myaccount'] = site_url('loginsignup/save_myaccount/'.$id);
		$this->load->view('frontend/myaccount',$data);
	}
	public function save_myaccount()
	{

			$accountid = $this->input->post('accountid');
			$save_medical_form = array(
				'doctor_name' => $this->input->post('doctor_name'),
				'doctor_email' => $this->input->post('doctor_email'),
				'doctor_phone' => $this->input->post('doctor_phone')
			);

			$cond=array('id'=>base64_decode($accountid));
			$val = $this->common_model->update('save_medical_form',$save_medical_form,$cond);
				if($val){
					echo 1; exit;
				}else{
					echo 0; exit;
				}

		/*$config = array(
						array(
								'field' => 'doctor_name',
								'label' => 'valid email id',
								'rules' => 'required|trim',
								'errors' => array(
										'required' => 'Please enter %s.',
								),
						),
					);*/
		//$this->form_validation->set_rules($config);
		//if ($this->form_validation->run() == FALSE)
		//{

		/*$config = array(
				array(
						'field' => 'doctor_name',
						'label' => 'The field is not blank',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => '%s.',
						),
				),*/
				/*array(
						'field' => 'doctor_email',
						'label' => 'The field is not blank',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => '%s.',
						),
				),
				array(
						'field' => 'doctor_phone',
						'label' => 'The field is not blank',
						'rules' => 'required|trim',
						'errors' => array(
								'required' => '%s.',
						),
				)*/
			//);
	/*	$this->form_validation->set_rules($config);
		if($this->form_validation->run())
		{

		//$data['myaccount'] = site_url('loginsignup/save_myaccount/'.$id);
		$this->msg = array('msg'=>$this->lang->line('RECORD_ERROR'), 'msg_type'=>'error');
		$this->session->set_flashdata($this->msg);
		$this->load->view('frontend/myaccount');
		}
		else
		{
			$save_medical_form = array(
			'doctor_name' => $this->input->post('doctor_name'),
			'doctor_email' => $this->input->post('doctor_email'),
			'doctor_phone' => $this->input->post('doctor_phone'),
			);
			$cond=array('id'=>base64_decode($id));
			$this->common_model->update('save_medical_form',$save_medical_form,$cond);
			$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
		$this->session->set_flashdata($this->msg);
		redirect('http://sd111/wellness/loginsignup/myaccount/MTA=');

		}*/

	}
	public function gen_password()
	{
		$data=array();
		$data['act'] = base_url().'loginsignup/submit_genPassword';
		$data['email']= $this->input->get('data');
		$data['hash']  = $this->input->get('inc');
		if($this->session->userdata('bmi_sess_data')) $this->session->unset_userdata('bmi_sess_data');
		
		$this->load->view('frontend/gen_password',$data);
	}

	public function submit_genPassword(){
		$this->form_validation->set_rules('new_password', 'Password', 'required');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[new_password]');
		$this->form_validation->run();
		$new_password = $this->input->post('new_password');
		$confirm_password = $this->input->post('confirm_password');
		$hash=$this->input->post('hash');
		$email=$this->input->post('email');

		if($this->form_validation->run())
		{
			if($new_password)
    		{
    		    $data['hash']=$hash = base64_decode($hash);
    		    $data['email']=$email = base64_decode($email);
    		    $hashData = $this->common_model->getRow('user','hash',array('emailid'=>$email,'role_type'=>3));
    		    if(!empty($hashData))
    		    {
    		    	if($hashData->hash == trim($hash))
	    		    {
	    				$respassword=$this->common_model->update('user',array('password'=>$this->hash_password(trim($confirm_password)),'active'=>1),array('emailid'=>trim($email),'hash'=>trim($hash)));
	    		    	if($respassword==1)
	    		    	{
							/*=========Code for Direct login after Change Password==================*/

							$uid = $this->common_model->get_user_id_from_username(trim($data['email']));
							$data['customers']= $this->common_model->get_user($uid);
							$all_cust_data=$data['customers'];
							if(isset($all_cust_data->active) && $all_cust_data->active==1)
							{
								$user_id = $all_cust_data->id;
								$this->session->set_userdata('customerId', $all_cust_data->emailid);
								$this->session->set_userdata('customers', $all_cust_data);
								$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
								$update_online =array('online'=>1,'logged_in'=>date('Y-m-d h:i:s'));
								$this->common_model->update('user', $update_online,array('id' =>$this->session->userdata('customers')->id));
								//update formid for  questionnaire :Anil
								$sessid = $this->session->userdata('find_session_id');
								$formdata = array('customer_id'=>$user_id);
								$cond=array('customer_id'=>$sessid);
								$this->common_model->update('savequestionnnairfrmval', $formdata, $cond);
								$this->session->set_userdata('find_session_id', $user_id);

								$checkupgrade = $this->common_model->getRows('orders','subscription_type,subscription_name',array('custid'=>$user_id),'id','DESC',0,1);
								if($all_cust_data->user_type == 0)
								{
									redirect('home/free_intro_lession');
								}

								if(!empty($checkupgrade))
								{
									/********for membership user********/
									$this->session->set_userdata('payment_status', $all_cust_data->payment_status);
									/********end for membership user********/
									$this->session->set_userdata('session_plan_name',$checkupgrade[0]->subscription_name);
									$this->session->set_userdata('session_plan_id',$checkupgrade[0]->subscription_type);
									redirect('daily-dite-form');
								}else{

									redirect('home/subscription');
								}
							}
							else
							{
								$this->msg = array('msg'=>'Please verify your email before login', 'msg_type'=>'danger');
								$this->session->set_flashdata($this->msg);
								$this->load->view('frontend/sign-up');
							}
							/*=========End Code For Direct Login ===================================*/
						}else{
							$this->msg = array('msg'=>$this->lang->line('OLDPASS'), 'msg_type'=>'danger');
							$this->session->set_flashdata($this->msg);
							$this->load->view('frontend/change_password');
						}
	    		    }else{
	    		    	$this->msg = array('msg'=>"Please use latest url for reset password", 'msg_type'=>'danger');
						$this->session->set_flashdata($this->msg);
						$this->load->view('frontend/change_password');
	    		    }
    		    }else{

	    		    	$this->msg = array('msg'=>"This is not Valid User", 'msg_type'=>'danger');
						$this->session->set_flashdata($this->msg);
						$this->load->view('frontend/change_password');
    		    }    
    		}
		}else{
			$this->load->view('frontend/gen_password',$data);
		}
	}
}
