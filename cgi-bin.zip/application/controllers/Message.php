<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Message extends CI_Controller
{
    public $data = array();
    public $msg = array();

    public function __construct()
	{
        parent::__construct();
		if((bool)$this->session->userdata('IsAdminLoggedIn') == FALSE)
		{
			redirect('backoffice/login');
			exit();
		}
		$this->data['page'] = 9;
		$this->data['page_form_id']=8;
		$this->data['page_module_id']=5;
		$this->data['live_user_id'] = $this->session->userdata('admin')->id;
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }	
	public function schedule_date($start=0)
	{
		$this->data['page_form_id']=35;
		$this->data['page_module_id']=4;
		//print_r($this->input->post());die;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message post</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(id) as total FROM time_slot ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM time_slot where created_by=".$this->session->userdata('admin')->id." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/schedule_date_view', $this->data);
    }
	public function save_schedule_date()
	{
		if($this->schedule_validData())
		{
			$time=time();
			$this->data = array(
			'providerid' => $this->input->post('providerid'),
			'timeslot' => $this->input->post('message'),			
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'created_by' => $this->data['live_user_id']);
			if((bool)$this->common_model->save('time_slot',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/schedule_date');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_schedule_date();
			}
		}
		else
		{
			return $this->add();
		}
	}
	public function show_nav($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		if($this->input->get('form_submit_nav')=='Search'){
			$nav_type = $this->input->get('nav_type');	
			if($nav_type!=''){
				$cond.= "nav_type like '%".$nav_type."%'";
				$con_use++;	
			}
			$url_cond.='?nav_type='.$nav_type.'&form_submit_nav=Search';
		}
		if($con_use){ $cond_created_where=' WHERE '; }else{ $cond_created_where=''; }
		/* get count */
		$total_get_sql = "SELECT count(id) as total FROM navigation_type ".$cond_created_where." ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$course_stream_sql="SELECT * FROM navigation_type ".$cond_created_where." ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_nav_type_search_submit']=base_url('backoffice/menu/show_nav');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/masters/nav_view', $this->data);
	}
	public function add_nav()
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Menu</li></ol>';
		$this->data['act'] = base_url('backoffice/menu/save_nav');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM navigation_type"; 
		$maxdisplay = $this->common_model->solveCustomQuery($maxdisplay);
		$this->data['maxdis'] = $maxdisplay[0]->maxdisplay+1;

        $this->load->view('backoffice/masters/add_nav_view', $this->data, FALSE);
    }
	public function save_nav()
	{
		if($this->nav_validData())
		{
			$time=time();
			$this->data = array(
			'title' => $this->input->post('title'),
			'nav_type' => $this->input->post('nav_type'),
			'display_order' => $this->input->post('display_order'),
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'created_by' => $this->data['live_user_id']);
			if((bool)$this->common_model->save('navigation_type',$this->data) === TRUE)
			{
				//echo "rr";die;
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/show_nav');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_nav();
			}
		}
		else
		{
			return $this->add_nav();
		}
	}
	
	private function nav_validData($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('nav_type', 'Nav Type', 'trim|required|strip_tags|callback_check_nav_type['.$id.']');
		}
		else
		{
			$this->form_validation->set_rules('title', 'Title', 'trim|required|strip_tags');
	$this->form_validation->set_rules('nav_type', 'Navigation Type', 'trim|required|strip_tags|is_unique[navigation_type.nav_type]');		
		}
		$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	public function nav_edit($id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Edit Menu</li></ol>';
			
	    $id=base64_decode($id);
		
		$this->data['rec'] = $this->common_model->getRow('navigation_type','*',array('id'=>$id));
		$this->data['act'] = site_url('backoffice/menu/nav_update/'.base64_encode($id));
		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/masters/add_nav_view', $this->data, FALSE);
	}
	public function nav_update($id)
	{
		if($this->nav_validData($id)){ 
			$this->data = array(
			'title' => $this->input->post('title'),
			'nav_type' => $this->input->post('nav_type'),
			'display_order' => $this->input->post('display_order'),
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'updated_by' => $this->data['live_user_id']);				
			if((bool)$this->common_model->update('navigation_type',$this->data, array('id'=>base64_decode($id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/show_nav');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->nav_edit($id);
			}
			}
			else
			{
				return $this->nav_edit($id);
			}
	}
	public function nav_delete($id=0){
		if((bool)$this->common_model->delete('navigation_type',array('id'=>base64_decode($id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/menu/show_nav');
	}
	public function show_nav_mapping($start=0)
	{
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		if($this->input->get('form_submit_nav')=='Search'){
			$nav_type = $this->input->get('nav_type');	
			if($nav_type!=''){
				$cond.= "nav_type like '%".$nav_type."%'";
				$con_use++;	
			}
			$url_cond.='?nav_type='.$nav_type.'&form_submit_nav=Search';
		}
		if($con_use){ $cond_created_where=' WHERE '; }else{ $cond_created_where=''; }
		/* get count */
		$total_get_sql = "SELECT count(id) as total FROM navigation_mapping ".$cond_created_where." ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$course_stream_sql="SELECT * FROM navigation_mapping ".$cond_created_where." ".$cond." order by id LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_nav_type_search_submit']=base_url('backoffice/menu/show_nav_mapping');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/masters/nav_view_mapping', $this->data);
	}
	public function add_nav_mapping()
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Menu</li></ol>';
		$this->data['act'] = base_url('backoffice/menu/save_nav_mapping');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM navigation_type"; 
		$maxdisplay = $this->common_model->solveCustomQuery($maxdisplay);
		$this->data['maxdis'] = $maxdisplay[0]->maxdisplay+1;
		$this->data['nav_type_list']=$this->common_model->getRows('navigation_type','id,nav_type',array('status'=>1));
		$this->data['menu_list']=$this->common_model->getRows('menu','id,menu_name',array('status'=>1));
		$this->data['page_list']=$this->common_model->getRows('page','page_id,page_name',array('page_status'=>1));
        $this->load->view('backoffice/masters/add_nav_view_mapping', $this->data, FALSE);
    }
	public function save_nav_mapping()
	{
		if($this->nav_mapping_validData())
		{ 
	        $user_id=$this->data['live_user_id']; 
			$time=time();
			$all_page_id=$this->input->post('page_id');
			if(!empty($all_page_id))
			{
				foreach($all_page_id as $page_id)
				{
					$this->data = array(
					'nav_type' => $this->input->post('nav_type'),
					'label' => $this->input->post('label'),
					'page_type' => $this->input->post('page_type'),
					'page_id' => $page_id,			
					'created_date' => date('Y-m-d'),
					'created_by' => $user_id,
					'updated_date' => date('Y-m-d'),
					'updated_by' => $user_id);
					if((bool)$this->common_model->save('navigation_mapping',$this->data) === TRUE)
					{
						//echo "rr";die;
						$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
						$this->session->set_flashdata($this->msg);
					}
					else
					{
						//echo "A4"; die;
						$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
						$this->session->set_flashdata($this->msg);
						return $this->add_nav_mapping();
					}
				}
				redirect('backoffice/menu/show_nav_mapping');
			}
		}
		else
		{
			return $this->add_nav_mapping();
		}
	}
	
	private function nav_mapping_validData($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('nav_type', 'Nav Type', 'trim|required|strip_tags|callback_check_nav_type['.$id.']');
		}
		else
		{
			$this->form_validation->set_rules('nav_type', 'Navigation Type', 'trim|required|strip_tags');
			$this->form_validation->set_rules('page_type', 'Category', 'trim|required|strip_tags');
			//$this->form_validation->set_rules('nav_type', 'Navigation Type', 'trim|required|strip_tags|is_unique[navigation_type.nav_type]');		
		}
		//$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	public function nav_mapping_edit($id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Edit Menu</li></ol>';
			
	    $id=base64_decode($id);
		
		$this->data['rec'] = $this->common_model->getRow('navigation_mapping','*',array('id'=>$id));
		$this->data['act'] = site_url('backoffice/menu/nav_mapping_update/'.base64_encode($id));
		$this->data['nav_type_list']=$this->common_model->getRows('navigation_type','id,nav_type',array('status'=>1));
		$this->data['menu_list']=$this->common_model->getRows('menu','id,menu_name',array('status'=>1));
		$this->data['page_list']=$this->common_model->getRows('page','page_id,page_name',array('page_status'=>1));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/masters/add_nav_view_mapping', $this->data, FALSE);
	}
	public function nav_mapping_update($id)
	{
		if($this->nav_mapping_validData($id)){ 
			$this->data = array(
			'title' => $this->input->post('title'),
			'nav_type' => $this->input->post('nav_type'),
			'display_order' => $this->input->post('display_order'),
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'updated_by' => $this->data['live_user_id']);				
			if((bool)$this->common_model->update('navigation_type',$this->data, array('id'=>base64_decode($id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/show_nav');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->nav_edit($id);
			}
			}
			else
			{
				return $this->nav_edit($id);
			}
	}
	public function nav_mapping_delete($id=0){
		if((bool)$this->common_model->delete('navigation_mapping',array('id'=>base64_decode($id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/menu/show_nav_mapping');
	}	
    public function show($start=0)
	{
		//print_r($this->input->post());die;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message post</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(MessageID) as total FROM messagecenterposttable ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM messagecenterposttable ".$cond." order by MessageID LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/message_view', $this->data);
    }
	 public function track_message($start=0)
	{
		//print_r($this->input->post());die;
		$this->data['page_form_id']=9;
		$this->data['page_module_id']=5;
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message tracking</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();
		if($this->input->post('form_submit_message')=='Search'){
			$message_name = $this->input->post('message_name');	
			if($message_name!=''){
				$conds[] = "Message like '%".$message_name."%'";
			}
			$url_cond.='?message_name='.$message_name.'&form_submit_message=Search';
		}
		if($conds){
			$con =implode('and',$conds);
		}
		if($con){
			$cond .= "Where ".$con;
		}
		$this->data['message_name'] =$this->input->post('message_name');
		$total_get_sql = "SELECT count(MessageID) as total FROM messagecentertrackingtable ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);		
		$course_stream_sql="SELECT * FROM messagecentertrackingtable ".$cond." order by MessageID LIMIT ".$limit_from.",".$limit;
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_message_search_submit']=base_url('backoffice/message/show');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/track_message_view', $this->data);
    }
	public function submenu_view($start=0)
	{		
		($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Stream</li></ol>';
		$cond='';
		$url_cond='';		
		$con_use=0;
		if($this->input->get('form_submit_submenu')=='Search'){
			$menu = $this->input->get('menu_name');	
			if($menu!=''){
				$cond.= "menu_name like '%".$menu."%'";
				$con_use++;	
			}
			$url_cond.='?menu_name='.$menu.'&form_submit_menu=Search';
		}
		if($con_use){ $cond_created_where=' WHERE '; }else{ $cond_created_where=''; }
		/* get count */
		$total_get_sql = "SELECT count(id) as total FROM menu ".$cond_created_where." ".$cond; 
		$total_get = $this->common_model->solveCustomQuery($total_get_sql);
		/* get count */
		/* get detail */
		$course_stream_sql="SELECT *,menu.menu_name FROM form_information join menu on menu.id =form_information.module_id order by form_id desc";
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);
		/* get detail */
		//pagination
		$records_count=$total_get[0]->total;
		$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);
		$this->data['act_menu_name_search_submit']=base_url('backoffice/menu/show_nav');
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/masters/submenu_view', $this->data);
    }
    public function add_schedule_date()
	{
		//echo '<pre>';print_r($this->session->userdata('admin'));
		$this->data['page'] = 2522;
		$this->data['page_form_id']=35;
		$this->data['page_module_id']=4;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Message</li></ol>';
		$this->data['act'] = base_url('backoffice/message/save_schedule_date');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['rec'] = $this->common_model->getRow('provider','*',array('pcustid'=>$this->session->userdata('admin')->id));
		//print_r($this->data['rec']);die;
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM messagecenterposttable"; 
		

        $this->load->view('backoffice/message/add_schedule_date_view', $this->data, FALSE);
    }
	public function add()
	{
		$this->data['page'] = 2522;
		$this->data['page_form_id']=8;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Message</li></ol>';
		$this->data['act'] = base_url('backoffice/message/save');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM messagecenterposttable"; 
		

        $this->load->view('backoffice/message/add_message_view', $this->data, FALSE);
    }
	public function submenu_add()
	{
		$this->data['page'] = 2522;
		$this->data['page_form_id']=8;
		$this->data['page_module_id']=3;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Sub Menu</li><li class="active">Add Sub Menu</li></ol>';
		$this->data['submenuact'] = base_url('backoffice/menu/submenu_save');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$maxdisplay = "SELECT max(display_order) as maxdisplay FROM menu"; 
		$maxdisplay = $this->common_model->solveCustomQuery($maxdisplay);
		$this->data['maxdis'] = $maxdisplay[0]->maxdisplay+1;
		$this->data['menu_name_list']=$this->common_model->getRows('menu','id,menu_name',array('status'=>1));
        $this->load->view('backoffice/masters/add_submenu_view', $this->data, FALSE);
    }
	public function submenu_save()
	{
		//echo '<pre>'; print_r($this->input->post());die;
		if($this->submenu_validate()){	
			$time=time();
			$this->data = array(
			'module_id' => $this->input->post('menu_name'),
			'form_name' => $this->input->post('sub_menu_name'),
			'display_order_form' => $this->input->post('display_order'),
			'form_url' => $this->input->post('menu_url'),
			'form_status' => $this->input->post('status'),
			'child' => $this->input->post('child')
			);
			if((bool)$this->common_model->save('form_information',$this->data) === TRUE)
			{
				//echo "rr";die;
				$form_id=$this->db->insert_id();
				$permission_data=array(
				"form_id"=>$form_id,
				"role_id"=>1,
				"form_view"=>1,
				"form_add"=>1,
				"form_edit"=>1,
				"form_delete"=>1
				);
				$this->common_model->save('form_permission',$permission_data);
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/submenu_view');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->submenu_add();
			}
		}
		else
		{
			//echo "B4"; die;

			return $this->submenu_add();
		}
	}
	private function submenu_validate($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('menu_name', 'Menu Name','trim|required|strip_tags|callback_check_course_menu_name['.$id.']');
		}
		else
		{
	$this->form_validation->set_rules('menu_name', 'Menu Name', 'trim|required');		
	$this->form_validation->set_rules('sub_menu_name', 'sub menu name','trim|required|is_unique[form_information.form_name]');
		}
		$this->form_validation->set_message('is_unique', 'This %s is already used');
		return $this->form_validation->run();
    }
	public function save()
	{
		if($this->_validData())
		{
			//$time=time();
			$this->data = array(
			'Message' => $this->input->post('message'),	
			'message_type_id' => $this->input->post('message_type_id'),			
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'CreatedBy' => $this->data['live_user_id']);
			if((bool)$this->common_model->save('messagecenterposttable',$this->data) === TRUE)
			{
				//echo "rr";die;
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/show');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add();
			}
		}
		else
		{
			//echo "B4"; die;

			return $this->add();
		}
	}
	
	private function _validData($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('message', 'Message', 'trim|required|strip_tags');
		}
		else
		{
		$this->form_validation->set_rules('message', 'Message Name', 'trim|required|strip_tags');	
		
		}		
		return $this->form_validation->run();
    }
	
	
	private function schedule_validData()
	{
		$this->form_validation->set_rules('message', 'Message', 'trim|required');
		return $this->form_validation->run();
    }
	public function delete($message_id=0){
		if((bool)$this->common_model->delete('messagecenterposttable',array('MessageID'=>base64_decode($message_id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/message/show');
	}
	public function submenu_delete($id=0){
		if((bool)$this->common_model->delete('form_information',array('form_id'=>base64_decode($id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/menu/submenu_view');
	}
	
	public function check_course_stream_name($course_stream_name, $course_stream_id)
	{
		$cond=array('course_stream_name'=>$course_stream_name,'course_stream_id !='=>$course_stream_id);
		if((bool)$this->common_model->getRows('course_stream', '', $cond)===true){
			$this->form_validation->set_message('check_course_stream_name', 'This %s is already used.');
			return false;
		}
		return true;
	}
    public function check_nav_type($nav_type, $id)
	{
		$cond=array('nav_type'=>$nav_type,'id !='=>$id);
		if((bool)$this->common_model->getRows('navigation_type', '', $cond)===true){
			$this->form_validation->set_message('check_nav_type', 'This %s is already used.');
			return false;
		}
		return true;
	}
	
	public function edit($menu_id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec'] = $this->common_model->getRow('messagecenterposttable','*',array('MessageID'=>$menu_id));
		$this->data['act'] = site_url('backoffice/message/update/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/message/add_message_view', $this->data, FALSE);
	}
	public function submenu_edit($submenu_id=0)
	{
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Sub Menu</li><li class="active">Edit SubMenu</li></ol>';
			
	    $submenu_id=base64_decode($submenu_id);
		
		$this->data['rec'] = $this->common_model->getRow('form_information','*',array('form_id'=>$submenu_id));
		//echo '<pre>'; print_r($this->data['rec']);die;
		$this->data['submenuact'] = site_url('backoffice/menu/submenu_update/'.base64_encode($submenu_id));
		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->data['menu_name_list']=$this->common_model->getRows('menu','id,menu_name',array('status'=>1));
		$this->load->view('backoffice/masters/add_submenu_view', $this->data, FALSE);
	}
	public function submenu_update($submenu_id)
	{
		if($this->schedule_validData())
		{
			$this->data = array(
			'module_id' => $this->input->post('menu_name'),
			'form_name' => $this->input->post('sub_menu_name'),
			'display_order_form' => $this->input->post('display_order'),
			'form_url' => $this->input->post('menu_url'),
			'form_status' => $this->input->post('status'),
			'child' => $this->input->post('child'),
			//'created_date' => date('Y-m-d'),
			//'updated_by' => $this->data['live_user_id']
			);				
		if((bool)$this->common_model->update('form_information',$this->data, array('form_id'=>base64_decode($submenu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/menu/submenu_view');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($submenu_id);
			}
		}
		else
		{
			return $this->edit($submenu_id);
		}
	}
	public function update($menu_id)
	{
		if($this->_validData($menu_id)){ 
			$this->data = array(			
			'Message' => $this->input->post('message'),
			'message_type_id' => $this->input->post('message_type_id'),				
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'updated_by' => $this->data['live_user_id']);				
			if((bool)$this->common_model->update('messagecenterposttable',$this->data, array('MessageID'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/show');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit($menu_id);
			}
			}
			else
			{
				return $this->edit($menu_id);
			}
	}
	
	public function ch_status($id=0,$Status=0)
	{		
		if($id)
		{
			$this->data = array('status'=>$Status);
			$Cond=array('country_id'=>base64_decode($id));	
			if($this->common_model->update('country',$this->data, $Cond))
			{
				$this->data['msg'] = lang('RECORD_UPDATED');
				$this->data['msg_type'] = true;
			}
			else
			{
				$this->data['msg'] = lang('RECORD_ERROR');
				$this->data['msg_type'] = false;
			}
		}
		else
		{
			$this->data['msg'] = lang('RECORD_ERROR');
			$this->data['msg_type'] = false;
		}
		header('Content-Type: application/json');
		echo json_encode( $this->data['msg_type']);
	}
	public function check_submenu_display_order(){
		$menu_name = $this->input->post('menu_name');
		$display_order_module="SELECT max(display_order_form) as display_order_module FROM form_information where module_id 
		= ".$menu_name.""; 
		$getresult = $this->common_model->solveCustomQuery($display_order_module);
		echo   ($getresult[0]->display_order_module) +1;	exit;	
		}
	public function schedule_date_delete($message_id=0){
		if((bool)$this->common_model->delete('time_slot',array('id'=>base64_decode($message_id)))==true){
			$this->msg = array('msg'=>lang('RECORD_DELETED'), 'msg_type'=>'success');
		}else{
			$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
		}
		$this->session->set_flashdata($this->msg);
		redirect('backoffice/message/schedule_date');
	}
	public function schedule_date_edit($menu_id=0){		
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$this->data['rec2'] = $this->common_model->getRow('time_slot','*',array('id'=>$menu_id));
		print_r($this->data['rec2']);die;

		$this->data['act'] = site_url('backoffice/message/schedule_date_update/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		$this->load->view('backoffice/message/add_schedule_date_view', $this->data, FALSE);
	}
	public function schedule_date_update($menu_id)
	{
		if($this->schedule_validData($menu_id)){
			$this->data = array(
				'providerid' => $this->input->post('providerid'),
				'timeslot' => $this->input->post('message'),			
				'status' => $this->input->post('status'),
				'created_date' => date('Y-m-d'),
				'created_by' => $this->data['live_user_id']
			);			
			if((bool)$this->common_model->update('time_slot',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/schedule_date');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->schedule_date_edit($menu_id);
			}
			}
			else
			{
				return $this->schedule_date_edit($menu_id);
			}
	}
	
	
	public function show_send_email()
	{
		$this->data['page_form_id']=36;
		$this->data['page_module_id']=14;
		//($start)?($limit_from=$start):($limit_from=0); $limit=100;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message post</li></ol>';
		$cond='';
		$url_cond='';$con='';		
		$conds=array();			
		$course_stream_sql="SELECT * FROM send_email ".$cond." order by id";
		$this->data['recs'] = $this->common_model->solveCustomQuery($course_stream_sql);		
		//$records_count=$total_get[0]->total;
		//$this->data['pagigShow']=$this->functions->drawPagination(@$records_count,$start,$limit_from,$limit,$url_cond);		
		$this->data['permission'] = $this->common_model->checkPermission();
		$this->load->view('backoffice/message/show_send_email', $this->data, FALSE);
    }
	public function add_send_email()
	{
		$this->data['page'] = 2522;
		$this->data['page_form_id']=36;
		$this->data['page_module_id']=14;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Menu</li><li class="active">Add Message</li></ol>';

		$this->data['templateemail']=$this->common_model->getRows('master_email_temp','id,name');

		$this->data['act'] = base_url('backoffice/message/save_send_email');
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
        $this->load->view('backoffice/message/send_message_view', $this->data, FALSE);
    }
	
	public function save_send_email()
	{
		if($this->valid_send_email())
		{
			$this->data = array(
			'name' => $this->input->post('tempname'),
			'email_description' => $this->input->post('email_description'),			
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'created_by' => $this->data['live_user_id']);
			if((bool)$this->common_model->save('send_email',$this->data) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/show_send_email');
			}
			else
			{
				//echo "A4"; die;
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->add_send_email();
			}
		}
		else
		{
			//echo "B4"; die;

			return $this->add_send_email();
		}
	}
	
	private function valid_send_email($id=0)
	{
		$id=base64_decode($id);
		if($id)
		{
			$this->form_validation->set_rules('email_description', 'Email Description', 'trim|required');
		}
		else
		{
			$this->form_validation->set_rules('email_description', 'Email Description', 'trim|required');	
		
		}		
		return $this->form_validation->run();
    }
	public function edit_send_email($menu_id=0)
	{
		$this->data['page_form_id']=36;
		$this->data['page_module_id']=14;
		$this->data['breadcrumb']='<ol class="breadcrumb"><li><a href="'.base_url('backoffice').'"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Message</li><li class="active">Edit Message</li></ol>';	
	    $menu_id=base64_decode($menu_id);		
		$course_stream_sql="SELECT * FROM send_email where id =".$menu_id." order by id";
		$this->data['rec'] = $this->common_model->solveCustomQuery($course_stream_sql);

		$this->data['templateemail']=$this->common_model->getRows('master_email_temp','id,name');

		
		$this->data['act'] = site_url('backoffice/message/update_send_email/'.base64_encode($menu_id));		
		$this->data['submit'] = 'Submit';
		$this->data['cancel'] = 'Cancel';
		$this->data['Submit'] = lang('SAVE_BTN');
		 $this->load->view('backoffice/message/send_message_view', $this->data, FALSE);
	}
	
	public function update_send_email($menu_id)
	{
		
		if($this->valid_send_email($menu_id)){// echo "dddddd";die;
			$this->data = array(				
			'name' => $this->input->post('tempname'),
			'email_description' => $this->input->post('email_description'),			
			'status' => $this->input->post('status'),
			'created_date' => date('Y-m-d'),
			'created_by' => $this->data['live_user_id']);			
			if((bool)$this->common_model->update('send_email',$this->data, array('id'=>base64_decode($menu_id))) === TRUE)
			{
				$this->msg = array('msg'=>lang('RECORD_UPDATED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('backoffice/message/show_send_email');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->edit_send_email($menu_id);
			}
			}
			else
			{ //echo "ddddfffffffdd";die;
				return $this->edit_send_email($menu_id);
			}
	}
}
?>
