<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

/* I think that everything in this file is for test purposes.  */


	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	
	public function calculate_date($get_created_date)
	{
		$nodays='';
		$noweek='';
		$days_info=array();

		$date1 = date('Y-m-d H:i:s');
		$date2 =  $get_created_date;
		$diff = strtotime($date1) - strtotime($date2);
		$days = ceil(($diff)/ (60*60*24));

		if($days >14){
			$noweek =  number_format($days/7,1);
			$totaldays= $days%7;
			$val = explode(".",$noweek);
			if($totaldays==0){
				$days_info['day']=7;
				$days_info['week'] = $val[0];
			}else{
				$days_info['day'] = $totaldays;
				$days_info['week'] = $val[0]+1;
			}
		}else{
				$days_info['day'] ='';
				$days_info['week']= '';
		}
		return $days_info;
	}
	
	public function cron_test(){
		$data = $this->common_model->getRows('send_email','email_description,name');
		foreach ($data as  $value) {
			$des =preg_replace('/\>\s+\</m', '><', $value->email_description);
			$this->common_model->update('send_email',array('email_description'=>$des),array('name'=>$value->name));
		}
	}
	public function test(){
		/*$staff_email= $this->common_model->getRow('send_email','email_description',array('id'=>1));
		//echo preg_replace('/\>\s+\</m', '><', $staff_email->email_description);exit;
		$sendMailData=array(
			'msg'=>preg_replace('/\>\s+\</m', '><', $staff_email->email_description),
			'to'=>'cchaubey55@gmail.com',
			'subject'=>'Premium Plan'
		);
		$a = $this->common_model->Send_GetStarted_Mail($sendMailData);	
		echo '<pre>';
		print_r($a);*/
		$sendMailData = array(
			'emailid'	=> 'cchaubey55@gmail.com',
			'full_name' => "Chandramauli",
			'contact_no' => "9006614336",
			'price'		=> 600,
			'subject'	=>"Test Data"
		);
		$a = $this->common_model->sendMail($sendMailData);
		print_r($a);
		/*$emailid ="cchaubey55@gmail.com";
		$stime ="04 PM";
		$sdate = date('M d Y');
		$customername ="chandra";
		$proname="chaubey";

		$sub33= $this->common_model->getCustomFielddata('send_email','subject_txt',array('id'=>3,'status'=>1));	
		$this->common_model->commonMail(3,$sub33,$emailid,'',@$stime,@$sdate,$customername,$proname,"maulic@rocketmail.com");*/	


	}

	public function medical_test(){
		$staff_email= $this->common_model->getRows('user','first_name,emailid',array('id'=>648));
		$user_email= $this->common_model->getRows('user','first_name,emailid',array('id'=>876));
		$meeting_data = $this->common_model->getRows('time_schedule','*',array('id'=>167));
		$emailid= $user_email[0]->emailid;
		$data['full_name']=$user_email[0]->first_name;
		$data['Content']= 'Sorry, we had to cancel this meeting   '.date('M d Y',strtotime($meeting_data[0]->schedule_date)).'/'.$meeting_data[0]->slottime.'.Unfortunately, '.$staff_email[0]->first_name.' @wellnessFromFood is not available to meet with you at this time.  Please re-schedule at your convinenance.';
		$massege = $this->load->view('frontend/email/staff_cancel_mail',$data,true);
		$subject ="Canceled By Staff";

		$email_dat = array(
		'to'=>$emailid,
		'subject'=>$subject,
		'msg'=>$massege);
		$res = $this->common_model->Send_GetStarted_Mail($email_dat);
	}

	public function test2(){
		$template ="<table role='presentation' border='0' cellpadding='0' cellspacing='0' class='body'><tr><td>&nbsp;</td><td class='container'><div class='content'><table role='presentation' class='main'><tr><td class='wrapper'><table role='presentation' border='0' cellpadding='0' cellspacing='0'><tr><td><p>Dear,</p><p>Mr Chandramauli haven't input his Daily Tracker information since 1970 Please Contact them  as soon as possible. phone no 9006614336</p><p>It's important to track your information everyday so that it's as accurate as possible. If you're having any issues with logging in, or entering data, please contact us at </p><p><a href='mailto:info@WellnessFromFood.com'>info@WellnessFromFood.com.</a></p><p>Thank you,</p><p>The WellnessFromFood Team</p></td></tr></table></td></tr></table></div></td><td>&nbsp;</td></tr></table>";
		$to = array(array('email'=>'p9006614336@gmail.com','name'=>'p9006614336@gmail.com'));
		$staff = $this->common_model->getRows('user','first_name,emailid',array('role_type'=>2,'id'=>648));
		$staff_data=array();
		if(!empty($staff)){
			foreach ($staff as $svalue) {
				$staff_data[] = array('email'=>$svalue->emailid,'name'=>$svalue->first_name);
			}
			
		}
		//echo json_encode($staff_data);exit;
	
					    $email_dat = array
						(
						'to'=>json_encode($to),
						'subject'=>'We need your data – WellnessFromFood',
						'msg'=>$template
						);
		$res = $this->common_model->Send_GetStarted_Mail($email_dat);
		print_r($res);
		
	}


	
	public function remove_lms(){
	//I think that this is just a test function
		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');

		$getDate = $this->common_model->solveCustomQuery("SELECT id,created_date,first_name,last_name,emailid,lms_id,subscription_plan_id FROM `user` where status=1  and created_date <>'0000-00-00' and starting_week > 1 order by created_date desc");
		if(!empty($getDate)){
			foreach($getDate as $val)
			{
				$lmsid = $val->lms_id;
			    $plan_id = $val->subscription_plan_id;
			    $user_id= $val->id;
			    if($plan_id==1)
			    {
			        TalentLMS::setDomain('diy-healthtransitionsuniversity.talentlms.com');
			    }else
			    {
			     	TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
			    }
			    $getDateval = $val->created_date;	
			    $noofweek = $this->calculate_date($getDateval);
			    if(!empty($noofweek))
				{
					if($noofweek['week'] >=3 && $noofweek['week'] < 10)
					{
						try{
						    TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '140'));
				        }catch(Exception $e){
                            $e->getMessage();
                        }
					
					}
					elseif($noofweek['week'] >=10 && $noofweek['week'] < 15)
					{
						try{
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '142'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }	
					}
					elseif($noofweek['week'] >=15 && $noofweek['week'] < 20)
					{
						try{
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '144'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >=20 && $noofweek['week'] < 25)
					{
						try{
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '146'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >=25 && $noofweek['week'] < 30)
					{
						try{
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '146'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '148'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >= 30 && $noofweek['week'] < 35)
					{
						//$WFF='WFF 8: Therapeutic Fasting';
						try{
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '146'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '148'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '150'));
						}catch(Exception $e){
	                    	$e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >=35 && $noofweek['week'] < 40)
					{
						try{
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '146'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '148'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '150'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '152'));
						}catch(Exception $e){
	                        $e->getMessage();
	                    }
					}
					elseif($noofweek['week'] >=40)
					{
						try{
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '140'));
						    TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '142'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '144'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '146'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '148'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '150'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '152'));
							TalentLMS_Course::removeUser(array('user_id' => $lmsid, 'course_id' => '154'));
						}catch(Exception $e){
	                         $e->getMessage();
	                    }
					}	
				}
			}
		}
	}
	public function form_one(){
		$this->load->view('frontend/form/form0');
	}
	public function form_two(){
		$this->load->view('frontend/form/form1');
	}
	public function form_three(){
		$this->load->view('frontend/form/form2');
	}

	public function user_data(){
		$getDate = $this->common_model->solveCustomQuery("SELECT id,created_date,first_name,last_name,emailid,lms_id,subscription_plan_id FROM `user` where status=1 and role_type = 3  and created_date <>'0000-00-00' order by created_date desc");
		$data['res_data'] = array();
		$data['title'] = "List";
		
		if(!empty($getDate)){
			foreach($getDate as $us_value){
				$return = $this->calculate_date($us_value->created_date);
				if(!empty($return['week']) && $return['week'] > 5 && $return['week'] <=20){
					$data['res_data'][] = array(
						'lms_id' => $us_value->lms_id,
						'emailid' => $us_value->emailid,
						'name'   => $us_value->first_name." ".$us_value->last_name,
						'week'   => $return['week'],
						'day'    => $return['day']
					);
				}
			}
		}
		$this->load->view('frontend/form/user_list',$data);
	}

	

}