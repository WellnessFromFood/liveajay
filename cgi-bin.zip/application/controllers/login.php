<?php 
if(!defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {
    public $data = array();
    public function __construct()
	{
        parent::__construct();
		$this->load->model('login_model','login');
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
        $this->output->set_header('Pragma: no-cache');
    }

    public function index()
	{
		$this->load->helper('captcha');
		$vals = array(
				'img_path'	=> './uploads/captcha/',
				'img_url'	=> site_url('uploads/captcha').'/',
				'font_path'  => './assets/css/ROCKBI.TTF',
				'img_width'  => 200,
				'img_height' => 50);			
		$cap = create_captcha($vals);
		$this->data['Captcha'] = $cap['image'];
		$this->session->set_userdata('Captcha',$cap['word']);
		$this->data['act'] = base_url('login/verifyLogin');
		$this->data['actRegister'] = base_url('login/save');
		$this->load->view('login_view', $this->data);
    }
     
    public function verifyLogin(){
		if($this->_validData()){
			redirect('index');
		}else{
			return $this->index();
        }
    }
	
	public function save()
	{		
		$time = time();		
		$this->data = array(
				'first_name' => $this->input->post('first_name'),
				'middle_name' => $this->input->post('middle_name'),
				'last_name' => $this->input->post('last_name'),
				'emailid' => $this->input->post('emailid'),
				'password' => md5($this->input->post('password')),
				'contact_no' => $this->input->post('contact_no'),
				'added_at' => $time,
				'status' => '1',
				'updated_at' => $time);
					
		if($this->_validRegisterData())
		{
			if((bool)$this->common_model->save('user',$this->data) === TRUE)
			{					
				$this->msg = array('msg'=>lang('RECORD_SAVED'), 'msg_type'=>'success');
				$this->session->set_flashdata($this->msg);
				redirect('login/index');
			}
			else
			{
				$this->msg = array('msg'=>lang('RECORD_ERROR'), 'msg_type'=>'error');
				$this->session->set_flashdata($this->msg);
				return $this->index();
			}
		}
		else
		{
			return $this->index();
		}
	}
	
	private function _validRegisterData()
	{
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
		$this->form_validation->set_rules('emailid', 'Email', 'trim|required|valid_email|is_unique[user.emailid]');
		$this->form_validation->set_rules('contact_no', 'Mobile No', 'trim|required|integer|min_length[10]|max_length[12]');
		$this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[6]|max_length[20]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|trim|matches[password]');
		return $this->form_validation->run();
    }
	
	private function _validData(){
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        $this->form_validation->set_rules('emailid', 'Email-Id', 'required');
		$this->form_validation->set_rules('captcha', 'Captcha', 'required|callback_validate_captcha');
        $this->form_validation->set_rules('password', 'Password', 'required|callback_checkLogin');
        return $this->form_validation->run();
    }
	
	public function isEmailAvailable()
	{
		$cond=array('emailid'=>$this->input->post('Email'));
		$result=$this->common_model->getRows('user','id',$cond);
		if(!empty($result)){
			echo(json_encode(false));
		}else{
			echo(json_encode(true));
		}
	}	
	
	public function CaptchaImageChange(){
		echo $res = $this->functions->CaptchaImageChange();
	}	
	
	public function validate_captcha()
	{	
	    if(@$this->input->post('captcha') != $this->session->userdata['Captcha'])
		{
			$this->form_validation->set_message('validate_captcha', 'Wrong captcha code');
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public function checkLogin(){
        $this->data = array(
            'emailid' => $this->input->post('emailid'),
            'password' => md5($this->input->post('password')));
        $this->data['user'] = $this->login->getVerifiedLogin($this->data);
		
		if(!empty($this->data['user'])){
			$this->session->set_userdata('user', $this->data['user'][0]);
			$this->session->set_userdata('IsFrontedLoggedIn', TRUE);
            return TRUE;
        }
		$this->form_validation->set_message('checkLogin', lang('VALIDATE_LOGIN'));
		return FALSE;
    }
	
	public function logout()
	{
        if($this->session->userdata('user'))
		{
            foreach($this->session->userdata as $key=>$val)
			{
                $this->session->unset_userdata($key);
            }
			$this->session->unset_userdata('IsFrontedLoggedIn');
        }
        redirect('login');
    }
}
?>
