<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Functions{

    public $data = array();
	public $campaign = array();
	public $banner = array();
	public $user = array();
	
	
	public function do_mupload($upload_path='', $FieldName='')
	{	
		$CI =& get_instance();
        $error = array();
		if($FieldName){
			$upload_conf = array(
				'upload_path'   => realpath($upload_path),
				'allowed_types' => 'gif|jpg|png|jpeg|pdf|doc|xml|php',
				'file_name' => rand(1000, 100000000),
				'max_size'        => "1000KB"
				);
			$CI->upload->initialize($upload_conf);
			foreach($_FILES[$FieldName] as $key=>$val){
				$i = 1;
				foreach($val as $v){
					$field_name = "file_".$i;
					$_FILES[$field_name][$key] = $v;
					$file[$i] = $field_name;
					$i++; 
				}
			}
			foreach($file as $field_name){
				if ( ! $CI->upload->do_upload($field_name)){
					$data['error'][] = $CI->upload->display_errors();
					return $data;
				}else{
					$data['success'][] = $CI->upload->data();
				}
			}
		}
		return $data;
    
    }

    public function CaptchaImageChange(){
		$CI =& get_instance();
		$CI->load->helper('captcha');
		$vals = array(
				'img_path'	=> 'uploads/captcha/',
				'img_url'	=> site_url('uploads/captcha').'/',
				'font_path'  => './assets/css/ROCKBI.TTF',
				'img_width'  => '200',
				'img_height' => 50
				);			
		$cap = create_captcha($vals);
		$CI->data['Captcha'] = $cap['image'];
		$CI->session->unset_userdata('Captcha');
		$CI->session->set_userdata('Captcha',$cap['word']);
		$CaptchaWord=$CI->session->userdata('Captcha');
		$res=$CI->data['Captcha'].'<input type="hidden" id="CaptchaCodeNew" name="CaptchaCodeNew" value="'.$CaptchaWord.'">';
		return $res;
	}
	
	public function get_recursive_parents($category_id) {
		$CI =& get_instance();
		$category = array();
		$this->__get_recursive_parents($category_id, $category);
		krsort($category);
		$category=substr(implode($category),8);
		return $category;
	}

	public function __get_recursive_parents($id, &$output){
		$CI =& get_instance();
		$res=$CI->common_model->getRow('stbl_category','page_name,id,parent_id',array('id'=>$id));
		$output[] = " &raquo ".$res->page_name;
		if ($res->parent_id) {    
			$this->__get_recursive_parents($res->parent_id, $output);
		}
	}	
	public function do_upload($upload_path='', $FileName='')
	{
	    //echo 'upload from Functions is called'; 
		$CI =& get_instance();
		$config['upload_path'] = $upload_path;
		$config['allowed_types'] = 'gif|jpg|png|pdf|mp4|wma';
		$config['file_name'] = rand(1000, 10000000);
		$config['max_size'] = 2048000000;
		$config['width']     = 280;
		$config['height']   = 380;
		$CI->load->library('upload');	
		$CI->upload->initialize($config);
		if (!$CI->upload->do_upload($FileName)){
			$CI->updata = array('msg' => $CI->upload->display_errors(), 'res' => FALSE);	
		}else{				
			$CI->updata = array('upload_data' => $CI->upload->data(), 'res' => TRUE);
			if(file_exists($CI->input->post('image_path'))){
				unlink($CI->input->post('image_path'));
			}
		}
		return $CI->updata;
    }
	public function do_file_upload($upload_path='', $FileName='')
	{
		$CI =& get_instance();
		$config['upload_path'] = $upload_path;
		$config['allowed_types'] = '*';
		$config['file_name'] = rand(1000, 100000000);
		$CI->load->library('upload');	
		$CI->upload->initialize($config);
		if (!$CI->upload->do_upload($FileName)){
			$CI->updata = array('msg' => $CI->upload->display_errors(), 'res' => FALSE);	
		}else{				
			$CI->updata = array('upload_data' => $CI->upload->data(), 'res' => TRUE);
			if(file_exists($CI->input->post('image_path'))){
				unlink($CI->input->post('image_path'));
			}
		}
		return $CI->updata;
    }
	public function drawPagination($count=0,$start=0,$limit_from=0,$limit=0,$url_cond=''){
		$site_url=(is_numeric(basename(current_url())))?(dirname(current_url())):(current_url());	
		$CI =& get_instance();
		$config=array('base_url'=>$site_url,'reuse_query_string'=>TRUE,'total_rows'=>$count,'per_page'=>$limit,'cur_page'=>$start,'uri_segment'=>5,'full_tag_open'=>'<li class="paginate_button active">','full_tag_close'=>'</li>','first_link'=> 'First','first_tag_open'=>'<li>','first_tag_close'=>'</li>','last_link'=>'Last','last_tag_open'=>'<li>','last_tag_close'=>'</li>','next_tag_open'=> '<li>','next_link'=>'&gt;','next_tag_close'=>'</li>','prev_tag_open'=>'<li>','prev_link'=>'&lt;','prev_tag_close'=>'</li>','cur_tag_open'=>'<li class="paginate_button active"><a href="javascript:void(0);">','cur_tag_close'=>'</a></li>','num_tag_open'=>'<li>','num_tag_close'=>'</li>');
		$CI->load->library('pagination');
		$CI->pagination->initialize($config);
		$totalPages=$count/$limit;
		if($limit_from){ 
			$page=($count-$limit_from)/$limit;
		}else{ 
			$page=$count/($limit_from+1);
		}
		if(is_float($totalPages)){ 
			$totalPages = intVal($totalPages)+1;
		}else{ 
			$totalPages = intVal($totalPages);
		}
		$page = ($totalPages-$page);
		if($page>0)	
		{
			if(is_float($page)){ 
				$page = intVal($page)+1;
			}else{ 
				$page = intVal($page);
			}
		}else{
			$page=1;
		}
		$pagination='Showing '.$page.' to '.$totalPages.' of '.$count.' entries';
		return $pagination;
	}
	public function get_message_name($id)
	{

		$CI =& get_instance();
		$net_gram_name = $CI->common_model->getCustomFielddata('messagecenterposttable','Message',array('MessageID'=>$id));			
				return $net_gram_name;				
	}

	public function get_userEmail($id)
	{

		$CI =& get_instance();
		$email = $CI->common_model->getCustomFielddata('user','emailid',array('id'=>$id));	return $email;				
	}

}
?>