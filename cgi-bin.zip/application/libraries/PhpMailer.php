<?php defined('BASEPATH') OR exit('No direct script access allowed');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require APPPATH.'third_party/phpmailer/src/Exception.php';
require APPPATH.'third_party/phpmailer/src/PHPMailer.php';
require APPPATH.'third_party/phpmailer/src/SMTP.php';


class PhpMailer{

	function __construct()
	{
		$this->mail = new PHPMailer(true);
	}



	public function sendMail(){

		try {
		    //Server settings
		    //$this->mail->SMTPDebug = 2;                                 // Enable verbose debug output
		    $this->mail->isSMTP();                                      // Set mailer to use SMTP
		    $this->mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
		    $this->mail->SMTPAuth = true;                               // Enable SMTP authentication
		    $this->mail->Username = 'manish.stercodigitex@gmail.com';                 // SMTP username
		    $this->mail->Password = 'manish@stercodigitex.com';                           // SMTP password
		    $this->mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
		    $this->mail->Port = 587;                                    // TCP port to connect to

		    //Recipients
		    $this->mail->setFrom('manish@stercodigitex.com', 'Mailer');
		    $this->mail->addAddress('manish.stercodigitex@gmail.com', 'Joe User');     // Add a recipient
		    $this->mail->addAddress('ellen@example.com');               // Name is optional
		    $this->mail->addReplyTo('info@example.com', 'Information');
		    $this->mail->addCC('cc@example.com');
		    $this->mail->addBCC('bcc@example.com');

		    //Attachments
		    $this->mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
		    $this->mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

		    //Content
		    $this->mail->isHTML(true);                                  // Set email format to HTML
		    $this->mail->Subject = 'Here is the subject';
		    $this->mail->Body    = 'This is the HTML message body <b>in bold!</b>';
		    $this->mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

		    $this->mail->send();
		    echo 'Message has been sent';
		} catch (Exception $e) {
    		echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
		}
	}

	
}

