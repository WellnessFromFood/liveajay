<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//echo "ffffff";die;

class Talentlmsapi{



    public $data = array();

	

	
    	public function forAll($id){
			require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
			TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
			TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');
			return TalentLMS_User::retrieve($id);
		}
		public function lmssignup($getuserdata,$plantype,$remove)

		{ 			

			$CI =& get_instance();	

			require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";

			TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');

			if($plantype=='Normal')

			{

				TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');

				$branch_id=4;

				$group_id=9;

				$group_key ='B8sm3YW6k';

			}

			else

			{

				TalentLMS::setDomain('healthtransitionsuniversity.talentlms.com');

				$branch_id=5;

				$group_id=10;

				$group_key ='jp58pMhSr';

			}



			if($remove==true)

			{

				$get_lms_id = $CI->common_model->getRow('user','lms_id,group_lms_id',array('status'=>'1','id'=>$getuserdata->id));

				if(!empty($get_lms_id))

				{

					try {

					$removeuser=TalentLMS_Branch::removeUser(array('user_id' =>$get_lms_id->lms_id, 'branch_id' =>$branch_id));

					$removegroup=TalentLMS_Group::removeUser(array('user_id' =>$get_lms_id->lms_id, 'group_id' =>$get_lms_id->group_lms_id));

					}

					catch(Exception $e) {

  						echo "Data-LMS-1".'Message: ' .$e->getMessage();

						}





					try {

							if(!empty($removeuser) && !empty($removegroup))

							{

								TalentLMS_Branch::addUser(array('user_id'=>$get_lms_id->lms_id, 

									'branch_id' =>$branch_id));

								TalentLMS_Group::addUser(array('user_id'=>$get_lms_id->lms_id, 

									'group_key' =>$group_key));

							}



						}

						catch(Exception $e) {

	  						echo "Data-LMS-2".'Message: ' .$e->getMessage();

						}

					}



			} 

			else

			 {

				$expemailid = explode('@',$getuserdata->emailid);

				$info =array(

				

				'first_name'=>$getuserdata->first_name,

				'last_name'=>($getuserdata->last_name != '') ? $getuserdata->last_name : 'Last Name',

				'email' =>trim($getuserdata->emailid),

				'user_type'=>'intro',

				'status'=>'active',

				'created_on'=>date('Y-m-d H:i:s'),

				'login' =>$getuserdata->emailid,

				'password' => $expemailid[0],
				'custom_field_1' => 'WellnessFromFood',
				);



				$usersignup =TalentLMS_User::signup($info);



				if(!empty($usersignup))

				{

				$info1 = array(

					'user_id'=> $usersignup['id'],

			    	'branch_id' => $branch_id

				);

				TalentLMS_Branch::addUser($info1);



				$group_val= array(

					'user_id'=>$usersignup['id'],

					'group_key' =>$group_key

				);

				$group_info = TalentLMS_Group::addUser($group_val);



				$created_on = explode(',',$usersignup['created_on']);			
//echo '<pre>'; echo '$usersignup is '; print_r($usersignup);
//echo '<pre>'; echo 'Inside TalentAPI and Created_on is '; print_r($created_on);
//$newTime = date('Y-m-d H:i:s',strtotime(date('Y-m-d H:i:s'),$created_on[0]." ".$created_on[1]));
//echo '$newTime is ' . $newTime; die;

//Wbp update - 9/4/2020
//From the tests that I ran, it looks like we have an issue with this original line:
//  'lms_created_date'=>date('Y-m-d H:i:s',strtotime(date('Y-m-d H:i:s'),$created_on[0]." ".$created_on[1]))),
//  Specifically - 
//
//  'lms_created_date'=>$created_on[0]." ".$created_on[1]  - that will provide a text date.
//  If we need a timestamp, then we will use the strtotime function

				$updateinfo = $CI->common_model->update("user",

				array('lms_id'=>$usersignup['id'],

					'group_lms_id'=>$group_info['group_id'],

					'group_lms_name'=>$group_info['group_name'],

					'lms_created_date'=>$created_on[0]." ".$created_on[1]),

				array('id'=>$getuserdata->id));



				}



			}



			return true;

		}





	public function directloginLMS(){

		try{

		$emailid = base64_decode($this->uri->segment(3));

		$getsessid = base64_decode($this->uri->segment(4));

		require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";

		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');

		if($getsessid==1)

		{

			TalentLMS::setDomain('diy-healthtransitionsuniversity.talentlms.com');

		}

		else

		{

			TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');

		}

		$expemailid = explode('@',$emailid);

		if(isset($expemailid) && ($expemailid !=''))

		{

			$response = TalentLMS_User::login(

				array(

				'login' =>trim($emailid), 

				'password'=>trim($expemailid[0]),

				'logout_redirect' =>base_url('loginsignup/logout')));



		}

		if(!empty($response))

		{

			$login_key = '';

			if(isset($getsessid))

			{

				if($getsessid == 2)

				{

					$login_key = 'https://premium-'.explode('://',$response['login_key'])[1];

				}else{



					$login_key = 'https://diy-'.explode('://',$response['login_key'])[1];	

				}	

			}

			

			if($login_key !='')

			{

				$this->redirect($login_key);	

			}

			

		}



		}catch(Exception $e) {

			echo "Password not match".'Message: ' .$e->getMessage();



		}

	}

}

?>