<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    
    function __construct()
	{
	    //parent::__construct();
        echo 'This called'; die;
        require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
    }

/*   
    class apiLimit
{
    public $numberOfCallsLeft;
    public $timeOfNextReset;
    
}
 */   
    
    function getNumberOfApiCallsLeftThisHour()
    {
       //This will return an apiLimit object - that will contain two pieces of data:
       //   the number of api calls left in this hour
       //   the number of minutes when the hour is up - and the apis will refresh
       
       require_once APPPATH."third_party/talentlms/lib/TalentLMS.php";
		TalentLMS::setApiKey('K9NRbBn1aSGu7n9tnileKWNM4HW7z4');
       //echo 'APPPATH is ' . APPPATH;
       
        TalentLMS::setDomain('premium-healthtransitionsuniversity.talentlms.com');
        //make a call to the api to force the cache to get reset
        $user_data = TalentLMS_User::retrieve(1);
        $sendInBlueApiLimit = TalentLMS_Siteinfo::getRateLimit();
        $date = date('d-m-y G:i:s');
        $nextUpdateIn = strtotime($sendInBlueApiLimit['formatted_reset']) - strtotime($date); 
       
       $thisApiLimit = new apiLimit();
       $thisApiLimit->numberOfCallsLeft = $sendInBlueApiLimit['remaining'];
       $thisApiLimit->timeOfNextReset = date("i:s", $nextUpdateIn);
       
       return $thisApiLimit;
   }
?>