<?php

defined('BASEPATH') OR exit('No direct script access allowed');
	
	function calculate_TheWeek($get_created_date)
	{
				
				$days_info=array();

				$date1 = date('Y-m-d H:i:s');
				$date2 =  $get_created_date;
				
				
				
				//echo 'Input = '. $get_created_date;
				
				$diff = strtotime($date1) - strtotime($date2);
				$days = $diff/ (60*60*24);
				
				//echo '$days is ' . $days; die;

                //Use the modulus operator to get the remaining days
                $remainingDays = $days % 7;

                // handle if we are a week or larger
				if($days > 6)
				{
					$numberOfWeeks = intval($days/7);
					
					//echo '$numberOfWeeks is ' . $numberOfWeeks . '<br>';
					//echo '$remainingDays is ' . $remainingDays . '<br>';
					if($remainingDays==0)
					{
						$days_info['day']=7;
						$days_info['week'] = $numberOfWeeks;                              
					}
					else
					{
						$days_info['day'] = $remainingDays;
						$days_info['week'] = $numberOfWeeks + 1;                                           
					}
					
				}
				else
				// This when it is less than a week.
				{
				    //This is when it is less than a day
				    if ($days < 1)
				    {
				        //one more check.  It may be less than a day, but did we cross our day boundry, if so,
				        //  then it is day 1
				        
				        //echo 'Sorry - temporary testing in progress - System should be available soon <br>';
				        //echo '$date2 is '. $date2 . '<br>';
				        if (false)
				        {
				            
				        }
				        else
				        {
				            $days_info['day'] = 0;
					        $days_info['week']= '1';
				        }
				    }
    				else
    				{
    					$days_info['day'] = $remainingDays;
    					$days_info['week']= '1';
    				}
				}
				//echo '<pre>'; print_r($days_info);die;
				return $days_info;
	}
	
	function addDurationToTotal($newDuration,$total='')
	{
	    //echo "inside the function";
	    $totalD=0;
	    $totalH=0;
	    $totalM=0;
	    $totalS=0;
	    $remainingHrs = 0;
	    $remainingMins = 0;
	    $remainingSecs = 0;
	    
	    
		if (empty($total))
		{
		    return $newDuration;
		}
		else
		{
		    //split up the $total first
		    $totalParts = explode(' ', $total);
		    
		    //break apart the Total
		    foreach($totalParts as $thisPart)
		    {
		        //get the last character of each part to determine what it stands for (days, Hours, minutes, seconds)
		        $startingAt = strlen($thisPart) - 1;
		        $partType = substr($thisPart, $startingAt);
		        $num = substr($thisPart, 0, $startingAt);
		        
		        
		        switch ($partType)
		        {
		          case "d":
		                //echo '$num is ' . $num;
		                $totalD = $num;
		                break;
		                
		          case "h":
		                //echo '$num is ' . $num;
		                $totalH = $num;
		                break;
		                
		          case "m":
		                //echo '$num is ' . $num;
		                $totalM = $num;
		                break;
		                
		          case "s":
		                //echo '$num is ' . $num;
		                $totalS = $num;
		                break;
		                
		          default:
		               echo '$partType is '. $partType;
		            
		        } 
		    }
		    
		    //now split up the $newDuration
		    $newDurationParts = explode(' ', $newDuration);
		    
		    //Now break apart the newDuration
		    foreach($newDurationParts as $thisPart)
		    {
		        //get the last character of each part to determine what it stands for (days, Hours, minutes, seconds)
		        $startingAt = strlen($thisPart) - 1;
		        $partType = substr($thisPart, $startingAt);
		        $num = substr($thisPart, 0, $startingAt);
		        
		        
		        switch ($partType)
		        {
		          case "d":
		                //echo '$num is ' . $num;
		                $totalD = $totalD + $num;
		                break;
		                
		          case "h":
		                //echo '$num is ' . $num;
		                $totalH = $totalH + $num;
		                break;
		                
		          case "m":
		                //echo '$num is ' . $num;
		                $totalM = $totalM + $num;
		                break;
		                
		          case "s":
		                //echo '$num is ' . $num;
		                $totalS = $totalS + $num;
		                break;
		                
		          default:
		               echo '$partType is '. $partType;
		            
		        } 
		    }
		    
		    if ($totalS > 59)
		    {
		        $additionalMins = number_format($totalS / 60,0);
		        $remainingSecs = $totalS % 60;
		        $totalM = $totalM + $additionalMins;
		    }
		    else
		    {
		        $remainingSecs = $totalS;
		    }
		    
		    if ($totalM > 59)
		    {
		        $additionalHrs = number_format($totalM / 60,0);
		        //echo "Billy check this " . $additionalHrs;
		        $remainingMins = $totalM % 60;
		        $totalH = $totalH + $additionalHrs;
		    }
		    else
		    {
		        $remainingMins = $totalM;
		    }
		    
		    if ($totalH > 23)
		    {
		        $additionalDays = number_format($totalH / 23,0);
		        $remainingHrs = $totalH % 24;
		        $totalD = $totalD+ $additionalDays;
		    }
		    else
		    {
		        $remainingHrs = $totalH;
		    }
		    
		    
		    $ans = $totalD ."d ". $remainingHrs ."h ". $remainingMins ."m ". $remainingSecs ."s"; 
		    //echo $ans;
		    return $ans;
		    
		}
	}
?>



