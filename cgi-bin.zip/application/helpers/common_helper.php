<?php

defined('BASEPATH') OR exit('No direct script access allowed');
	function staticMenushow($id,$static = 0)
	{
		$CI = & get_instance();
		if($static == 1){
			$data = $CI->common_model->getRow('dynamicDietslog','status',array('id'=>$id));
		}else
		{
			$data = $CI->common_model->getRow('dynamicDietslog','status',array('dietsPlans_id'=>$id));
		}
		return $data->status;
	}

	function enrollCustomer($user="",$week=""){
		$CI = & get_instance();
		$userdata = $CI->common_model->getRow('user','emailid',array('id'=>$user));
		$content = $CI->common_model->getRow('send_email','subject_txt,email_description',array('name'=>$week,'status'=>1));
		if(!empty($userdata) && !empty($content)){
			$email_dat = array(
				'to'=>$userdata->emailid,
				'subject'=>$content->subject_txt,
				'msg'=>$content->email_description
			);
			$CI->common_model->Send_GetStarted_Mail($email_dat);
		}	
	}
?>