<?php

defined('BASEPATH') OR exit('No direct script access allowed');
	
	class TimeDurationFromTalentLMS {
	    
	    
	    
	    
	    function TimeDurationFromTalenLMS(){
	        $this->days = '';
            $this->hours = '';
            $this->mins = '';
            $this->secs = '';
	    
	    
	    }
	
	    function addDurationToTotal($aString, $currentTotal)
	    {
	        
	       echo 'Got to addDurationToTotal - lets pause.'; die; 
	        
	       if (empty($currentTotal))
        {
            return $aString;
        }
      else
      {
          
          $currentParts = explode(' ', $currentTotal);
          echo "Adding Time an we found " . count($currentParts) . '<br>';
          foreach($currentParts as $key=>$thisPart)
          {
            // Get the last character to determine how to treat the value
            $size = strlen($thisPart);
            $timePartType = substr($thisPart, $size-1);
            
            switch ($timePartType)
            {
                case 'd':
                    echo "Found a day" . '<br>';
                    break;
                    
                case 'h':
                    echo "Found an hour". '<br>';
                    break;
                    
                case 'm':
                    echo "Found a minute". '<br>';
                    break;
                    
                case 's':
                    echo "Found a sec". '<br>';
                    break;
                
                default:
                    echo "WTF?". '<br>';
            }
            
            echo "Time part is " . $timePartType .'<br>';
            $numberValue = substr($thisPart, 0, $size -1);
            echo '$numberValue is ' . $numberValue .'<br>';
              
              
              
          }
          
      }
	        
	        
	        
	        
	        
	    }
	    
	}
?>